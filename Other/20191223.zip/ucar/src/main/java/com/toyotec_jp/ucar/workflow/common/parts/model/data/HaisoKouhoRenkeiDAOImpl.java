package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean;

/**
 * <strong>配送候補連携操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/19 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class HaisoKouhoRenkeiDAOImpl extends UcarSharedDBDAO implements HaisoKouhoRenkeiDAOIF {

	/** 配送候補連携DB取得 SQL */
	private static final String SELECT_TBJLA24M_PT_SQL
		= "SELECT "
		+ "    HAISORENKEI.CD_KAISYA "
		+ "  , HAISORENKEI.CD_HANBAITN "
		+ "  , HAISORENKEI.DD_HANNYU "
		+ "  , HAISORENKEI.NO_KANRI "
		+ "  , HAISORENKEI.DD_HISKIB "
		+ "  , HAISORENKEI.CD_NORIKUSI "
		+ "  , HAISORENKEI.KB_NOSYASYU "
		+ "  , HAISORENKEI.CD_NOGYOTAI "
		+ "  , HAISORENKEI.NO_NOSEIRI "
		+ "  , HAISORENKEI.MJ_SITKATA "
		+ "  , HAISORENKEI.NO_SYADAI "
		+ "  , HAISORENKEI.MJ_SYAMEI "
		+ "  , HAISORENKEI.CD_HSTENPO "
		+ "  , HAISORENKEI.KB_SGYOKT "
		+ "  , HAISORENKEI.MJ_SGYOKT "
		+ "  , HAISORENKEI.NO_HISIRI "
		+ "  , HAISORENKEI.MJ_BIKOU "
		+ "FROM "
		+ "  TBJLA24M_PT HAISORENKEI "
		+ "WHERE "
		+ "      HAISORENKEI.CD_KAISYA   = ? "
		+ "  AND HAISORENKEI.CD_HANBAITN = ? ";

	/** 配送候補連携DB取得 ORDER SQL */
	private static final String SELECT_TBJLA24M_PT_ORDER_SQL
		= "ORDER BY "
		+ "    HAISORENKEI.CD_KAISYA "
		+ "  , HAISORENKEI.CD_HANBAITN "
		+ "  , HAISORENKEI.DD_HANNYU "
		+ "  , HAISORENKEI.NO_KANRI ";

	/** 更新処理（ステータスDB）SQL */
	private static final String UPDATE_T220012G_SQL
		= "UPDATE T220012G "
		+ "SET "
		+ "    DT_STATUS20 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
		+ "  , DT_KOSIN    = ? "
		+ "  , CD_KSNSYA   = ? "
		+ "  , CD_KSNAPP   = ? "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 更新処理（車両搬出情報）SQL */
	private static final String UPDATE_T220013G_SQL
		= "UPDATE T220013G "
		+ "SET "
		+ "    DD_HISKIB   = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
		+ "  , NO_HISIRI   = ? "
		+ "  , MJ_HANSYTBK = ? "
		+ "  , DT_KOSIN    = ? "
		+ "  , CD_KSNSYA   = ? "
		+ "  , CD_KSNAPP   = ? "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 配送候補連携BUFFER取得 SQL */
	private static final String SELECT_T220015W_SQL
		= "SELECT "
		+ "    HAISORENKEIBUF.CD_KAISYA "
		+ "  , HAISORENKEIBUF.CD_HANBAITN "
		+ "  , HAISORENKEIBUF.DD_HANNYU "
		+ "  , HAISORENKEIBUF.NO_KANRI "
		+ "  , HAISORENKEIBUF.DD_HISKIB "
		+ "  , HAISORENKEIBUF.CD_NORIKUSI "
		+ "  , HAISORENKEIBUF.KB_NOSYASYU "
		+ "  , HAISORENKEIBUF.CD_NOGYOTAI "
		+ "  , HAISORENKEIBUF.NO_NOSEIRI "
		+ "  , HAISORENKEIBUF.MJ_SITKATA "
		+ "  , HAISORENKEIBUF.NO_SYADAI "
		+ "  , HAISORENKEIBUF.MJ_SYAMEI "
		+ "  , HAISORENKEIBUF.CD_HSTENPO "
		+ "  , HAISORENKEIBUF.KB_SGYOKT "
		+ "  , HAISORENKEIBUF.MJ_SGYOKT "
		+ "  , HAISORENKEIBUF.NO_HISIRI "
		+ "  , HAISORENKEIBUF.MJ_BIKOU "
		+ "FROM "
		+ "  T220015W HAISORENKEIBUF "
		+ "WHERE "
		+ "      HAISORENKEIBUF.CD_KAISYA   = ? "
		+ "  AND HAISORENKEIBUF.CD_HANBAITN = ? ";

	/** 削除処理（配送候補連携）SQL */
	private static final String DELETE_TBJLA24M_PT_SQL
		= "DELETE "
		+ "FROM "
		+ "  TBJLA24M_PT "
		+ "WHERE "
		+ "  CD_KAISYA       = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 削除処理（配送候補連携BUFFER）SQL */
	private static final String DELETE_T220015W_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220015W "
		+ "WHERE "
		+ "  CD_KAISYA       = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 更新処理（配送候補連携）SQL */
	private static final String UPDATE_TBJLA24M_PT_SQL
		= "UPDATE TBJLA24M_PT "
		+ "SET "
		+ "    DD_HISKIB 	= TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
		+ "  , CD_NORIKUSI 	= ? "
		+ "  , KB_NOSYASYU 	= ? "
		+ "  , CD_NOGYOTAI 	= ? "
		+ "  , NO_NOSEIRI 	= ? "
		+ "  , MJ_SITKATA 	= ? "
		+ "  , NO_SYADAI 	= ? "
		+ "  , MJ_SYAMEI 	= ? "
		+ "  , CD_HSTENPO 	= ? "
		+ "  , KB_SGYOKT 	= ? "
		+ "  , MJ_SGYOKT 	= ? "
		+ "  , NO_HISIRI 	= ? "
		+ "  , MJ_BIKOU 	= ? "
		+ "  , DT_KOSIN 	= ? "
		+ "  , CD_KSNSYA 	= ? "
		+ "  , CD_KSNAPP 	= ? "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 更新処理（配送候補連携）SQL
	 * <pre>作業仕分用</pre>
	 *  */
	private static final String UPDATE_TBJLA24M_PT_WORKSORT_SQL
		= "UPDATE TBJLA24M_PT "
		+ "SET "
		+ "    CD_NORIKUSI 	= ? "
		+ "  , KB_NOSYASYU 	= ? "
		+ "  , CD_NOGYOTAI 	= ? "
		+ "  , NO_NOSEIRI 	= ? "
		+ "  , MJ_SITKATA 	= ? "
		+ "  , NO_SYADAI 	= ? "
		+ "  , MJ_SYAMEI 	= ? "
		+ "  , CD_HSTENPO 	= ? "
		+ "  , KB_SGYOKT 	= ? "
		+ "  , MJ_SGYOKT 	= ? "
		+ "  , DT_KOSIN 	= ? "
		+ "  , CD_KSNSYA 	= ? "
		+ "  , CD_KSNAPP 	= ? "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 新規登録処理（配送候補連携）SQL */
	private static final String INSERT_TBJLA24M_PT_SQL
		= "INSERT "
		+ "INTO TBJLA24M_PT( "
		+ "    CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , DD_HANNYU "
		+ "  , NO_KANRI "
		+ "  , DD_HISKIB "
		+ "  , CD_NORIKUSI "
		+ "  , KB_NOSYASYU "
		+ "  , CD_NOGYOTAI "
		+ "  , NO_NOSEIRI "
		+ "  , MJ_SITKATA "
		+ "  , NO_SYADAI "
		+ "  , MJ_SYAMEI "
		+ "  , CD_HSTENPO "
		+ "  , KB_SGYOKT "
		+ "  , MJ_SGYOKT "
		+ "  , NO_HISIRI "
		+ "  , MJ_BIKOU "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ ") "
		+ "VALUES ( "
		+ "    ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ ") ";

	/** 更新処理（配送候補連携BUFFER）SQL */
	private static final String UPDATE_T220015W_SQL
		= "UPDATE T220015W "
		+ "SET "
		+ "    CD_NORIKUSI 	= ? "
		+ "  , DT_KOSIN 	= ? "
		+ "  , CD_KSNSYA 	= ? "
		+ "  , CD_KSNAPP 	= ? "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 更新処理（配送候補連携BUFFER）SQL
	 * <pre>作業仕分用</pre>
	 *  */
	private static final String UPDATE_T220015W_WORKSORT_SQL
		= "UPDATE T220015W "
		+ "SET "
		+ "    CD_NORIKUSI 	= ? "
		+ "  , KB_NOSYASYU 	= ? "
		+ "  , CD_NOGYOTAI 	= ? "
		+ "  , NO_NOSEIRI 	= ? "
		+ "  , MJ_SITKATA 	= ? "
		+ "  , NO_SYADAI 	= ? "
		+ "  , MJ_SYAMEI 	= ? "
		+ "  , CD_HSTENPO 	= ? "
		+ "  , KB_SGYOKT 	= ? "
		+ "  , MJ_SGYOKT 	= ? "
		+ "  , DT_KOSIN 	= ? "
		+ "  , CD_KSNSYA 	= ? "
		+ "  , CD_KSNAPP 	= ? "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? ";

	/** 新規登録処理（配送候補連携BUFFER）SQL */
	private static final String INSERT_T220015W_SQL
		= "INSERT "
		+ "INTO T220015W( "
		+ "    CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , DD_HANNYU "
		+ "  , NO_KANRI "
		+ "  , DD_HISKIB "
		+ "  , CD_NORIKUSI "
		+ "  , KB_NOSYASYU "
		+ "  , CD_NOGYOTAI "
		+ "  , NO_NOSEIRI "
		+ "  , MJ_SITKATA "
		+ "  , NO_SYADAI "
		+ "  , MJ_SYAMEI "
		+ "  , CD_HSTENPO "
		+ "  , KB_SGYOKT "
		+ "  , MJ_SGYOKT "
		+ "  , NO_HISIRI "
		+ "  , MJ_BIKOU "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ ") "
		+ "VALUES ( "
		+ "    ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ ") ";

	/** 配送候補連携 登録データ取得 SQL */
	private static final String SELECT_HAISORENKEI_SQL
		= "SELECT "
		+ "    HANNYU.CD_KAISYA "
		+ "  , HANNYU.CD_HANBAITN "
		+ "  , HANNYU.DD_HANNYU "
		+ "  , HANNYU.NO_KANRI "
		+ "  , HANNYU.CD_NORIKUSI "
		+ "  , HANNYU.KB_NOSYASYU "
		+ "  , HANNYU.CD_NOGYOTAI "
		+ "  , HANNYU.NO_NOSEIRI "
		+ "  , HANNYU.MJ_SITKATA "
		+ "  , HANNYU.NO_SYADAI "
		+ "  , HANNYU.MJ_SYAMEI "
		+ "  , HANSYUTU.CD_HSTENPO "
		+ "  , HANSYUTU.KB_SGYOKT "
		+ "  , SAGYOU.MJ_SGYOKT "
		+ "FROM "
		+ "  T220001G HANNYU "
		+ "  LEFT JOIN T220013G HANSYUTU "
		+ "    ON HANNYU.CD_KAISYA = HANSYUTU.CD_KAISYA "
		+ "    AND HANNYU.CD_HANBAITN = HANSYUTU.CD_HANBAITN "
		+ "    AND HANNYU.DD_HANNYU = HANSYUTU.DD_HANNYU "
		+ "    AND HANNYU.NO_KANRI = HANSYUTU.NO_KANRI "
		+ "  LEFT JOIN T220014M SAGYOU "
		+ "    ON HANSYUTU.CD_KAISYA = SAGYOU.CD_KAISYA "
		+ "    AND HANSYUTU.CD_HANBAITN = SAGYOU.CD_HANBAITN "
		+ "    AND HANSYUTU.KB_SGYOKT = SAGYOU.KB_SGYOKT "
		+ "WHERE "
		+ "      HANNYU.CD_KAISYA   = ? "
		+ "  AND HANNYU.CD_HANBAITN = ? "
		+ "  AND HANNYU.DD_HANNYU   = ? "
		+ "  AND HANNYU.NO_KANRI    = ? ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#selectTbjla24mCount(java.lang.String, java.lang.String)
	 */
	@Override
	public int selectTbjla24mCount(String cdKaisya, String cdHanbaitn)
			throws TecDAOException {

		int count = 0;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_TBJLA24M_PT_SQL);

			// パラメータセット<条件>
			paramBean.setString(cdKaisya);		// 会社コード
			paramBean.setString(cdHanbaitn);	// 販売店コード

			// 取得
			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#getHaisoKouhoRenkeiList()
	 */
	@Override
	public ResultArrayList<Tbjla24mBean> selectTbjla24m(String cdKaisya,
			String cdHanbaitn) throws TecDAOException {

		return selectTbjla24m(cdKaisya, cdHanbaitn, null, null, true);
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#selectTbjla24m(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Tbjla24mBean> selectTbjla24m(String cdKaisya,
														String cdHanbaitn,
														String ddHannyu,
														String noKanri,
														boolean isNotNullDdHiskib) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder selectSql = new StringBuilder(SELECT_TBJLA24M_PT_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード

		if (!StringCheckUtils.isEmpty(ddHannyu)) {
			selectSql.append("  AND HAISORENKEI.DD_HANNYU = ? ");
			paramBean.setString(ddHannyu);	// 搬入日
		}
		if (!StringCheckUtils.isEmpty(noKanri)) {
			selectSql.append("  AND HAISORENKEI.NO_KANRI = ? ");
			paramBean.setString(noKanri);	// 管理番号
		}

		if (isNotNullDdHiskib) {
			selectSql.append("  AND HAISORENKEI.DD_HISKIB IS NOT NULL ");
		}

		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_TBJLA24M_PT_ORDER_SQL);

		ResultArrayList<Tbjla24mBean> selectList
			= executeSimpleSelectQuery(paramBean, Tbjla24mBean.class);

		return selectList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#updateT220012g(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean)
	 */
	@Override
	public SimpleExecuteResultBean updateT220012g(Ucab007gBean t220012gBean,
													Timestamp executeDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220012G_SQL);

		// パラメータセット<値>
		paramBean.setString(DateUtils.dateToString(t220012gBean.getDtStatus20(),
							DateUtils.FORMAT_LONG_SPACE));	// ステータス20

		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220012gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220012gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gBean.getNoKanri());		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#updateT220013g(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac001gBean)
	 */
	@Override
	public SimpleExecuteResultBean updateT220013g(Ucac001gBean t220013gBean,
			Timestamp executeDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220013G_SQL);

		// パラメータセット<値>
		paramBean.setString(DateUtils.dateToString(t220013gBean.getDdHiskib(),
							DateUtils.FORMAT_LONG_SPACE));	// 配送希望日

		paramBean.setString(t220013gBean.getNoHisiri());	// 配送依頼№
		paramBean.setString(t220013gBean.getMjHansytbk());	// 配送備考

		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220013gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220013gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220013gBean.getNoKanri());		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#selectT220015w()
	 */
	@Override
	public ResultArrayList<Ucac003wBean> selectT220015w(String cdKaisya,
			String cdHanbaitn) throws TecDAOException {
		return selectT220015w(cdKaisya, cdHanbaitn, null);
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#selectT220015w()
	 */
	@Override
	public ResultArrayList<Ucac003wBean> selectT220015w(String cdKaisya,
			String cdHanbaitn,
			String cdNorikusi)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder selectSql = new StringBuilder(SELECT_T220015W_SQL);

		// パラメータセット<条件>
		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

		if (!StringCheckUtils.isEmpty(cdNorikusi)) {
			selectSql.append("  AND RTRIM(HAISORENKEIBUF.CD_NORIKUSI) = ? ");
			paramBean.setString(cdNorikusi);		// 登録NO陸支コード
		}

		paramBean.setSql(selectSql.toString());

		ResultArrayList<Ucac003wBean> selectList
			= executeSimpleSelectQuery(paramBean, Ucac003wBean.class);

		return selectList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#selectT220015w(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Ucac003wBean> selectT220015w(String cdKaisya,
			String cdHanbaitn, String ddHannyu, String noKanri)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder selectSql = new StringBuilder(SELECT_T220015W_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード

		if (!StringCheckUtils.isEmpty(ddHannyu)) {
			selectSql.append("  AND HAISORENKEIBUF.DD_HANNYU = ? ");
			paramBean.setString(ddHannyu);		// 搬入日
		}
		if (!StringCheckUtils.isEmpty(noKanri)) {
			selectSql.append("  AND HAISORENKEIBUF.NO_KANRI = ? ");
			paramBean.setString(noKanri);		// 管理番号
		}

		paramBean.setSql(selectSql.toString());

		ResultArrayList<Ucac003wBean> selectList
			= executeSimpleSelectQuery(paramBean, Ucac003wBean.class);

		return selectList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#deleteTbjla24m(com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean)
	 */
	@Override
	public SimpleExecuteResultBean deleteTbjla24m(String cdKaisya,
													String cdHanbaitn,
													String ddHannyu,
													String noKanri) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_TBJLA24M_PT_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHannyu);		// 搬入日
		paramBean.setString(noKanri);		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#deleteT220015w(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220015w(String cdKaisya,
													String cdHanbaitn,
													String ddHannyu,
													String noKanri) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220015W_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHannyu);		// 搬入日
		paramBean.setString(noKanri);		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#insertTbjla24m(com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean)
	 */
	@Override
	public SimpleExecuteResultBean insertTbjla24m(Tbjla24mBean tbjla24mBean,
			Timestamp executeDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_TBJLA24M_PT_SQL);

		// パラメータセット<条件>
		paramBean.setString(tbjla24mBean.getCdKaisya());	// 会社コード
		paramBean.setString(tbjla24mBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(tbjla24mBean.getDdHannyu());	// 搬入日
		paramBean.setString(tbjla24mBean.getNoKanri());		// 管理番号

		// 配送希望日
		if (tbjla24mBean.getDdHiskib() == null) {
			paramBean.setString(null);
		} else {
			paramBean.setString(DateUtils.dateToString(tbjla24mBean.getDdHiskib(),
														DateUtils.FORMAT_LONG_SPACE));
		}
		paramBean.setString(tbjla24mBean.getCdNorikusi());	// 登録NO陸支コード
		paramBean.setString(tbjla24mBean.getKbNosyasyu());	// 登録NO車種区分
		paramBean.setString(tbjla24mBean.getCdNogyotai());	// 登録NO業態コード
		paramBean.setString(tbjla24mBean.getNoNoseiri());	// 登録NO整理番号
		paramBean.setString(tbjla24mBean.getMjSitkata());	// 指定型式
		paramBean.setString(tbjla24mBean.getNoSyadai());	// 車台番号
		paramBean.setString(tbjla24mBean.getMjSyamei());	// 車名
		paramBean.setString(tbjla24mBean.getCdHstenpo());	// 配車店舗コード
		paramBean.setString(tbjla24mBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(tbjla24mBean.getMjSgyokt());	// 作業工程名称
		paramBean.setString(tbjla24mBean.getNoHisiri());	// 配送依頼№
		paramBean.setString(tbjla24mBean.getMjBikou());		// 配送備考
		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(tbjla24mBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(tbjla24mBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(tbjla24mBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(tbjla24mBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#updateTbjla24m(com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean)
	 */
	@Override
	public SimpleExecuteResultBean updateTbjla24m(Tbjla24mBean tbjla24mBean,
			Timestamp executeDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_TBJLA24M_PT_SQL);

		// パラメータセット<値>
		// 配送希望日
		if (tbjla24mBean.getDdHiskib() == null) {
			paramBean.setString(null);
		} else {
			paramBean.setString(DateUtils.dateToString(tbjla24mBean.getDdHiskib(),
														DateUtils.FORMAT_LONG_SPACE));
		}
		paramBean.setString(tbjla24mBean.getCdNorikusi());	// 登録NO陸支コード
		paramBean.setString(tbjla24mBean.getKbNosyasyu());	// 登録NO車種区分
		paramBean.setString(tbjla24mBean.getCdNogyotai());	// 登録NO業態コード
		paramBean.setString(tbjla24mBean.getNoNoseiri());	// 登録NO整理番号
		paramBean.setString(tbjla24mBean.getMjSitkata());	// 指定型式
		paramBean.setString(tbjla24mBean.getNoSyadai());	// 車台番号
		paramBean.setString(tbjla24mBean.getMjSyamei());	// 車名
		paramBean.setString(tbjla24mBean.getCdHstenpo());	// 配車店舗コード
		paramBean.setString(tbjla24mBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(tbjla24mBean.getMjSgyokt());	// 作業工程名称
		paramBean.setString(tbjla24mBean.getNoHisiri());	// 配送依頼№
		paramBean.setString(tbjla24mBean.getMjBikou());		// 配送備考
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(tbjla24mBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(tbjla24mBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(tbjla24mBean.getCdKaisya());	// 会社コード
		paramBean.setString(tbjla24mBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(tbjla24mBean.getDdHannyu());	// 搬入日
		paramBean.setString(tbjla24mBean.getNoKanri());		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#updateTbjla24mWorkSort(com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateTbjla24mWorkSort(
			Tbjla24mBean tbjla24mBean, Timestamp executeDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_TBJLA24M_PT_WORKSORT_SQL);

		// パラメータセット<値>
		paramBean.setString(tbjla24mBean.getCdNorikusi());	// 登録NO陸支コード
		paramBean.setString(tbjla24mBean.getKbNosyasyu());	// 登録NO車種区分
		paramBean.setString(tbjla24mBean.getCdNogyotai());	// 登録NO業態コード
		paramBean.setString(tbjla24mBean.getNoNoseiri());	// 登録NO整理番号
		paramBean.setString(tbjla24mBean.getMjSitkata());	// 指定型式
		paramBean.setString(tbjla24mBean.getNoSyadai());	// 車台番号
		paramBean.setString(tbjla24mBean.getMjSyamei());	// 車名
		paramBean.setString(tbjla24mBean.getCdHstenpo());	// 配車店舗コード
		paramBean.setString(tbjla24mBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(tbjla24mBean.getMjSgyokt());	// 作業工程名称
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(tbjla24mBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(tbjla24mBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(tbjla24mBean.getCdKaisya());	// 会社コード
		paramBean.setString(tbjla24mBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(tbjla24mBean.getDdHannyu());	// 搬入日
		paramBean.setString(tbjla24mBean.getNoKanri());		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#insertT220015w(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean insertT220015w(Ucac003wBean t220015wBean,
			Timestamp executeDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220015W_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220015wBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220015wBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220015wBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220015wBean.getNoKanri());		// 管理番号

		// 配送希望日
		if (t220015wBean.getDdHiskib() == null) {
			paramBean.setString(null);
		} else {
			paramBean.setString(DateUtils.dateToString(t220015wBean.getDdHiskib(),
														DateUtils.FORMAT_LONG_SPACE));
		}
		paramBean.setString(t220015wBean.getCdNorikusi());	// 登録NO陸支コード
		paramBean.setString(t220015wBean.getKbNosyasyu());	// 登録NO車種区分
		paramBean.setString(t220015wBean.getCdNogyotai());	// 登録NO業態コード
		paramBean.setString(t220015wBean.getNoNoseiri());	// 登録NO整理番号
		paramBean.setString(t220015wBean.getMjSitkata());	// 指定型式
		paramBean.setString(t220015wBean.getNoSyadai());	// 車台番号
		paramBean.setString(t220015wBean.getMjSyamei());	// 車名
		paramBean.setString(t220015wBean.getCdHstenpo());	// 配車店舗コード
		paramBean.setString(t220015wBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(t220015wBean.getMjSgyokt());	// 作業工程名称
		paramBean.setString(t220015wBean.getNoHisiri());	// 配送依頼№
		paramBean.setString(t220015wBean.getMjBikou());		// 配送備考
		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220015wBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220015wBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220015wBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220015wBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#updateT220015w(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220015wDel(Ucac003wBean t220015wBean,
			Timestamp executeDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220015W_SQL);

		// パラメータセット<値>
		paramBean.setString(t220015wBean.getCdNorikusi());	// 登録NO陸支コード
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220015wBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220015wBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220015wBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220015wBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220015wBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220015wBean.getNoKanri());		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#updateT220015wWorkSort(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220015wWorkSort(
			Ucac003wBean t220015wBean, Timestamp executeDate)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220015W_WORKSORT_SQL);

		// パラメータセット<値>
		paramBean.setString(t220015wBean.getCdNorikusi());	// 登録NO陸支コード
		paramBean.setString(t220015wBean.getKbNosyasyu());	// 登録NO車種区分
		paramBean.setString(t220015wBean.getCdNogyotai());	// 登録NO業態コード
		paramBean.setString(t220015wBean.getNoNoseiri());	// 登録NO整理番号
		paramBean.setString(t220015wBean.getMjSitkata());	// 指定型式
		paramBean.setString(t220015wBean.getNoSyadai());	// 車台番号
		paramBean.setString(t220015wBean.getMjSyamei());	// 車名
		paramBean.setString(t220015wBean.getCdHstenpo());	// 配車店舗コード
		paramBean.setString(t220015wBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(t220015wBean.getMjSgyokt());	// 作業工程名称
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220015wBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220015wBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220015wBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220015wBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220015wBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220015wBean.getNoKanri());		// 管理番号

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF#selectHaisorenkei(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Tbjla24mBean selectHaisorenkei(String cdKaisya,
			String cdHanbaitn, String ddHannyu, String noKanri) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder selectSql = new StringBuilder(SELECT_HAISORENKEI_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHannyu);		// 搬入日
		paramBean.setString(noKanri);		// 管理番号

		paramBean.setSql(selectSql.toString());

		ResultArrayList<Tbjla24mBean> selectList
			= executeSimpleSelectQuery(paramBean, Tbjla24mBean.class);

		Tbjla24mBean tbjla24mBean = null;
		if (selectList.size() > 0) {
			tbjla24mBean = selectList.get(0);
		}

		return tbjla24mBean;
	}

}
