package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataListPagingBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckParamBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb005gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb006gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両チェックDAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/07 新規作成<br>
 * @since 1.00
 * @category [[車両チェック]]
 */
public interface CarCheckDAOIF {

	/**
	 * 入庫検査 画面出力値取得処理
	 * <pre>
	 * ページング用データ取得
	 * </pre>
	 * @param cdKaisya				会社コード
	 * @param cdHanbaitn			販売店コード
	 * @param cdHantenpo			搬入店舗コード
	 * @param carCheckParamBean		車両チェック 検索条件Bean
	 * @param isNarrowSearch		絞り込み検索
	 * @param sortOrder				ソート順
	 * @param sortParam				ソートキー
	 * @param pageNo 				ページ番号
	 * @param pageSize 				ページサイズ
	 * @throws LcmDAOException DAO例外クラス
	 */
	public CarCheckDataListPagingBean selectEnterCheckListPaging(String cdKaisya,
																String cdHanbaitn,
																// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																String cdHantenpo,
																String kbScenter,
																// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																CarCheckParamBean carCheckParamBean,
																boolean isNarrowSearch,
																String sortOrder,
																String sortParam,
																String pageNo,
																String pageSize) throws TecDAOException;

	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
	/**
	 * 入庫検査 画面出力値取得処理
	 * <pre>
	 * </pre>
	 * @param cdKaisya				会社コード
	 * @param cdHanbaitn			販売店コード
	 * @param cdHantenpo			搬入店舗コード
	 * @param ddHannyu				搬入日
	 * @param noKanri				管理番号
	 * @param isNullDdNkkns			入庫検査日の検索に検索付加条件
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<CarCheckDataBean> selectEnterCheckList(String cdKaisya,
																	String cdHanbaitn,
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																	String cdHantenpo,
																	String kbScenter,
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																	String ddHannyu,
																	String noKanri,
																	boolean isNullDdNkkns) throws TecDAOException;
	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end

	/**
	 * 件数取得処理(入庫チェックDB)
	 * @param 	t220008gBean    入庫チェックDB(店舗用)Bean
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
//	public int selectT220008GCount(T220008gBean t220008gBean) throws TecDAOException;
	public int selectT220008GCount(Uccb005gBean t220008gBean) throws TecDAOException;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

	/**
	 * 新規登録処理（入庫チェックDB）
	 * @param	t220008gBean    入庫チェックDB(店舗用)Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220008G(T220008gBean t220008gBean,
	public SimpleExecuteResultBean insertT220008G(Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（入庫チェックDB）
	 * @param	t220008gBean    入庫チェックDB(店舗用)Bean
	 * @param	nyukoDtKosin    入庫チェックDB：データ更新日時(排他チェック用)
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220008G(T220008gBean t220008gBean,
	public SimpleExecuteResultBean updateT220008G(Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													String nyukoDtKosin,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 削除処理（入庫チェックDB）
	 * @param	t220008gBean    入庫チェックDB(店舗用)Bean
	 * @param	nyukoDtKosin    入庫チェックDB：データ更新日時(排他チェック用)
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean deleteT220008G(T220008gBean t220008gBean,
	public SimpleExecuteResultBean deleteT220008G(Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String t220013gDtKosin) throws TecDAOException;

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/**
	 * 新規登録処理（ステータスDB）
	 * @param	t220012gInputDataBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean insertT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（ステータスDB）入庫検査用
	 * @param	t220012gInputDataBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220012GEnterCheck(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean updateT220012GEnterCheck(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（ステータスDB）作業仕分用
	 * @param	t220012gInputDataBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220012GWorkSort(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean updateT220012GWorkSort(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															Timestamp executeDate) throws TecDAOException;
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	/**
	 * 作業仕分 画面出力値取得処理
	 * <pre>
	 * ページング用データ取得
	 * </pre>
	 * @param cdKaisya				会社コード
	 * @param cdHanbaitn			販売店コード
	 * @param cdHantenpo			搬入店舗コード
	 * @param carCheckParamBean		車両チェック 検索条件Bean
	 * @param isNarrowSearch		絞り込み検索
	 * @param sortOrder				ソート順
	 * @param sortParam				ソートキー
	 * @param pageNo 				ページ番号
	 * @param pageSize 				ページサイズ
	 * @throws LcmDAOException DAO例外クラス
	 */
	public CarCheckDataListPagingBean selectWorkSortListPaging(String cdKaisya,
																String cdHanbaitn,
																// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																String cdHantenpo,
																String kbScenter,
																// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																CarCheckParamBean carCheckParamBean,
																boolean isNarrowSearch,
																String sortOrder,
																String sortParam,
																String pageNo,
																String pageSize) throws TecDAOException;

	/**
	 * 件数取得処理(仕分作業DB)
	 * @param 	t220009gBean    仕分作業DB(店舗用)Bean
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
//	public int selectT220009GCount(T220009gBean t220009gBean) throws TecDAOException;
	public int selectT220009GCount(Uccb006gBean t220009gBean) throws TecDAOException;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

	/**
	 * 新規登録処理（仕分作業DB）
	 * @param	t220009gBean    仕分作業DB(店舗用)Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220009G(T220009gBean t220009gBean,
	public SimpleExecuteResultBean insertT220009G(Uccb006gBean t220009gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（仕分作業DB）
	 * @param	t220009gBean    仕分作業DB(店舗用)Bean
	 * @param	siwakeDtKosin   仕分作業DB：データ更新日時(排他チェック用)
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220009G(T220009gBean t220009gBean,
	public SimpleExecuteResultBean updateT220009G(Uccb006gBean t220009gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String siwakeDtKosin,
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 削除処理（仕分作業DB）
	 * @param	t220009gBean    仕分作業DBBean
	 * @param	siwakeDtKosin   仕分作業DB：データ更新日時(排他チェック用)
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean deleteT220009G(T220009gBean t220009gBean,
	public SimpleExecuteResultBean deleteT220009G(Uccb006gBean t220009gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String siwakeDtKosin) throws TecDAOException;

	/**
	 * 件数取得処理(車両搬出情報DB)
	 * @param	t220013gBean    車両搬出情報Bean
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
//	public int selectT220013GCount(T220013gBean t220013gBean) throws TecDAOException;
	public int selectT220013GCount(Uccb009gBean t220013gBean) throws TecDAOException;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

	// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため start
	/**
	 * 車両搬出情報取得処理(車両搬出情報DB)
	 * @param	t220013gBean    車両搬出情報Bean
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Uccb009gBean> selectT220013G(Uccb009gBean t220013gBean) throws TecDAOException;
	// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため end

	/**
	 * 新規登録処理（車両搬出情報）
	 * @param	t220013gBean    車両搬出情報Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean insertT220013G(Uccb009gBean t220013gBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（車両搬出情報）
	 * @param	t220013gBean    車両搬出情報(店舗用)Bean
	 * @param	hansyutuDtKosin 車両搬出情報：データ更新日時(排他チェック用)
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean updateT220013G(Uccb009gBean t220013gBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
													String hansyutuDtKosin,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 加修フラグ取得処理(作業工程マスタ)
	 * @param 	cdKaisya    会社コード
	 * @param  cdHanbaitn  販売店コード
	 * @param 	kbSgyokt    作業工程区分
	 * @return 加修フラグ
	 * @throws LcmDAOException DAO例外クラス
	 */
	public String selectKbKasyu(String cdKaisya,
								String cdHanbaitn,
								String kbSgyokt) throws TecDAOException;

}
