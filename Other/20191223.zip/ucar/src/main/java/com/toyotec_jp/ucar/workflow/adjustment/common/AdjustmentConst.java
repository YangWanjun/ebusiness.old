package com.toyotec_jp.ucar.workflow.adjustment.common;

import com.toyotec_jp.im_common.TecApplicationManager.TecApplicationIdIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecServiceIdIF;
import com.toyotec_jp.ucar.UcarApplicationManager;

/**
 * <strong>精算関連共通定数管理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[精算(共通)]]
 */
public class AdjustmentConst {

	/** パッケージカテゴリ:精算 */
	public static final String PKG_CAT_ADJUSTMENT = ".adjustment";

	/** 精算関連パッケージルート */
	public static final String ADJUSTMENT_ROOT
		= UcarApplicationManager.WF_ROOT + PKG_CAT_ADJUSTMENT;

	/** 売上精算パッケージルート */
	public static final String SALESADJUSTMENT_ROOT
		= ADJUSTMENT_ROOT + ".salesadjustment";

	/** アプリID:精算-売上精算 */
	public static final String APPID_ADJUSTMENT_SALESADJUSTMENT =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.adjustment.SalesAdjustment");

	/** 再発行識別フラグ：精算、精算取消 */
	public static final String REISSUE_FLG_ADJUSTMENT 	= "0";
	/** 再発行識別フラグ：再発行 */
	public static final String REISSUE_FLG_REISSUE 		= "1";

	/** 印刷実行フラグ */
	public static final String PRINT_EXECUTE 		= "1";

	/** インスタンスを生成しない。 */
	private AdjustmentConst(){
	}

	/** 精算関連タイトル */
	public enum AdjustmentTitle {
		/** 売上精算 */
		SALESADJUSTMENT(".SalesAdjustment"),
		;
		private String titleLabel;
		private AdjustmentTitle(String key){
			this.titleLabel = UcarApplicationManager.getConstantValue(
					UcarApplicationManager.WF_ROOT + ".title" + PKG_CAT_ADJUSTMENT + key);
		}
		public String toString(){
			return titleLabel;
		}
		/**
		 * 画面タイトルを取得する。
		 * @return titleLabel 画面タイトル
		 */
		public String getTitleLabel() {
			return titleLabel;
		}
	}

	/** 精算関連アプリケーションID */
	public enum AdjustmentApplicationId implements TecApplicationIdIF {
		/** 売上精算 */
		SALESADJUSTMENT(SALESADJUSTMENT_ROOT + ".SalesAdjustment"),
		;
		private String applicationId;
		private AdjustmentApplicationId(String applicationId){
			this.applicationId = applicationId;
		}
		public String toString(){
			return applicationId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
	}

	/** 精算関連サービスID */
	public enum AdjustmentServiceId implements TecServiceIdIF {
		/** 初期処理 */
		SALESADJUSTMENT_INIT(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentInit"),
		/** 初期処理(特定処理(取消処理など)後に初期処理を行う場合) */
		SALESADJUSTMENT_EXECUTEAFTER_INIT(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentExecuteAfterInit"),
		/** 検索処理 */
		SALESADJUSTMENT_SEARCH(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentSearch"),
		/** 検索処理(特定処理(取消処理など)後に検索処理を行う場合) */
		SALESADJUSTMENT_EXECUTEAFTER_SEARCH(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentExecuteAfterSearch"),
		/** 再表示処理(検索時) */
		SALESADJUSTMENT_RELOAD_SEARCH(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentReloadSearch"),
		/** 確認処理 */
		SALESADJUSTMENT_CONFIRM(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentConfirm"),
		/** 精算処理 */
		SALESADJUSTMENT_ADJUSTMENT(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentAdjustment"),
		/** 精算取消処理 */
		SALESADJUSTMENT_ADJUSTMENT_CANCEL(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentAdjustmentCancel"),
		/** 再発行処理 */
		SALESADJUSTMENT_REISSUE(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentReissue"),
		;
		private String applicationId;
		private String serviceId;
		private AdjustmentServiceId(TecApplicationIdIF appId, String serviceId){
			this.applicationId = appId.getApplicationId();
			this.serviceId = serviceId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
		@Override
		public String getServiceId() {
			return serviceId;
		}
		/**
		 * 精算関連サービスID取得。
		 * <pre>
		 * 受付車両登録関連サービスIDを返却する。<br>
		 * 値として認められない場合はnullを返却する。
		 * </pre>
		 * @param serviceId サービスID
		 * @return 受付車両登録関連サービスID
		 */
		public static AdjustmentServiceId getTargetAdjustmentServiceId(String serviceId){
			AdjustmentServiceId target = null;
			for(AdjustmentServiceId enumElement : AdjustmentServiceId.values()){
				if(enumElement.getServiceId().equals(serviceId)){
					target = enumElement;
					break;
				}
			}
			return target;
		}
	}

	/** 精算関連イベントキー */
	public enum AdjustmentEventKey implements TecEventKeyIF {
		/** 取得処理イベント */
		GET_SALESADJUSTMENT_DATA(AdjustmentApplicationId.SALESADJUSTMENT, "GetSalesAdjustmentDataEvent"),
		/** 精算処理イベント */
		SAVE_SALESADJUSTMENT_DATA(AdjustmentApplicationId.SALESADJUSTMENT, "SaveSalesAdjustmentDataEvent"),
		/** 精算取消処理イベント */
		CANCEL_SALESADJUSTMENT_DATA(AdjustmentApplicationId.SALESADJUSTMENT, "CancelSalesAdjustmentDataEvent"),
		;
		private String applicationId;
		private String eventKey;
		private AdjustmentEventKey(TecApplicationIdIF appId, String eventKey){
			this.applicationId = appId.getApplicationId();
			this.eventKey = eventKey;
		}
		public String toString(){
			return eventKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getEventKey(){
			return eventKey;
		}
	}

	/** 精算関連DAOキー */
	public enum AdjustmentDAOKey implements TecDAOKeyIF {
		/** 売上精算DAO */
		SALESADJUSTMENT_DAO(AdjustmentApplicationId.SALESADJUSTMENT, "SalesAdjustmentDAO"),
		;
		private String applicationId;
		private String daoKey;
		private AdjustmentDAOKey(TecApplicationIdIF appId, String daoKey){
			this.applicationId = appId.getApplicationId();
			this.daoKey = daoKey;
		}
		public String toString(){
			return daoKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getDAOKey(){
			return daoKey;
		}
	}
}
