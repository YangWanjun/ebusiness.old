package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.util.ArrayList;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.ExcelWriteBeanIF;

/**
 * <strong>Excel書き込みイベント。</strong>
 * <p>
 * ・パラメータ詳細<br>
 * docFormatID・・・書式ID(DOC_FORMAT_ID)を設定。(必須)<br>
 * baseFilePath・・・書き込むための雛形となるExcelファイルのパスを設定。<br>
 * 未指定にすることでDBに定義されているパス情報を使用する。<br>
 * tempSavePath・・・一時保存先のパスを設定。<br>
 * 未指定にすることで自動生成する。
 * isAppBaseFilePath・・・
 * trueの場合アプリケーションサーバ、falseの場合ストレージサービスから雛形を読み込む。
 * デフォルトはfalse。<br>
 * isSaveAppSrv・・・
 * trueの場合アプリケーションサーバ、falseの場合ストレージサービスへ一時保存する。
 * デフォルトはfalse。<br>
 * writeStrings・・・通常SET項目を格納する。<br>
 * setWriteStrings(ExcelWriteBeanIF)を使用して設定する。<br>
 * writeLists・・・リストSET項目を格納する。<br>
 * addWriteListを使用して設定する。<br>
 * ・返却<br>
 * 一時保存したパス文字列がResultObjectの形式で返却される。<br>
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/13 新規作成<br>
 * @since 1.00
 */
public class ExcelFormatWriteEvent extends UcarEvent {

	private static final long serialVersionUID = 1534818940225270088L;

	private String docFormatID;

	private String baseFilePath;

	private String tempSavePath;

	private boolean isAppBaseFilePath = false;

	private boolean isSaveAppSrv = false;

	private String[] writeStrings;

	private ArrayList<String[][]> writeLists = new ArrayList<String[][]>();

	/**
	 * docFormatIDを取得する。
	 * @return docFormatID
	 */
	public String getDocFormatID() {
		return docFormatID;
	}

	/**
	 * docFormatIDを設定する。
	 * @param docFormatID
	 */
	public void setDocFormatID(String docFormatID) {
		this.docFormatID = docFormatID;
	}

	/**
	 * baseFilePathを取得する。
	 * @return baseFilePath
	 */
	public String getBaseFilePath() {
		return baseFilePath;
	}

	/**
	 * baseFilePathを設定する。
	 * @param baseFilePath
	 */
	public void setBaseFilePath(String baseFilePath) {
		this.baseFilePath = baseFilePath;
	}

	/**
	 * tempSavePathを取得する。
	 * @return tempSavePath
	 */
	public String getTempSavePath() {
		return tempSavePath;
	}

	/**
	 * tempSavePathを設定する。
	 * @param tempSavePath
	 */
	public void setTempSavePath(String tempSavePath) {
		this.tempSavePath = tempSavePath;
	}

	/**
	 * isAppBaseFilePathを取得する。
	 * @return isAppBaseFilePath
	 */
	public boolean isAppBaseFilePath() {
		return isAppBaseFilePath;
	}

	/**
	 * isAppBaseFilePathを設定する。
	 * @param isAppBaseFilePath
	 */
	public void setAppBaseFilePath(boolean isAppBaseFilePath) {
		this.isAppBaseFilePath = isAppBaseFilePath;
	}

	/**
	 * isSaveAppSrvを取得する。
	 * @return isSaveAppSrv
	 */
	public boolean isSaveAppSrv() {
		return isSaveAppSrv;
	}

	/**
	 * isSaveAppSrvを設定する。
	 * @param isSaveAppSrv
	 */
	public void setSaveAppSrv(boolean isSaveAppSrv) {
		this.isSaveAppSrv = isSaveAppSrv;
	}

	/**
	 * writeStringsを取得する。
	 * @return writeStrings
	 */
	public String[] getWriteStrings() {
		return writeStrings;
	}

	/**
	 * 通常SET項目設定。
	 * @param writeBean
	 */
	public void setWriteStrings(ExcelWriteBeanIF writeBean) {
		setWriteStrings(writeBean.getExcelWriteList());
	}

	/**
	 * 通常SET項目設定。
	 * @param writeStrings
	 */
	public void setWriteStrings(ArrayList<String> writeStrings) {
		setWriteStrings(writeStrings.toArray(new String[writeStrings.size()]));
	}

	/**
	 * writeStringsを設定する。
	 * @param writeStrings
	 */
	public void setWriteStrings(String[] writeStrings) {
		this.writeStrings = writeStrings;
	}

	/**
	 * リストSET項目取得。
	 * @return リストSET項目
	 */
	public String[][][] getWriteLists() {
		return writeLists.toArray(new String[writeLists.size()][][]);
	}

	/**
	 * リストSET項目設定。
	 * <pre>
	 * DB取得結果等を設定(追加)する。
	 * </pre>
	 * @param writeList
	 */
	public void addWriteList(ArrayList<? extends ExcelWriteBeanIF> writeList){
		ArrayList<String[]> recList = new ArrayList<String[]>(writeList.size());
		for(Object recBean : writeList){
			ArrayList<String> rec = ((ExcelWriteBeanIF)recBean).getExcelWriteList();
			recList.add(rec.toArray(new String[rec.size()]));
		}
		writeLists.add(recList.toArray(new String[recList.size()][]));
	}

}
