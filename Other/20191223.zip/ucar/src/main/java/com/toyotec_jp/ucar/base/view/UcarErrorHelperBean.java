/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarErrorHelperBean.java
 * 【  説  明  】
 * 【  作  成  】2010/07/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.view;

import java.io.PrintWriter;
import java.io.StringWriter;

import jp.co.intra_mart.framework.base.web.bean.ErrorHelperBean;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecExceptionLevel;
import com.toyotec_jp.im_common.system.exception.TecHandleNormalCaseHelperBeanException;
import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarConstantKey;
import com.toyotec_jp.ucar.system.message.UcarMessageKey;

/**
 * <strong>エラー画面用ヘルパービーン。</strong>
 * <p>
 * 例外発生時の画面表示を補助する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/01 新規作成<br>
 * @since 1.00
 */
public abstract class UcarErrorHelperBean extends ErrorHelperBean {

	private static final long serialVersionUID = 5890454959372234414L;

	private boolean isException = false;

	private boolean isApplicationException = false;

	private boolean isSystemException = false;

	private boolean isHelperBeanException = false;

	private TecExceptionLevel level = TecExceptionLevel.ERROR;

	private String exceptionName = null;

	private String exceptionDispMessage = null;

	private String exceptionMessage = null;

	private String exceptionTraceMessage = null;

	private Throwable targetException = null;

	/**
	 * コンストラクタ。
	 * @throws HelperBeanException
	 */
	public UcarErrorHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.web.bean.HelperBean#init()
	 */
	@Override
	public void init() throws HelperBeanException {
		setupExceptionParams();
	}

	// 例外発生時の初期設定
	protected void setupExceptionParams(){
		setTargetException();
		// 例外の場合、その種別により分岐
		if(isException){
			try{
				// 例外発生時の呼び出し部署
				String alertTarget = UcarApplicationManager.getConstantValue(UcarConstantKey.DEFAULT_CONTACT_INFO);
				// 対象取得失敗などによって対象が存在しない場合はシステム例外とする
				if(targetException == null){
					isSystemException = true;
					level = TecExceptionLevel.ERROR;
					exceptionDispMessage = TecMessageManager.getMessage(
							UcarMessageKey.WF_E_DEFAULT_SYSTEM_EXCEPTION_MESSAGE_KEY, alertTarget);
				} else {
					// DAO例外
					if(TecDAOException.class.isAssignableFrom(targetException.getClass())){
						isSystemException = true;
						level = TecSystemException.class.cast(targetException).getLevel();
						exceptionDispMessage = TecMessageManager.getMessage(
								UcarMessageKey.WF_E_DEFAULT_DATABASE_EXCEPTION_MESSAGE_KEY, alertTarget);
					// システム例外(共通)
					} else if(TecSystemException.class.isAssignableFrom(targetException.getClass())){
						isSystemException = true;
						level = TecSystemException.class.cast(targetException).getLevel();
						exceptionDispMessage = TecMessageManager.getMessage(
								UcarMessageKey.WF_E_DEFAULT_SYSTEM_EXCEPTION_MESSAGE_KEY, alertTarget);
					// アプリケーション例外(共通)
					} else if(TecApplicationException.class.isAssignableFrom(targetException.getClass())){
						isApplicationException = true;
						level = TecApplicationException.class.cast(targetException).getLevel();
						exceptionDispMessage = exceptionMessage;
					// システム例外(IM)
					} else if(SystemException.class.isAssignableFrom(targetException.getClass())){
						isSystemException = true;
						level = TecExceptionLevel.ERROR;
						exceptionDispMessage = TecMessageManager.getMessage(
								UcarMessageKey.WF_E_DEFAULT_SYSTEM_EXCEPTION_MESSAGE_KEY, alertTarget);
					// アプリケーション例外(IM)
					} else if(ApplicationException.class.isAssignableFrom(targetException.getClass())){
						isApplicationException = true;
						level = TecExceptionLevel.WARN;
						exceptionDispMessage = exceptionMessage;
					// それ以外の例外
					} else {
						isSystemException = true;
						level = TecExceptionLevel.ERROR;
						exceptionDispMessage = TecMessageManager.getMessage(
								UcarMessageKey.WF_E_DEFAULT_SYSTEM_EXCEPTION_MESSAGE_KEY, alertTarget);
					}
				}
			} catch (TecMessageException e) {
				// この例外はエラー画面において本来必要としないためスローしない
				TecLogger.error("メッセージ取得失敗", e);
			}
		}
	}

	// 対象例外の設定
	private void setTargetException(){
		// 例外取得
		Throwable ex = null;
		try {
			Throwable mainException = getException();
			if(mainException != null){
				isException = true;
				ex = getTargetException(mainException, 0, 10);
				// 対象とする例外が不明である場合、親の例外を対象とする
				if(ex == null){
					ex = mainException;
				}
			}
		} catch (HelperBeanException e){
			// この例外はエラー画面において本来必要としないためスローしない
			TecLogger.error("例外取得失敗", e);
		}
		// 例外の場合
		if(isException){
			exceptionMessage = getExceptionMessage(ex, true);
			if(ex != null){
				// 正常系ヘルパービーン例外は例外として扱わない
				if(TecHandleNormalCaseHelperBeanException.class.isAssignableFrom(ex.getClass())){
					isException = false;
					isHelperBeanException = true;
					targetException = ex;
				// ヘルパービーン例外は子が本体
				} else if(HelperBeanException.class.isAssignableFrom(ex.getClass())){
					isHelperBeanException = true;
					targetException = ex.getCause();
				} else {
					targetException = ex;
				}
			}
			if(targetException != null){
				exceptionName = targetException.getClass().getName();
				exceptionTraceMessage = getDetailString(targetException);
			}
		}
	}

	// 対象とする例外を取得
	private static Throwable getTargetException(Throwable target, int idx, int maxIdx){
		Throwable ret = null;
		// 対象がNull、maxIdx(無限ループ防止用)以上の場合はNullを返却
		if(target == null || idx >= maxIdx){
			ret = null;
		// 対象がヘルパービーン例外、システム共通例外、アプリケーション共通例外、
		// またはそれら例外を継承しているならば対象を返却
		} else if(
				HelperBeanException.class.isAssignableFrom(target.getClass()) ||
				TecSystemException.class.isAssignableFrom(target.getClass()) ||
				TecApplicationException.class.isAssignableFrom(target.getClass())){
			ret = target;
		} else {
			// Causeが存在しない、対象とCauseが同じ場合はNullを返却
			// (対象とする例外が不明である場合)
			// ※対象を返却する条件と、対象とCauseが同じ場合についての条件の前後関係に注意
			if(target.getCause() == null || target.equals(target.getCause())){
				ret = null;
			// 上記を満たさない場合はCauseで再帰
			} else {
				idx++;
				ret = getTargetException(target.getCause(), idx, maxIdx);
			}
		}
		return ret;
		/*
		// maxIdx(無限ループ防止用)以上、Causeが存在しない、対象とCauseが同じ場合はNullを返却
		// (対象とする例外が不明である場合)
		if(idx >= maxIdx || target.getCause() == null || target.equals(target.getCause())){
			return null;
		}
		// 対象がヘルパービーン例外、システム共通例外、アプリケーション共通例外、
		// またはそれら例外を継承しているならば対象を返却
		// 上記を満たさない場合はCauseで再帰
		if(
				!HelperBeanException.class.isAssignableFrom(target.getClass()) &&
				!TSystemException.class.isAssignableFrom(target.getClass()) &&
				!TApplicationException.class.isAssignableFrom(target.getClass())){
			idx++;
			return getTargetException(target.getCause(), idx, maxIdx);
		}
		return target;
		*/
	}

	// 例外の種別ごとのメッセージ取得
	private String getExceptionMessage(Throwable target, boolean isParent){
		String retMessage = null;
		// 対象取得失敗などによって対象が存在しない場合はシステム例外とする
		if(target == null){
			retMessage = "不明なエラーです";
		} else {
			// ヘルパービーン例外
			if(HelperBeanException.class.isAssignableFrom(target.getClass())){
				retMessage = target.getMessage();
				if(retMessage == null){
					// ヘルパービーン例外のメッセージがNullの場合、子のメッセージを使用する
					if(isParent){
						retMessage = getExceptionMessage(target.getCause(), false);
					} else {
						retMessage = "致命的なエラーです";
					}
				}
			// システム例外(IM)
			} else if(SystemException.class.isAssignableFrom(target.getClass())){
				retMessage = target.getMessage();
				// システム例外においてメッセージがない場合は固定のメッセージを設定
				if(retMessage == null){
					retMessage = "致命的なエラーです";
				}
			// アプリケーション例外(IM)
			} else if(ApplicationException.class.isAssignableFrom(target.getClass())){
				// アプリケーション例外は例外のメッセージを表示
				retMessage = target.getMessage();
			// それ以外の例外
			} else {
				retMessage = "その他の例外がでてます";
			}
		}
		return retMessage;
	}

	// 詳細メッセージ取得
	private static String getDetailString(Object detail){
		Throwable e = null;
		String detailString = null;
		// 詳細文字列の作成
		// detailがThrowableのインスタンスである場合はそのスタックトレースの内容を、
		// そうでない場合はtoStringメソッドの戻り値を設定する
		if(detail != null){
			if (detail instanceof Throwable) {
				e = (Throwable)detail;
			}
			if (e != null) {
				StringWriter writer = new StringWriter();
				e.printStackTrace(new PrintWriter(writer));
				detailString = new String(writer.getBuffer());
			} else {
				detailString = detail.toString();
			}
		}
		return detailString;
	}

	/**
	 * isExceptionを取得する。
	 * @return isException
	 */
	public boolean isException() {
		return isException;
	}

	/**
	 * isExceptionを設定する。
	 * @param isException
	 */
	public void setException(boolean isException) {
		this.isException = isException;
	}

	/**
	 * isApplicationExceptionを取得する。
	 * @return isApplicationException
	 */
	public boolean isApplicationException() {
		return isApplicationException;
	}

	/**
	 * isApplicationExceptionを設定する。
	 * @param isApplicationException
	 */
	public void setApplicationException(boolean isApplicationException) {
		this.isApplicationException = isApplicationException;
	}

	/**
	 * isSystemExceptionを取得する。
	 * @return isSystemException
	 */
	public boolean isSystemException() {
		return isSystemException;
	}

	/**
	 * isSystemExceptionを設定する。
	 * @param isSystemException
	 */
	public void setSystemException(boolean isSystemException) {
		this.isSystemException = isSystemException;
	}

	/**
	 * isHelperBeanExceptionを取得する。
	 * @return isHelperBeanException
	 */
	public boolean isHelperBeanException() {
		return isHelperBeanException;
	}

	/**
	 * isHelperBeanExceptionを設定する。
	 * @param isHelperBeanException
	 */
	public void setHelperBeanException(boolean isHelperBeanException) {
		this.isHelperBeanException = isHelperBeanException;
	}

	/**
	 * levelを取得する。
	 * @return level
	 */
	public TecExceptionLevel getLevel() {
		return level;
	}

	/**
	 * levelを設定する。
	 * @param level
	 */
	public void setLevel(TecExceptionLevel level) {
		this.level = level;
	}

	/**
	 * exceptionDispMessageを取得する。
	 * @return exceptionDispMessage
	 */
	public String getExceptionDispMessage() {
		return exceptionDispMessage;
	}

	/**
	 * exceptionDispMessageを設定する。
	 * @param exceptionDispMessage
	 */
	public void setExceptionDispMessage(String exceptionDispMessage) {
		this.exceptionDispMessage = exceptionDispMessage;
	}

	/**
	 * exceptionMessageを取得する。
	 * @return exceptionMessage
	 */
	public String getExceptionMessage() {
		return exceptionMessage;
	}

	/**
	 * exceptionMessageを設定する。
	 * @param exceptionMessage
	 */
	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	/**
	 * exceptionTraceMessageを取得する。
	 * @return exceptionTraceMessage
	 */
	public String getExceptionTraceMessage() {
		return exceptionTraceMessage;
	}

	/**
	 * exceptionTraceMessageを設定する。
	 * @param exceptionTraceMessage
	 */
	public void setExceptionTraceMessage(String exceptionTraceMessage) {
		this.exceptionTraceMessage = exceptionTraceMessage;
	}

	/**
	 * targetExceptionを取得する。
	 * @return targetException
	 */
	public Throwable getTargetException() {
		return targetException;
	}

	/**
	 * targetExceptionを設定する。
	 * @param targetException
	 */
	public void setTargetException(Throwable targetException) {
		this.targetException = targetException;
	}

	/**
	 * exceptionNameを取得する。
	 * @return exceptionName
	 */
	public String getExceptionName() {
		return exceptionName;
	}

	/**
	 * exceptionNameを設定する。
	 * @param exceptionName
	 */
	public void setExceptionName(String exceptionName) {
		this.exceptionName = exceptionName;
	}

}
