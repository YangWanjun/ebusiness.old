/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecExceptionLevel.java
 * 【  説  明  】
 * 【  作  成  】2010/07/02 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

/**
 * <strong>例外のレベル。</strong>
 * @author H.O(SCC)
 * @version 1.00 2010/07/02 新規作成<br>
 * @since 1.00
 */
public enum TecExceptionLevel {
	/** ERROR */
	ERROR,
	/** WARNING */
	WARN,
	/** INFORMATION */
	INFO
}
