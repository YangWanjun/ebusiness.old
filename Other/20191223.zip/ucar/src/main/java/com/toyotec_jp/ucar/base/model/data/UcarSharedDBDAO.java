package com.toyotec_jp.ucar.base.model.data;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.HashMap;

import jp.co.intra_mart.framework.base.data.DataConnectException;
import jp.co.intra_mart.framework.base.data.DataPropertyException;
import jp.co.intra_mart.framework.base.data.SharedDBDAO;

import com.toyotec_jp.im_common.system.db.TecConnection;
import com.toyotec_jp.im_common.system.db.TecPreparedStatement;
import com.toyotec_jp.im_common.system.db.TecResultSet;
import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageKey;
import com.toyotec_jp.im_common.system.model.object.MethodInfoBean;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimplePagingResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.ReflectionUtils;
import com.toyotec_jp.im_common.system.utils.SimpleDBResultMapper;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;

/**
 * <strong>システムデータベース用基本データアクセスオブジェクト。</strong>
 * <p>
 * システムデータベースDAO作成時は本クラスを継承すること。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2019/10/09 新規作成<br>
 * @since 1.00
 */
public abstract class UcarSharedDBDAO extends SharedDBDAO {

	/**
	 * 共通コネクション取得。
	 * @return 共通コネクション
	 * @throws TecDAOException
	 */
	protected TecConnection getTConnection() throws TecDAOException {
		TecConnection con = null;
		try {
			con = new TecConnection(super.getConnection());
		} catch (DataConnectException e) {
			TecLogger.error(e);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_GET_CONNECTION, e);
		} catch (DataPropertyException e) {
			TecLogger.error(e);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_GET_CONNECTION, e);
		}
		return con;
	}

	/**
	 * 共通プリペアドステートメント取得。
	 * @param sql SQL
	 * @return 共通プリペアドステートメント
	 * @throws TecDAOException
	 */
	protected TecPreparedStatement getTPreparedStatement(String sql) throws TecDAOException {
		TecPreparedStatement pstmt = null;
		try {
			pstmt = getTConnection().prepareStatement(sql);
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_GET_PSTMT, e);
		}
		return pstmt;
	}

	/**
	 * 簡易更新クエリ実行。
	 * <pre>
	 * 更新クエリを実行し、
	 * 更新件数等を設定した簡易更新クエリ実行結果ビーンを返却する。
	 * </pre>
	 * @param paramBean 簡易クエリ実行用クエリパラメータビーン
	 * @return 簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException
	 */
	protected SimpleExecuteResultBean executeSimpleUpdateQuery(SimpleQueryParamBean paramBean) throws TecDAOException {
		// 引数チェック
		if(paramBean == null || StringCheckUtils.isEmpty(paramBean.getSql())){
			TecDAOException daoEx = new TecDAOException(TecMessageKey.SYS_E_ILLEGAL_ARGUMENT, new IllegalArgumentException());
			TecLogger.error(daoEx);
			throw daoEx;
		}
		TecPreparedStatement pstmt = null;
		SimpleExecuteResultBean resultBean = new SimpleExecuteResultBean();
		try{
			pstmt = getTPreparedStatement(paramBean.getSql());
			pstmt.setParameters(paramBean);
			int execCnt = pstmt.executeUpdate();
			resultBean.setExecuteCount(execCnt);
			// 2011.06.08 T.Hayato getInsertIdentityValue()内でSQLServer専用のSQLを使用しているため start
//			if(execCnt > 0){
//				String insId = getInsertIdentityValue(pstmt);
//				if(insId != null){
//					resultBean.setGeneratedKey(insId);
//				}
//			}
			// 2011.06.08 T.Hayato getInsertIdentityValue()内でSQLServer専用のSQLを使用しているため end

		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} catch (TecDAOException e) {
			throw e;
		} catch (Exception e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} finally {
			try {
				if(pstmt != null){
					pstmt.close();
					pstmt = null;
				}
			} catch(SQLException e){
				// Close時の例外は無視
			}
		}
		return resultBean;
	}

	/**
	 * 簡易検索クエリ実行(全件取得)。
	 * <pre>
	 * 検索クエリを実行し、
	 * 引数で指定されたビーンのリストを検索結果として返却する。<br>
	 * 結果が存在しない場合は空(サイズ0)のリストを返却する。<br>
	 * 件数制限は無し。
	 * </pre>
	 * @param <E>
	 * @param paramBean 簡易クエリ実行用クエリパラメータビーン
	 * @param cls 返却するResultArrayListの要素となるビーンのクラス
	 * @return 検索結果のリスト
	 * @throws TecDAOException
	 */
	protected <E extends TecBean> ResultArrayList<E> executeSimpleSelectQuery(
			SimpleQueryParamBean paramBean, Class<E> cls) throws TecDAOException {
		// 引数チェック
		if(paramBean == null || StringCheckUtils.isEmpty(paramBean.getSql()) || cls == null){
			TecDAOException daoEx = new TecDAOException(TecMessageKey.SYS_E_ILLEGAL_ARGUMENT, new IllegalArgumentException());
			TecLogger.error(daoEx);
			throw daoEx;
		}
		TecPreparedStatement pstmt = null;
		TecResultSet rs = null;
		ResultArrayList<E> list = new ResultArrayList<E>();
		try{
			Constructor<E> constructor = getDefaultConstructor(cls);
			pstmt = getTPreparedStatement(
					paramBean.getSql() + " " + StringUtils.defaultValue(paramBean.getOrderSql()));
			pstmt.setParameters(paramBean);
			TecLogger.trace("executeQuery start[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
			rs = pstmt.executeQuery();
			TecLogger.trace("executeQuery end[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
			HashMap<String, MethodInfoBean> setterMap = ReflectionUtils.getBeanSetterMap(cls);
			while(rs.next()){
				E bean = getNewInstanceByDefaultConstructor(constructor);
				SimpleDBResultMapper.setResult(rs, bean, setterMap);
				list.add(bean);
			}
			TecLogger.trace("resultMapping end[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
			list.trimToSize();
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} catch (TecDAOException e) {
			throw e;
		} catch (Exception e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} finally {
			try {
				if(rs != null){
					rs.close();
					rs = null;
				}
				if(pstmt != null){
					pstmt.close();
					pstmt = null;
				}
			} catch(SQLException e){
				// Close時の例外は無視
			}
		}
		return list;
	}

	/**
	 * 簡易SELECTクエリ実行(ページング)。
	 * <pre>
	 * 検索クエリを実行し、
	 * 引数で指定されたページング用ビーンを検索結果として返却する。<br>
	 * (ページング用ビーンの内部に検索結果となるビーンのリストを持つ。)
	 * </pre>
	 * @param <E>
	 * @param <L>
	 * @param paramBean 簡易クエリ実行用クエリパラメータビーン
	 * @param resultPageCls 返却するページング用ビーンのクラス
	 * @param listCls 返却するResultArrayListの要素となるビーンのクラス
	 * @return 簡易ページング用クエリ実行結果
	 * @throws TecDAOException
	 */
	protected <E extends SimplePagingResultBean<L>, L extends TecBean> E executeSimplePagingQuery(
			SimpleQueryParamBean paramBean, Class<E> resultPageCls, Class<L> listCls) throws TecDAOException {
		// 引数チェック
		if(paramBean == null || StringCheckUtils.isEmpty(paramBean.getSql()) || StringCheckUtils.isEmpty(paramBean.getOrderSql()) ||
				resultPageCls == null || listCls == null){
			TecDAOException daoEx = new TecDAOException(TecMessageKey.SYS_E_ILLEGAL_ARGUMENT, new IllegalArgumentException());
			TecLogger.error(daoEx);
			throw daoEx;
		}
		TecPreparedStatement pstmt = null;
		TecResultSet rs = null;
		E pageBean = null;
		try{
			ResultArrayList<L> list = new ResultArrayList<L>();
			Constructor<E> pageBeanConstructor = getDefaultConstructor(resultPageCls);
			Constructor<L> listBeanConstructor = getDefaultConstructor(listCls);
			pageBean = getNewInstanceByDefaultConstructor(pageBeanConstructor);
			int pageNo = getPageNo(paramBean);
			int pageSize = getPageSize(paramBean);
			int recLimit = paramBean.getRecLimit();
			// 1ページあたりの件数調整
			pageBean.setPageSize(pageSize);
			pageBean.setRecLimit(recLimit);
			// 件数取得
			TecLogger.trace("count start[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
			int totalRecordCount = getRecordCount(paramBean);
			TecLogger.trace("count end[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
			pageBean.setTotalRecordCount(totalRecordCount);
			// 件数超過
			if(recLimit > 0 && recLimit < totalRecordCount){
				pageBean.setOverRecLimit(true);
			} else {
				// 表示ページ番号調整
				if(totalRecordCount < getMinRecNo(pageNo, pageSize)){
					pageNo = 1;
				}
				pageBean.setPageNo(pageNo);
				// 件数が0件でない場合は
				if(totalRecordCount > 0){
					pstmt = getTPreparedStatement(getPagingSql(paramBean, pageNo));
					pstmt.setParameters(paramBean);
					// SQL実行
					TecLogger.trace("executeQuery start[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
					rs = pstmt.executeQuery();
					TecLogger.trace("executeQuery end[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
					HashMap<String, MethodInfoBean> setterMap = ReflectionUtils.getBeanSetterMap(listCls);
					while(rs.next()){
						L listBean = getNewInstanceByDefaultConstructor(listBeanConstructor);
						SimpleDBResultMapper.setResult(rs, listBean, setterMap);
						list.add(listBean);
					}
					TecLogger.trace("resultMapping end[" + DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + "]");
				}
				list.trimToSize();
				pageBean.setRecordCount(list.size());
				pageBean.setResultRecordList(list);
			}

		} catch (NullPointerException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} finally {
			try {
				if(rs != null){
					rs.close();
					rs = null;
				}
				if(pstmt != null){
					pstmt.close();
					pstmt = null;
				}
			} catch(SQLException e){
				// Close時の例外は無視
			}
		}
		return pageBean;
	}

	/**
	 * 件数を返却する。
	 * @param paramBean 簡易クエリ実行用クエリパラメータビーン
	 * @return 件数
	 * @throws TecDAOException
	 */
	protected int getRecordCount(SimpleQueryParamBean paramBean) throws TecDAOException {
		TecPreparedStatement pstmt = null;
		TecResultSet rs = null;
		int recordCount = 0;
		try{
			String countSql =
				StringUtils.defaultValue(paramBean.getWithSql()) +
				"SELECT COUNT(*) AS cmn_sp_rec_count FROM (" +
				paramBean.getSql() +
				") CMN_SP_CNT_T " +
				"";
			pstmt = getTPreparedStatement(countSql);
			pstmt.setParameters(paramBean);
			rs = pstmt.executeQuery();
			if(rs.next()){
				recordCount = rs.getInt("cmn_sp_rec_count");
			}
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} finally {
			try {
				if(rs != null){
					rs.close();
					rs = null;
				}
				if(pstmt != null){
					pstmt.close();
					pstmt = null;
				}
			} catch(SQLException e){
				// Close時の例外は無視
			}
		}
		return recordCount;
	}

	/**
	 * インサート実行時に自動生成されたIDを取得。
	 * <pre>
	 * トリガ等で別のインサートが実行された場合、そちらが返却されるため注意。
	 * </pre>
	 * @param pstmt 共通プリペアドステートメント
	 * @return 自動生成されたID
	 * @throws TecDAOException
	 */
	protected String getInsertIdentityValue(TecPreparedStatement pstmt) throws TecDAOException {
		TecPreparedStatement idpstmt = null;
		TecResultSet rs = null;
		String insId = null;
		try{
			//String selectIdSql = "SELECT SCOPE_IDENTITY() AS cmn_new_identity ";
			String selectIdSql = "SELECT @@IDENTITY AS cmn_new_identity ";
			TecConnection con = new TecConnection(pstmt.getConnection());
			idpstmt = con.prepareStatement(selectIdSql);
			rs = idpstmt.executeQuery();
			if(rs.next()){
				insId = rs.getString("cmn_new_identity");
			}
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} finally {
			try {
				if(rs != null){
					rs.close();
					rs = null;
				}
				if(idpstmt != null){
					idpstmt.close();
					idpstmt = null;
				}
			} catch(SQLException e){
				// Close時の例外は無視
			}
		}
		return insId;
	}

	// デフォルトコンストラクタ取得
	private <E extends TecBean> Constructor<E> getDefaultConstructor(Class<E> cls) throws TecDAOException {
		Constructor<E> constructor = null;
		try {
			constructor = cls.getConstructor();
		} catch (NoSuchMethodException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		}
		return constructor;
	}

	// デフォルトコンストラクタを使用してインスタンスを生成
	private <E extends TecBean> E getNewInstanceByDefaultConstructor(Constructor<E> constructor) throws TecDAOException {
		E resBean = null;
		try {
			resBean = constructor.newInstance();
		} catch (InstantiationException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} catch (IllegalAccessException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} catch (InvocationTargetException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		}
		return resBean;
	}

	// ページング用SQL生成
	private String getPagingSql(SimpleQueryParamBean paramBean, int pageNo){
		String pagingSql = null;

		String sql = paramBean.getSql();
		String orderSql = paramBean.getOrderSql();
		String withSql = paramBean.getWithSql();
		int pageSize = getPageSize(paramBean);

		if(pageSize <= 0){
			pagingSql =
				StringUtils.defaultValue(withSql) + " " +
				sql + " " +
				orderSql +
				"";
		} else {
			String minRecNo = Integer.toString(getMinRecNo(pageNo, pageSize));
			String maxRecNo = Integer.toString(getMaxRecNo(pageNo, pageSize));
			// 2011.06.08 Y.Furuya SQLエラー発生のため、PagingSqlの3行目の*の前に表別名を追加
			pagingSql =
				StringUtils.defaultValue(withSql) +
				"SELECT * " +
				"FROM (" +
				"  SELECT ROW_NUMBER() OVER (" + orderSql + ") AS cmn_sp_rownum, CMN_SP_TMP1_T.* " +
				"  FROM (" +
				sql +
				"  ) CMN_SP_TMP1_T " +
				") CMN_SP_TMP2_T " +
				"WHERE cmn_sp_rownum BETWEEN " + minRecNo + " AND " + maxRecNo + " " +
				orderSql +
				"";
		}
		return pagingSql;
	}

	// パラメータビーンからページ番号を取得
	private int getPageNo(SimpleQueryParamBean paramBean){
		int pageNo = paramBean.getPageNo();
		int pageSize = getPageSize(paramBean);
		if(pageNo < 1){
			pageNo = 1;
		}
		// 1ページに表示する行数が0の場合はページング無しなので1ページ
		if(pageSize == 0){
			pageNo = 1;
		}
		return pageNo;
	}

	// パラメータビーンから1ページに表示する行数を取得
	private int getPageSize(SimpleQueryParamBean paramBean){
		int pageSize = paramBean.getPageSize();
		if(pageSize < 0){
			pageSize = 0;
		}
		return pageSize;
	}

	// ページ番号と1ページに表示する行数からそのページにおける最少行番号を返却
	private int getMinRecNo(int pageNo, int pageSize){
		return ((pageNo - 1) * pageSize) + 1;
	}

	// ページ番号と1ページに表示する行数からそのページにおける最大行番号を返却
	private int getMaxRecNo(int pageNo, int pageSize){
		return pageNo * pageSize;
	}

//	private static Pattern PAT_ORDERBY = Pattern.compile("\\s*order\\s+by\\s*", Pattern.CASE_INSENSITIVE);
//
//	private String getPagingOrderSql(String orderSql, String pagingTableName){
//		StringBuilder sb = new StringBuilder();
//		String[] colAry = PAT_ORDERBY.matcher(orderSql).replaceFirst("").split(",");
//		for(String colPath : colAry){
//			if(sb.length() == 0){
//				sb.append(" ORDER BY ");
//			} else {
//				sb.append(", ");
//			}
//			String[] colSpl = colPath.split("\\.");
//			sb.append(pagingTableName + "." + colSpl[colSpl.length - 1]);
//		}
//		sb.append(" ");
//		return new String(sb);
//	}

}
