package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import java.util.Date;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>車両搬出情報登録イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/05/28 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** データ更新日時 */
	private Date dtKosin;

	/**
	 * dtKosinを取得する。
	 * @return dtKosin データ更新日時
	 */
	public Date getDtKosin() {
		return dtKosin;
	}

	/**
	 * dtKosinを設定する。
	 * @param dtKosin データ更新日時
	 */
	public void setDtKosin(Date dtKosin) {
		this.dtKosin = dtKosin;
	}

}
