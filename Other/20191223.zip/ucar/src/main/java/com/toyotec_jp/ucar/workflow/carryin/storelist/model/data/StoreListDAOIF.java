package com.toyotec_jp.ucar.workflow.carryin.storelist.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListPagingBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListParamBean;

/**
 * <strong>展示店舗受取処理DAOインターフェース。</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/24 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public interface StoreListDAOIF {

	/**
	 * 展示店舗受取処理 画面出力値取得処理
	 * @param cdKaisya            会社コード
	 * @param cdHanbaitn	       販売店コード
	 * @param storeListParamBean  展示店舗受取処理 検索条件Bean
	 * @param sortParam           ソートキー
	 * @param sortOrder           ソート順
	 * @param pageNo              ページ番号
	 * @param pageSize            ページサイズ
	 * @param isInit              初期表示か検索処理かの判定フラグ
	 * @throws TecDAOException    DAO例外クラス
	 */
	public StoreListPagingBean selectStoreListPaging(String cdKaisya,
			                                          String cdHanbaitn,
			                                          StoreListParamBean storeListParamBean,
			                                          String sortParam,
			                                          String sortOrder,
			                                          String pageNo,
			                                          String pageSize,
			                                          boolean isInit) throws TecDAOException;

	// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
	/**
	 * 更新処理(車両搬出情報DB･店舗受取日)
	 * @param t220001gPKBean      車両搬出情報 プライマリーキーBean
	 * @param updateUserId        更新ユーザID
	 * @param updateAppId         更新アプリID
	 * @param executeDate         データ更新日時
	 * @param kbData              データ区分
	 * @throws TecDAOException    DAO例外クラス
	 */
	public SimpleExecuteResultBean updateDdTenukt(Ucaa001gPKBean t220001gPKBean,
												   String cdZaitenpo,
												   String dtKosin,
			                                       String updateUserId,
			                                       String updateAppId,
			                                       Timestamp executeDate,
			                                       String kbData) throws TecDAOException;

	/**
	 * 更新処理(ステータスDB･ステータス26:店舗受取日)
	 * @param t220001gPKBean      車両搬出情報 プライマリーキーBean
	 * @param updateUserId        更新ユーザID
	 * @param updateAppId         更新アプリID
	 * @param kbData              データ区分
	 * @throws TecDAOException    DAO例外クラス
	 */
	public SimpleExecuteResultBean updateStatus26(Ucaa001gPKBean t220001gPKBean,
												   String cdZaitenpo,
			                                       String updateUserId,
			                                       String updateAppId,
			                                       Timestamp executeDate,
			                                       String kbData) throws TecDAOException;
	// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end

	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため start
	/**
	 * 新規登録処理(車両受付情報)
	 * @param t220001gPKBean      車両搬出情報 プライマリーキーBean
	 * @param cdUketenpo		   受取店舗コード
	 * @param cdHantenpo		   搬入店舗コード
	 * @param updateUserId        更新ユーザID
	 * @param updateAppId         更新アプリID
	 * @param executeDate         データ更新日時
	 * @param kbData              データ区分
	 * @throws TecDAOException    DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220108g(Ucaa001gPKBean t220001gPKBean,
													String cdUketenpo,
													String cdHantenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate,
													String kbData) throws TecDAOException;

	/**
	 * 新規登録処理(ステータスDB(店舗用))
	 * @param t220001gPKBean      車両搬出情報 プライマリーキーBean
	 * @param cdTenpo             店舗コード
	 * @param updateUserId        更新ユーザID
	 * @param updateAppId         更新アプリID
	 * @param executeDate         データ更新日時
	 * @throws TecDAOException    DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220107g(Ucaa001gPKBean t220001gPKBean,
													String cdTenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate) throws TecDAOException;


	/**
	 * 更新処理(車両搬出情報DB(店舗用))
	 * @param t220001gPKBean      車両搬出情報 プライマリーキーBean
	 * @param cdTenpo             店舗コード
	 * @param updateUserId        更新ユーザID
	 * @param updateAppId         更新アプリID
	 * @param executeDate         データ更新日時
	 * @throws TecDAOException    DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220109g(Ucaa001gPKBean t220001gPKBean,
													String cdTenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理(ステータスDB(店舗用))
	 * @param t220001gPKBean      車両搬出情報 プライマリーキーBean
	 * @param cdTenpo             店舗コード
	 * @param updateUserId        更新ユーザID
	 * @param updateAppId         更新アプリID
	 * @param executeDate         データ更新日時
	 * @throws TecDAOException    DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220107g(Ucaa001gPKBean t220001gPKBean,
													String cdTenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate) throws TecDAOException;
	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため end
}