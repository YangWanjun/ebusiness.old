/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecMessageKeyIF.java
 * 【  説  明  】
 * 【  作  成  】2010/12/24 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.message;

/**
 * <strong>メッセージキーIF。</strong>
 * @author H.O(SCC)
 * @version 1.00 2010/12/24 新規作成<br>
 * @since 1.00
 */
public interface TecMessageKeyIF {

	/** メッセージキー取得 */
	public String getMessageKey();

}
