package com.toyotec_jp.ucar.workflow.carryout.register.service.controller;

import java.util.ArrayList;
import java.util.Date;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarEventKey;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutSessionBean;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutEventKey;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutServiceId;
import com.toyotec_jp.ucar.workflow.carryout.register.model.event.CarryoutPlanRegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryout.register.model.event.CarryoutRegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryout.register.model.event.CarryoutRegisterDataEventResult;
import com.toyotec_jp.ucar.workflow.carryout.register.model.event.DeleteCarryoutRegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryout.register.model.object.CarryoutRegisterSessionBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.InitHaisoKouhoRenkeiEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportUtils;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst.ReportEventKey;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportSyaryouHansyutuEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportSyaryouHansyutuEventResult;
import com.toyotec_jp.ucar.workflow.report.model.object.SyaryouHansyutuPKBean;
/**
 * <strong>車両搬出登録サービスコントローラ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterServiceController extends UcarServiceController {

	/** サービスID */
	private String serviceId = "";
	/** 車両搬出関連サービスID */
	private CarryoutServiceId targetServiceId = null;

	/** 車両搬出セッションBean */
	private CarryoutSessionBean carryoutSession;
	/** 車両搬出登録セッションBean */
	private CarryoutRegisterSessionBean carryoutRegisterSession;
	/** 車両搬出情報Bean */
//	private T220013gBean t220013gBean = new T220013gBean();
	private Uccb009gBean t220013gBean = new Uccb009gBean();	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

	/** 車両搬入情報Bean */
	private Ucaa001gBean t220001gBean = new Ucaa001gBean();
	/** ステータスDBBean */
	private Ucab007gBean t220012gBean = new Ucab007gBean();

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {
		TecLogger.trace("service start");
		// セッション設定

		setupSession();
		// サービス個別処理

		executeServiceProcess();
		TecLogger.trace("service end");
		return null;
	}

	/** セッション設定 */
	private void setupSession() throws TecSystemException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = CarryoutServiceId.getTargetCarryoutServiceId(serviceId);
		String menuId = getMenuId();

		TecLogger.debug("serviceId[" + serviceId + "]menuId[" + menuId + "]");

		String kbCenterTenpo = "";	//2016.8.17
		String ddHannyu = "";
		String noKanri = "";
		//2019.03.31 T.Osada start 
		String cdKaisya = "";
		String cdHanbaitn = "";
		//2019.03.31 T.Osada end

		// サービスごとの処理

		if(targetServiceId != null){
			switch (targetServiceId) {
				case REGISTER_INIT:
					// 初期処理


					// セッションのクリア
					clearAllApplicationSession();

					// 新規セッション取得

					carryoutSession 		= getNewApplicationSessionBean(CarryoutSessionBean.class);
					carryoutRegisterSession = getNewApplicationSessionBean(CarryoutRegisterSessionBean.class);

					// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
					// 会社コード

					carryoutSession.getT220001gPkBean().setCdKaisya(getLoginSessionBean().getUserInfoBean().getCdKaisya());
					// 販売店コード

					carryoutSession.getT220001gPkBean().setCdHanbaitn(getLoginSessionBean().getUserInfoBean().getCdHanbaitn());
					// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end
					break;
				case REGISTER_SEARCH:
					// 検索処理


					// セッション領域から取得

					carryoutSession 		= getApplicationSessionBean(CarryoutSessionBean.class);
					carryoutRegisterSession = getApplicationSessionBean(CarryoutRegisterSessionBean.class);
					
					// 搬入日
					ddHannyu = getRequest().getParameter("dd_hannyu");
					if (ddHannyu == null) {
						// 排他制御時に実行

						carryoutSession.getT220001gPkBean().setDdHannyu(carryoutSession.getT220001gPkBean().getDdHannyu());
					} else {
						carryoutSession.getT220001gPkBean().setDdHannyu(ddHannyu);
					}
					// 管理番号
					noKanri = getRequest().getParameter("no_kanri");
					if (noKanri == null) {
						// 排他制御時に実行

						carryoutSession.getT220001gPkBean().setNoKanri(carryoutSession.getT220001gPkBean().getNoKanri());
					} else {
						carryoutSession.getT220001gPkBean().setNoKanri(noKanri);
					}
					// 検索方法

					carryoutRegisterSession.setRdoSearch(getRequest().getParameter("rdo_search"));

					break;
					
				case REGISTER_SEARCHMV:
					// セッションのクリア
					//clearAllApplicationSession();

					// 新規セッション取得
					carryoutSession 		= getNewApplicationSessionBean(CarryoutSessionBean.class);
					carryoutRegisterSession = getNewApplicationSessionBean(CarryoutRegisterSessionBean.class);
					
					//センタ、店舗区分(2016.8.17)
					kbCenterTenpo = getRequest().getParameter("display_Mode");
					carryoutRegisterSession.setKbCenterTenpo(kbCenterTenpo);
					carryoutSession.setBackFlg((kbCenterTenpo.equals(UcarConst.KB_SCENTER_SCENTER)?"true":"false"));

					// 会社コード
					carryoutSession.getT220001gPkBean().setCdKaisya(getLoginSessionBean().getUserInfoBean().getCdKaisya());

					// 販売店コード
					carryoutSession.getT220001gPkBean().setCdHanbaitn(getLoginSessionBean().getUserInfoBean().getCdHanbaitn());
					String dateStr = getRequest().getParameter("dd_hannyu");
					carryoutSession.getT220001gPkBean().setDdHannyu(
											dateStr.substring(0,4)+"/"+dateStr.substring(4,6)+"/"+dateStr.substring(6,8));
					carryoutSession.getT220001gPkBean().setNoKanri(getRequest().getParameter("no_kanri"));

					// 検索方法
					carryoutRegisterSession.setRdoSearch("hand");
					targetServiceId = CarryoutServiceId.REGISTER_SEARCH;
					serviceId="RegisterSearch";
//2016.8.17				carryoutSession.setBackFlg("true");
					break;
					
					
				case REGISTER_EXECUTE:
				// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため start
				case REGISTER_EXECUTE_AND_DOWNLOAD:
				// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため end
				case REGISTER_DELETE:
					// 登録処理

					// 削除処理


					// セッション領域から取得

					carryoutSession 		= getApplicationSessionBean(CarryoutSessionBean.class);
					carryoutRegisterSession = getApplicationSessionBean(CarryoutRegisterSessionBean.class);

					// 2019.03.31 T.Osada Start
					// 会社コード
					cdKaisya = getRequest().getParameter("selected_cd_kaisya");
					//t220013gBean.setCdKaisya(carryoutSession.getT220001gPkBean().getCdKaisya());
					t220013gBean.setCdKaisya(cdKaisya);

					// 販売店コード
					cdHanbaitn = getRequest().getParameter("selected_cd_hanbaitn");
					//t220013gBean.setCdHanbaitn(carryoutSession.getT220001gPkBean().getCdHanbaitn());
					t220013gBean.setCdHanbaitn(cdHanbaitn);
					// 2019.03.31 T.Osada End

					// 搬入日
					ddHannyu = UcarUtils.getStringDateFormatShortSimple(getRequest().getParameter("dd_hannyu"));
					carryoutSession.getT220001gPkBean().setDdHannyu(ddHannyu);
					t220013gBean.setDdHannyu(ddHannyu);

					// 管理番号
					noKanri = getRequest().getParameter("no_kanri");
					carryoutSession.getT220001gPkBean().setNoKanri(noKanri);
					t220013gBean.setNoKanri(noKanri);

					// 搬出日
					String ddHansyt = UcarUtils.getStringDateFormatShortSimple(getRequest().getParameter("dd_hansyt"));
					t220013gBean.setDdHansyt(ddHansyt);

					// 作業工程区分

					t220013gBean.setKbSgyokt(getRequest().getParameter("Kb_sgyokt"));

					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
					// 行先
					t220013gBean.setCdHstenpo(getRequest().getParameter("cd_hstenpo"));

					// 他店貸出
					t220013gBean.setKbKasidasi(StringUtils.defaultValue(getRequest().getParameter("kb_kasidasi")).replace("null", ""));
					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
					break;
				// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
				case REGISTER_PLAN_EXECUTE:
					// セッション領域から取得

					carryoutSession 		= getApplicationSessionBean(CarryoutSessionBean.class);
					carryoutRegisterSession = getApplicationSessionBean(CarryoutRegisterSessionBean.class);

					// 会社コード
					//2019.05.13 T.Osada Start
					cdKaisya = getRequest().getParameter("selected_cd_kaisya");

					//t220001gBean.setCdKaisya(carryoutSession.getT220001gPkBean().getCdKaisya());
					//t220012gBean.setCdKaisya(carryoutSession.getT220001gPkBean().getCdKaisya());
					t220001gBean.setCdKaisya(cdKaisya);
					t220012gBean.setCdKaisya(cdKaisya);
					
					// 販売店コード
					cdHanbaitn = getRequest().getParameter("selected_cd_hanbaitn");

					//t220001gBean.setCdHanbaitn(carryoutSession.getT220001gPkBean().getCdHanbaitn());
					//t220012gBean.setCdHanbaitn(carryoutSession.getT220001gPkBean().getCdHanbaitn());
					t220001gBean.setCdHanbaitn(cdHanbaitn);
					t220012gBean.setCdHanbaitn(cdHanbaitn);
					//2019.05.13 T.Osada end

					// 搬入日
					ddHannyu = UcarUtils.getStringDateFormatShortSimple(getRequest().getParameter("dd_hannyu"));
					carryoutSession.getT220001gPkBean().setDdHannyu(ddHannyu);
					t220001gBean.setDdHannyu(ddHannyu);
					t220012gBean.setDdHannyu(ddHannyu);

					// 管理番号
					noKanri = getRequest().getParameter("no_kanri");
					carryoutSession.getT220001gPkBean().setNoKanri(noKanri);
					t220001gBean.setNoKanri(noKanri);
					t220012gBean.setNoKanri(noKanri);
					
					if(getRequest().getParameter("dd_outpln") != null){
						//車両搬出予定日
						Date ddOutpln = DateUtils.getDate(getRequest().getParameter("dd_outpln") + " 00:00:00:000","yyyy/MM/dd HH:mm:ss:SSS");
						t220012gBean.setDdOutpln(ddOutpln);
					}
					if(getRequest().getParameter("dt_status25") != null){
						//写真撮影日
						Date dtStatus25 = DateUtils.getDate(getRequest().getParameter("dt_status25") + " 00:00:00:000","yyyy/MM/dd HH:mm:ss:SSS");
						t220012gBean.setDtStatus25(dtStatus25);
					}
					
					//商談区分

					t220001gBean.setKbShodan(getRequest().getParameter("kb_shodan"));
					
					//商談担当者コード

					t220001gBean.setCdShtan(getRequest().getParameter("cd_shtan"));
					
					//商談備考

					t220001gBean.setMjSbikou(getRequest().getParameter("mj_sbikou"));
					
					break;
				// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end
				default:
					break;
			}
			carryoutSession.setServiceId(serviceId);
		}
		TecLogger.trace("setupSession end");
	}

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException, ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if(targetServiceId != null){
			switch (targetServiceId) {
				case REGISTER_INIT:
					// 初期処理

					// 2013.02.13 T.Hayato 修正 P東京ログイン時のみ 配送候補連携を行うため start
					String cdKaisya = carryoutSession.getT220001gPkBean().getCdKaisya();
					String cdHanbaitn = carryoutSession.getT220001gPkBean().getCdHanbaitn();
					// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//					if (UcarConst.CD_KAISYA.equals(cdKaisya)
					if (UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.CdTenpo.Scenter")
						.equals(getLoginSessionBean().getUserInfoBean().getCdTenpo())
						// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
						&& UcarConst.TOYOPET.equals(cdHanbaitn)) {
						// P東京の場合


						// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため start
						executeHaisoRenkei(cdKaisya, cdHanbaitn);
						// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため end
					}
					// 2013.02.13 T.Hayato 修正 P東京ログイン時のみ 配送候補連携を行うため end
					break;

				// 2013.05.28 T.Hayato 修正 搬入拠点分散対応2のため start
				case REGISTER_EXECUTE:
					// 登録処理

					executeRegister(false);
					break;

				case REGISTER_EXECUTE_AND_DOWNLOAD:
					// 登録(帳票印刷)処理

					executeRegister(true);
					// 印刷処理（車両搬出表）

					executeReportHansyutu();
					break;
				// 2013.05.28 T.Hayato 修正 搬入拠点分散対応2のため end

				case REGISTER_DELETE:
					// 削除処理

					executeDelete();
					// 完了メッセージ表示後、初期表示を行う
					setExecuteEndMessageBean(
							TecMessageManager.getMessage(UcarMessage.EXEC_ANY, "車両搬出情報を削除"),
														CarryoutServiceId.REGISTER_INIT);
					//2019.0513 T.Osada Start
					break;
					//2019.0513 T.Osada end 以下の追加時に消失 
				// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
				case REGISTER_PLAN_EXECUTE:
					executePlanRegister();
					// 完了メッセージ表示後、初期表示を行う
					setExecuteEndMessageBean(
							TecMessageManager.getMessage(UcarMessage.EXEC_ANY, "搬出予定を登録"),
														CarryoutServiceId.REGISTER_INIT);
					break;
				// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end
				default:
					break;
			}
		}
		TecLogger.trace("executeServiceProcess end");
	}

	// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため start
	/**
	 * 配送候補連携処理

	 * @param cdKaisya 会社コード

	 * @param cdHanbaitn 販売店コード

	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void executeHaisoRenkei(String cdKaisya,
			String cdHanbaitn) throws SystemException, ApplicationException {

		InitHaisoKouhoRenkeiEvent event
			= createEvent(UcarEventKey.INIT_HAISO_KOUHO_RENKEI, InitHaisoKouhoRenkeiEvent.class);

		event.setCdKaisya(cdKaisya);
		event.setCdHanbaitn(cdHanbaitn);
		event.setExecuteAppId(CarryoutConst.APPID_CARRYOUT_REGISTER);

		try {
			dispatchEvent(event);
		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定

			setApplicationExceptionMessageBean(e.getMessage(), CarryoutServiceId.REGISTER_INIT);
			throw e;
		}
	}
	// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため end

	/** 登録処理 */
	private void executeRegister(boolean resetDtKosin) throws SystemException, ApplicationException {

		CarryoutRegisterDataEvent event
			= createEvent(CarryoutEventKey.REGISTER_DATA, CarryoutRegisterDataEvent.class);

		event.setT220013gBean(t220013gBean);
		event.setT220013gDtKosin(carryoutRegisterSession.getT220013gDtKosin());

		try {
			// 2013.05.28 T.Hayato 修正 搬入拠点分散対応2のため start
			CarryoutRegisterDataEventResult eventResult = (CarryoutRegisterDataEventResult) dispatchEvent(event);

			if (resetDtKosin) {
				// 排他制御時に使用する更新日時をセッションにセット
				carryoutRegisterSession.setT220013gDtKosin(DateUtils.dateToString(eventResult.getDtKosin(),
																				  DateUtils.DB_FORMAT_LONG_M));
			}
			// 2013.05.28 T.Hayato 修正 搬入拠点分散対応2のため end

		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定

			setApplicationExceptionMessageBean(e.getMessage(), CarryoutServiceId.REGISTER_SEARCH);
			throw e;
		}
	}

	// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 帳票処理：車両搬出表 */
	private void executeReportHansyutu() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportSyaryouHansyutuEvent event = createEvent(ReportEventKey.REPORT_SYARYOU_HANSYUTU,
															ReportSyaryouHansyutuEvent.class);

			ArrayList<SyaryouHansyutuPKBean> syaryouHansyutuPKList = new ArrayList<SyaryouHansyutuPKBean>();

			SyaryouHansyutuPKBean syaryouHansyutuPKBean = new SyaryouHansyutuPKBean(t220013gBean.getCdKaisya(),
																					t220013gBean.getCdHanbaitn(),
																					t220013gBean.getDdHannyu(),
																					t220013gBean.getNoKanri(),
																					event.getUserInfoBean().getCdTenpo(),
																					event.getUserInfoBean().getKbScenter());
			syaryouHansyutuPKList.add(syaryouHansyutuPKBean);

			event.setSyaryouHansyutuPKList(syaryouHansyutuPKList);
			event.setExecuteDtKosin(false);

			ReportSyaryouHansyutuEventResult eventResult = (ReportSyaryouHansyutuEventResult)dispatchEvent(event);

			// ダウンロード用処理

			String tempFilePath = eventResult.getFilePath();
			String downloadfileName
				= ReportUtils.getDownloadFileName(ReportConst.FILE_NAME_SYARYOU_HANSYUTU,
										StringUtils.getFileExtension(tempFilePath));

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定

			setApplicationExceptionMessageBean(e.getMessage(), CarryoutServiceId.REGISTER_SEARCH);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}
	// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため end

	/** 削除処理 */
	private void executeDelete() throws SystemException, ApplicationException {

		DeleteCarryoutRegisterDataEvent event
			= createEvent(CarryoutEventKey.DELETE_REGISTER_DATA, DeleteCarryoutRegisterDataEvent.class);

		event.setT220013gBean(t220013gBean);
		event.setT220013gDtKosin(carryoutRegisterSession.getT220013gDtKosin());

		try {
			dispatchEvent(event);
		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定

			setApplicationExceptionMessageBean(e.getMessage(), CarryoutServiceId.REGISTER_SEARCH);
			throw e;
		}
	}
	
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
	/** 搬出予定登録処理 */
	private void executePlanRegister() throws SystemException, ApplicationException {

		CarryoutPlanRegisterDataEvent event
			= createEvent(CarryoutEventKey.PLAN_REGISTER_DATA, CarryoutPlanRegisterDataEvent.class);

		event.setUcaa001gBean(t220001gBean);
		event.setUcab007gBean(t220012gBean);
		event.setUcaa001gDtKosin(carryoutRegisterSession.getT220013gDtKosin());

		try {
			dispatchEvent(event);

		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定

			setApplicationExceptionMessageBean(e.getMessage(), CarryoutServiceId.REGISTER_SEARCH);
			throw e;
		}
	}
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end

	/** 正常系メッセージ設定 */
	private void setExecuteEndMessageBean(String message, CarryoutServiceId carryoutServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carryoutServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryoutServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_INFORMATION);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, CarryoutServiceId carryoutServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carryoutServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryoutServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}
}
