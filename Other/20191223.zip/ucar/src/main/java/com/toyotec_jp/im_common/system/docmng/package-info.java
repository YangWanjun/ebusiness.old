/**
 * 文書エンジン基本パッケージ
 * @version 1.00 2009/04/01 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.im_common.system.docmng;
