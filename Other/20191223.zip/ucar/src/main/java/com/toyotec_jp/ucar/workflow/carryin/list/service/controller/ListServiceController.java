package com.toyotec_jp.ucar.workflow.carryin.list.service.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import jp.co.intra_mart.framework.base.service.ServiceControllerException;
import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinEventKey;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.event.RegisterDocumentCheckDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.list.model.event.RegisterDocumentCheckDataEventResult;
import com.toyotec_jp.ucar.workflow.carryin.list.model.event.RegisterListDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListOutputBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListParamBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst.ReportEventKey;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportHannyuIchiranEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportHannyuIchiranEventResult;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportKouteiKanriEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportKouteiKanriEventResult;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportListEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportListEventResult;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportSyaryoSoubiCheckSheetEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportSyaryoSoubiCheckSheetEventResult;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportZaikoCardEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportZaikoCardEventResult;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportZaikoCardGyohanEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportZaikoCardGyohanEventResult;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportZaikoCardTenpoEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportZaikoCardTenpoEventResult;
import com.toyotec_jp.ucar.workflow.report.model.object.ReportArgumentBean;
/**
 * <strong>車両搬入一覧サービスコントローラ</strong>
 * @author Y.F(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class ListServiceController extends UcarServiceController {

	private ListParamBean listParamBean 	= new ListParamBean();
	private ListOutputBean listOutputBean 	= new ListOutputBean();
	/** 車両搬入セッションBean */
	private CarryinSessionBean sessionBean = null;
	/** 車両搬入情報 プライマリーキーList */
	private ArrayList<Ucaa001gPKBean> arrayT220001gBean = new ArrayList<Ucaa001gPKBean>();

	private String serviceId = "";
	private CarryinServiceId targetServiceId 	= null;
	private HttpServletRequest request 		= null;
	private String cdKaisya 	= null;
	private String cdHanbaitn 	= null;
	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
	private String cdTenpo 	= null;
	private String kbScenter 	= null;
	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため start
	private ArrayList<ReportArgumentBean> reportArgumentList = new ArrayList<ReportArgumentBean>();
	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため end
	private String kbGyohan 	= null;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {
		TecLogger.trace("service start");
		// セッション設定
		setupSession();
		// サービス個別処理
		executeServiceProcess();
		TecLogger.trace("service end");
		return null;
	}

	/** セッション設定
	 * @throws ServiceControllerException */
	private void setupSession() throws TecSystemException, ServiceControllerException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = CarryinServiceId.getTargetCarryinServiceId(serviceId);
		String menuId = getMenuId();

		TecLogger.debug("serviceId[" + serviceId + "]menuId[" + menuId + "]");

		// メニューID有りの場合はメニューからの呼び出し
		if(menuId != null){
			// セッションのクリア
			clearAllApplicationSession();
			// セッションの取得(新規)
			sessionBean = getNewApplicationSessionBean(CarryinSessionBean.class);
			// メニューID
			sessionBean.setMenuId(menuId);

			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
			setLoginUserInfo();

			// 会社コード
			sessionBean.getT220001gPkBean().setCdKaisya(cdKaisya);
			// 販売店コード
			sessionBean.getT220001gPkBean().setCdHanbaitn(cdHanbaitn);
			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

		} else {
			// セッションの取得
			sessionBean = getApplicationSessionBean(CarryinSessionBean.class);
		}
		sessionBean.setServiceId(serviceId);
		request = getRequest();

		// サービスごとの処理
		if(targetServiceId != null){
			switch (targetServiceId) {
				case LIST_INIT:
					// 初期処理
					//パラメータをセッションに送る
					sessionBean.setListParamBean(listParamBean);

					//ページングの設定				//	検索条件ステータス
					sessionBean.setSortParam("");	//	ソートキー
					sessionBean.setSortOrder("");	//	ソート順
					sessionBean.setPageNo("1");		//	ページ
					sessionBean.setIsKensakuOn(request.getParameter("is_kensaku_on"));
					break;

				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
				case DOCUMENT_CHECK_INIT:
					// 初期処理
					//パラメータをセッションに送る
					sessionBean.setListParamBean(listParamBean);

					//ページングの設定				//	検索条件ステータス
					sessionBean.setSortParam("");	//	ソートキー
					sessionBean.setSortOrder("");	//	ソート順
					sessionBean.setPageNo("1");		//	ページ

					sessionBean.setDocumentCheckExecute("");
					sessionBean.setCountExecute(0);
					sessionBean.setSelectRowNumber("0");
					sessionBean.setIsKensakuOn(request.getParameter("is_kensaku_on"));
					break;
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

				// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
				case LIST_REGISTER:
					// 車両搬入一覧：登録処理
					break;
				// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

				case LIST_SEARCH:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
				case DOCUMENT_CHECK_SEARCH:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
					// 検索処理
					setListParamBean();

					sessionBean.setDocumentCheckExecute("");
					sessionBean.setCountExecute(0);
					break;

				case LIST_SORT:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
				case DOCUMENT_CHECK_SORT:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
					// 検索処理
					sessionBean.setSortParam(request.getParameter("sort_param"));		//	ソートキー
					sessionBean.setSortOrder(request.getParameter("sort_order"));		//	ソート順
					sessionBean.setPageNo(request.getParameter("current_page"));		//	ページ
					// 検索on/off 2011.10.20 H.Yamashita add
					sessionBean.setIsKensakuOn(request.getParameter("is_kensaku_on"));

					// 選択行番号を初期化
					sessionBean.setSelectRowNumber("0");

					sessionBean.setDocumentCheckExecute("");
					sessionBean.setCountExecute(0);
					break;

				case TRANS_REGISTER:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
				case DOCUMENT_CHECK_TRANS_REGISTER:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
					// 搬入登録画面遷移
//					setListParamBean();
					//ページングの設定
					sessionBean.setSortParam(request.getParameter("sort_param"));		//	ソートキー
					sessionBean.setSortOrder(request.getParameter("sort_order"));		//	ソート順
					sessionBean.setPageNo(request.getParameter("current_page"));		//	ページ

					// 車両搬入一覧／書類チェック画面での選択行番号
					sessionBean.setSelectRowNumber(request.getParameter("select_row_number"));

					//sessionBean.setMenuId(menuId);
					Ucaa001gPKBean t220001gPKBean = new Ucaa001gPKBean();

					t220001gPKBean.setCdKaisya(request.getParameter("trans_cd_kaisya"));
					t220001gPKBean.setCdHanbaitn(request.getParameter("trans_cd_hanbaitn"));
					t220001gPKBean.setDdHannyu(request.getParameter("trans_dd_hannyu"));
					t220001gPKBean.setNoKanri(request.getParameter("trans_no_kanri"));
					// 会社コード
					sessionBean.setT220001gPkBean(t220001gPKBean);

					// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
					if (targetServiceId == CarryinServiceId.DOCUMENT_CHECK_TRANS_REGISTER) {
						sessionBean.setTransDocumentCheck(true);
					}
					// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

					sessionBean.setDocumentCheckExecute("");
					sessionBean.setCountExecute(0);
					// 2012.01.30 T.Hayato 追加 遷移前の絞り込み検索開閉状態 保持のため start
					sessionBean.setIsKensakuOn(request.getParameter("is_kensaku_on"));
					// 2012.01.30 T.Hayato 追加 遷移前の絞り込み検索開閉状態 保持のため end
					break;

				case RETURN_REGISTER:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
				case DOCUMENT_CHECK_RETURN_REGISTER:
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
					// 搬入登録画面からの遷移
					//sessionBean.setMenuId(null);
					break;

				// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため start
				case ZAIKO_DOWNLOAD:
					// 在庫ダウンロード
					setLoginUserInfo();
					setListOutputBean();

					if (UcarConst.KB_SCENTER_SCENTER.equals(kbScenter)) {
						// 商品化センターの場合
						listOutputBean.setArrayOutChkChecked(request.getParameterValues("rec_out_chk1_checked"));
						setArrayUcaa001gPKBean();
					} else {
						// 業販・U-Car店舗の場合
						listOutputBean.setArraySelectShape(request.getParameterValues("select_shape"));
						setArrayUcaa001gPKBeanShape();
					}

					break;

				case SYARYOSOUBI_DOWNLOAD:
					// 車両装備チェックシートダウンロード
					setLoginUserInfo();
					setListOutputBean();

					listOutputBean.setArraySelectShape(request.getParameterValues("select_shape"));
					setArrayUcaa001gPKBeanShape();

					break;
				// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため end

				case KOUTEI_DOWNLOAD:
					// 工程ダウンロード
					listOutputBean.setArrayOutChkChecked(request.getParameterValues("rec_out_chk2_checked"));
					setListOutputBean();
					setArrayUcaa001gPKBean();
					break;

				case HANNYU_DOWNLOAD:
					// 搬入一覧ダウンロード
					setListParamBean();
					break;

				case CSV_DOWNLOAD:
					setListParamBean();
					break;

				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
				case DOCUMENT_CHECK_REGISTER:
					// 搬入書類チェック：登録処理
					if (UcarConst.RDO_KUBUN_COMPLETE.equals(getRequest().getParameter("rdo_kubun"))) {
						// 検査完了／仕分完了
						resetSession();
						sessionBean.setDocumentCheckExecute(UcarConst.EXECUTE_REGISTER);
						sessionBean.setSelectRowNumber("0");
					} else {
						// 保留
						// 車両搬入一覧／書類チェック画面での選択行番号
						sessionBean.setListParamBean(new ListParamBean());
						sessionBean.setDocumentCheckExecute(UcarConst.EXECUTE_RESERVE);
						sessionBean.setSelectRowNumber("0");

						// 入庫検査／作業仕分画面での保留時に先頭で選択されたPKキー
						sessionBean.setSelectHeadReservePk(getRequest().getParameter("select_head_reserve_pk"));
					}
					listOutputBean.setArrayOutChkChecked(request.getParameterValues("rec_select_data_checked"));
					setListOutputBean();
					setArrayUcaa001gPKBean();

					sessionBean.setIsKensakuOn(request.getParameter("is_kensaku_on"));
					break;

				case DOCUMENT_CHECK_CANCEL:
					// 搬入書類チェック：取消処理
					resetSession();

					listOutputBean.setArrayOutChkChecked(request.getParameterValues("rec_select_data_checked"));
					setListOutputBean();
					setArrayUcaa001gPKBean();

					sessionBean.setDocumentCheckExecute(UcarConst.EXECUTE_CANCEL);

					sessionBean.setSelectRowNumber("0");
					sessionBean.setIsKensakuOn(request.getParameter("is_kensaku_on"));
					break;
				// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
				default:
					break;
			}
		}
		TecLogger.trace("setupSession end");
	}

	/**
	 * ログインユーザ情報設定処理
	 * @throws TecSystemException
	 * @throws ServiceControllerException
	 */
	private void setLoginUserInfo() throws TecSystemException,
												ServiceControllerException {

		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());
		cdKaisya 	= loginSessionBean.getUserInfoBean().getCdKaisya();
		cdHanbaitn 	= loginSessionBean.getUserInfoBean().getCdHanbaitn();
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		cdTenpo 	= loginSessionBean.getUserInfoBean().getCdTenpo();
		kbScenter 	= loginSessionBean.getUserInfoBean().getKbScenter();
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end
		kbGyohan 	= loginSessionBean.getUserInfoBean().getKbGyohan();
	}
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
	/**
	 * 搬入書類チェックセッションBean パラメータクリア処理
	 */
	private void resetSession() {
		sessionBean.setSortOrder("");
		sessionBean.setSortParam("");
		sessionBean.setListParamBean(new ListParamBean());
	}
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException, ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if(targetServiceId != null){
			switch (targetServiceId) {

			// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため start
			case ZAIKO_DOWNLOAD:
				// 在庫カードダウンロード
				if (UcarConst.KB_SCENTER_SCENTER.equals(kbScenter)) {
					// 商品化センターの場合
					executeReport();
				// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 start	
				} else if (UcarConst.KB_GYOHAN.equals(kbGyohan)) {
					// 業販店舗の場合
					executeReportZaikoCardGyohan();
					// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 end			
				} else {
					executeReportZaikoCardTenpo();
				}
				break;

			case SYARYOSOUBI_DOWNLOAD:
				// 車両装備チェックシートダウンロード
				executeReportReportSyaryoSoubiCheckSheet();
				break;
			// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため end

			case KOUTEI_DOWNLOAD:
				// 工程管理表ダウンロード
				executeReportKouteiKanri();
				break;

			case HANNYU_DOWNLOAD:
				// 搬入一覧ダウンロード
				executeReportHannyuIchiran();
				break;

			case CSV_DOWNLOAD:
				// CSVダウンロード
				executeCSV();
				break;

			// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
			case LIST_REGISTER:
				// 登録処理
				executeListRegister();
				break;
			// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

			// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
			case DOCUMENT_CHECK_REGISTER:
				// 登録処理
				executeDocumentCheckRegister();
				break;

			case DOCUMENT_CHECK_CANCEL:
				// 取消処理
				executeCancel();
				break;
			// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

			default:
				break;
			}
		}
		TecLogger.trace("executeServiceProcess end");
	}

	/** 検索用データ取得
	 * @throws ServiceControllerException
	 * @throws TecSystemException */
	private void setListParamBean() throws TecSystemException, ServiceControllerException{

		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
		setLoginUserInfo();

		// 会社コード
		listParamBean.setCdKaisya(cdKaisya);
		// 販売店コード
		listParamBean.setCdHanbaitn(cdHanbaitn);
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		// 店舗コード
		listParamBean.setCdTenpo(cdTenpo);
		// 商品化センター区分
		listParamBean.setKbScenter(kbScenter);
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

		listParamBean.setDdHannyuFrom(StringUtils.defaultValue(request.getParameter("dd_hannyu_from")));
																											// 搬入日(From)
		listParamBean.setDdHannyuTo(StringUtils.defaultValue(request.getParameter("dd_hannyu_to")));
																											// 搬入日(To)
		listParamBean.setCdSirtenpo(StringUtils.defaultValue(request.getParameter("cd_sirtenpo")));			// 仕入れ店舗名
		listParamBean.setCdNorikusi(StringUtils.defaultValue(request.getParameter("cd_norikusi")));			// 登録NO陸支コード
		listParamBean.setKbNosyasyu(StringUtils.defaultValue(request.getParameter("kb_nosyasyu")));			// 登録NO車種区分
		listParamBean.setCdNogyotai(StringUtils.defaultValue(request.getParameter("cd_nogyotai")));			// 登録NO業態番号
		listParamBean.setNoNoseiri(StringUtils.defaultValue(request.getParameter("no_noseiri")));			// 登録NO整理番号
		listParamBean.setMjSyamei(StringUtils.defaultValue(request.getParameter("mj_syamei")));				// 車名
		listParamBean.setMjSitkata(StringUtils.defaultValue(request.getParameter("mj_sitkata")));			// 型式
		listParamBean.setNoSyaryou(StringUtils.defaultValue(request.getParameter("no_syaryou")));			// ai21車両NO
		listParamBean.setArrayKbCheck(request.getParameterValues("kb_check"));								// チェック(未完了)
		listParamBean.setArrayKbCheckPrint(request.getParameterValues("kb_check_print"));					// 印刷チェック

		listParamBean.setArrayCheckSrk(request.getParameterValues("check_srk"));							// 状態チェック			2011.10.19 H.Yamashita add
		listParamBean.setNoSyadai(StringUtils.defaultValue(request.getParameter("no_syadai")));				// フレームNo			2011.10.20 H.Yamashita add
		listParamBean.setDdSrknbFrom(StringUtils.defaultValue(request.getParameter("dd_srknb_from")));		// 書類完備日(From)		2011.10.20 H.Yamashita add
		listParamBean.setDdSrknbTo(StringUtils.defaultValue(request.getParameter("dd_srknb_to")));			// 書類完備日(To)		2011.10.20 H.Yamashita add
		listParamBean.setDdSrkhrFrom(StringUtils.defaultValue(request.getParameter("dd_srkhr_from")));		// 保留日(From)			2011.10.20 H.Yamashita add
		listParamBean.setDdSrkhrTo(StringUtils.defaultValue(request.getParameter("dd_srkhr_to")));			// 保留日(To)			2011.10.20 H.Yamashita add
		listParamBean.setArrayKbSiire(request.getParameterValues("kb_siire"));								// 仕入種別チェック		2011.10.20 H.Yamashita add

		sessionBean.setListParamBean(listParamBean);

		//ページングの設定
		sessionBean.setSortParam(request.getParameter("sort_param"));										//	ソートキー
		sessionBean.setSortOrder(request.getParameter("sort_order"));										//	ソート順
		sessionBean.setPageNo(request.getParameter("current_page"));										//	ページ

		// 検索on/off 2011.10.19 H.Yamashita add
		sessionBean.setIsKensakuOn(request.getParameter("is_kensaku_on"));

		// 選択行番号を初期化
		sessionBean.setSelectRowNumber("0");
	}

	/** 出力用データ取得 */
	private void setListOutputBean(){
		listOutputBean.setArrayCdKaisya(request.getParameterValues("rec_cd_kaisya"));
		listOutputBean.setArrayCdHanbaitn(request.getParameterValues("rec_cd_hanbaitn"));
		listOutputBean.setArrayDdHannyu(request.getParameterValues("rec_dd_hannyu"));
		listOutputBean.setArrayNoKanri(request.getParameterValues("rec_no_kanri"));
		// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため start
		listOutputBean.setArrayCdHantenpo(request.getParameterValues("rec_cd_hantenpo"));
		// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため end
	}

	/** 出力用データ取得 */
	private void setArrayUcaa001gPKBean(){
		for (int i = 0; i < listOutputBean.getArrayOutChkChecked().length; i++) {
			if ("1".equals(listOutputBean.getArrayOutChkChecked()[i])){
				Ucaa001gPKBean wkUcaa001gPKBean = new Ucaa001gPKBean();
				wkUcaa001gPKBean.setCdKaisya(listOutputBean.getArrayCdKaisya()[i]);
				wkUcaa001gPKBean.setCdHanbaitn(listOutputBean.getArrayCdHanbaitn()[i]);
				wkUcaa001gPKBean.setDdHannyu(listOutputBean.getArrayDdHannyu()[i]);
				wkUcaa001gPKBean.setNoKanri(listOutputBean.getArrayNoKanri()[i]);

				arrayT220001gBean.add(wkUcaa001gPKBean);
			}
		}
	}

	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 出力用データ取得：形態用 */
	private void setArrayUcaa001gPKBeanShape(){
		for (int i = 0; i < listOutputBean.getArraySelectShape().length; i++) {
			if (!"".equals(listOutputBean.getArraySelectShape()[i])){
				// セダン・バンの場合

				ReportArgumentBean zaikoCardArgumentBean = new ReportArgumentBean();
				zaikoCardArgumentBean.setCdKaisya(listOutputBean.getArrayCdKaisya()[i]);
				zaikoCardArgumentBean.setCdHanbaitn(listOutputBean.getArrayCdHanbaitn()[i]);
				zaikoCardArgumentBean.setDdHannyu(listOutputBean.getArrayDdHannyu()[i]);
				zaikoCardArgumentBean.setNoKanri(listOutputBean.getArrayNoKanri()[i]);
				// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため start
				zaikoCardArgumentBean.setCdHantenpo(listOutputBean.getArrayCdHantenpo()[i]);
				// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため end

				zaikoCardArgumentBean.setSelectShape(listOutputBean.getArraySelectShape()[i]);

				reportArgumentList.add(zaikoCardArgumentBean);
			}
		}
	}
	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため end

	/** 帳票処理：在庫カード */
	private void executeReport() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportZaikoCardEvent event = createEvent(ReportEventKey.REPORT_ZAIKO_CARD,
													ReportZaikoCardEvent.class);

			event.setT220001gPKList(arrayT220001gBean);

			ReportZaikoCardEventResult eventResult = (ReportZaikoCardEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName = getDownloadFileName(ReportConst.FILE_NAME_ZAIKO_CARD, StringUtils.getFileExtension(tempFilePath));

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}

	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 帳票処理：在庫カード(店舗用) */
	private void executeReportZaikoCardTenpo() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportZaikoCardTenpoEvent event = createEvent(ReportEventKey.REPORT_ZAIKO_CARD_TENPO,
					ReportZaikoCardTenpoEvent.class);

			event.setReportArgumentList(reportArgumentList);

			ReportZaikoCardTenpoEventResult eventResult = (ReportZaikoCardTenpoEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName = getDownloadFileName(ReportConst.FILE_NAME_ZAIKO_CARD, StringUtils.getFileExtension(tempFilePath));

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}

	/** 帳票処理：車両装備チェックシート */
	private void executeReportReportSyaryoSoubiCheckSheet() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportSyaryoSoubiCheckSheetEvent event = createEvent(ReportEventKey.REPORT_SYARYO_SOUBI_CHECK_SHEET,
																ReportSyaryoSoubiCheckSheetEvent.class);

			event.setReportArgumentList(reportArgumentList);

			ReportSyaryoSoubiCheckSheetEventResult eventResult = (ReportSyaryoSoubiCheckSheetEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName = getDownloadFileName(ReportConst.FILE_NAME_SYARYO_SOUBI_CHECK_SHEET,
															StringUtils.getFileExtension(tempFilePath));

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}
	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため end

	// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 start
	/** 帳票処理：在庫カード(業販店舗用) */
	private void executeReportZaikoCardGyohan() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportZaikoCardGyohanEvent event = createEvent(ReportEventKey.REPORT_ZAIKO_CARD_GYOHAN,
					ReportZaikoCardGyohanEvent.class);

			event.setReportArgumentList(reportArgumentList);

			ReportZaikoCardGyohanEventResult eventResult = (ReportZaikoCardGyohanEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName = getDownloadFileName(ReportConst.FILE_NAME_ZAIKO_CARD, StringUtils.getFileExtension(tempFilePath));

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}
	// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 end
	
	/** 帳票処理：工程管理表 */
	private void executeReportKouteiKanri() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportKouteiKanriEvent event = createEvent(ReportEventKey.REPORT_KOUTEI_KANRI, ReportKouteiKanriEvent.class);

			event.setT220001gPKList(arrayT220001gBean);

			ReportKouteiKanriEventResult eventResult = (ReportKouteiKanriEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName = getDownloadFileName(ReportConst.FILE_NAME_KOUTEI_KANRI, StringUtils.getFileExtension(tempFilePath));

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}

	/** 帳票処理：搬入一覧表 */
	private void executeReportHannyuIchiran() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportHannyuIchiranEvent event = createEvent(ReportEventKey.REPORT_HANNYU_ICHIRAN, ReportHannyuIchiranEvent.class);

			event.setListParamBean(listParamBean);

			ReportHannyuIchiranEventResult eventResult = (ReportHannyuIchiranEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName = getDownloadFileName(ReportConst.FILE_NAME_HANNYU_ICHIRAN, StringUtils.getFileExtension(tempFilePath));

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}

	/** CSV出力処理 */
	private void executeCSV() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため start
			ReportListEvent event = createEvent(ReportEventKey.REPORT_LIST_CSV, ReportListEvent.class);
			// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため end

			event.setListParamBean(listParamBean);

			ReportListEventResult eventResult = (ReportListEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName = eventResult.getFileName();

			setAPDownloadInformation(downloadfileName, tempFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}

	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 車両搬入一覧：登録処理 */
	private void executeListRegister() throws SystemException, ApplicationException {

		RegisterListDataEvent event
			= createEvent(CarryinEventKey.LIST_REGISTER, RegisterListDataEvent.class);

		event.setCdKaisya(request.getParameterValues("rec_cd_kaisya"));
		event.setCdHanbaitn(request.getParameterValues("rec_cd_hanbaitn"));
		event.setDdHannyu(request.getParameterValues("rec_dd_hannyu"));
		event.setNoKanri(request.getParameterValues("rec_no_kanri"));

		event.setNoSyaryou(request.getParameterValues("rec_no_syaryou"));
		event.setBeforeNoSyaryou(request.getParameterValues("rec_before_no_syaryou"));

		try {
			dispatchEvent(event);

		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
			throw e;
		}

	}
	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
	/** 書類チェック：登録処理 */
	private void executeDocumentCheckRegister() throws SystemException, ApplicationException {

		RegisterDocumentCheckDataEvent event
			= createEvent(CarryinEventKey.DOCUMENT_CHECK_REGISTER, RegisterDocumentCheckDataEvent.class);

		event.setT220001gPKList(arrayT220001gBean);

		event.setRdoKubun(getRequest().getParameter("rdo_kubun"));
		event.setDdSetDate(getRequest().getParameter("dd_set_date"));

		event.setDocumentCheckDataList(sessionBean.getDocumentCheckDataList());

		event.setExecuteRegister(true);

		try {
			RegisterDocumentCheckDataEventResult eventResult
				= (RegisterDocumentCheckDataEventResult)dispatchEvent(event);

			sessionBean.setCountExecute(eventResult.getCountExecute());

		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.DOCUMENT_CHECK_INIT);
			throw e;
		}

	}

	/** 取消処理 */
	private void executeCancel() throws SystemException, ApplicationException {

		RegisterDocumentCheckDataEvent event
			= createEvent(CarryinEventKey.DOCUMENT_CHECK_REGISTER, RegisterDocumentCheckDataEvent.class);

		event.setT220001gPKList(arrayT220001gBean);

		event.setRdoKubun(getRequest().getParameter("rdo_kubun"));
		event.setDdSetDate(getRequest().getParameter("dd_set_date"));

		event.setDocumentCheckDataList(sessionBean.getDocumentCheckDataList());

		event.setExecuteRegister(false);

		try {
			RegisterDocumentCheckDataEventResult eventResult
				= (RegisterDocumentCheckDataEventResult)dispatchEvent(event);

			sessionBean.setCountExecute(eventResult.getCountExecute());

		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.DOCUMENT_CHECK_INIT);
			throw e;
		}

	}
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

	/** 帳票ダウンロードファイル名取得
	 * @param fileName */
	private String getDownloadFileName(String fileName, String fileExtension){
		StringBuilder sb = new StringBuilder();

		sb.append(fileName + "_");

		sb.append(DateUtils.getCurrentDateStr(DateUtils.FORMAT_LONG_SIMPLE));
		sb.append("." + fileExtension);
		return new String(sb);
	}

	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, CarryinServiceId carryinServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carryinServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryinServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

}
