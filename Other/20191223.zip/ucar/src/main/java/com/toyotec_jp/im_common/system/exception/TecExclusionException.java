/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecExclusionException.java
 * 【  説  明  】
 * 【  作  成  】2010/06/17 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import java.util.ArrayList;

import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;


/**
 * <strong>排他例外クラス。</strong>
 * <p>
 * 排他による更新処理失敗時のアプリケーション例外。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/17 新規作成<br>
 * @since 1.00
 */
public class TecExclusionException extends TecApplicationException {

	private static final long serialVersionUID = 4988705429539771879L;

	/**
	 * コンストラクタ。
	 */
	public TecExclusionException() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param message
	 */
	public TecExclusionException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * @param cause
	 */
	public TecExclusionException(Throwable cause) {
		super(cause);
	}

	/**
	 * コンストラクタ。
	 * @param message
	 * @param cause
	 */
	public TecExclusionException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 */
	public TecExclusionException(TecMessageKeyIF messageKey) {
		super(messageKey);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 */
	public TecExclusionException(TecMessageKeyIF messageKey, ArrayList<Object> args) {
		super(messageKey, args);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param cause
	 */
	public TecExclusionException(TecMessageKeyIF messageKey, Throwable cause) {
		super(messageKey, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 * @param cause
	 */
	public TecExclusionException(TecMessageKeyIF messageKey, ArrayList<Object> args, Throwable cause) {
		super(messageKey, args, cause);
	}

}
