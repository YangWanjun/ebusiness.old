package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;

/**
 * <strong>売上精算取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class GetSalesAdjustmentDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 売上精算 画面出力値Bean */
	private SalesAdjustmentDataBean salesAdjustmentDataBean;
	/** 確認メッセージ表示 */
	private boolean confirmMessage;
	/** 再発行ボタン使用可否フラグ */
	private boolean disabledBtnReissue;

	/**
	 * salesAdjustmentDataBeanを取得する。
	 * @return salesAdjustmentDataBean
	 */
	public SalesAdjustmentDataBean getSalesAdjustmentDataBean() {
		return salesAdjustmentDataBean;
	}

	/**
	 * salesAdjustmentDataBeanを設定する。
	 * @param salesAdjustmentDataBean
	 */
	public void setSalesAdjustmentDataBean(
			SalesAdjustmentDataBean salesAdjustmentDataBean) {
		this.salesAdjustmentDataBean = salesAdjustmentDataBean;
	}

	/**
	 * confirmMessageを取得する。
	 * @return confirmMessage
	 */
	public boolean isConfirmMessage() {
		return confirmMessage;
	}

	/**
	 * confirmMessageを設定する。
	 * @param confirmMessage
	 */
	public void setConfirmMessage(boolean confirmMessage) {
		this.confirmMessage = confirmMessage;
	}

	/**
	 * disabledBtnReissueを取得する。
	 * @return disabledBtnReissue
	 */
	public boolean isDisabledBtnReissue() {
		return disabledBtnReissue;
	}

	/**
	 * disabledBtnReissueを設定する。
	 * @param disabledBtnReissue
	 */
	public void setDisabledBtnReissue(boolean disabledBtnReissue) {
		this.disabledBtnReissue = disabledBtnReissue;
	}

}
