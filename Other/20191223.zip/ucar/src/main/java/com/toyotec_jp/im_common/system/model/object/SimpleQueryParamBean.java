/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】SimpleQueryParamBean.java
 * 【  説  明  】
 * 【  作  成  】2010/06/04 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.model.object;

import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;

import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.TecApplicationManager.TecConfigKey;


/**
 * <strong>簡易クエリ実行用クエリパラメータビーン。</strong>
 * <p>
 * 簡易クエリ実行メソッドを使用する場合、以下の手順で設定を行い、
 * 引数として使用すること。<br>
 * 1.インスタンス化<br>
 * 2.SQL設定<br>
 * sqlはORDER BY、WITH句を除いた文を設定する。<br>
 * ORDER BY句はorderSql、WITH句はwithSqlに設定する。<br>
 * 3.ページングを使用する場合、pageNo、pageSizeを設定する。<br>
 * 未指定の場合、pageNoは1、
 * pageSizeは「TConfig.properties」の
 * 「com.toyotec_jp.im_common.system.paging.DefaultPageSize」をデフォルト値とする。<br>
 * pageSize=0の場合、ページング無し。<br>
 * 4.行数制限がある場合はrecLimitを設定する。<br>
 * 未指定の場合、「TConfig.properties」の
 * 「com.toyotec_jp.im_common.system.paging.DefaultRecLimit」をデフォルト値とする。<br>
 * recLimit=0の場合、制限無し。<br>
 * 5.プリペアドステートメント用パラメータ設定<br>
 * プリペアドステートメントに対してsetXXXを実行する場合と同じ要領でsetXXXを実行する。<br>
 * SQLServerのbit、date、datetime2型用にsetSqlSrvXXXを追加している。<br>
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/04 新規作成<br>
 * @since 1.00
 */
public class SimpleQueryParamBean extends TecBean {

	private static final long serialVersionUID = 7515445958963085454L;

	private String sql;

	private String withSql;

	private String orderSql;

	private int pageNo;

	private int pageSize;

	private int recLimit;

	private ArrayList<SimplePrepareParamBean> paramList = new ArrayList<SimplePrepareParamBean>();

	/**
	 * コンストラクタ。
	 * @param sql
	 */
	public SimpleQueryParamBean(String sql){
		init(sql, null);
	}

	/**
	 * コンストラクタ。
	 * @param sql
	 * @param orderSql
	 */
	public SimpleQueryParamBean(String sql, String orderSql){
		init(sql, orderSql);
	}

	// 初期処理
	private void init(String sql, String orderSql){
		this.sql = sql;
		this.orderSql = orderSql;
		this.pageNo = 1;
		this.pageSize = TecApplicationManager.getConfigInt(TecConfigKey.DEFAULT_PAGE_SIZE);
		if(this.pageSize < 0){
			this.pageSize = 0;
		}
		this.recLimit = TecApplicationManager.getConfigInt(TecConfigKey.DEFAULT_REC_LIMIT);
		if(this.recLimit < 0){
			this.recLimit = 0;
		}
	}

	/**
	 * プリペアドステートメント用パラメータ(BigDecimal型)設定。
	 * @param value
	 */
	public void setBigDecimal(BigDecimal value){
		setObject(value, Types.NUMERIC);
	}

	/**
	 * プリペアドステートメント用パラメータ(boolean型)設定。
	 * @param value
	 */
	public void setBoolean(boolean value){
		setObject(value, Types.BOOLEAN);
	}

	/**
	 * プリペアドステートメント用パラメータ(java.sql.Date型)設定。
	 * @param value
	 */
	public void setDate(java.sql.Date value){
		setObject(value, Types.DATE);
	}

	/**
	 * プリペアドステートメント用パラメータ(java.util.Date型)設定。
	 * @param value
	 */
	public void setDate(java.util.Date value){
		setObject(new java.sql.Date(value.getTime()), Types.DATE);
	}

	/**
	 * プリペアドステートメント用パラメータ(double型)設定。
	 * @param value
	 */
	public void setDouble(double value){
		setObject(value, Types.DOUBLE);
	}

	/**
	 * プリペアドステートメント用パラメータ(float型)設定。
	 * @param value
	 */
	public void setFloat(float value){
		setObject(value, Types.REAL);
	}

	/**
	 * プリペアドステートメント用パラメータ(int型)設定。
	 * @param value
	 */
	public void setInt(int value){
		setObject(value, Types.INTEGER);
	}

	/**
	 * プリペアドステートメント用パラメータ(long型)設定。
	 * @param value
	 */
	public void setLong(long value){
		setObject(value, Types.BIGINT);
	}

	/**
	 * プリペアドステートメント用パラメータ(NString型)設定。
	 * @param value
	 */
	public void setNString(String value){
		setObject(value, Types.NVARCHAR);
	}

	/**
	 * プリペアドステートメント用パラメータ(short型)設定。
	 * @param value
	 */
	public void setShort(short value){
		setObject(value, Types.SMALLINT);
	}

	/**
	 * プリペアドステートメント用パラメータ(String型)設定。
	 * @param value
	 */
	public void setString(String value){
		setObject(value, Types.VARCHAR);
	}

	/**
	 * プリペアドステートメント用パラメータ(Time型)設定。
	 * @param value
	 */
	public void setTime(Time value){
		setObject(value, Types.TIME);
	}

	/**
	 * プリペアドステートメント用パラメータ(Timestamp型)設定。
	 * @param value
	 */
	public void setTimestamp(Timestamp value){
		setObject(value, Types.TIMESTAMP);
	}

	/**
	 * プリペアドステートメント用パラメータ(bit型)設定。<br>
	 * bit項目に対する値の設定(SQLServer用)。
	 * <pre>
	 * 1:true、0:false
	 * </pre>
	 * @param value
	 */
	public void setSqlSrvBit(String value){
		setObject(value, Types.VARCHAR);
	}

	/**
	 * プリペアドステートメント用パラメータ(bit型)設定。<br>
	 * bit項目に対する値の設定(SQLServer用)。
	 * @param value
	 */
	public void setSqlSrvBit(boolean value){
		setObject(value, Types.BOOLEAN);
	}

	/**
	 * プリペアドステートメント用パラメータ(date型)設定。<br>
	 * date項目に対する値の設定(SQLServer用)。
	 * <pre>
	 * フォーマットは「YYYY-MM-DD」、「YYYY/MM/DD」、「YYYY-M-D」、「YYYY/M/D」
	 * </pre>
	 * @param value
	 */
	public void setSqlSrvDate(String value){
		if(value == null || value.length() == 0){
			setObject(null, Types.VARCHAR);
		} else {
			setObject(value, Types.VARCHAR);
		}
	}

	/**
	 * プリペアドステートメント用パラメータ(date型)設定。<br>
	 * date項目に対する値の設定(SQLServer用)。
	 * <pre>
	 * 1970 年 1 月 1 日、0 時 0 分 0 秒 GMT (グリニッジ標準時) を起点とした時間をミリ秒で表した値で、
	 * 8099 年のミリ秒表現を超えない値。
	 * 負の値は、1970 年 1 月 1 日、0 時 0 分 0 秒 GMT (グリニッジ標準時) より前のミリ秒を示す。
	 * </pre>
	 * @param value
	 */
	public void setSqlSrvDate(long value){
		setObject(new java.sql.Date(value).toString(), Types.VARCHAR);
	}

	/**
	 * プリペアドステートメント用パラメータ(date型)設定。<br>
	 * date項目に対する値の設定(SQLServer用)。
	 * @param value
	 */
	public void setSqlSrvDate(java.util.Date value){
		if(value == null){
			setObject(null, Types.VARCHAR);
		} else {
			setObject(new java.sql.Date(value.getTime()).toString(), Types.VARCHAR);
		}
	}

	/**
	 * プリペアドステートメント用パラメータ(date型)設定。<br>
	 * date項目に対する値の設定(SQLServer用)。
	 * @param value
	 */
	public void setSqlSrvDate(Timestamp value){
		if(value == null){
			setObject(null, Types.VARCHAR);
		} else {
			setObject(new java.sql.Date(value.getTime()).toString(), Types.VARCHAR);
		}
	}

	/**
	 * プリペアドステートメント用パラメータ(datetime2型)設定。<br>
	 * datetime2項目に対する値の設定(SQLServer用)。
	 * @param value
	 */
	public void setSqlSrvDatetime2(String value){
		if(value == null || value.length() == 0){
			setObject(null, Types.VARCHAR);
		} else {
			setObject(value, Types.VARCHAR);
		}
	}

	/**
	 * プリペアドステートメント用パラメータ(datetime2型)設定。<br>
	 * datetime2項目に対する値の設定(SQLServer用)。
	 * <pre>
	 * ナノ秒は対象外。
	 * 1970 年 1 月 1 日、0 時 0 分 0 秒 GMT (グリニッジ標準時) を起点とした時間をミリ秒で表した値で、
	 * 8099 年のミリ秒表現を超えない値。
	 * 負の値は、1970 年 1 月 1 日、0 時 0 分 0 秒 GMT (グリニッジ標準時) より前のミリ秒を示す。
	 * </pre>
	 * @param value
	 */
	public void setSqlSrvDatetime2(long value){
		setObject(new Timestamp(value).toString(), Types.VARCHAR);
	}

	/**
	 * プリペアドステートメント用パラメータ(datetime2型)設定。<br>
	 * datetime2項目に対する値の設定(SQLServer用)。
	 * <pre>
	 * ナノ秒は対象外。
	 * </pre>
	 * @param value
	 */
	public void setSqlSrvDatetime2(java.util.Date value){
		if(value == null){
			setObject(null, Types.VARCHAR);
		} else {
			setObject(new Timestamp(value.getTime()).toString(), Types.VARCHAR);
		}
	}

	/**
	 * プリペアドステートメント用パラメータ(datetime2型)設定。<br>
	 * datetime2項目に対する値の設定(SQLServer用)。
	 * @param value
	 */
	public void setSqlSrvDatetime2(Timestamp value){
		if(value == null){
			setObject(null, Types.VARCHAR);
		} else {
			setObject(value.toString(), Types.VARCHAR);
		}
	}

	/**
	 * プリペアドステートメント用パラメータ(Null)設定。
	 * @param sqlType
	 */
	public void setNull(int sqlType){
		setObject(null, sqlType);
	}

	/**
	 * プリペアドステートメント用パラメータ設定。
	 * @param value
	 * @param targetSqlType
	 */
	public void setObject(Object value, int targetSqlType){
		addParamList(targetSqlType, value);
	}

	// プリペアドステートメント用パラメータ追加
	private void addParamList(int sqlType, Object value){
		if(paramList == null){
			paramList = new ArrayList<SimplePrepareParamBean>();
		}
		SimplePrepareParamBean bean = new SimplePrepareParamBean(sqlType, value);
		paramList.add(bean);
	}

	/**
	 * プリペアドステートメント用パラメータをクリアする。
	 */
	public void clearParamList(){
		if(paramList != null){
			paramList.clear();
		}
	}

	/**
	 * sqlを取得する。
	 * @return sql
	 */
	public String getSql() {
		return sql;
	}

	/**
	 * sqlを設定する。
	 * @param sql
	 */
	public void setSql(String sql) {
		this.sql = sql;
	}

	/**
	 * withSqlを取得する。
	 * @return withSql
	 */
	public String getWithSql() {
		return withSql;
	}

	/**
	 * withSqlを設定する。
	 * @param withSql
	 */
	public void setWithSql(String withSql) {
		this.withSql = withSql;
	}

	/**
	 * orderSqlを取得する。
	 * @return orderSql
	 */
	public String getOrderSql() {
		return orderSql;
	}

	/**
	 * orderSqlを設定する。
	 * @param orderSql
	 */
	public void setOrderSql(String orderSql) {
		this.orderSql = orderSql;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @param pageNo
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * recLimitを取得する。
	 * @return recLimit
	 */
	public int getRecLimit() {
		return recLimit;
	}

	/**
	 * recLimitを設定する。
	 * @param recLimit
	 */
	public void setRecLimit(int recLimit) {
		this.recLimit = recLimit;
	}

	/**
	 * paramListを取得する。
	 * @return paramList
	 */
	public ArrayList<SimplePrepareParamBean> getParamList() {
		return paramList;
	}

	/**
	 * paramListを設定する。
	 * @param paramList
	 */
	public void setParamList(ArrayList<SimplePrepareParamBean> paramList) {
		this.paramList = paramList;
	}

}
