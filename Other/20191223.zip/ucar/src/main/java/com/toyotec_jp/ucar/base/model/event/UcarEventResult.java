/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarEventResult.java
 * 【  説  明  】
 * 【  作  成  】2010/06/02 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.model.event;

import jp.co.intra_mart.framework.base.event.EventResult;

/**
 * <strong>基本イベントリザルト。</strong>
 * <p>
 * イベントリザルト作成時は本IFを実装すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/02 新規作成<br>
 * @since 1.00
 */
public abstract interface UcarEventResult extends EventResult {

}
