
package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSystemDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.report.model.object.UcarZaikoBean;
/**
 * <strong>在庫カード(店舗用) System Dao</strong>
 * <pre>
 *  system-data-sourceで直接addonDBにアクセスするために使用する
 * </pre>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/11 新規作成<br>
 * @since 1.00
 * @category [[在庫カード(店舗用)]]
 */
public class UcarCommonSystemDBDAOImpl extends UcarSystemDBDAO implements UcarCommonSystemDBDAOIF {

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListDaoIF#selectAll()
	 */
	@Override
	public UcarZaikoBean selectUcarZaiko(String dbLink, String cdKaisya, String noSyaryou) throws TecDAOException {

		String executeSql
		= "SELECT "
		+ "    KIHON.KI_SIIREKA "
		+ "  , KIHON.KI_HONTSTK "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add start
		+ "  , KIHON.KI_HONTSTZM "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add end
		+ "  , KIHON.CD_UCTOCOL "
		+ "  , KIHON.CD_NAISO "
		+ "  , KIHON.DD_SYKNMANR "
		+ "  , KIHON.DD_JIBAMANR "
		+ "  , KIHON.NO_FRAME "
		+ "  , KIHON.NO_SITERUIB "
		+ "  , KIHON.NU_ZENHABA "
		+ "  , KIHON.NU_ZENTYO "
		+ "  , KIHON.NU_ZENKO "
		+ "  , KIHON.DD_YATAKU "
		+ "  , KIHON.KI_AZRECYYO "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add start
		+ "  , KIHON.KI_AZRECYZM "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add end
		+ "  , KIHON.KI_JIZNENZE "
		+ "  , KIHON.MJ_DOASU "
		+ "  , KIHON.CD_MISSION "
		+ "  , KIHON.KB_AIRCONUM "
		+ "  , KIHON.KB_PSUTEUMU "
		+ "  , KIHON.KB_PWINDOWU "
		+ "  , KIHON.KB_ARUMIUMU "
		+ "  , KIHON.KB_SANRUFUU "
		+ "  , KIHON.MJ_FURUSYAM "
		+ "  , KIHON.NU_HAIKIRYO "
		+ "  , KIHON.SU_SYODOTOR "
		+ "  , KIHON.DD_SIIRE "
		+ "  , KIHON.MJ_21SYAMEK MJ_SYAMEK21 "	// 本来のカラム名のままgetter/setterすると、executeSimpleSelectQueryのsetter処理の変換がうまくいかないので変更してます
		+ "  , KIHON.NU_SEKISAIR "
		+ "  , KIHON.NU_KAZEJYRY "
		+ "  , KIHON.MJ_SITKATA "
		+ "  , KIHON.KB_ENGINE "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add start
		+ "  , KIHON.CD_SITADOTE "
		+ "  , KIHON.NU_SOUKOUKM "
		+ "  , KIHON.KB_TSVALUE "
		+ "  , KIHON.KB_HOSYOU "
		+ "  , KIHON.MJ_FREEKEHA "
		+ "  , KIHON.MJ_FREEKETO "
		+ "  , KIHON.MJ_HAIGASU "
		+ "  , KIHON.MJ_KATASIKI "
		+ "  , KIHON.NO_SYADAIBA "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add end
		// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 start
		+ "  , KIHON.CD_KAISYA "
		+ "  , KIHON.MJ_SIRENORI "
		+ "  , KIHON.KB_SIRETOSY "
		+ "  , KIHON.CD_SIRETOGY "
		+ "  , KIHON.NO_SIRETOSE "
		// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 end
		+ "  , SIIRE.KB_KUDOHOHO "
		+ "  , SIIRE.KB_KANREIUM "
		+ "  , SIIRE.KB_SOBI1UM "
		+ "  , SIIRE.KB_AUTODUM "
		+ "  , SIIRE.KB_ABSUM "
		+ "  , SIIRE.KB_AIRBAKUM "
		+ "  , SIIRE.KB_SOBI2UM "
		+ "  , SIIRE.KB_SOBI3UM "
		+ "  , SIIRE.CD_CDUMU "
		+ "  , SIIRE.KB_DVDUMU "
		+ "  , SIIRE.KB_TVUMU "
		+ "  , SIIRE.KB_KANABUMU "
		+ "  , SIIRE.KB_SOBI10UM "
		+ "  , SIIRE.KB_SOBI11UM "
		+ "  , SIIRE.KB_PWSEATUM "
		+ "  , SIIRE.KB_SEATSZAI "
		+ "  , SIIRE.KB_SOBI7UM "
		+ "  , SIIRE.KB_SOBI8UM "
		+ "  , SIIRE.KB_SOBI9UM "
		+ "  , SIIRE.KB_SOBI6UM "
		+ "  , SIIRE.KB_SUPUM "
		+ "  , SIIRE.KB_LODOWNUM "
		+ "  , SIIRE.CD_HIDUM "
		+ "  , SIIRE.KB_DENDODUM "
		+ "  , SIIRE.KB_KEYLESUM "
		+ "  , SIIRE.KB_RMCONUM "
		+ "  , SIIRE.KB_ETCUM "
		+ "  , SIIRE.KB_BACKMUM "
		+ "  , SIIRE.KB_SOBI4UM "
		+ "  , SIIRE.KB_SOBI5UM "
		+ "  , SIIRE.NU_JOSYA1 "
		+ "  , SIIRE.NU_JOSYA2 "
		+ "FROM "
		+ "  TBBC001G" + dbLink + " KIHON "
		+ "  LEFT JOIN TBBC002G" + dbLink + " SIIRE "
		+ "    ON KIHON.CD_KAISYA = SIIRE.CD_KAISYA "
		+ "    AND KIHON.NO_SYARYOU = SIIRE.NO_SYARYOU "
		+ "WHERE "
		+ "  KIHON.CD_KAISYA = ? "
		+ "  AND KIHON.NO_SYARYOU = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(noSyaryou);	// 車両NO

		ResultArrayList<UcarZaikoBean> ucarZaikoList = executeSimpleSelectQuery(paramBean, UcarZaikoBean.class);
		UcarZaikoBean ucarZaikoBean = new UcarZaikoBean();

		if (ucarZaikoList.size() > 0) {
			ucarZaikoBean = ucarZaikoList.get(0);
		}

		return ucarZaikoBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.report.model.data.ZaikoCardTenpoSystemDBDaoIF#selectSyaryoSoubi(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public UcarZaikoBean selectSyaryoSoubiCheckSheet(String dbLink, String cdKaisya,
			String noSyaryou) throws TecDAOException {

		String executeSql
		= "SELECT "
		+ "    KIHON.NU_HAIKIRYO "
		+ "  , KIHON.NO_SITERUIB "
		+ "  , KIHON.NU_ZENTYO "
		+ "  , KIHON.NU_ZENHABA "
		+ "  , KIHON.DD_JIBAMANR "
		+ "  , KIHON.DD_SIIRE "
		+ "  , KIHON.CD_SITADOTE "
		+ "  , KIHON.NU_ZENKO "
		+ "  , KIHON.CD_SIRETENP "
		+ "  , KIHON.KI_SIIREKA "
		+ "  , KIHON.KI_HONTSTK "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add start
		+ "  , KIHON.KI_HONTSTZM "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add end
		+ "  , KIHON.DD_YATAKU "
		+ "  , KIHON.KI_AZRECYYO "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add start
		+ "  , KIHON.KI_AZRECYZM "
		+ "  , KIHON.MJ_KATASIKI "
		+ "  , KIHON.NU_SOUKOUKM "
		+ "  , KIHON.CD_UCTOCOL "
		+ "  , KIHON.CD_NAISO "
		+ "  , KIHON.MJ_HAIGASU "
		// 2015.03.17 Y.Negishi U-Car帳票改善 add end
		+ "FROM "
		+ "  TBBC001G" + dbLink + " KIHON "
		+ "WHERE "
		+ "  KIHON.CD_KAISYA = ? "
		+ "  AND KIHON.NO_SYARYOU = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(noSyaryou);	// 車両NO

		ResultArrayList<UcarZaikoBean> ucarZaikoList = executeSimpleSelectQuery(paramBean, UcarZaikoBean.class);
		UcarZaikoBean ucarZaikoBean = new UcarZaikoBean();

		if (ucarZaikoList.size() > 0) {
			ucarZaikoBean = ucarZaikoList.get(0);
		}

		return ucarZaikoBean;
	}

}