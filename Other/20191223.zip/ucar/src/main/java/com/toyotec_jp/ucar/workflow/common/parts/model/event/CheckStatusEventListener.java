package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaTransactionDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gBean;

/**
 * <strong>ステータスDB存在チェックイベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/04 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CheckStatusEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		CheckStatusEvent targetEvent = (CheckStatusEvent)event;

		UcaaTransactionDAOIF dao
			= getDAO(UcarDAOKey.UCAA_TRANSACTION_DAO, targetEvent, UcaaTransactionDAOIF.class);

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//		T220012gBean t220012gBean = dao.selectT220012g(targetEvent.getT220001gPkBean().getCdKaisya(),
//														targetEvent.getT220001gPkBean().getCdHanbaitn(),
//														targetEvent.getT220001gPkBean().getDdHannyu(),
//														targetEvent.getT220001gPkBean().getNoKanri());
		Uccb007gBean t220012gBean = dao.selectT220012g(targetEvent.getT220107gPkBean().getCdKaisya(),
														targetEvent.getT220107gPkBean().getCdHanbaitn(),
														targetEvent.getT220107gPkBean().getDdHannyu(),
														targetEvent.getT220107gPkBean().getNoKanri(),
														targetEvent.getT220107gPkBean().getCdZaitenpo(),
														targetEvent.getT220107gPkBean().getKbScenter());
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		// チェック範囲内に日付が存在すればtrue
		boolean existDtStatus = false;

		int startDdStatus = targetEvent.getStartDtStatus();
		int endDdStatus = targetEvent.getEndDtStatus();

		if (t220012gBean != null) {
			// ステータスDBにデータがある場合
			for (int i = startDdStatus; i <= endDdStatus; i++) {
				switch (i) {
					case 1:
						if (t220012gBean.getDtStatus01() != null) {
							existDtStatus = true;
						}
						break;
					case 2:
						if (t220012gBean.getDtStatus02() != null) {
							existDtStatus = true;
						}
						break;
					case 3:
						if (t220012gBean.getDtStatus03() != null) {
							existDtStatus = true;
						}
						break;
					case 4:
						if (t220012gBean.getDtStatus04() != null) {
							existDtStatus = true;
						}
						break;
					case 5:
						if (t220012gBean.getDtStatus05() != null) {
							existDtStatus = true;
						}
						break;
					case 6:
						if (t220012gBean.getDtStatus06() != null) {
							existDtStatus = true;
						}
						break;
					case 7:
						if (t220012gBean.getDtStatus07() != null) {
							existDtStatus = true;
						}
						break;
					case 8:
						if (t220012gBean.getDtStatus08() != null) {
							existDtStatus = true;
						}
						break;
					case 9:
						if (t220012gBean.getDtStatus09() != null) {
							existDtStatus = true;
						}
						break;
					case 10:
						if (t220012gBean.getDtStatus10() != null) {
							existDtStatus = true;
						}
						break;
					case 11:
						if (t220012gBean.getDtStatus11() != null) {
							existDtStatus = true;
						}
						break;
					case 12:
						if (t220012gBean.getDtStatus12() != null) {
							existDtStatus = true;
						}
						break;
					case 13:
						if (t220012gBean.getDtStatus13() != null) {
							existDtStatus = true;
						}
						break;
					case 14:
						if (t220012gBean.getDtStatus14() != null) {
							existDtStatus = true;
						}
						break;
					case 15:
						if (t220012gBean.getDtStatus15() != null) {
							existDtStatus = true;
						}
						break;
					case 16:
						if (t220012gBean.getDtStatus16() != null) {
							existDtStatus = true;
						}
						break;
					case 17:
						if (t220012gBean.getDtStatus17() != null) {
							existDtStatus = true;
						}
						break;
					case 18:
						if (t220012gBean.getDtStatus18() != null) {
							existDtStatus = true;
						}
						break;
					case 19:
						if (t220012gBean.getDtStatus19() != null) {
							existDtStatus = true;
						}
						break;
					case 20:
						if (t220012gBean.getDtStatus20() != null) {
							existDtStatus = true;
						}
						break;
					case 21:
						if (t220012gBean.getDtStatus21() != null) {
							existDtStatus = true;
						}
						break;
					case 22:
						if (t220012gBean.getDtStatus22() != null) {
							existDtStatus = true;
						}
						break;
					case 23:
						if (t220012gBean.getDtStatus23() != null) {
							existDtStatus = true;
						}
						break;
					case 24:
						if (t220012gBean.getDtStatus24() != null) {
							existDtStatus = true;
						}
						break;
					default:
						break;
				}
				if (existDtStatus) {
					break;
				}
			}
		}

		CheckStatusEventResult getResult = new CheckStatusEventResult();
		getResult.setExistDtStatus(existDtStatus);
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
		return getResult;
	}
}
