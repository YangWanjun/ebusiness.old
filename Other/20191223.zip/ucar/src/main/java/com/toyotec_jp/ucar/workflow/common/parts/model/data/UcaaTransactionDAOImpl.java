package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;

/**
 * <strong>U-Car商品化システム トランザクション操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/07/05 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UcaaTransactionDAOImpl extends UcarSharedDBDAO implements UcaaTransactionDAOIF {

	private static final String SELECT_NO_KATARUIB_SQL
		= "SELECT "
		+ "    NO_KATARUIB "
		+ "FROM "
		+ "  T220001G ";

	private static final String SELECT_NO_KATARUIB_WHERE_SQL
		= "WHERE"
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND NO_KATARUIB = ? ";

	private static final String SELECT_NO_KATARUIB_EDIT_WHERE_SQL
		= "WHERE "
		+ "      NO_KATARUIB = ? "
		+ "  AND NOT (CD_KAISYA  = ? "
		+ "      AND CD_HANBAITN = ? "
		+ "      AND DD_HANNYU   = ? "
		+ "      AND NO_KANRI    = ? ) ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaTransactionDAOIF#selectNoKataruibCount(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectNoKataruibCount(String cdKaisya, String cdHanbaitn, String noKataruib) throws TecDAOException {

		int count = 0;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

			StringBuilder selectSql = new StringBuilder(SELECT_NO_KATARUIB_SQL);
			selectSql.append(SELECT_NO_KATARUIB_WHERE_SQL);

			paramBean.setSql(selectSql.toString());

			// パラメータセット<条件>
			paramBean.setString(cdKaisya);		// 会社コード
			paramBean.setString(cdHanbaitn);	// 販売店コード
			paramBean.setString(noKataruib);	// 型式指定類別NO

			// 取得
			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaTransactionDAOIF#selectNoKataruibEditCount(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectNoKataruibEditCount(String cdKaisya, String cdHanbaitn,
			String ddHannyu, String noKanri, String noKataruib)
			throws TecDAOException {

		int count = 0;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

			StringBuilder selectSql = new StringBuilder(SELECT_NO_KATARUIB_SQL);
			selectSql.append(SELECT_NO_KATARUIB_EDIT_WHERE_SQL);

			paramBean.setSql(selectSql.toString());

			// パラメータセット<条件>
			paramBean.setString(noKataruib);	// 型式指定類別NO
			paramBean.setString(cdKaisya);		// 会社コード
			paramBean.setString(cdHanbaitn);	// 販売店コード
			paramBean.setString(ddHannyu);		// 搬入日
			paramBean.setString(noKanri);		// 管理番号

			// 取得
			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	@Override
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
//	public T220012gBean selectT220012g(String cdKaisya, String cdHanbaitn,
//			String ddHannyu, String noKanri) throws TecDAOException {
	public Uccb007gBean selectT220012g(String cdKaisya, String cdHanbaitn,
			String ddHannyu, String noKanri, String cdTenpo, String kbScenter) throws TecDAOException {
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start		
		/** ステータスDB */
		String selectT220012gSql
			= "SELECT "
			+ "    DT_STATUS01 "
			+ "  , DT_STATUS02 "
			+ "  , DT_STATUS03 "
			+ "  , DT_STATUS04 "
			+ "  , DT_STATUS05 "
			+ "  , DT_STATUS06 "
			+ "  , DT_STATUS07 "
			+ "  , DT_STATUS08 "
			+ "  , DT_STATUS09 "
			+ "  , DT_STATUS10 "
			+ "  , DT_STATUS11 "
			+ "  , DT_STATUS12 "
			+ "  , DT_STATUS13 "
			+ "  , DT_STATUS14 "
			+ "  , DT_STATUS15 "
			+ "  , DT_STATUS16 "
			+ "  , DT_STATUS17 "
			+ "  , DT_STATUS18 "
			+ "  , DT_STATUS19 "
			+ "  , DT_STATUS20 "
			+ "  , DT_STATUS21 "
			+ "  , DT_STATUS22 "
			+ "  , DT_STATUS23 "
			+ "  , DT_STATUS24 "
			+ "  , NU_AZONE "
			+ "  , NU_BZONE "
			+ "FROM "
//			+ "  T220012G "
			+ "  " + UcarTableManager.getStatus(kbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(selectT220012gSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(cdHanbaitn);// 販売店コード
		paramBean.setString(ddHannyu);	// 搬入日
		paramBean.setString(noKanri);	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(cdTenpo);	// 在庫店舗コード			
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

//		ResultArrayList<T220012gBean> ucac007gList = executeSimpleSelectQuery(paramBean, T220012gBean.class);
		ResultArrayList<Uccb007gBean> ucac007gList = executeSimpleSelectQuery(paramBean, Uccb007gBean.class);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

//		T220012gBean t220012gBean = null;
		Uccb007gBean t220012gBean = null;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		if(ucac007gList.size() > 0){
			t220012gBean = ucac007gList.get(0);
			if(ucac007gList.size() > 1){
				TecLogger.warn("ステータスDB(新) 不整合");
			}
		}
		return t220012gBean;
	}
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため start
	@Override
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
//	public T220012gBean selectT220012g(String cdKaisya, String cdHanbaitn,
//			String ddHannyu, String noKanri, int checkStatusNo)
	public Uccb007gBean selectT220012g(String cdKaisya, String cdHanbaitn,
			String ddHannyu, String noKanri, String cdTenpo, String kbScenter, int checkStatusNo)
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		
		String selectT220012gSql
			= "SELECT "
			+ "    DT_STATUS" + StringUtils.padLeft(String.valueOf(checkStatusNo), '0', 2)
			+ " FROM "
//			+ "  T220012G "
			+ "  " + UcarTableManager.getStatus(kbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ " WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(selectT220012gSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(cdHanbaitn);// 販売店コード
		paramBean.setString(ddHannyu);	// 搬入日
		paramBean.setString(noKanri);	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(cdTenpo);	// 在庫店舗コード			
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

//		ResultArrayList<T220012gBean> ucac007gList = executeSimpleSelectQuery(paramBean, T220012gBean.class);
		ResultArrayList<Uccb007gBean> ucac007gList = executeSimpleSelectQuery(paramBean, Uccb007gBean.class);

//		T220012gBean t220012gBean = null;
		Uccb007gBean t220012gBean = null;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		if(ucac007gList.size() > 0){
			t220012gBean = ucac007gList.get(0);
			if(ucac007gList.size() > 1){
				TecLogger.warn("ステータスDB(新) 不整合");
			}
		}
		return t220012gBean;
	}
	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため end

	// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#updateT220012GZoneDate(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220012gInputDataBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220012GZoneDate(
//			T220012gInputDataBean t220012gInputDataBean, Timestamp executeDate)
			Uccb007gInputDataBean t220012gInputDataBean, Timestamp executeDate)	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		// 2012.02.10 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
		/** 更新処理（ステータスDB）Aゾーン日数・ABゾーン日数 更新用 SQL */
		String updateT220012gZonedateSql
//			= "UPDATE T220012G "
			= "UPDATE " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    NU_AZONE    = ? "
			+ "  , NU_ABZONE   = ? "
			+ "  , DT_KOSIN    = ? "
			+ "  , CD_KSNSYA   = ? "
			+ "  , CD_KSNAPP   = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		// 2012.02.10 T.Hayato 追加 Bゾーン日数・ABゾーン日数 更新のため end
		
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(updateT220012gZonedateSql);

		// パラメータセット<値>
		//2019.04.01 T.Osada Start
		int AZone = 0;
		int ABZone = 0;
		
		AZone = t220012gInputDataBean.getNuAzone();
		if (AZone >= 1000){
			AZone = 999;
		} 
		ABZone = t220012gInputDataBean.getNuAbzone();
		if (ABZone >= 1000){
			ABZone = 999;
		} 
		paramBean.setInt(AZone);		// Aゾーン日数
		paramBean.setInt(ABZone);		// ABゾーン日数
		// 2019.04.01 T.Osada End

		paramBean.setTimestamp(executeDate);						// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード			
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}
	// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため end

}
