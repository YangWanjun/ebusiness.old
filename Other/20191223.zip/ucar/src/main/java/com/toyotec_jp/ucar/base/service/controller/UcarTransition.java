/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarTransition.java
 * 【  説  明  】
 * 【  作  成  】2010/08/26 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.service.controller;

import javax.servlet.http.HttpServletRequest;

import jp.co.intra_mart.framework.base.service.DefaultTransition;
import jp.co.intra_mart.framework.base.service.TransitionException;
import jp.co.intra_mart.framework.base.util.UserInfo;
import jp.co.intra_mart.framework.base.util.UserInfoException;
import jp.co.intra_mart.framework.base.util.UserInfoUtil;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.system.session.ApplicationSessionBeanIF;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;

/**
 * <strong>基本トランジション。</strong>
 * <p>
 * トランジション作成時は本クラスを継承すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/08/26 新規作成<br>
 * @since 1.00
 */
public abstract class UcarTransition extends DefaultTransition {

	/**
	 * ログインセッションビーン取得。
	 * <pre>
	 * ログインユーザの情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、ログインセッションビーンを生成しセッションに設定した後、返却する。
	 * </pre>
	 * @return ログインセッションビーン
	 * @throws TransitionException
	 * @see UcarSessionManager#getLoginSessionBean(HttpServletRequest, jp.co.intra_mart.framework.base.util.UserInfo)
	 */
	protected LoginSessionBean getLoginSessionBean() throws TransitionException {
		LoginSessionBean result;
		UserInfo userInfo = null;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			userInfo = UserInfoUtil.createUserInfo(getRequest(), getResponse());
			result = sessionMng.getLoginSessionBean(getRequest(), userInfo);
		} catch (UserInfoException e) {
			TecLogger.error(e);
			throw new TransitionException(e.getMessage(), e);
		} catch (TecSystemException e) {
			throw new TransitionException(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * 新規アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * セッションキーはクラス名を使用する。<br>
	 * 既存の値をセッションから削除し、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TransitionException
	 * @see UcarSessionManager#getNewApplicationSessionBean(HttpServletRequest, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getNewApplicationSessionBean(Class<E> cls) throws TransitionException {
		E result;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			result = sessionMng.getNewApplicationSessionBean(getRequest(), cls);
		} catch (TecSystemException e) {
			throw new TransitionException(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * 新規アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * 既存の値をセッションから削除し、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TransitionException
	 * @see UcarSessionManager#getNewApplicationSessionBean(HttpServletRequest, String, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getNewApplicationSessionBean(
			String key, Class<E> cls) throws TransitionException {
		E result;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			result = sessionMng.getNewApplicationSessionBean(getRequest(), key, cls);
		} catch (TecSystemException e) {
			throw new TransitionException(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * セッションキーはクラス名を使用する。<br>
	 * 存在しない場合、または存在しているがそのクラスが引数として設定されたクラスと異なる場合、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TransitionException
	 * @see UcarSessionManager#getApplicationSessionBean(HttpServletRequest, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(Class<E> cls) throws TransitionException {
		E result;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			result = sessionMng.getApplicationSessionBean(getRequest(), cls);
		} catch (TecSystemException e) {
			throw new TransitionException(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、または存在しているがそのクラスが引数として設定されたクラスと異なる場合、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TransitionException
	 * @see UcarSessionManager#getApplicationSessionBean(HttpServletRequest, String, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			String key, Class<E> cls) throws TransitionException {
		E result;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			result = sessionMng.getApplicationSessionBean(getRequest(), key, cls);
		} catch (TecSystemException e) {
			throw new TransitionException(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws TransitionException
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			Class<E> cls, boolean doCreate) throws TransitionException {
		E result;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			result = sessionMng.getApplicationSessionBean(getRequest(), cls, doCreate);
		} catch (TecSystemException e) {
			throw new TransitionException(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws TransitionException
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			String key, Class<E> cls, boolean doCreate) throws TransitionException {
		E result;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			result = sessionMng.getApplicationSessionBean(getRequest(), key, cls, doCreate);
		} catch (TecSystemException e) {
			throw new TransitionException(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * リクエストに画面遷移用ビーンを設定。
	 * @param <E>
	 * @param bean 画面遷移用ビーン
	 */
	protected <E extends TecBean> void setTransitBean(E bean){
		getRequest().setAttribute(UcarApplicationManager.REQ_ATTR_KEY_TRANSIT_BEAN, bean);
	}

	/**
	 * リクエストから画面遷移用ビーンを取得。
	 * <pre>
	 * 指定した画面遷移用ビーンクラスにCASTして返却する。<br>
	 * 対象が指定クラスまたは指定クラスを継承していない場合はNullを返却する。
	 * </pre>
	 * @param <E>
	 * @param cls 画面遷移用ビーンクラス
	 * @return 画面遷移用ビーン
	 */
	protected <E extends TecBean> E getTransitBean(Class<E> cls){
		E bean = null;
		Object val = getRequest().getAttribute(UcarApplicationManager.REQ_ATTR_KEY_TRANSIT_BEAN);
		if(val != null && cls.isAssignableFrom(val.getClass())){
			bean = cls.cast(val);
		}
		return bean;
	}

	/**
	 * リクエストに共通メッセージ画面遷移用ビーンを設定。
	 * @param bean 共通メッセージ画面遷移用ビーン
	 */
	protected void setMessageBean(MessageBean bean){
		getRequest().setAttribute(UcarApplicationManager.REQ_ATTR_KEY_MESSAGE_BEAN, bean);
	}

	/**
	 * リクエストから共通メッセージ画面遷移用ビーンを取得。
	 * <pre>
	 * 共通メッセージ画面遷移用ビーンではない場合はNullを返却する。
	 * </pre>
	 * @return 共通メッセージ画面遷移用ビーン
	 */
	protected MessageBean getMessageBean(){
		MessageBean bean = null;
		Object val = getRequest().getAttribute(UcarApplicationManager.REQ_ATTR_KEY_MESSAGE_BEAN);
		if(val != null && MessageBean.class.isAssignableFrom(val.getClass())){
			bean = MessageBean.class.cast(val);
		}
		return bean;
	}

}
