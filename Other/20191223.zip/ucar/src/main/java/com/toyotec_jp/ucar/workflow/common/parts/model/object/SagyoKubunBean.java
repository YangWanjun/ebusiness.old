package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>作業区分Bean</strong>
 * <p>コード区部マスタ(T220204M)、区分ID='01'の区分名称を格納するBean</p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2014/02/27 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SagyoKubunBean extends TecBean {

	/**
	 *
	 */
	private static final long	serialVersionUID	= 4875383729331795512L;

	/** 区分ID：作業 */
	public static final String KB_ID_SAGYO = "01";

	// Seasar開発のJspでも使用するため、変数はpublicを指定
	/** 区分名称：01 */
	public String mjKubun01 = "";
	/** 区分名称：02 */
	public String mjKubun02 = "";
	/** 区分名称：03 */
	public String mjKubun03 = "";
	/** 区分名称：04 */
	public String mjKubun04 = "";

	/**
	 *
	 */
	public SagyoKubunBean() {
		super();
	}

	private String divide(String strTarget, int divideLength) {

		String strEdit = "";

		if (divideLength == 0) {
			strEdit = strTarget;
		} else {
			String strTargetFull = strTarget;
			int count = 0;
			for (int i = 0; i < strTargetFull.length(); i++) {
				if (divideLength == count) {
					// 指定文字数の文字を取得する
					strEdit += strTarget.substring(0, count);
					// 残りの文字を取得する
					strTarget = strTarget.substring(count);

					if (strTarget.length() > 0) {
						strEdit += "<BR>";
					}
					count = 0;
				}
				count++;
			}
			strEdit += strTarget;
		}

		return strEdit;
	}

	/**
	 * mjKubun01を取得する。
	 * @return mjKubun01 作業区分名称01
	 */
	public String getMjKubun01() {
		return mjKubun01;
	}

	/**
	 * mjKubun01を取得する。
	 * @param divideLength 改行する文字数
	 * @return mjKubun01 作業区分名称01(改行タグ込み)
	 */
	public String getMjKubun01(int divideLength) {
		return divide(mjKubun01, divideLength);
	}

	/**
	 * mjKubun01を設定する。
	 * @param mjKubun01 作業区分名称01
	 */
	public void setMjKubun01(String mjKubun01) {
		this.mjKubun01 = mjKubun01;
	}

	/**
	 * mjKubun02を取得する。
	 * @return mjKubun02 作業区分名称02
	 */
	public String getMjKubun02() {
		return mjKubun02;
	}

	/**
	 * mjKubun02を取得する。
	 * @param divideLength 改行する文字数
	 * @return mjKubun02 作業区分名称02(改行タグ込み)
	 */
	public String getMjKubun02(int divideLength) {
		return divide(mjKubun02, divideLength);
	}

	/**
	 * mjKubun02を設定する。
	 * @param mjKubun02 作業区分名称02
	 */
	public void setMjKubun02(String mjKubun02) {
		this.mjKubun02 = mjKubun02;
	}

	/**
	 * mjKubun03を取得する。
	 * @return mjKubun03 作業区分名称03
	 */
	public String getMjKubun03() {
		return mjKubun03;
	}

	/**
	 * mjKubun03を取得する。
	 * @param divideLength 改行する文字数
	 * @return mjKubun03 作業区分名称03(改行タグ込み)
	 */
	public String getMjKubun03(int divideLength) {
		return divide(mjKubun03, divideLength);
	}

	/**
	 * mjKubun03を設定する。
	 * @param mjKubun03 作業区分名称03
	 */
	public void setMjKubun03(String mjKubun03) {
		this.mjKubun03 = mjKubun03;
	}

	/**
	 * mjKubun04を取得する。
	 * @return mjKubun04 作業区分名称04
	 */
	public String getMjKubun04() {
		return mjKubun04;
	}

	/**
	 * mjKubun04を取得する。
	 * @param divideLength 改行する文字数
	 * @return mjKubun04 作業区分名称04(改行タグ込み)
	 */
	public String getMjKubun04(int divideLength) {
		return divide(mjKubun04, divideLength);
	}

	/**
	 * mjKubun04を設定する。
	 * @param mjKubun04 作業区分名称04
	 */
	public void setMjKubun04(String mjKubun04) {
		this.mjKubun04 = mjKubun04;
	}

}