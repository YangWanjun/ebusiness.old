package com.toyotec_jp.ucar.workflow.carryout.common;

import com.toyotec_jp.im_common.TecApplicationManager.TecApplicationIdIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecServiceIdIF;
import com.toyotec_jp.ucar.UcarApplicationManager;

/**
 * <strong>車両搬出関連共通定数管理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/02 新規作成<br>
 * @since 1.00
 * @category [[車両搬出(共通)]]
 */
public class CarryoutConst {

	/** パッケージカテゴリ:車両搬出 */
	public static final String PKG_CAT_CARRYOUT = ".carryout";

	/** 車両搬出関連パッケージルート */
	public static final String CARRYOUT_ROOT
		= UcarApplicationManager.WF_ROOT + PKG_CAT_CARRYOUT;

	/** 車両搬出登録パッケージルート */
	public static final String REGISTER_ROOT
		= CARRYOUT_ROOT + ".register";

	/** アプリID:車両搬出-車両搬出登録 */
	public static final String APPID_CARRYOUT_REGISTER
		= UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.carryout.CarryoutRegister");

	/** 検索方法：名称：バーコード */
	public static final String SEARCH_NAME_BARCODE 	= "バーコード";
	/** 検索方法：値：バーコード */
	public static final String SEARCH_VALUE_BARCODE 	= "barcode";
	/** 検索方法：名称：手入力 */
	public static final String SEARCH_NAME_HAND 		= "手入力";
	/** 検索方法：値：手入力 */
	public static final String SEARCH_VALUE_HAND 		= "hand";

	/** インスタンスを生成しない。 */
	private CarryoutConst(){
	}

	/** 車両搬出関連タイトル */
	public enum CarryoutTitle {
		/** 車両搬出登録 */
		CARRYOUT_REGISTER(".CarryoutRegister"),
		;
		private String titleLabel;
		private CarryoutTitle(String key){
			this.titleLabel = UcarApplicationManager.getConstantValue(
					UcarApplicationManager.WF_ROOT + ".title" + PKG_CAT_CARRYOUT + key);
		}
		public String toString(){
			return titleLabel;
		}
		/**
		 * 画面タイトルを取得する。
		 * @return titleLabel 画面タイトル
		 */
		public String getTitleLabel() {
			return titleLabel;
		}
	}

	/** 車両搬出関連アプリケーションID */
	public enum CarryoutApplicationId implements TecApplicationIdIF {
		/** 車両搬出登録 */
		REGISTER(REGISTER_ROOT + ".CarryoutRegister"),
		;
		private String applicationId;
		private CarryoutApplicationId(String applicationId){
			this.applicationId = applicationId;
		}
		public String toString(){
			return applicationId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
	}

	/** 車両搬出関連サービスID */
	public enum CarryoutServiceId implements TecServiceIdIF {
		/** 初期処理 */
		REGISTER_INIT(CarryoutApplicationId.REGISTER, "RegisterInit"),
		/** 検索処理 */
		REGISTER_SEARCH(CarryoutApplicationId.REGISTER, "RegisterSearch"),
		// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため start
		/** 登録処理(帳票印刷) */
		REGISTER_EXECUTE_AND_DOWNLOAD(CarryoutApplicationId.REGISTER, "RegisterExecuteAndDownload"),
		// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため end
		/** 登録処理 */
		REGISTER_EXECUTE(CarryoutApplicationId.REGISTER, "RegisterExecute"),
		/** 削除処理 */
		REGISTER_DELETE(CarryoutApplicationId.REGISTER, "RegisterDelete"),
		// 2014.08.11 00496_990215 追加 搬出予定情報登録のため start
		/** 搬出予定登録処理 */
		REGISTER_PLAN_EXECUTE(CarryoutApplicationId.REGISTER, "RegisterPlanExecute"),
		// 2014.08.11 00496_990215 追加 搬出予定情報登録のため end
		REGISTER_SEARCHMV(CarryoutApplicationId.REGISTER, "RegisterSearchMV"),
		
		
		
		;
		private String applicationId;
		private String serviceId;
		private CarryoutServiceId(TecApplicationIdIF appId, String serviceId){
			this.applicationId = appId.getApplicationId();
			this.serviceId = serviceId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
		@Override
		public String getServiceId() {
			return serviceId;
		}
		/**
		 * 車両搬出関連サービスID取得。
		 * <pre>
		 * 車両搬出関連サービスIDを返却する。<br>
		 * 値として認められない場合はnullを返却する。
		 * </pre>
		 * @param serviceId サービスID
		 * @return 車両搬出関連サービスID
		 */
		public static CarryoutServiceId getTargetCarryoutServiceId(String serviceId){
			CarryoutServiceId target = null;
			for(CarryoutServiceId enumElement : CarryoutServiceId.values()){
				if(enumElement.getServiceId().equals(serviceId)){
					target = enumElement;
					break;
				}
			}
			return target;
		}
	}

	/** 車両搬出関連イベントキー */
	public enum CarryoutEventKey implements TecEventKeyIF {
		/** 車両搬出情報取得イベント */
		GET_REGISTER_DATA(CarryoutApplicationId.REGISTER, "GetRegisterDataEvent"),
		/** 登録処理イベント */
		REGISTER_DATA(CarryoutApplicationId.REGISTER, "RegisterDataEvent"),
		/** 削除処理イベント */
		DELETE_REGISTER_DATA(CarryoutApplicationId.REGISTER, "DeleteRegisterDataEvent"),
		// 2014.08.11 00496_990215 追加 搬出予定情報登録のため start
		/** 搬出予定登録処理イベント */
		PLAN_REGISTER_DATA(CarryoutApplicationId.REGISTER, "PlanRegisterDataEvent"),
		// 2014.08.11 00496_990215 追加 搬出予定情報登録のため end
		;
		private String applicationId;
		private String eventKey;
		private CarryoutEventKey(TecApplicationIdIF appId, String eventKey){
			this.applicationId = appId.getApplicationId();
			this.eventKey = eventKey;
		}
		public String toString(){
			return eventKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getEventKey(){
			return eventKey;
		}
	}

	/** 車両搬出関連DAOキー */
	public enum CarryoutDAOKey implements TecDAOKeyIF {
		/** 車両搬出登録DAO */
		REGISTER_DAO(CarryoutApplicationId.REGISTER, "RegisterDAO"),
		;
		private String applicationId;
		private String daoKey;
		private CarryoutDAOKey(TecApplicationIdIF appId, String daoKey){
			this.applicationId = appId.getApplicationId();
			this.daoKey = daoKey;
		}
		public String toString(){
			return daoKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getDAOKey(){
			return daoKey;
		}
	}

}
