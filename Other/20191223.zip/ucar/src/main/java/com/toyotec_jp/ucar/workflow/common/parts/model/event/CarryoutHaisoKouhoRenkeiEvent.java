package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;

/**
 * <strong>配送候補連携DB操作用イベント(車両搬出用)</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/19 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CarryoutHaisoKouhoRenkeiEvent extends UcarEvent {

	private static final long serialVersionUID = -8975344836334571960L;

	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPKBean;
	/** 実行アプリID */
	private String executeAppId;

	/**
	 * t220001gPKBeanを取得する。
	 * @return t220001gPKBean
	 */
	public Ucaa001gPKBean getUcaa001gPKBean() {
		return t220001gPKBean;
	}

	/**
	 * t220001gPKBeanを設定する。
	 * @param t220001gPKBean
	 */
	public void setUcaa001gPKBean(Ucaa001gPKBean t220001gPKBean) {
		this.t220001gPKBean = t220001gPKBean;
	}

	/**
	 * executeAppIdを取得する。
	 * @return executeAppId
	 */
	public String getExecuteAppId() {
		return executeAppId;
	}

	/**
	 * executeAppIdを設定する。
	 * @param executeAppId
	 */
	public void setExecuteAppId(String executeAppId) {
		this.executeAppId = executeAppId;
	}

}
