/*
 * 【システム名】
 * 【ファイル名】DMYoshikiMap.java
 * 【  説  明  】様式情報格納用マップクラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

import java.util.TreeMap;

/**
 * <strong>DMYoshikiMap</strong>
 * <p>
 * 様式情報格納用マップクラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 * 【変 更】
 * 2013/01/08 H.T(TOYOTEC) 継承クラスをHashMapからTreeMapに変更。
 */
public class DMYoshikiMap<K, V> extends TreeMap<K, V> {

	/** シリアルバージョン */
	private static final long serialVersionUID = 4818395093807280704L;

	/**
	 * コンストラクタ
	 * @param fileMapData
	 * @param initialCapacity
	 * @param loadFactor
	 */
	public DMYoshikiMap(DMFilesMapData fileMapData, int initialCapacity, float loadFactor) {
		super();
//		super(initialCapacity, loadFactor);
		setYoshikiInfo(fileMapData);
	}

	/**
	 * コンストラクタ
	 * @param fileMapData
	 * @param initialCapacity
	 */
	public DMYoshikiMap(DMFilesMapData fileMapData, int initialCapacity) {
		super();
//		super(initialCapacity);
		setYoshikiInfo(fileMapData);
	}

	/**
	 * コンストラクタ
	 * @param fileMapData
	 */
	public DMYoshikiMap(DMFilesMapData fileMapData){
		super();
		setYoshikiInfo(fileMapData);
	}

	/**
	 * コンストラクタ
	 */
	public DMYoshikiMap(){
		super();
	}

	private String yoshikiId;
	private String yoshikiNm;
	private String torokuFileNm;
	private String butsuriFileNm;

	/**
	 * 様式情報設定
	 * @param fileMapData
	 * @since 1.00
	 */
	public void setYoshikiInfo(DMFilesMapData fileMapData){
		if(fileMapData != null){
			yoshikiId = fileMapData.getYoshikiId();
			yoshikiNm = fileMapData.getYoshikiNm();
			torokuFileNm = fileMapData.getTorokuFileNm();
			butsuriFileNm = fileMapData.getButsuriFileNm();
		}
	}

	/**
	 * 様式-物理ファイル名取得
	 * @return 様式-物理ファイル名
	 * @since 1.00
	 */
	public String getButsuriFileNm() {
		return butsuriFileNm;
	}
	/**
	 * 様式-登録ファイル名取得
	 * @return 様式-登録ファイル名
	 * @since 1.00
	 */
	public String getTorokuFileNm() {
		return torokuFileNm;
	}
	/**
	 * 様式-様式ID取得
	 * @return 様式-様式ID
	 * @since 1.00
	 */
	public String getYoshikiId() {
		return yoshikiId;
	}
	/**
	 * 様式-様式名取得
	 * @return 様式-様式名
	 * @since 1.00
	 */
	public String getYoshikiNm() {
		return yoshikiNm;
	}

}
