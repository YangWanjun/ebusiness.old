package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object;

import java.util.Date;

import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;

/**
 * <strong>車両チェック 画面出力値Bean</strong>
 * <p>
 * 車両搬入情報Bean(Ucaa001gBean)を継承している。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/07 新規作成<br>
 * @since 1.00
 * @category [[車両チェック]]
 */
public class CarCheckDataBean extends Ucaa001gBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 入庫検査／作業仕分：区分内容(塗色) */
	private String mjKubunnai;
	/** 入庫検査：入庫検査日 */
	private String ddNkkns;
	/** 入庫検査／作業仕分：入庫検査保留日 */
	private String ddNkkhr;
	/** 入庫検査／作業仕分：書類完備保留日 */
	private String ddSrkhr;
	/** 入庫検査：データ更新日時
	 * <pre>
	 * 排他制御時に使用する
	 * </pre>
	 *  */
	private Date nyukoDtKosin;

	/** 作業仕分：作業工程区分 */
	private String kbSgyokt;
	/** 作業仕分：作業工程名称 */
	private String mjSgyokt;
	/** 作業仕分：配車店舗コード */
	private String cdHstenpo;
	/** 作業仕分：仕分日 */
	private String ddSiwake;
	/** 作業仕分：仕分保留日 */
	private String ddSwkhr;
	/** 作業仕分：データ更新日時
	 * <pre>
	 * 排他制御時に使用する
	 * </pre>
	 *  */
	private Date siwakeDtKosin;

	/** 車両搬出情報：データ更新日時
	 * <pre>
	 * 排他制御時に使用する
	 * </pre>
	 *  */
	private Date hansyutuDtKosin;

	/** 搬入時のチェック内容フラグ
	 * <pre>
	 * 搬入時に下取書類、保証書、記録簿が全て存在すれば"true"
	 * </pre> */
	private String existCheckContents;

	/**
	 *
	 */
	public CarCheckDataBean() {
		super();
	}

	/**
	 * mjKubunnaiを取得する。
	 * @return mjKubunnai 区分内容(塗色)
	 */
	public String getMjKubunnai() {
		return mjKubunnai;
	}

	/**
	 * mjKubunnaiを設定する。
	 * @param mjKubunnai 区分内容(塗色)
	 */
	public void setMjKubunnai(String mjKubunnai) {
		this.mjKubunnai = mjKubunnai;
	}

	/**
	 * ddNkknsを取得する。
	 * @return ddNkkns 入庫検査日
	 */
	public String getDdNkkns() {
		return ddNkkns;
	}

	/**
	 * ddNkknsを設定する。
	 * @param ddNkkns 入庫検査日
	 */
	public void setDdNkkns(String ddNkkns) {
		this.ddNkkns = ddNkkns;
	}

	/**
	 * ddNkkhrを取得する。
	 * @return ddNkkhr 入庫検査保留日
	 */
	public String getDdNkkhr() {
		return ddNkkhr;
	}

	/**
	 * ddNkkhrを設定する。
	 * @param ddNkkhr 入庫検査保留日
	 */
	public void setDdNkkhr(String ddNkkhr) {
		this.ddNkkhr = ddNkkhr;
	}

	/**
	 * ddSrkhrを取得する。
	 * @return ddSrkhr 書類完備保留日
	 */
	public String getDdSrkhr() {
		return ddSrkhr;
	}

	/**
	 * ddSrkhrを設定する。
	 * @param ddSrkhr 書類完備保留日
	 */
	public void setDdSrkhr(String ddSrkhr) {
		this.ddSrkhr = ddSrkhr;
	}

	/**
	 * nyukoDtKosinを取得する。
	 * @return nyukoDtKosin データ更新日時(入庫チェックDB)
	 */
	public Date getNyukoDtKosin() {
		return nyukoDtKosin;
	}

	/**
	 * nyukoDtKosinを設定する。
	 * @param nyukoDtKosin データ更新日時(入庫チェックDB)
	 */
	public void setNyukoDtKosin(Date nyukoDtKosin) {
		this.nyukoDtKosin = nyukoDtKosin;
	}

	/**
	 * 塗色を取得する。
	 * @return cdTosyoku + mjKubunnai
	 */
	public String getTosyoku() {
		return StringUtils.defaultValue(super.getCdTosyoku()) + " " + StringUtils.defaultValue(mjKubunnai);
	}

	/**
	 * existCheckContentsを取得する。
	 * @return existCheckContents
	 */
	public String getExistCheckContents() {
		return existCheckContents;
	}

	/**
	 * existCheckContentsを設定する。
	 * @param existCheckContents
	 */
	public void setExistCheckContents(String existCheckContents) {
		this.existCheckContents = existCheckContents;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean#getMjBikou()
	 */
	@Override
	public String getMjBikou() {
		// 備考の最大出力文字数
		final int maxLength = 12;
		return UcarUtils.getMaxLengthSubstring(super.getMjBikou(), maxLength);
	}

	/**
	 * kbSgyoktを取得する。
	 * @return kbSgyokt
	 */
	public String getKbSgyokt() {
		return kbSgyokt;
	}

	/**
	 * kbSgyoktを設定する。
	 * @param kbSgyokt
	 */
	public void setKbSgyokt(String kbSgyokt) {
		this.kbSgyokt = kbSgyokt;
	}

	/**
	 * mjSgyoktを取得する。
	 * @return mjSgyokt
	 */
	public String getMjSgyokt() {
		return mjSgyokt;
	}

	/**
	 * mjSgyoktを設定する。
	 * @param mjSgyokt
	 */
	public void setMjSgyokt(String mjSgyokt) {
		this.mjSgyokt = mjSgyokt;
	}

	/**
	 * cdHstenpoを取得する。
	 * @return cdHstenpo
	 */
	public String getCdHstenpo() {
		return cdHstenpo;
	}

	/**
	 * cdHstenpoを設定する。
	 * @param cdHstenpo
	 */
	public void setCdHstenpo(String cdHstenpo) {
		this.cdHstenpo = cdHstenpo;
	}

	/**
	 * ddSiwakeを取得する。
	 * @return ddSiwake
	 */
	public String getDdSiwake() {
		return ddSiwake;
	}

	/**
	 * ddSiwakeを設定する。
	 * @param ddSiwake
	 */
	public void setDdSiwake(String ddSiwake) {
		this.ddSiwake = ddSiwake;
	}

	/**
	 * ddSwkhrを取得する。
	 * @return ddSwkhr
	 */
	public String getDdSwkhr() {
		return ddSwkhr;
	}

	/**
	 * ddSwkhrを設定する。
	 * @param ddSwkhr
	 */
	public void setDdSwkhr(String ddSwkhr) {
		this.ddSwkhr = ddSwkhr;
	}

	/**
	 * siwakeDtKosinを取得する。
	 * @return siwakeDtKosin
	 */
	public Date getSiwakeDtKosin() {
		return siwakeDtKosin;
	}

	/**
	 * siwakeDtKosinを設定する。
	 * @param siwakeDtKosin
	 */
	public void setSiwakeDtKosin(Date siwakeDtKosin) {
		this.siwakeDtKosin = siwakeDtKosin;
	}

	/**
	 * hansyutuDtKosinを取得する。
	 * @return hansyutuDtKosin
	 */
	public Date getHansyutuDtKosin() {
		return hansyutuDtKosin;
	}

	/**
	 * hansyutuDtKosinを設定する。
	 * @param hansyutuDtKosin
	 */
	public void setHansyutuDtKosin(Date hansyutuDtKosin) {
		this.hansyutuDtKosin = hansyutuDtKosin;
	}

}
