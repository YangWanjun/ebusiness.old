/**
 * 車両搬入登録データビーン関連パッケージ
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.carryin.register.model.object;
