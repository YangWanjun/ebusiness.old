/*
 * 【システム名】リース管理システム
 * 【ファイル名】MassageInitServiceController.java
 * 【  説  明  】共通メッセージ
 * 【  作  成  】2010/07/05 K.T(SCC)
 */
package com.toyotec_jp.ucar.workflow.common.message.service;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;

public class MessageInitServiceController extends UcarServiceController {

	/**
	 * 呼出しに対する処理を実行します。
	 *
	 * @return 処理結果
	 * @throws SystemException 処理実行時にシステム例外が発生
	 * @throws ApplicationException 処理実行時にアプリケーション例外が発生
	 */
	public ServiceResult service() throws SystemException, ApplicationException {
		// サービス処理結果を返します。
		return null;
	}

}
