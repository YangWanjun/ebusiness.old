/**
 * 搬入情報一覧関連パッケージ
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.carryin.list;
