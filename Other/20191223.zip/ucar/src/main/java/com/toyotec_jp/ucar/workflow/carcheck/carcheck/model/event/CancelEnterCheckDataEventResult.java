package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>入庫検査取消イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/20 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class CancelEnterCheckDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 処理実行件数 */
	private int countExecute;

	/**
	 * countExecuteを取得する。
	 * @return countExecute
	 */
	public int getCountExecute() {
		return countExecute;
	}

	/**
	 * countExecuteを設定する。
	 * @param countExecute
	 */
	public void setCountExecute(int countExecute) {
		this.countExecute = countExecute;
	}

}
