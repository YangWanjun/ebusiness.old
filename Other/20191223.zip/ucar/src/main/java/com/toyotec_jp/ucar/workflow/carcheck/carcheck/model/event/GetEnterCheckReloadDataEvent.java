package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;


/**
 * <strong>入庫検査再取得イベント。</strong>
 * <p>
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/23 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class GetEnterCheckReloadDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/**
	 * 入庫検査Beanリスト
	 * <pre>
	 * 選択処理後画面に表示しているデータリスト
	 * </pre>
	 *  */
	private List<CarCheckDataBean> selectDataList;

	/**
	 * selectDataListを取得する。
	 * @return selectDataList
	 */
	public List<CarCheckDataBean> getSelectDataList() {
		return selectDataList;
	}

	/**
	 * selectDataListを設定する。
	 * @param selectDataList
	 */
	public void setSelectDataList(List<CarCheckDataBean> selectDataList) {
		this.selectDataList = selectDataList;
	}

}
