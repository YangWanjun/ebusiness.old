package com.toyotec_jp.ucar.workflow.carryin.storelist.model.event;

import java.sql.Timestamp;
import java.util.List;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.data.StoreListDAOIF;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcarCommonDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb011vBean;

/**
 * <strong>更新イベントリスナ</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/03/09 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class UpdateStoreListDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		// イベントのキャスト
		UpdateStoreListDataEvent targetEvent = (UpdateStoreListDataEvent) event;
		Ucaa001gPKBean t220001gPKBean = targetEvent.getUcaa001gPKBean();

		// DAOIF取得
		StoreListDAOIF dao = getDAO(CarryinDAOKey.STORELIST_DAO, targetEvent, StoreListDAOIF.class);

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		// 更新ユーザID
		String updateUserId = targetEvent.getUserInfo().getUserID();
		// 更新アプリID
		String updateAppId = CarryinConst.APPID_CARRYIN_STORELIST;

		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		// 自店舗の情報チェックをする
		UcarCommonDAOIF commonDao 	= getDAO(UcarDAOKey.UCARCOMMON_DAO, targetEvent, UcarCommonDAOIF.class);

		String loginUserCdTenpo = targetEvent.getUserInfoBean().getCdTenpo();
		Uccb011vBean t220902vBean = commonDao.selectT220902v(t220001gPKBean.getCdKaisya(),
															t220001gPKBean.getCdHanbaitn(),
															t220001gPKBean.getDdHannyu(),
															t220001gPKBean.getNoKanri(),
															loginUserCdTenpo);

		List<StoreListDataBean> storeListDataList = targetEvent.getStoreListDataList();

		String kbData = "";
		String cdHantenpo = "";
		for (StoreListDataBean storeListDataBean : storeListDataList) {
			// 画面表示時点のデータリストからデータ区分を取得する
			if (storeListDataBean.getCdKaisya().equals(t220001gPKBean.getCdKaisya())
					&& storeListDataBean.getCdHanbaitn().equals(t220001gPKBean.getCdHanbaitn())
					&& storeListDataBean.getDdHannyu().equals(t220001gPKBean.getDdHannyu())
					&& storeListDataBean.getNoKanri().equals(t220001gPKBean.getNoKanri())
			) {
				// データ区分
				kbData = storeListDataBean.getKbData();
				// 店舗コード(搬出元)
				cdHantenpo = storeListDataBean.getCdHantenpo();
				break;
			}
		}

		if (t220902vBean != null) {
			// データがあるとき

			// 車両搬出情報(店舗用)の搬出日、店舗受取日をクリアする
			dao.updateT220109g(t220001gPKBean,
								loginUserCdTenpo,
								updateUserId,
								updateAppId,
								executeDate);

			// ステータスDB(店舗用)のステータス21、ステータス26をクリアする
			dao.updateT220107g(t220001gPKBean,
								loginUserCdTenpo,
								updateUserId,
								updateAppId,
								executeDate);

		} else {
			// データがないとき

			// 車両受取情報にInsert処理をする
			dao.insertT220108g(t220001gPKBean,
								loginUserCdTenpo,
								cdHantenpo,
								updateUserId,
								updateAppId,
								executeDate,
								kbData);

			// ステータスDB(店舗用)にInsert処理をする
			dao.insertT220107g(t220001gPKBean,
								loginUserCdTenpo,
								updateUserId,
								updateAppId,
								executeDate);

		}

		// データ更新(車両搬出情報DB･店舗受取日)
		SimpleExecuteResultBean updateDdTenukt = dao.updateDdTenukt(t220001gPKBean,
				cdHantenpo,
				targetEvent.getDtKosin(),
				updateUserId,
				updateAppId,
				executeDate,
				kbData);

		if (updateDdTenukt.getExecuteCount() != 1) {
			// 実行更新件数が1以外の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
		}

		// データ更新(ステータス26･店舗受取日)
		dao.updateStatus26(t220001gPKBean,
				cdHantenpo,
				updateUserId,
				updateAppId,
				executeDate,
				kbData);
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end

		// イベント処理結果を返す
		return null;
	}
}