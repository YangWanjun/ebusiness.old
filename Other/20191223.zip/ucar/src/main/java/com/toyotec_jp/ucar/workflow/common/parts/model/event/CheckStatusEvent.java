package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;


/**
 * <strong>ステータスDB存在チェックイベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/04 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CheckStatusEvent extends UcarEvent {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;
	/** ステータスDB(店舗用) プライマリーキーBean */
	private Uccb007gPKBean t220107gPkBean;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/** チェック開始ステータス番号
	 * <pre>
	 * ステータスDB(新)用
	 * </pre>
	 *  */
	private int startDtStatus;
	/** チェック終了ステータス番号
	 * <pre>
	 * ステータスDB(新)用
	 * </pre>
	 *  */
	private int endDtStatus;
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	public CheckStatusEvent() {
		super();
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// デフォルトではステータス全てをチェックするように設定
		startDtStatus	= 1;
		endDtStatus		= 24;
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
	}

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}
	
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * t220107gPkBeanを取得する。
	 * @return t220107gPkBean
	 */
	public Uccb007gPKBean getT220107gPkBean() {
		return t220107gPkBean;
	}

	/**
	 * t220107gPkBeanを設定する。
	 * @param t220107gPkBean
	 */
	public void setT220107gPkBean(Uccb007gPKBean t220107gPkBean) {
		this.t220107gPkBean = t220107gPkBean;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	/**
	 * startDtStatusを取得する。
	 * @return startDtStatus
	 */
	public int getStartDtStatus() {
		return startDtStatus;
	}

	/**
	 * startDtStatusを設定する。
	 * @param startDtStatus
	 */
	public void setStartDtStatus(int startDtStatus) {
		this.startDtStatus = startDtStatus;
	}

	/**
	 * endDtStatusを取得する。
	 * @return endDtStatus
	 */
	public int getEndDtStatus() {
		return endDtStatus;
	}

	/**
	 * endDtStatusを設定する。
	 * @param endDtStatus
	 */
	public void setEndDtStatus(int endDtStatus) {
		this.endDtStatus = endDtStatus;
	}

}
