package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.sql.SQLException;
import java.util.ArrayList;

import com.toyotec_jp.im_common.system.db.TecPreparedStatement;
import com.toyotec_jp.im_common.system.db.TecResultSet;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;

/**
 * <strong>書式操作DAOの実装。</strong>
 * @author H.O(SCC)
 * @version 1.00 2010/07/12 新規作成<br>
 * @since 1.00
 */
public class DocFormatDAOImpl extends UcarSharedDBDAO implements DocFormatDAOIF {

	private static final String SELECT_DOC_FORMAT_DEFINE =
		"SELECT " +
		"  FT.DOC_FORMAT_ID AS YOSHIKI_ID, FT.DOC_FORMAT_NAME AS YOSHIKI_NM, " +
		"  NULL AS TOROKU_FILE_NM, FT.DOC_FORMAT_PATH AS BUTSURI_FILE_NM, " +
		"  ST.SHEET_IDX AS SHEET_IDX, ST.SHEET_NAME AS SHEET_NM, " +
		"  ST.SHEET_TYPE AS SHEET_KBN, ST.PAGE_DIRECTION_TYPE AS KAI_PAGE_KBN, " +
		"  ST.INITIAL_PAGE_FILE_PATH AS SHOKI_FILE_PATH, ST.INITIAL_PAGE_SHEET_NAME AS SHOKI_SHEET_NM, " +
		"  ST.INITIAL_PAGE_END_COL AS SHOKI_SAISHURETSU, ST.INITIAL_PAGE_END_ROW AS SHOKI_SAISHUGYO, " +
		"  ST.ADD_PAGE_FILE_PATH AS TSUIKA_FILE_PATH, ST.ADD_PAGE_SHEET_NAME AS TSUIKA_SHEET_NM, " +
		"  ST.ADD_PAGE_START_COL AS TSUIKA_KAISHIRETSU, ST.ADD_PAGE_START_ROW AS TSUIKA_KAISHIGYO, " +
		"  ST.ADD_PAGE_END_COL AS TSUIKA_SHURYORETSU, ST.ADD_PAGE_END_ROW AS TSUIKA_SHURYOGYO, " +
		"  ST.ADD_PAGE_COL_OFFSET AS TSUIKA_RETSU_HOSEICHI, ST.ADD_PAGE_ROW_OFFSET AS TSUIKA_GYO_HOSEICHI, " +
		"  KT.PROCESS_TYPE AS SHORI_KBN, KT.PROCESS_DETAIL_TYPE AS SHORI_SHOSAI_KBN, " +
		"  KT.ARGUMENT_IDX AS HIKISU_IDX, KT.ARRAY_IDX AS HAIRETSU_IDX, KT.LIST_ID AS LIST_ID, " +
		"  KT.ITEM_NAME AS KOMOKU_NM, KT.ITEM_TYPE AS KOMOKU_KBN, KT.TARGET_COL AS TAISHORETSU, KT.TARGET_ROW AS TAISHOGYO, " +
		"  KT.SHAPE_END_COL AS SHUTENRETSU, KT.SHAPE_END_ROW AS SHUTENGYO, " +
		"  KT.SHAPE_START_CELL_X_POS AS SHITEN_X_ZAHYO, KT.SHAPE_START_CELL_Y_POS AS SHITEN_Y_ZAHYO, " +
		"  KT.SHAPE_END_CELL_X_POS AS SHUTEN_X_ZAHYO, KT.SHAPE_END_CELL_Y_POS AS SHUTEN_Y_ZAHYO, " +
		"  KT.CMNT AS BIKO, " +
		"  LT.LIST_INCREMENT_VALUE AS ZOBUNCHI, LT.LIST_UNIT_ITEMS AS UNIT_KOMOKUSU, LT.MAX_ITEMS AS SAIDAI_KOMOKUSU " +
		"FROM " +
		"  T220801M FT INNER JOIN (" +
		"    T220802M ST INNER JOIN (" +
		"      T220803M KT LEFT OUTER JOIN T220804M LT ON (" +
		"        KT.DOC_FORMAT_ID = LT.DOC_FORMAT_ID AND KT.LIST_ID = LT.LIST_ID " +
		"      )" +
		"    ) ON (" +
		"      ST.DOC_FORMAT_ID = KT.DOC_FORMAT_ID AND ST.SHEET_IDX = KT.SHEET_IDX " +
		"    )" +
		"  ) ON (FT.DOC_FORMAT_ID = ST.DOC_FORMAT_ID) " +
		"WHERE FT.DOC_FORMAT_ID = ? " +
		"";

	private static final String SELECT_DOC_OUTPUT_TYPE =
		"SELECT " +
		"  FT.OUTPUT_TYPE " +
		"FROM T220801M FT " +
		"WHERE FT.DOC_FORMAT_ID = ? " +
		"";

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.workflow.common.parts.model.data.DocFormatDAOIF#getDocFormatDefineList(java.lang.String)
	 */
	@Override
	public ArrayList<DMFilesMapData> getDocFormatDefineList(String docFormatId) throws TecDAOException {
		TecPreparedStatement pstmt = null;
		TecResultSet rs = null;
		ArrayList<DMFilesMapData> list = new ArrayList<DMFilesMapData>();
		try{
			pstmt = getTPreparedStatement(SELECT_DOC_FORMAT_DEFINE);
			pstmt.setString(1, docFormatId);
			rs = pstmt.executeQuery();
			while(rs.next()){
				DMFilesMapData bean = getMappedDocFormatBean(rs);
				list.add(bean);
			}
			list.trimToSize();
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} catch (TecDAOException e) {
			throw e;
		} catch (Exception e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} finally {
			try {
				if(rs != null){
					rs.close();
					rs = null;
				}
				if(pstmt != null){
					pstmt.close();
					pstmt = null;
				}
			} catch(SQLException e){
				// Close時の例外は無視
			}
		}
		return list;
	}

	private DMFilesMapData getMappedDocFormatBean(TecResultSet rs) throws SQLException {
		// 自動マッピング不可のため手動でマッピング
		DMFilesMapData bean = new DMFilesMapData();
		// T220801M
		bean.setYoshikiId(rs.getString("YOSHIKI_ID"));
		bean.setYoshikiNm(rs.getString("YOSHIKI_NM"));
		bean.setTorokuFileNm(rs.getString("TOROKU_FILE_NM"));
		bean.setButsuriFileNm(rs.getString("BUTSURI_FILE_NM"));
		// T220802M
		bean.setSheetIdx(rs.getInt("SHEET_IDX"));
		bean.setSheetNm(rs.getString("SHEET_NM"));
		bean.setSheetKbn(rs.getInt("SHEET_KBN"));
		bean.setKaiPageKbn(rs.getInt("KAI_PAGE_KBN"));
		bean.setShokiFilePath(rs.getString("SHOKI_FILE_PATH"));
		bean.setShokiSheetNm(rs.getString("SHOKI_SHEET_NM"));
		bean.setShokiSaishuretsu(rs.getInt("SHOKI_SAISHURETSU"));
		bean.setShokiSaishugyo(rs.getInt("SHOKI_SAISHUGYO"));
		bean.setTsuikaFilePath(rs.getString("TSUIKA_FILE_PATH"));
		bean.setTsuikaSheetNm(rs.getString("TSUIKA_SHEET_NM"));
		bean.setTsuikaKaishiretsu(rs.getInt("TSUIKA_KAISHIRETSU"));
		bean.setTsuikaKaishigyo(rs.getInt("TSUIKA_KAISHIGYO"));
		bean.setTsuikaShuryoretsu(rs.getInt("TSUIKA_SHURYORETSU"));
		bean.setTsuikaShuryogyo(rs.getInt("TSUIKA_SHURYOGYO"));
		bean.setTsuikaRetsuHoseichi(rs.getInt("TSUIKA_RETSU_HOSEICHI"));
		bean.setTsuikaGyoHoseichi(rs.getInt("TSUIKA_GYO_HOSEICHI"));
		// T220803M
		bean.setShoriKbn(rs.getString("SHORI_KBN"));
		bean.setShoriShosaiKbn(rs.getString("SHORI_SHOSAI_KBN"));
		bean.setHikisuIdx(rs.getInt("HIKISU_IDX"));
		bean.setHairetsuIdx(rs.getInt("HAIRETSU_IDX"));
		bean.setListId(rs.getString("LIST_ID"));
		bean.setKomokuNm(rs.getString("KOMOKU_NM"));
		bean.setKomokuKbn(rs.getInt("KOMOKU_KBN"));
		bean.setTaishoretsu(rs.getInt("TAISHORETSU"));
		bean.setTaishogyo(rs.getInt("TAISHOGYO"));
		bean.setShutenretsu(rs.getInt("SHUTENRETSU"));
		bean.setShutengyo(rs.getInt("SHUTENGYO"));
		bean.setShitenXZahyo(rs.getInt("SHITEN_X_ZAHYO"));
		bean.setShitenYZahyo(rs.getInt("SHITEN_Y_ZAHYO"));
		bean.setShutenXZahyo(rs.getInt("SHUTEN_X_ZAHYO"));
		bean.setShutenYZahyo(rs.getInt("SHUTEN_Y_ZAHYO"));
		bean.setBiko(rs.getString("BIKO"));
		// T220804M
		bean.setZobunchi(rs.getInt("ZOBUNCHI"));
		bean.setUnitKomokusu(rs.getInt("UNIT_KOMOKUSU"));
		bean.setSaidaiKomokusu(rs.getInt("SAIDAI_KOMOKUSU"));
		return bean;
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.workflow.common.parts.model.data.DocFormatDAOIF#getDocOutputType(java.lang.String)
	 */
	@Override
	public String getDocOutputType(String docFormatId) throws TecDAOException {
		TecPreparedStatement pstmt = null;
		TecResultSet rs = null;
		String result = null;
		try{
			pstmt = getTPreparedStatement(SELECT_DOC_OUTPUT_TYPE);
			pstmt.setString(1, docFormatId);
			rs = pstmt.executeQuery();
			while(rs.next()){
				result = rs.getString("OUTPUT_TYPE");
			}
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} catch (TecDAOException e) {
			throw e;
		} catch (Exception e) {
			TecLogger.error(e);
			throw new TecDAOException(e);
		} finally {
			try {
				if(rs != null){
					rs.close();
					rs = null;
				}
				if(pstmt != null){
					pstmt.close();
					pstmt = null;
				}
			} catch(SQLException e){
				// Close時の例外は無視
			}
		}
		return result;
	}

}
