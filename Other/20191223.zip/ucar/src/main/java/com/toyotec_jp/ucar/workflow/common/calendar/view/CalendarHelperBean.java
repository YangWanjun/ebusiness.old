/*
 * 【システム名】リース管理システム
 * 【ファイル名】CalendarHelperBean.java
 * 【  説  明  】カレンダーヘルパービーン
 * 【  作  成  】2010/07/09 T.H(SCC)
 */
package com.toyotec_jp.ucar.workflow.common.calendar.view;


import java.text.SimpleDateFormat;
import java.util.Locale;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;

import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.workflow.common.calendar.model.object.CalendarSessionBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;


/**
 * カレンダーヘルパービーン
 */
public class CalendarHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 1L;

	/** 表示形式 */
	private String format 			= "standard";
	/** 曜日表示 */
	private String weekCaption[] 	= {"日", "月", "火", "水", "木", "金", "土"};

	private String form;				// エレメントフォーム名
	private String name;				// エレメント名
	private String year;				// 指定年
	private String month;				// 指定月
	private String group;				// 指定ログイングループID
	private String dateformat;			// 日付書式
	private String dateformatYear;		// 指定年(日付書式)
//2015.4.22 前後追加 START
	private String yearBefore;				// 指定前年
	private String monthBefore;			// 指定前月
	private String dateformatYearBefore;	// 指定前年(日付書式)
	
	private String yearAfter;				// 指定翌年
	private String monthAfter;				// 指定翌月
	private String dateformatYearAfter;	// 指定翌年(日付書式)
//2015.4.55 前後追加 END	

	/**
	 * コンストラクタ
	 */
	public CalendarHelperBean() throws HelperBeanException{
		super();
	}

	/**
	 * 初期処理
	 */
	public void init() throws HelperBeanException{
		// セッションから日付を設定
		CalendarSessionBean sessionBean = getApplicationSessionBean("calendarSessionBean", CalendarSessionBean.class);
		setForm(sessionBean.getForm());
		setName(sessionBean.getName());
		setYear(sessionBean.getYear());
	    setMonth(sessionBean.getMonth());
	    setGroup(getUserInfo().getLoginGroupID());
	    setDateformat(sessionBean.getDateformat());
	    if (UcarConst.FORMAT_G_SHORT.equals(sessionBean.getDateformat())) {
	    	SimpleDateFormat sdf = new SimpleDateFormat(sessionBean.getDateformat(), new Locale("ja","JP","JP"));
	    	String gDate = sdf.format(DateUtils.getDate(sessionBean.getYear() + "/" + sessionBean.getMonth() + "/01" , DateUtils.FORMAT_SHORT));
	    	// H元 → H1(元年は「元」となるため、「1」に変換する)
	    	gDate = gDate.replaceAll("元", "1");
	    	String arrayGDate[] = gDate.split("/");
	    	setDateformatYear(arrayGDate[0]);
	    } else {
	    	setDateformatYear(sessionBean.getYear());
	    }
//2015.4.22 前後追加 START
    	SimpleDateFormat sdf = new SimpleDateFormat(sessionBean.getDateformat(), new Locale("ja","JP","JP"));
	    //前年
		setYearBefore(sessionBean.getYearBefore());
	    setMonthBefore(sessionBean.getMonthBefore());    
	    if (UcarConst.FORMAT_G_SHORT.equals(sessionBean.getDateformat())) {
	    	String gDate = sdf.format(DateUtils.getDate(sessionBean.getYearBefore() + "/" + sessionBean.getMonthBefore() + "/01" , DateUtils.FORMAT_SHORT));
	    	// H元 → H1(元年は「元」となるため、「1」に変換する)
	    	gDate = gDate.replaceAll("元", "1");
	    	String arrayGDate[] = gDate.split("/");
	    	setDateformatYearBefore(arrayGDate[0]);
	    } else {
	    	setDateformatYearBefore(sessionBean.getYearBefore());
	    }
	    //翌年
		setYearAfter(sessionBean.getYearAfter());
	    setMonthAfter(sessionBean.getMonthAfter());    
	    if (UcarConst.FORMAT_G_SHORT.equals(sessionBean.getDateformat())) {
	    	String gDate = sdf.format(DateUtils.getDate(sessionBean.getYearAfter() + "/" + sessionBean.getMonthAfter() + "/01" , DateUtils.FORMAT_SHORT));
	    	// H元 → H1(元年は「元」となるため、「1」に変換する)
	    	gDate = gDate.replaceAll("元", "1");
	    	String arrayGDate[] = gDate.split("/");
	    	setDateformatYearAfter(arrayGDate[0]);
	    } else {
	    	setDateformatYearAfter(sessionBean.getYearAfter());
	    }
//2015.4.22 前後追加 END	    
	}

	/**
	 * フォームを設定します
	 * @return フォーム
	 */
	public String getForm() {
		return form;
	}

	/**
	 * フォームを返却します
	 * @param フォーム
	 */
	public void setForm(String form) {
		this.form = form;
	}

	/**
	 * エレメント名を設定します
	 * @return エレメント名
	 */
	public String getName() {
		return name;
	}

	/**
	 * エレメント名を返却します
	 * @param エレメント名
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * フォーマットを返却します
	 * @return フォーマット
	 */
	public String getFormat() {
		return format;
	}

	/**
	 * フォーマットを設定します
	 * @param フォーマット
	 */
	public void setFormat(String format) {
		this.format = format;
	}

	/**
	 * 曜日書式を返却します
	 * @return 曜日書式
	 */
	public String[] getWeekCaption() {
		return weekCaption;
	}

	/**
	 * 曜日書式を設定します
	 * @param 曜日書式
	 */
	public void setWeekCaption(String[] weekCaption) {
		this.weekCaption = weekCaption;
	}

	/**
	 * 年を返却します
	 * @return 年
	 */
	public String getYear() {
		return year;
	}

	/**
	 * 年を設定します
	 * @param 年
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * 月を返却します
	 * @return 月
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * 月を設定します
	 * @param 月
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * ログインユーザグループを返却します
	 * @return ログインユーザグループ
	 */
	public String getGroup() {
		return group;
	}

	/**
	 * ログインユーザグループを設定します
	 * @param ログインユーザグループ
	 */
	public void setGroup(String group) {
		this.group = group;
	}

	/**
	 * dateformatを取得する。
	 * @return dateformat 日付書式
	 */
	public String getDateformat() {
		return dateformat;
	}

	/**
	 * dateformatを設定する。
	 * @param dateformat 日付書式
	 */
	public void setDateformat(String dateformat) {
		this.dateformat = dateformat;
	}

	/**
	 * dateformatYearを取得する。
	 * @return dateformatYear 指定年(日付書式)
	 */
	public String getDateformatYear() {
		return dateformatYear;
	}

	/**
	 * dateformatYearを設定する。
	 * @param dateformatYear 指定年(日付書式)
	 */
	public void setDateformatYear(String dateformatYear) {
		this.dateformatYear = dateformatYear;
	}

	/**
	 * DateUtils.FORMAT_SHORTを取得する。
	 * @return DateUtils.FORMAT_SHORT yyyy/MM/dd
	 */
	public String getFormatShort() {
		return DateUtils.FORMAT_SHORT;
	}

	/**
	 * UcarConst.FORMAT_SHORT_Y2MD;を取得する。
	 * @return UcarConst.FORMAT_SHORT_Y2MD yy/MM/dd
	 */
	public String getFormatShortY2MD() {
		return UcarConst.FORMAT_SHORT_Y2MD;
	}

	/**
	 * UcarConst.FORMAT_G_SHORTを取得する。
	 * @return UcarConst.FORMAT_G_SHORT Gyyyy/MM/dd
	 */
	public String getFormatGShort() {
		return UcarConst.FORMAT_G_SHORT;
	}
//2015.4.22 前後追加 START
	public String getYearBefore() {
		return yearBefore;
	}

	public void setYearBefore(String yearBefore) {
		this.yearBefore = yearBefore;
	}

	public String getMonthBefore() {
		return monthBefore;
	}

	public void setMonthBefore(String monthBefore) {
		this.monthBefore = monthBefore;
	}

	public String getDateformatYearBefore() {
		return dateformatYearBefore;
	}

	public void setDateformatYearBefore(String dateformatYearBefore) {
		this.dateformatYearBefore = dateformatYearBefore;
	}

	public String getYearAfter() {
		return yearAfter;
	}

	public void setYearAfter(String yearAfter) {
		this.yearAfter = yearAfter;
	}

	public String getMonthAfter() {
		return monthAfter;
	}

	public void setMonthAfter(String monthAfter) {
		this.monthAfter = monthAfter;
	}

	public String getDateformatYearAfter() {
		return dateformatYearAfter;
	}

	public void setDateformatYearAfter(String dateformatYearAfter) {
		this.dateformatYearAfter = dateformatYearAfter;
	}
//2015.4.22 前後追加 END

}