package com.toyotec_jp.ucar.workflow.carryin.list.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListPageingBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListParamBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;

/**
 * <strong>車両搬入一覧 Daoインターフェース</strong>
 * @author Y.F(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public interface ListDaoIF {

	// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため start
	/**
	 * @param prmData
	 * @param t220005mList
	 * @param sortParam
	 * @param sortOrder
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws TecDAOException
	 */
	public ListPageingBean selectMain(String kbScenter
									, ListParamBean prmData
									, ResultArrayList<Ucaa005mBean> t220005mList
									, ResultArrayList<Ucaa004mBean> t220004mList
									, String sortParam
									, String sortOrder
									, String page
									, String pageSize) throws TecDAOException ;
	// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため end

	/**
	 * @param prmData
	 * @return
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucaa005mBean> selectT220005M(ListParamBean prmData) throws TecDAOException ;

	/**
	 * @param prmData
	 * @return
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucaa004mBean> selectT220004M(ListParamBean prmData) throws TecDAOException ;

	/**
	 * 更新処理（車両搬入情報DB）
	 * @param
	 * @return	簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException DAO例外クラス
	 */
	// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
	public SimpleExecuteResultBean updateSyaryoHannyu(Ucaa001gBean t220001gBean,
														String loginKbScenter,
														Timestamp executeDate,
														String kbData) throws TecDAOException;
	// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end

	/**
	 * 車両搬入情報取得処理
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @param ddHannyu 搬入日
	 * @param noKanri 管理番号
	 * @param loginKbScenter 商品化センター区分
	 * @return
	 * @throws TecDAOException
	 */
	// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
	public Ucaa001gBean selectSyaryoHannyu(String cdKaisya,
											String cdHanbaitn,
											String ddHannyu,
											String noKanri,
											String loginKbScenter) throws TecDAOException;
	// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
}