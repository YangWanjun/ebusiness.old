/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecExcelMngException.java
 * 【  説  明  】
 * 【  作  成  】2010/09/09 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import java.util.ArrayList;

import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;


/**
 * <strong>Excel操作例外クラス。</strong>
 * <p>
 * Excel操作による例外。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/09/09 新規作成<br>
 * @since 1.00
 */
public class TecExcelMngException extends TecSystemException {

	private static final long serialVersionUID = 6892172594953850932L;

	/**
	 * コンストラクタ。
	 */
	public TecExcelMngException() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param message
	 */
	public TecExcelMngException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * @param cause
	 */
	public TecExcelMngException(Throwable cause) {
		super(cause);
	}

	/**
	 * コンストラクタ。
	 * @param message
	 * @param cause
	 */
	public TecExcelMngException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 */
	public TecExcelMngException(TecMessageKeyIF messageKey) {
		super(messageKey);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 */
	public TecExcelMngException(TecMessageKeyIF messageKey, ArrayList<Object> args) {
		super(messageKey, args);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param cause
	 */
	public TecExcelMngException(TecMessageKeyIF messageKey, Throwable cause) {
		super(messageKey, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 * @param cause
	 */
	public TecExcelMngException(TecMessageKeyIF messageKey, ArrayList<Object> args, Throwable cause) {
		super(messageKey, args, cause);
	}

}
