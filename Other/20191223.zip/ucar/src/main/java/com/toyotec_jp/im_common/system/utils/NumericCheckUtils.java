/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】NumericCheckUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/06/08 T.H(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.StringTokenizer;


/**
 * <strong>数値チェック系ユーティリティクラス</strong>
 * <p>
 * 数値チェック関連支援処理を管理するクラス
 *
 * @author T.H(SCC)
 * @version 1.00 2010/06/08 新規作成<br>
 */
public class NumericCheckUtils {


	/** 文字　ゼロ. */
	public static final String ZERO = "0";
	/** 文字　プラス. */
	public static final String PLUS = "+";
	/** 文字　マイナス. */
	public static final String MINUS;
	/** 文字　小数点	".". */
	public static final String PERIOD;
	/** 文字　桁	 ",". */
	public static final String COMMA;

	/** 数字の大小判定：パラメータ不良. */
	public static final int COMP_UNKNOWN = -3;
	/** 数字の大小判定：一致. */
	public static final int COMP_MATCH = 0;
	/** 数字の大小判定：A > B . */
	public static final int COMP_A_GREATER = 1;
	/** 数字の大小判定：A < B . */
	public static final int COMP_B_GREATER = -1;

	static {

        DecimalFormatSymbols ss = new DecimalFormatSymbols(Locale.getDefault());

        char[] dss = { ss.getDecimalSeparator() };
        PERIOD = new String(dss);

        char[] minus = { ss.getMinusSign() };
        MINUS = new String(minus);

        char[] conma = { ss.getGroupingSeparator() };
        COMMA = new String(conma);
    }

	/** 基本数字文字定義 */
	private static final String GENUINE_NUMERIC_STRINGS = ZERO + "123456789";

	/** 基本数字文字定義 数字に加えてマイナスと小数点を認め、表現として＋を認めない */
	private static final String NUMERIC_STRINGS = GENUINE_NUMERIC_STRINGS + MINUS + PERIOD;

	/*
     * デフォルトコンストラクタ
     */
	private NumericCheckUtils() {
	}

	/** 基本数字、マイナス、小数点文字判定関数 */
	private static boolean isNumeric(String num) {
		if (num == null){
			return false;
		}
		if (num.length() == 0){
			return false;
		}
		for (int i = 0; i < num.length(); i++) {
			if (NUMERIC_STRINGS.indexOf(num.substring(i, i + 1)) < 0) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 数字判定関数
	 * <pre>
	 * 符号表現許可がfalseで、符号表現が含まれているならばfalseとなる
	 * 小数値許可がfalseで、小数部が存在するならばfalseとなる
	 * [許可する数字表現例]
	 * 　123
	 * 　0123
	 * 　123.1
	 * 　123.01
	 * 　123.10000
	 * 　.001
	 * 　-123
	 * 　-0123
	 * 　-123.1
	 * 　-123.01
	 * 　-123.10000
	 * 　-.001
	 * 　+123		プラス表現は現在エラーとする仕様
	 * 　+0123
	 * 　+123.1
	 * 　+123.01
	 * 　+123.10000
	 * 　+.001
	 * </pre>
	 * @param num	検査対象文字列
	 * @param permitSign 符号表現許可
	 * @param permitDecimal 小数値包含許可
	 * @return true：数字表現形式　false：数字表現形式以外orマイナス許可違反or小数値許可違反
	 */
	public static boolean isNumericFormat(String num, boolean permitSign, boolean permitDecimal) {

		// 数字判定
		if ( !isNumeric(num) ){
			return false;
		}

		// 小数判定
		if ( !permitDecimal ) {
			if (num.indexOf(PERIOD) >= 0){
				return false;
			}
		}

		// 符号判定
		if (!permitSign) {
			if (num.indexOf(PLUS) >= 0){
				return false;
			}
			if (num.indexOf(MINUS) >= 0){
				return false;
			}
		}

		// 符号妥当性判定
		String tmp;
		if (isSignExist(num)) {
			tmp = num.substring(1, num.length());
		} else {
			tmp = num;
		}
		if (tmp.indexOf(PLUS) >= 0) {
			return false;
		} else if (tmp.indexOf(MINUS) >= 0) {
			return false;
		}

		// 小数妥当性判定
		int iStart = num.indexOf(PERIOD);
		if ( (iStart >= 0) && (num.indexOf(PERIOD, iStart + 1) > -1) ) {
			return false;
		}
		StringTokenizer st = new StringTokenizer(tmp, PERIOD);
		int tokenCount = st.countTokens();
		switch (tokenCount) {
			case 0:
				return false;
			case 1:
				break;
			case 2:
				break;
			default:
				return false;
		}

		return true;
	}

	/**
	 * 整数判定関数
	 *
	 * @param num	検査対象文字列
	 * @param permitSign 符号表現許可
	 * @return true：整数表現形式　false：整数表現形式以外orマイナス許可違反or整数取扱可能範囲外
	 */
	public static boolean isInteger(String num, boolean permitSign) {
		if (isNumericFormat(num, permitSign, false)) {
			return false;
		}
		if (compareInteger(num, String.valueOf(Integer.MAX_VALUE)) == COMP_A_GREATER) {
			return false;
		}
		if (compareInteger(num, String.valueOf(Integer.MIN_VALUE)) == COMP_B_GREATER) {
			return false;
		}
		return true;
	}

	/**
	 * 桁数判定関数
	 * <pre>
	 * 対象文字列が、指定の整数部桁以内で指定の小数部桁以内で、符号付加許可に
	 * 合致しているかを判定する
	 * </pre>
	 * @param num 検査対象文字列
	 * @param integerBeams 整数部桁数
	 * @param decimalBeams 小数部桁数
	 * @param permitSign 符号付加許可
	 * @return true：数字表現形式　false：数字表現形式以外or整数部指定桁数以上or小数部指定桁数以上or符号許可エラー
	 */
	public static boolean isSpecificNumberForm(String num, int integerBeams, int decimalBeams, boolean permitSign) {

		if ( !isNumericFormat(num, permitSign, true) ) {
			return false;
		}
		if (decimalBeams == 0) {
			if (num.indexOf(PERIOD) >= 0) return false;
		}

		String tmp;
		if ( isSignExist(num) ) {
			tmp = num.substring(1);
		} else {
			tmp = num;
		}
		int[] x = NumericUtils.getLengthOfIntegerAndDecimal(tmp);
		if (x[0] > integerBeams) {
			return false;
		}
		if (x[1] > decimalBeams) {
			return false;
		}
		return true;
	}

	/**
	 * マイナス値判定関数
	 * <pre>
	 * 日本語圏としての数字表現形式で、マイナスか否かを判定する（文字の先頭に”マイナス”文字）
	 * 数字表現形式の妥当性は確認しない（事前にチェックしておくこと）
	 * </pre>
	 * @param num	検査対象文字列
	 * @return true：マイナス　false：マイナス以外
	 */
	public static boolean isMinus(String num) {
		if ( num.startsWith(PLUS) ) {
			return false;
		} else if ( num.startsWith(MINUS) ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * プラス値判定関数
	 * <pre>
	 * 日本語圏としての数字表現形式で、プラスか否かを判定する（文字の先頭に”プラス”文字）
	 * 数字表現形式の妥当性は確認しない（事前にチェックしておくこと）
	 * </pre>
	 * @param num 検査対象文字列
	 * @return true：プラス、false：プラス以外
	 */
	public static boolean isPlus(String num) {
		if (num.startsWith(PLUS)) {
			return true;
		} else if (num.startsWith(MINUS)) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 符号表現存在判定関数
	 * <pre>
	 * 日本語圏としての数字表現形式で、プラスマイナスの表現が含まれているかを確認する
	 * 数字表現形式の妥当性は確認しない（事前にチェックしておくこと）
	 * </pre>
	 * @param num	検査対象文字列
	 * @return true：表現が含まれている　false：含まれていない
	 */
	public static boolean isSignExist(String num) {
		if (num.startsWith(PLUS)) {
			return true;
		} else if (num.startsWith(MINUS)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 数字大小判定関数(整数値版)
	 * <pre>
	 * 整数の大小を判定する
	 * </pre>
	 * @param a 数字A
	 * @param b 数字B
	 * @return 判定結果
	 * @see #COMP_UNKNOWN
	 * @see #COMP_MATCH
	 * @see #COMP_A_GREATER
	 * @see #COMP_B_GREATER
	 */
	public static int compareInteger(String a, String b) {
	    boolean signA = true;
	    boolean signB = true;
	    int ret = COMP_UNKNOWN;
	    if ( (a == null)||(a.length() < 1)||(b == null)||(b.length() < 1) ) {
	        return COMP_UNKNOWN;
	    }
	    String ax = a;
	    String bx = b;
		if (ax.startsWith(PLUS)) {
			ax = ax.substring(1);
		} else if (ax.startsWith(MINUS)) {
			ax = ax.substring(1);
			signA = false;
		}
		if (bx.startsWith(PLUS)) {
			bx = bx.substring(1);
		} else if (bx.startsWith(MINUS)) {
			bx = bx.substring(1);
			signB = false;
		}

		if (signA & signB) {
	        ret = COMP_UNKNOWN;
	    } else if (signA & !signB) {
	        return COMP_A_GREATER;
	    } else if (!signA & signB) {
	        return COMP_B_GREATER;
	    } else if (!signA & !signB) {
	        ret = COMP_UNKNOWN;
	    }

	    if (ax.length() < bx.length()) {
	        while (0 < bx.length() - ax.length()) {
	            ax = "0" + ax;
	        }
	    }
	    if (ax.length() > bx.length()) {
	        while (0 < ax.length() - bx.length()) {
	            bx = "0" + bx;
	        }
	    }
	    int r = ax.compareTo(bx);;
		if (r == 0) {
		    ret = COMP_MATCH;
		} else if (r > 0) {
		    ret = COMP_A_GREATER;
		} else {
		    ret = COMP_B_GREATER;
		}

	    if (!signA & !signB) {
	        ret = ret * -1;
	    }
	    return ret;
	}

	/**
	 * 数字大小判定関数(小数値版)
	 * <pre>
	 * 整数の大小を判定する
	 * </pre>
	 * @param a 数字A
	 * @param b 数字B
	 * @return 判定結果
	 * @see #COMP_UNKNOWN
	 * @see #COMP_MATCH
	 * @see #COMP_A_GREATER
	 * @see #COMP_B_GREATER
	 */
	public static int compareFloat(String a, String b) {
	    boolean signA = true;
	    boolean signB = true;
	    int ret = COMP_UNKNOWN;
	    if ( (a == null)||(a.length() < 1)||(b == null)||(b.length() < 1) ) {
	        return COMP_UNKNOWN;
	    }
	    String ax = a;
	    String bx = b;
		if (ax.startsWith(PLUS)) {
			ax = ax.substring(1);
		} else if (ax.startsWith(MINUS)) {
			ax = ax.substring(1);
			signA = false;
		}
		if (bx.startsWith(PLUS)) {
			bx = bx.substring(1);
		} else if (bx.startsWith(MINUS)) {
			bx = bx.substring(1);
			signB = false;
		}

		if (signA & signB) {
	        ret = COMP_UNKNOWN;
	    } else if (signA & !signB) {
	        return COMP_A_GREATER;
	    } else if (!signA & signB) {
	        return COMP_B_GREATER;
	    } else if (!signA & !signB) {
	        ret = COMP_UNKNOWN;
	    }

	    String[] axArray = NumericUtils.separateIntegerAndDecimal(ax);
	    String[] bxArray = NumericUtils.separateIntegerAndDecimal(bx);

	    ret = compareInteger(axArray[0], bxArray[0]);
	    if (ret != COMP_MATCH) {
		    if (signA & signB) {
		        return ret;
		    } else if (signA & !signB) {
		        return COMP_A_GREATER;
		    } else if (!signA & signB) {
		        return COMP_B_GREATER;
		    } else if (!signA & !signB) {
		        return ret * -1;
		    }
	    }
	    if (axArray[1].length() < bxArray[1].length()) {
	        while (0 < bxArray[1].length() - axArray[1].length()) {
	            axArray[1] = axArray[1] + "0";
	        }
	    }
	    if (axArray[1].length() > bxArray[1].length()) {
	        while (0 < axArray[1].length() - bxArray[1].length()) {
	            bxArray[1] = bxArray[1] + "0";;
	        }
	    }
	    ret = compareInteger(axArray[1], bxArray[1]);
	    if (!signA & !signB) {
	        ret = ret * -1;
	    }
	    return ret;
	}

}
