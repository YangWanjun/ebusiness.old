package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>共通店舗会社区分DBBean</strong>
 * <p>テーブル英名：TBV0201M</p>
 * @author T.O(TOYOTEC)
 * @version 1.00 2019/04/24 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SiireTenpoKbkaisyaDBBean extends TecBean {

	/**
	 *
	 */
	private static final long	serialVersionUID	= -4469233974701059808L;

	/** 会社区分 */
	private String	kbKaisya;

	/**
	 *
	 */
	public SiireTenpoKbkaisyaDBBean() {
		super();
	}

	/**
	 * kbKaisyaを取得する。
	 * @return kbKaisya 会社区分
	 */
	public String getKbKaisya() {
		return kbKaisya;
	}

	/**
	 * kjTentanmsを設定する。
	 * @param kjTentanms 店舗短縮名
	 */
	public void setKbKaisya(String kbKaisya) {
		this.kbKaisya = kbKaisya;
	}

}
