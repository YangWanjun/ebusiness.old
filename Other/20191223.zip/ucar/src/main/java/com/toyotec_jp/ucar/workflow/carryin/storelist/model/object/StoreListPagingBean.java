package com.toyotec_jp.ucar.workflow.carryin.storelist.model.object;

import com.toyotec_jp.im_common.system.model.object.SimplePagingResultBean;

/**
 * <strong>展示店舗受取処理 画面出力値 リストページングBean</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/03/09 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class StoreListPagingBean extends SimplePagingResultBean<StoreListDataBean> {

	private static final long serialVersionUID = -7898490009941526316L;

}
