package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;

/**
 * <strong>U-Car商品化システム マスタ操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/17 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UcaaMasterDAOImpl extends UcarSharedDBDAO implements UcaaMasterDAOIF {

	private static final String SELECT_T220004M_LIST_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , KB_SIIRE "
		+ "  , MJ_SIIRE "
		+ "  , MJ_TANSIIRE "
		+ "  , KB_DISP "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ "FROM "
		+ "  T220004M ";

	private static final String SELECT_T220004M_WHERE_SQL
		= "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_DISP     = ? ";

	private static final String SELECT_T220004M_ORDER_SQL
		= "ORDER BY "
		+ "  NU_HYZYUN ";

	private static final String SELECT_T220005M_LIST_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , KB_CHECK "
		+ "  , MJ_CHECK "
		+ "  , KB_DISP "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ "FROM "
		+ "  T220005M ";

	private static final String SELECT_T220005M_WHERE_SQL
		= "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_DISP     = ? ";

	private static final String SELECT_T220005M_ORDER_SQL
		= "ORDER BY "
		+ "  NU_HYZYUN ";

	private static final String SELECT_T220014M_LIST_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , KB_SGYOKT "
		+ "  , MJ_SGYOKT "
		+ "  , KB_DISP "
		+ "  , NU_HYZYUN "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ "FROM "
		+ "  T220014M ";

	private static final String SELECT_T220014M_WHERE_SQL
		= "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_KASYU    = ? "
		+ "  AND KB_TENPOSK  = ? "	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		+ "  AND KB_DISP     = ? ";

	private static final String SELECT_T220014M_ORDER_SQL
		= "ORDER BY "
		+ "  NU_HYZYUN ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.T220004mDAOIF#getT220004mList(java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Ucaa004mBean> getT220004mList(String cdKaisya,
			String cdHanbaitn) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder(SELECT_T220004M_LIST_SQL);

		selectSql.append(SELECT_T220004M_WHERE_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);				// 会社コード
		paramBean.setString(cdHanbaitn);			// 販売店コード
		paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分

		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_T220004M_ORDER_SQL);

		ResultArrayList<Ucaa004mBean> resList
			= executeSimpleSelectQuery(paramBean, Ucaa004mBean.class);

		return resList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaMasterDAOIF#getT220005mList(java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Ucaa005mBean> getT220005mList(String cdKaisya,
			String cdHanbaitn) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder(SELECT_T220005M_LIST_SQL);

		selectSql.append(SELECT_T220005M_WHERE_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);				// 会社コード
		paramBean.setString(cdHanbaitn);			// 販売店コード
		paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分

		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_T220005M_ORDER_SQL);

		ResultArrayList<Ucaa005mBean> resList
			= executeSimpleSelectQuery(paramBean, Ucaa005mBean.class);

		return resList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaMasterDAOIF#getT220014mList(java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Ucac002mBean> getT220014mList(String cdKaisya,
														  String cdHanbaitn,
														  String kbKasyu,
														  String kbTenposk) throws TecDAOException {	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder(SELECT_T220014M_LIST_SQL);

		selectSql.append(SELECT_T220014M_WHERE_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);				// 会社コード
		paramBean.setString(cdHanbaitn);			// 販売店コード
		paramBean.setString(kbKasyu);				// 加修フラグ
		paramBean.setString(kbTenposk);				// 加修フラグ
		paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分

		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_T220014M_ORDER_SQL);

		ResultArrayList<Ucac002mBean> resList
			= executeSimpleSelectQuery(paramBean, Ucac002mBean.class);

		return resList;
	}

}
