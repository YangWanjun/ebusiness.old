package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.SyainDBDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean;

/**
 * <strong>車両搬入情報取得イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/10 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class GetRegisterDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetRegisterDataEvent targetEvent = (GetRegisterDataEvent)event;

		Ucaa001gPKBean t220001gPkBean = targetEvent.getT220001gPkBean();

		// DAOIF取得
		RegisterDAOIF getDao = getDAO(CarryinDAOKey.REGISTER_DAO, targetEvent, RegisterDAOIF.class);

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 車両搬入情報取得
		ResultArrayList<Ucaa001gBean> t220001gList = getDao.selectT220001G(t220001gPkBean,
																			targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																			targetEvent.getUserInfoBean().getKbScenter());
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// 検索対象が0件の場合
		if (t220001gList.size() == 0) {
			throw new TecApplicationException(TecMessageManager.getMessage(UcarMessage.NOT_FOUND));
		}

		SyainDBDAOIF syainDao = getDAO(UcarDAOKey.SYAIN_DB_DAO, event, SyainDBDAOIF.class);

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		Ucaa001gBean t220001gBean = t220001gList.get(0);
		ResultArrayList<SyainDBBean> SyainDBList = syainDao.getSyainDBList(t220001gBean.getCdKaisya(),
																			t220001gBean.getCdHanbaitn(),
																			t220001gBean.getCdSdtan());
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		GetRegisterDataEventResult getEventResult = new GetRegisterDataEventResult();

		if (SyainDBList.size() > 0) {
			getEventResult.setSyainDBBean(SyainDBList.get(0));
		} else {
			getEventResult.setSyainDBBean(new SyainDBBean());
		}

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 仕入種別情報取得
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//		ResultArrayList<Ucaa002gBean> t220002gList = getDao.selectT220002G(t220001gPkBean,
//																			targetEvent.getUserInfoBean().getKbScenter());
		ResultArrayList<Ucaa002gBean> t220002gList = null;
		t220002gList = getDao.selectT220002G(t220001gPkBean,
											UcarConst.KB_SCENTER_SCENTER);
		if (t220002gList.size() == 0) {
			t220002gList = getDao.selectT220002G(t220001gPkBean,
												"");			
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		// チェック内容情報取得
		ResultArrayList<Ucaa003gBean> t220003gList = getDao.selectT220003G(t220001gPkBean,
																			targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																			targetEvent.getUserInfoBean().getKbScenter(),
																			null);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		getEventResult.setUcaa001gBean(t220001gList.get(0));
		getEventResult.setT220002gList(t220002gList);
		getEventResult.setT220003gList(t220003gList);


		// 書類完備情報取得 2011.10.12 H.Yamashita add start
		ResultArrayList<Ucab002gBean> t220007gList = getDao.selectT220007G(t220001gPkBean,
																			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
																			targetEvent.getUserInfoBean().getCdTenpo(),
																			targetEvent.getUserInfoBean().getKbScenter());
																			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		if (t220007gList.size() > 0) {
			getEventResult.setUcab002gBean(t220007gList.get(0));
		}else {
			getEventResult.setUcab002gBean(new Ucab002gBean());
		}
		// 書類完備情報取得 2011.10.12 H.Yamashita add end

		return getEventResult;
	}

}
