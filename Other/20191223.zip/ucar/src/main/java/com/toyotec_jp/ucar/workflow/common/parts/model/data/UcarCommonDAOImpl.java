package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.util.Date;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucca002mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb011vBean;

/**
 * <strong>U-Car商品化システム(共通)用DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/07 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UcarCommonDAOImpl extends UcarSharedDBDAO implements UcarCommonDAOIF {

	/** 消費税率取得（コード区分マスタ）SQL */
	private static final String SELECT_SYOUHIZEI_SQL
	= "SELECT "
		+ "    MJ_KUBUN "
		+ "  , MJ_INFO3 "
		+ "FROM "
		+ "  T220204M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND KB_ID       = ? "
		+ "  AND MJ_INFO1    <= ? "
		+ "  AND ?           <= MJ_INFO2 ";

	/** 端数処理取得（コード区分マスタ）SQL */
	private static final String SELECT_HASUU_SQL
		= "SELECT "
		+ "    MJ_KUBUN "
		+ "FROM "
		+ "  T220204M "
		+ "WHERE "
		+ "  CD_KAISYA       = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND KB_ID       = ? "
		+ "  AND CD_KUBUN    = ? ";

	/** データ取得（コード区分マスタ）SQL */
	private static final String SELECT_T220204M_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , KB_ID "
		+ "  , CD_KUBUN "
		+ "  , MJ_KUBUN "
		+ "  , MJ_KBNRK "
		+ "  , MJ_INFO1 "
		+ "  , MJ_INFO2 "
		+ "  , MJ_INFO3 "
		+ "  , MJ_INFO4 "
		+ "  , MJ_INFO5 "
		+ "  , NO_SORT "
		+ "  , MJ_BIKOU "
		+ "FROM "
		+ "  T220204M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND KB_ID       = ? ";

	/** データ取得（コード区分マスタ） ORDER BY SQL */
	private static final String SELECT_T220204M_ORDER_SQL
		= "ORDER BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , KB_ID "
		+ "  , CD_KUBUN ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.report.model.data.MitumoriDAOIF#selectSyouhizei(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220211gBean)
	 */
	@Override
	public Ucba004mBean selectSyouhizei(Ucba004mBean t220204mBean,
			Date targetDate) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_SYOUHIZEI_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220204mBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220204mBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString("29");							// 区分ID
		paramBean.setDate(targetDate);						// 取得対象日付
		paramBean.setDate(targetDate);						// 取得対象日付

		ResultArrayList<Ucba004mBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucba004mBean.class);

		Ucba004mBean resultBean = null;
		if (resultList.size() > 0) {
			resultBean = resultList.get(0);
		}
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.report.model.data.MitumoriDAOIF#selectHasuu(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220211gBean)
	 */
	@Override
	public Ucba004mBean selectHasuu(Ucba004mBean t220204mBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_HASUU_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220204mBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220204mBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString("30");							// 区分ID
		paramBean.setString(t220204mBean.getCdKubun());		// 区分コード

		ResultArrayList<Ucba004mBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucba004mBean.class);

		Ucba004mBean resultBean = null;
		if (resultList.size() > 0) {
			resultBean = resultList.get(0);
		}
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.UcarCommonDAOIF#selectT220204M(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean)
	 */
	@Override
	public ResultArrayList<Ucba004mBean> selectT220204M(Ucba004mBean t220204mBean) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220204M_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220204mBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220204mBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220204mBean.getKbId());		// 区分ID

		if (!StringCheckUtils.isEmpty(t220204mBean.getCdKubun())) {
			executeSql.append("  AND CD_KUBUN    = ? ");
			paramBean.setString(t220204mBean.getCdKubun());	// 区分コード
		}

		if (!StringCheckUtils.isEmpty(t220204mBean.getMjKbnrk())) {
			executeSql.append("  AND MJ_KBNRK    = ? ");
			paramBean.setString(t220204mBean.getMjKbnrk());	// 区分略名
		}

		paramBean.setSql(executeSql.toString());
		paramBean.setOrderSql(SELECT_T220204M_ORDER_SQL);

		ResultArrayList<Ucba004mBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucba004mBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListDaoIF#selectT220018m(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Ucca002mBean selectT220018m(String cdKaisya, String cdHanbaitn,
			String kbId, String cdKubun) throws TecDAOException {

		final String executeSql
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , KB_ID "
			+ "  , CD_KUBUN "
			+ "  , MJ_KUBUN "
			+ "  , MJ_KBNRK "
			+ "  , MJ_INFO1 "
			+ "  , MJ_INFO2 "
			+ "  , MJ_INFO3 "
			+ "  , MJ_INFO4 "
			+ "  , MJ_INFO5 "
			+ "  , NO_SORT "
			+ "  , MJ_BIKOU "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
			+ "  T220018M "
			+ "WHERE "
			+ "  CD_KAISYA = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND KB_ID = ? "
			+ "  AND CD_KUBUN = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(kbId);			// 区分ID
		paramBean.setString(cdKubun);		// 区分コード

		ResultArrayList<Ucca002mBean> t220018mList = executeSimpleSelectQuery(paramBean, Ucca002mBean.class);

		Ucca002mBean t220018mBean = null;
		if (t220018mList.size() > 0) {
			t220018mBean = t220018mList.get(0);
		}

		return t220018mBean;
	}

	// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.report.model.data.KouteiKanriDAOIF#selectT220902v(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Uccb011vBean selectT220902v(String cdKaisya,
										String cdHanbaitn,
										String ddHannyu,
										String noKanri,
										String cdHantenpo) throws TecDAOException {

		String executeSql
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , CD_OKYAKU "
			+ "  , KJ_OKYAKUM "
			+ "  , CD_NORIKUSI "
			+ "  , KB_NOSYASYU "
			+ "  , CD_NOGYOTAI "
			+ "  , NO_NOSEIRI "
			+ "  , CD_HANTENPO "
			+ "  , DD_UKETORI "
			+ "  , MJ_SITKATA "
			+ "  , NO_SYADAI "
			+ "  , MJ_SYAMEI "
			+ "  , DD_SYODOTOR "
			+ "  , DD_SYKNMANR "
			+ "  , NO_KATARUIB "
			+ "  , CD_TOSYOKU "
			+ "  , NU_SOUKUKM "
			+ "  , CD_SIRTENPO "
			+ "  , CD_SDTAN "
			+ "  , KI_NYUKOK "
			+ "  , CD_KOZINZYHO "
			+ "  , NO_ZYUTYU "
			+ "  , MJ_UKETAN "
			+ "  , NO_SYARYOU "
			+ "  , DD_SIIRE "
			+ "  , MJ_BIKOU "
			+ "  , DT_ZAIKO "
			+ "  , DT_KOUTEI "
			+ "  , DD_INKANKGN "
			+ "  , DT_SOUBI "
			+ "  , DT_SHAKO "
			+ "  , DT_ZEI "
			+ "  , DT_TYUMON "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "  , KB_DATA "
			+ "FROM "
			+ "  T220902V "
			+ "WHERE "
/*--2019.3.20 from
			+ "  CD_KAISYA = ? "
			+ "  AND CD_HANBAITN = ? "
*/
			+ "  CD_KAISYA = ? ";
		if(UcarConst.WCOROLLA.equals(cdHanbaitn)){
			executeSql += " AND CD_HANBAITN = ? ";
		}else{
			executeSql += " AND CD_HANBAITN != ? ";
		}
		executeSql += ""
//--2019.3.20 to
			+ "  AND DD_HANNYU = ? "
			+ "  AND NO_KANRI = ? "
			+ "  AND CD_HANTENPO = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
/*--2019.3.20 from
		paramBean.setString(cdHanbaitn);	// 販売店コード
*/
		if(UcarConst.WCOROLLA.equals(cdHanbaitn)){
			paramBean.setString(cdHanbaitn);	// 販売店コード
		}else{
			paramBean.setString(UcarConst.WCOROLLA);
		}
//--2019.3.20 to
		paramBean.setString(ddHannyu);		// 搬入日
		paramBean.setString(noKanri);		// 管理番号
		paramBean.setString(cdHantenpo);	// 搬入店舗コード・受取店舗コード

		ResultArrayList<Uccb011vBean> t220902vList = executeSimpleSelectQuery(paramBean, Uccb011vBean.class);

		Uccb011vBean t220902vBean = null;
		if (t220902vList.size() > 0) {
			t220902vBean = t220902vList.get(0);
		}

		return t220902vBean;
	}
	// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end

}
