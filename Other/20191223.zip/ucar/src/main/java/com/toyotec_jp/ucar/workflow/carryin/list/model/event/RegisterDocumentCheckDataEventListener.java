package com.toyotec_jp.ucar.workflow.carryin.list.model.event;

import java.sql.Timestamp;
import java.util.ArrayList;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventException;
import jp.co.intra_mart.framework.base.event.EventManagerException;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.data.DocumentCheckDAOIF;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.UpdateZoneDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb004gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;

/**
 * <strong>書類チェック登録イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/18 新規作成<br>
 * @since 1.00
 * @category [[搬入書類チェック]]
 */
public class RegisterDocumentCheckDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		TecLogger.trace("insert/update registerData start");

		RegisterDocumentCheckDataEvent targetEvent = (RegisterDocumentCheckDataEvent) event;

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarryinConst.APPID_CARRYIN_LIST;

		ArrayList<Ucaa001gPKBean> t220001gPKList = targetEvent.getT220001gPKList();

		// DAOIF取得
		DocumentCheckDAOIF dao = getDAO(CarryinDAOKey.DOCUMENT_CHECK_DAO, targetEvent, DocumentCheckDAOIF.class);

		int resultCount = 0;
		for (Ucaa001gPKBean t220001gPKBean : t220001gPKList) {

			// 書類チェックDB：会社コード・販売店コード・搬入日・管理番号
			// 				   在庫店舗コード	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			// 				   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
//			T220007gBean t220007gBean = new T220007gBean(t220001gPKBean.getCdKaisya(),
			Uccb004gBean t220007gBean = new Uccb004gBean(t220001gPKBean.getCdKaisya(),				// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
														t220001gPKBean.getCdHanbaitn(),
														t220001gPKBean.getDdHannyu(),
														t220001gPKBean.getNoKanri(),
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
														targetEvent.getUserInfoBean().getCdTenpo(),	
														targetEvent.getUserInfoBean().getKbScenter(),
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
														updateUserId,
														updateUserId,
														updateAppId,
														updateAppId);

			// ステータスDB：会社コード・販売店コード・搬入日・管理番号
			//			   在庫店舗コード・商品化センター区分	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			//			   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
//			T220012gInputDataBean t220012gInputDataBean = new T220012gInputDataBean(t220001gPKBean.getCdKaisya(),
			Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(t220001gPKBean.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
														t220001gPKBean.getCdHanbaitn(),
														t220001gPKBean.getDdHannyu(),
														t220001gPKBean.getNoKanri(),
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
														targetEvent.getUserInfoBean().getCdTenpo(),	
														targetEvent.getUserInfoBean().getKbScenter(),
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
														updateUserId,
														updateUserId,
														updateAppId,
														updateAppId);

			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
			Uccb007gPKBean t220107gPKBean = new Uccb007gPKBean(t220001gPKBean.getCdKaisya(),
																t220001gPKBean.getCdHanbaitn(),
																t220001gPKBean.getDdHannyu(),
																t220001gPKBean.getNoKanri(),
																targetEvent.getUserInfoBean().getCdTenpo(),	
																targetEvent.getUserInfoBean().getKbScenter());
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			String ddSetDate = UcarUtils.getStringDateFormatShortSimple(targetEvent.getDdSetDate());

			boolean executeT220003g = false;

			if (targetEvent.isExecuteRegister()) {
				// チェックしたデータを登録の場合
				if (UcarConst.RDO_KUBUN_COMPLETE.equals(targetEvent.getRdoKubun())) {
					// 完了
					// 書類チェックDB：書類完備日
					t220007gBean.setDdSrknb(ddSetDate);
					// ステータスDB：ステータス03
					CheckStatusDateEventResult csdeResult
//						= checkStatusDate(targetEvent, t220001gPKBean, 3, targetEvent.getDdSetDate());
						= checkStatusDate(targetEvent, t220107gPKBean, 3, targetEvent.getDdSetDate());	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
					t220012gInputDataBean.setStrDtStatus03(csdeResult.getDtStatus());
					t220012gInputDataBean.setStrDtStatus04(null);

					// 書類完備日登録の場合はチェック内容情報の下取書類に登録を行う
					executeT220003g = true;

				} else {
					// 保留
					// 入庫チェックDB：書類完備保留日
					t220007gBean.setDdSrkhr(ddSetDate);
					// ステータスDB:ステータス04
					CheckStatusDateEventResult csdeResult
//						= checkStatusDate(targetEvent, t220001gPKBean, 4, targetEvent.getDdSetDate());
						= checkStatusDate(targetEvent, t220107gPKBean, 4, targetEvent.getDdSetDate());	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
					t220012gInputDataBean.setStrDtStatus03(null);
					t220012gInputDataBean.setStrDtStatus04(csdeResult.getDtStatus());
				}
			} else {
				// チェックしたデータを取消の場合

				// ステータスDBに対してチェック処理を実施する
//				checkStatusDB(targetEvent, t220001gPKBean, "[搬入日]:" + t220001gPKBean.getDdHannyu() + "　" +
				checkStatusDB(targetEvent, t220107gPKBean, "[搬入日]:" + t220001gPKBean.getDdHannyu() + "　" +	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
															"[管理番号]:" + t220001gPKBean.getNoKanri() + "　は、" +
															"次工程に入力がありますので、取消を行うことはできません。");

				t220012gInputDataBean.setStrDtStatus03(null);
				t220012gInputDataBean.setStrDtStatus04(null);
			}

			// 書類チェック情報
			int countSelect = dao.selectT220007GCount(t220007gBean);
			if (countSelect > 0) {
				String nyukoDtKosin = getSyoruiDtKosin(targetEvent, t220001gPKBean);
				// 更新処理
				updateT220007gData(dao, t220007gBean, nyukoDtKosin, executeDate);
			} else {
				// 新規登録処理
				insertT220007gData(dao, t220007gBean, executeDate);
			}
			resultCount++;

			// チェック内容区分
//			T220003gBean t220003gBean = new T220003gBean(t220001gPKBean.getCdKaisya(),
			Uccb003gBean t220003gBean = new Uccb003gBean(t220001gPKBean.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
														t220001gPKBean.getCdHanbaitn(),
														t220001gPKBean.getDdHannyu(),
														t220001gPKBean.getNoKanri(),
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
														targetEvent.getUserInfoBean().getCdTenpo(),	
														targetEvent.getUserInfoBean().getKbScenter(),
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
														UcarConst.KB_CHECK_SITADORI,
														ddSetDate,
														updateUserId,
														updateUserId,
														updateAppId,
														updateAppId);
			
			// センターの場合のみ処理
			if (t220003gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
				// チェック内容情報の下取書類を削除する
				dao.deleteT220003G(t220003gBean);
	
				if (executeT220003g) {
					// 書類完備日登録の場合はチェック内容情報に下取書類の登録を行う
					dao.insertT220003G(t220003gBean, executeDate);
				}
			}

			// ステータス更新処理
			SimpleExecuteResultBean updateStatusResult = dao.updateT220012G(t220012gInputDataBean, executeDate);
			if (updateStatusResult.getExecuteCount() == 0) {
				// 更新件数が0件の場合はInsert処理

				// Insertの場合はステータス01をセット
				String strDtStatus01 = UcarUtils.getStringDateFormatShort(t220001gPKBean.getDdHannyu());
				t220012gInputDataBean.setStrDtStatus01(strDtStatus01);

				dao.insertT220012G(t220012gInputDataBean, executeDate);
			}

			// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
			UpdateZoneDateEvent updateZoneDateEvent
				= createEvent(UcarEventKey.UPDATE_ZONE_DATE, targetEvent.getUserInfo(), UpdateZoneDateEvent.class);
			
//			updateZoneDateEvent.setT220001gPkBean(t220001gPKBean);
			updateZoneDateEvent.setT220107gPkBean(t220107gPKBean);
//			updateZoneDateEvent.setT220012gInputDataBean(t220012gInputDataBean);
			updateZoneDateEvent.setUccb007gInputDataBean(t220012gInputDataBean);
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			updateZoneDateEvent.setExecuteDtStatus03(true);
			updateZoneDateEvent.setExecuteDtStatus05(true);
			updateZoneDateEvent.setExecuteDtStatus07(true);

			updateZoneDateEvent.setExecuteDate(executeDate);

			// イベント実行
			dispatchEvent(updateZoneDateEvent);
			// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため end
		}

		RegisterDocumentCheckDataEventResult eventResult = new RegisterDocumentCheckDataEventResult();
		// 処理件数を返す
		eventResult.setCountExecute(resultCount);

		TecLogger.trace("insert/update registerData end");
		return eventResult;
	}

	/**
	 * ステータスDB日付比較チェック
	 * @param targetEvent
	 * @param t220001gPkBean
	 * @param checkStatusNo
	 * @param dtStatus
	 * @return
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	public CheckStatusDateEventResult checkStatusDate(RegisterDocumentCheckDataEvent targetEvent,
//														Ucaa001gPKBean t220001gPkBean,
														Uccb007gPKBean t220107gPKBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
														int checkStatusNo,
														String dtStatus) throws SystemException, ApplicationException {

		CheckStatusDateEvent checkStatusDateEvent
			= createEvent(UcarEventKey.CHECK_STATUS_DATE, targetEvent.getUserInfo(), CheckStatusDateEvent.class);

//		checkStatusDateEvent.setT220001gPkBean(t220001gPkBean);
		checkStatusDateEvent.setT220107gPkBean(t220107gPKBean);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		checkStatusDateEvent.setCheckStatusNo(checkStatusNo);
		checkStatusDateEvent.setDtStatus(dtStatus);

		return (CheckStatusDateEventResult)dispatchEvent(checkStatusDateEvent);
	}

	/**
	 * ステータスDBチェック
	 * @param targetEvent
	 * @throws TecSystemException
	 * @throws EventManagerException
	 * @throws EventException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void checkStatusDB(RegisterDocumentCheckDataEvent targetEvent,
//			Ucaa001gPKBean t220001gPKBean,
			Uccb007gPKBean t220107gPKBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			String message)
			throws TecSystemException, EventManagerException, EventException,
			SystemException, ApplicationException {

		CheckStatusEvent checkStatusEvent
			= createEvent(UcarEventKey.CHECK_STATUS, targetEvent.getUserInfo(), CheckStatusEvent.class);

//		checkStatusEvent.setT220001gPkBean(t220001gPKBean);
		checkStatusEvent.setT220107gPkBean(t220107gPKBean);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// ステータス05から
		checkStatusEvent.setStartDtStatus(5);
		// ステータス08まで
		checkStatusEvent.setEndDtStatus(8);
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		// イベント実行
		CheckStatusEventResult checkStatusResult
			= (CheckStatusEventResult)dispatchEvent(checkStatusEvent);

		if (checkStatusResult.isExistDtStatus()) {
			throw new TecApplicationException(message);
		}
	}

	/**
	 * 書類チェックDB データ更新日時取得
	 * <pre>
	 * 取得したデータ更新日時を使用して、排他制御を実行する
	 * </pre>
	 * @param targetEvent
	 * @param carCheckDataList
	 * @param arraySelectData
	 * @return
	 */
	private String getSyoruiDtKosin(RegisterDocumentCheckDataEvent targetEvent, Ucaa001gPKBean t220001gPKBean) {

		String syoruiDtKosin = null;

		for (ListDataBean listDataBean : targetEvent.getDocumentCheckDataList()) {
			// 画面表示リスト件数分

			if (t220001gPKBean.getCdKaisya().equals(listDataBean.getCdKaisya())
				&& t220001gPKBean.getCdHanbaitn().equals(listDataBean.getCdHanbaitn())
				&& t220001gPKBean.getDdHannyu().equals(listDataBean.getDdHannyu())
				&& t220001gPKBean.getNoKanri().equals(listDataBean.getNoKanri())) {
				// 更新対象のキーと一致した場合

				if (listDataBean.getSyoruiDtKosin() != null) {
					// 書類チェックDBのデータ更新日時がNullでなければ、更新日時を取得
					syoruiDtKosin = DateUtils.dateToString(listDataBean.getSyoruiDtKosin(), DateUtils.DB_FORMAT_LONG_M);
				}
				break;
			}
		}
		return syoruiDtKosin;
	}

	/**
	 * 書類チェックDB 更新処理
	 * @param dao
	 * @param t220007gBean
	 * @param syoruiDtKosin
	 * @param executeDate
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void updateT220007gData(DocumentCheckDAOIF dao,
//									T220007gBean t220007gBean,
									Uccb004gBean t220007gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
									String syoruiDtKosin,
									Timestamp executeDate)
									throws TecExclusionException, TecMessageException, TecDAOException {

		SimpleExecuteResultBean updateResult = dao.updateT220007G(t220007gBean,
																	syoruiDtKosin,
																	executeDate);

		if (updateResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
		}
	}

	/**
	 * 書類チェックDB 新規登録処理
	 * @param dao
	 * @param t220007gBean
	 * @param executeDate
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void insertT220007gData(DocumentCheckDAOIF dao,
//									T220007gBean t220007gBean,
									Uccb004gBean t220007gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
									Timestamp executeDate)
									throws TecExclusionException, TecMessageException, TecDAOException {

		try {
			dao.insertT220007G(t220007gBean, executeDate);
		} catch (TecDAOException e) {
			if (e.getMessage().indexOf("ORA-00001") != -1) {
				// 一意キー制約の場合は排他制御としてエラーをthrow
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
			} else {
				throw e;
			}
		}
	}

}
