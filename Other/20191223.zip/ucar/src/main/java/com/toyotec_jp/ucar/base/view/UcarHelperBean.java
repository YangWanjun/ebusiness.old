/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarHelperBean.java
 * 【  説  明  】
 * 【  作  成  】2010/06/02 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.view;

import java.lang.reflect.Constructor;

import javax.servlet.http.HttpServletRequest;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.service.ServiceManager;
import jp.co.intra_mart.framework.base.service.ServiceManagerException;
import jp.co.intra_mart.framework.base.service.ServiceServlet;
import jp.co.intra_mart.framework.base.util.UserInfo;
import jp.co.intra_mart.framework.base.web.bean.HelperBean;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;

import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecServiceIdIF;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.im_common.system.utils.SimpleRequestMapper;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.system.session.ApplicationSessionBeanIF;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;

/**
 * <strong>基本ヘルパービーン。</strong>
 * <p>
 * ヘルパービーン作成時は本クラスを継承すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/02 新規作成<br>
 * @since 1.00
 */
public abstract class UcarHelperBean extends HelperBean {

	private static final long serialVersionUID = -5849258552024167400L;

	public UcarHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.web.bean.HelperBean#init()
	 */
	@Override
	public abstract void init() throws HelperBeanException;

	/**
	 * 画面入力値をマッピングしたビーンを取得する。
	 * <pre>
	 * リクエストとして受け取った画面入力値をビーンにマッピングする。<br>
	 * 画面name属性「ab_cde_fg」はビーンのプロパティ「abCdeFg」に
	 * メソッド「setAbCdeFg」を使用してマッピングされる。
	 * </pre>
	 * @param <E>
	 * @param cls マッピング対象となるビーンのクラス
	 * @return リクエストの値をマッピングしたビーン
	 * @throws HelperBeanException
	 * @see SimpleRequestMapper#setRequest(HttpServletRequest, TecBean)
	 */
	protected <E extends TecBean> E getRequestParamMappedBean(Class<E> cls) throws HelperBeanException{
		E bean = null;
		Constructor<E> constructor = null;
		try {
			constructor = cls.getConstructor();
			bean = constructor.newInstance();
			SimpleRequestMapper.setRequest(getRequest(), bean);
		} catch (Exception e) {
			TecLogger.error(e.getMessage(), cls.getName());
			throw new HelperBeanException();
		}
		return bean;
	}

	/**
	 * ログインセッションビーン取得。
	 * <pre>
	 * ログインユーザの情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、ログインセッションビーンを生成しセッションに設定した後、返却する。
	 * </pre>
	 * @return ログインセッションビーン
	 * @throws HelperBeanException
	 * @see UcarSessionManager#getLoginSessionBean(HttpServletRequest, UserInfo)
	 */
	protected LoginSessionBean getLoginSessionBean() throws HelperBeanException {
		LoginSessionBean loginSessionBean = null;
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		try {
			loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());
		} catch (TecSystemException e) {
			throw new HelperBeanException();
		}
		return loginSessionBean;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * アプリケーションセッションビーンのクラス名をキーとしてセッションから取得する。
	 * 詳細については{@link UcarHelperBean#getApplicationSessionBean(String, Class)}を参照。
	 * </pre>
	 * @param <E>
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws HelperBeanException
	 * @see UcarSessionManager#getApplicationSessionBean(HttpServletRequest, String, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(Class<E> cls) throws HelperBeanException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		E sessionBean = null;
		try {
			sessionBean = sessionMng.getApplicationSessionBean(getRequest(), cls);
		} catch (TecSystemException e) {
			throw new HelperBeanException();
		}
		return sessionBean;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、または存在しているがそのクラスが引数として設定されたクラスと異なる場合、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws HelperBeanException
	 * @see UcarSessionManager#getApplicationSessionBean(HttpServletRequest, String, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			String key, Class<E> cls) throws HelperBeanException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		E sessionBean = null;
		try {
			sessionBean = sessionMng.getApplicationSessionBean(getRequest(), key, cls);
		} catch (TecSystemException e) {
			throw new HelperBeanException();
		}
		return sessionBean;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws HelperBeanException
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			Class<E> cls, boolean doCreate) throws HelperBeanException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		E sessionBean = null;
		try {
			sessionBean = sessionMng.getApplicationSessionBean(getRequest(), cls, doCreate);
		} catch (TecSystemException e) {
			throw new HelperBeanException();
		}
		return sessionBean;
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws HelperBeanException
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			String key, Class<E> cls, boolean doCreate) throws HelperBeanException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		E sessionBean = null;
		try {
			sessionBean = sessionMng.getApplicationSessionBean(getRequest(), key, cls, doCreate);
		} catch (TecSystemException e) {
			throw new HelperBeanException();
		}
		return sessionBean;
	}

	/**
	 * リクエストに共通メッセージ画面遷移用ビーンを設定。
	 * @param bean 共通メッセージ画面遷移用ビーン
	 */
	protected void setMessageBean(MessageBean bean){
		getRequest().setAttribute(UcarApplicationManager.REQ_ATTR_KEY_MESSAGE_BEAN, bean);
	}

	/**
	 * リクエストから共通メッセージ画面遷移用ビーンを取得。
	 * <pre>
	 * 共通メッセージ画面遷移用ビーンではない場合はNullを返却する。
	 * </pre>
	 * @return 共通メッセージ画面遷移用ビーン
	 */
	protected MessageBean getMessageBean(){
		MessageBean bean = null;
		Object val = getRequest().getAttribute(UcarApplicationManager.REQ_ATTR_KEY_MESSAGE_BEAN);
		if(val != null && MessageBean.class.isAssignableFrom(val.getClass())){
			bean = MessageBean.class.cast(val);
		}
		return bean;
	}

	/**
	 * イベントを生成。
	 * <pre>
	 * イベントキーに対応するイベントを返却する。
	 * </pre>
	 * @param eventKey イベントキー
	 * @return イベントキーに対応するイベント
	 * @throws HelperBeanException
	 */
	protected Event createEvent(TecEventKeyIF eventKey) throws HelperBeanException {
		return createEvent(eventKey.getApplicationId(), eventKey.getEventKey());
	}

	/**
	 * イベントを生成。
	 * <pre>
	 * イベントキーに対応するイベントを返却する。
	 * </pre>
	 * @param <E>
	 * @param eventKey イベントキー
	 * @param cls 返却するイベントのクラス
	 * @return イベントキーに対応するイベント
	 * @throws HelperBeanException
	 */
	protected <E extends Event> E createEvent(TecEventKeyIF eventKey, Class<E> cls) throws HelperBeanException {
		E targetEvent = null;
		Event event = createEvent(eventKey);
		//新環境構築疎通テストの一時修正 2019-09-01 Modify start
//		if(cls.isAssignableFrom(UcarEvent.class)){
		if(UcarEvent.class.isAssignableFrom(cls)){
		//新環境構築疎通テストの一時修正 2019-09-01 Modify end	
			UcarEvent targetEvent2 = (UcarEvent) event;
			LoginSessionBean se = getLoginSessionBean();
			targetEvent2.setUserInfoBean(se.getUserInfoBean());
			targetEvent = (E) targetEvent2;
		} else if(cls.isAssignableFrom(event.getClass())){
			targetEvent = cls.cast(event);
		} else {
			HelperBeanException e = new HelperBeanException("イベントの型が不正です", new ClassCastException());
			TecLogger.error(e);
			throw e;
		}
		return targetEvent;
	}

	/**
	 * サービス呼び出しURL取得。
	 * @param serviceId サービスID
	 * @return サービス呼び出しURL
	 * @throws HelperBeanException
	 */
	protected String getServiceUrl(TecServiceIdIF serviceId) throws HelperBeanException {
		return getServiceUrl(serviceId.getApplicationId(), serviceId.getServiceId());
	}

	/**
	 * サービス呼び出しURL取得。
	 * @param applicationId アプリケーションID
	 * @param serviceId サービスID
	 * @return サービス呼び出しURL
	 * @throws HelperBeanException
	 */
	protected String getServiceUrl(String applicationId, String serviceId) throws HelperBeanException {
		ServiceManager serviceManager = null;
		String serviceExtension = null;
		String serviceUrl = null;
		try {
			serviceManager = ServiceManager.getServiceManager();
			serviceExtension = serviceManager.getExtesion();
			String tempPath =
				getRequest().getContextPath() + "/" +
				applicationId + ServiceServlet.REQUEST_SEPARATOR + serviceId + "." + serviceExtension;
			serviceUrl = getResponse().encodeURL(tempPath);
		} catch (ServiceManagerException e) {
			throw new HelperBeanException();
		}
		return serviceUrl;
	}

	/**
	 * サービスID取得。
	 * <pre>
	 * リクエストからサービスIDを取得する。
	 * </pre>
	 * @return サービスID
	 */
	protected String getServiceID(){
		return getRequest().getParameter("service");
	}

	/**
	 * アプリケーションID取得。
	 * <pre>
	 * リクエストからアプリケーションIDを取得する。
	 * </pre>
	 * @return アプリケーションID
	 */
	protected String getApplicationID(){
		return getRequest().getParameter("application");
	}

}
