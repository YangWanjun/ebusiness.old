/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecUnsupportedDataTypeException.java
 * 【  説  明  】
 * 【  作  成  】2010/06/18 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import java.util.ArrayList;

import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;


/**
 * <strong>サポート対象外データ型例外クラス。</strong>
 * <p>
 * サポート対象外データ型を操作した場合のシステム例外。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/18 新規作成<br>
 * @since 1.00
 */
public class TecUnsupportedDataTypeException extends TecSystemException {

	private static final long serialVersionUID = -8021500082192995740L;

	/**
	 * コンストラクタ。
	 */
	public TecUnsupportedDataTypeException() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param message
	 */
	public TecUnsupportedDataTypeException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * @param cause
	 */
	public TecUnsupportedDataTypeException(Throwable cause) {
		super(cause);
	}

	/**
	 * コンストラクタ。
	 * @param message
	 * @param cause
	 */
	public TecUnsupportedDataTypeException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 */
	public TecUnsupportedDataTypeException(TecMessageKeyIF messageKey) {
		super(messageKey);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 */
	public TecUnsupportedDataTypeException(TecMessageKeyIF messageKey, ArrayList<Object> args) {
		super(messageKey, args);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param cause
	 */
	public TecUnsupportedDataTypeException(TecMessageKeyIF messageKey, Throwable cause) {
		super(messageKey, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 * @param cause
	 */
	public TecUnsupportedDataTypeException(TecMessageKeyIF messageKey, ArrayList<Object> args, Throwable cause) {
		super(messageKey, args, cause);
	}

}
