package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>登録イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/23 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 管理番号 */
	private String	noKanri;

	/**
	 * noKanriを取得する。
	 * @return noKanri
	 */
	public String getNoKanri() {
		return noKanri;
	}

	/**
	 * noKanriを設定する。
	 * @param noKanri
	 */
	public void setNoKanri(String noKanri) {
		this.noKanri = noKanri;
	}

}
