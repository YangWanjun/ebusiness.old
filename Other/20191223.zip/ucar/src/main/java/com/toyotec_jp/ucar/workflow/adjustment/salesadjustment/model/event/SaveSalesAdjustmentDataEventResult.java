package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>精算イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/25 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SaveSalesAdjustmentDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
