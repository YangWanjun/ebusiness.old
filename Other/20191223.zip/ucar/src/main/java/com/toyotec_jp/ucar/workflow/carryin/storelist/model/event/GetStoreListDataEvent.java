package com.toyotec_jp.ucar.workflow.carryin.storelist.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListDataBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListParamBean;

/**
 * <strong>展示店舗受取処理情報取得イベント</strong>
 * <p>
 * </p>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/27 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class GetStoreListDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	
	/** ソート順(asc/desc) */
	private String sortOrder;
	/** ソートキー */
	private String sortParam;
	/** ページ番号 */
	private String pageNo;
	/** ページサイズ */
	private String pageSize;

	/** 展示店舗受取処理 検索条件Bean */
	private StoreListParamBean storeListParamBean;
	/** 展示店舗受取処理 画面出力値Bean */
	private StoreListDataBean storeListDataBean;

	/** 初期表示か検索処理かの判定フラグ
	 * <pre>
	 * true:初期表示
	 * false:検索処理
	 * </pre>
	 */
	private boolean isInit;


	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn 販売店コード
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn 販売店コード
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * sortOrderを取得する。
	 * @return sortOrder ソート順
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * sortOrderを設定する。
	 * @param sortOrder ソート順
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * sortParamを取得する。
	 * @return sortParam ソートキー
	 */
	public String getSortParam() {
		return sortParam;
	}

	/**
	 * sortParamを設定する。
	 * @param sortParam ソートキー
	 */
	public void setSortParam(String sortParam) {
		this.sortParam = sortParam;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo ページ番号
	 */
	public String getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @param pageNo ページ番号
	 */
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize 一覧の最大表示件数
	 */
	public String getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize 一覧の最大表示件数
	 */
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * storeListParamBeanを取得する。
	 * @return storeListParamBean 展示店舗受取処理 検索条件Bean
	 */
	public StoreListParamBean getStoreListParamBean() {
		return storeListParamBean;
	}

	/**
	 * storeListParamBeanを設定する。
	 * @param storeListParamBean 展示店舗受取処理 検索条件Bean
	 */
	public void setStoreListParamBean(StoreListParamBean storeListParamBean) {
		this.storeListParamBean = storeListParamBean;
	}

	/**
	 * storeListDataBeanを取得する。
	 * @return storeListDataBean 展示店舗受取処理 画面出力値Bean
	 */
	public StoreListDataBean getStoreListDataBean() {
		return storeListDataBean;
	}

	/**
	 * storeListDataBeanを設定する。
	 * @param storeListDataBean 展示店舗受取処理 画面出力値Bean
	 */
	public void setStoreListDataBean(StoreListDataBean storeListDataBean) {
		this.storeListDataBean = storeListDataBean;
	}

	/**
	 * isInitを取得する。
	 * @return isInit 初期表示か検索処理かの判定フラグ
	 */
	public boolean isInit() {
		return isInit;
	}

	/**
	 * isInitを設定する。
	 * @param isInit 初期表示か検索処理かの判定フラグ
	 */
	public void setInit(boolean isInit) {
		this.isInit = isInit;
	}

}
