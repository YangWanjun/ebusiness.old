package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.util.ArrayList;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.exception.TecDAOException;


/**
 * <strong>書式操作DAOインターフェース。</strong>
 * <p>
 * 書式に関するテーブル操作用共通DAOインターフェース。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/12 新規作成<br>
 * @since 1.00
 */
public interface DocFormatDAOIF {

	/**
	 * 書式定義情報を取得。
	 * @param docFormatId 書式ID
	 * @return 書式定義情報
	 * @throws TecDAOException
	 */
	public ArrayList<DMFilesMapData> getDocFormatDefineList(String docFormatId) throws TecDAOException;

	/**
	 * 書式出力種別を取得。
	 * @param docFormatId 書式ID
	 * @return 出力種別
	 * @throws TecDAOException
	 */
	public String getDocOutputType(String docFormatId) throws TecDAOException;

}
