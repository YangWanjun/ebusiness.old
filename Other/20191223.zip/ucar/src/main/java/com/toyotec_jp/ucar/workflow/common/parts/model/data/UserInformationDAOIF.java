package com.toyotec_jp.ucar.workflow.common.parts.model.data;


import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>ユーザ関連情報操作DAOインターフェース。</strong>
 * <p>
 * ユーザ情報に関するテーブル操作用共通DAOインターフェース。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/07 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface UserInformationDAOIF {

	/**
	 * ユーザ情報を取得。
	 * @param employeeCd 社員コード
	 * @return ユーザ情報ビーン
	 */
	public UserInformationBean getUserInformation(String employeeCd) throws TecDAOException;
}
