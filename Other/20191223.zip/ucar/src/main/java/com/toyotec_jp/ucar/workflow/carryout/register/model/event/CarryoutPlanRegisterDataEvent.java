package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;

/**
 * <strong>搬出予定車両登録イベント</strong>
 * @author 00496_990215
 * @version 1.00 2014/08/11 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutPlanRegisterDataEvent extends UcarEvent {

	private static final long serialVersionUID = 1710014134596097871L;
	
	/** 車両搬入情報Bean */
	private Ucaa001gBean t220001gBean;	
	/** ステータスDBBean */
	private Ucab007gBean t220012gBean;	
	/** 車両搬出情報：データ更新日時(排他チェック用) */
	private String t220001gDtKosin;
	
	/**
	 * t220001gBeanを取得する。
	 * @return t220013gBean
	 */
	public Ucaa001gBean getUcaa001gBean() {
		return t220001gBean;
	}
	
	
	/**
	 * t220001gBeanを設定する。
	 * @param t220013gBean
	 */
	public void setUcaa001gBean(Ucaa001gBean t220001gBean) {
		this.t220001gBean = t220001gBean;
	}
	
	/**
	 * t220012gBeanを取得する。
	 * @return t220013gBean
	 */
	public Ucab007gBean getUcab007gBean() {
		return t220012gBean;
	}
	
	/**
	 * t220012gBeanを設定する。
	 * @param t220013gBean
	 */
	public void setUcab007gBean(Ucab007gBean t220012gBean) {
		this.t220012gBean = t220012gBean;
	}
	
	/**
	 * t220001gDtKosiを取得する。
	 * @return t220013gBean
	 */
	public String getUcaa001gDtKosin() {
		return t220001gDtKosin;
	}
	
	/**
	 * t220001gDtKosinを設定する。
	 * @param t220001gDtKosin
	 */
	public void setUcaa001gDtKosin(String t220001gDtKosin) {
		this.t220001gDtKosin = t220001gDtKosin;
	}

}
