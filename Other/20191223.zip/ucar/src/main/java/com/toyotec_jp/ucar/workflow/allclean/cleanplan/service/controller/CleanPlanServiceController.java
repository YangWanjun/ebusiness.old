package com.toyotec_jp.ucar.workflow.allclean.cleanplan.service.controller;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanSessionBean;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanConst.AllCleanServiceId;

/**
 * <strong>まるクリ作業計画入力サービスコントローラ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/17 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public class CleanPlanServiceController extends UcarServiceController {

	/** サービスID */
	private String serviceId = "";
	/** まるクリ関連サービスID */
	private AllCleanServiceId targetServiceId = null;
	/** まるクリセッションBean */
	private AllCleanSessionBean allCleanSessionBean;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {
		TecLogger.trace("service start");
		// セッション設定
		setupSession();
		// サービス個別処理
		executeServiceProcess();
		TecLogger.trace("service end");
		return null;
	}

	/** セッション設定 */
	private void setupSession() throws TecSystemException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = AllCleanServiceId.getTargetAllCleanServiceId(serviceId);
		String menuId = getMenuId();

		TecLogger.debug("serviceId[" + serviceId + "]menuId[" + menuId + "]");

		// サービスごとの処理
		if(targetServiceId != null){
			switch (targetServiceId) {
				case CLEANPLAN_INIT:
					// 初期処理

					// セッションのクリア
					clearAllApplicationSession();
					// 新規セッション取得
					allCleanSessionBean = getNewApplicationSessionBean(AllCleanSessionBean.class);

//					// 会社コード
//					allCleanSessionBean.getT220001gPkBean().setCdKaisya(UcarConst.CD_KAISYA);
//					// 販売店コード
//					allCleanSessionBean.getT220001gPkBean().setCdHanbaitn(UcarConst.CD_HANBAITN);
					break;
				default:
					break;
			}
			allCleanSessionBean.setServiceId(serviceId);
		}
		TecLogger.trace("setupSession end");
	}

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException, ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if(targetServiceId != null){
			switch (targetServiceId) {
				default:
					break;
			}
		}
		TecLogger.trace("executeServiceProcess end");
	}
}
