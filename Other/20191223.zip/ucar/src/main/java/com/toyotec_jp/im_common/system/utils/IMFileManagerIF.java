/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】IMFileManagerIF.java
 * 【  説  明  】
 * 【  作  成  】2010/07/23 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import com.toyotec_jp.im_common.system.exception.TecFileMngException;

/**
 * <strong>IMファイル操作インターフェース。</strong>
 * <p>
 * IMのストレージサービス、AppRuntime上のファイル操作用インターフェース。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/23 新規作成<br>
 * @since 1.00
 */
public interface IMFileManagerIF {

	/**
	 * ファイル保存
	 * @param path パス
	 * @param byteStream 保存バイト配列
	 * @param doOverWrite true:上書き
	 * @throws TecFileMngException
	 */
	public void saveFile(String path, byte[] byteStream, boolean doOverWrite) throws TecFileMngException;

	/**
	 * ファイル読込。
	 * @param path パス
	 * @return 読込バイト配列
	 * @throws TecFileMngException
	 */
	public byte[] loadFile(String path) throws TecFileMngException;

	/**
	 * ファイル削除。
	 * @param path パス
	 * @throws TecFileMngException
	 */
	public void deleteFile(String path) throws TecFileMngException;

	/**
	 * ファイルサイズ取得。
	 * @param path パス
	 * @return ファイルサイズ
	 * @throws TecFileMngException
	 */
	public long getFileByteLength(String path) throws TecFileMngException;

}
