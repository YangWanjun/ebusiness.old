/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】ZipUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/09/15 S.K(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import jp.co.intra_mart.framework.system.exception.SystemException;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;

import com.toyotec_jp.im_common.system.exception.TecSystemException;

/**
 * <strong>ZIPユーティリティクラス。</strong>
 * <p>
 * ZIP関連支援処理を管理するクラス
 *
 * @author S.K(SCC)
 * @version 1.00 2010/09/15 新規作成<br>
 */
public class ZipUtils {

	/** 圧縮対象ディレクトリリスト */
	private ArrayList<String> targetPathList;

	/** ZIPファイル名 */
	private String zipFilePath;

	/** 相対パス用基準ディレクトリ*/
	private String targetBaseDirectory;

	/**
	 * コンストラクタ
	 * @param zipFilePath　ZIPファイル名
	 */
	public ZipUtils(String zipFilePath){

		/** ディレクトリリスト初期化 */
		this.targetPathList = new ArrayList<String>();
		this.targetPathList.clear();
		this.targetBaseDirectory = "";

		this.zipFilePath = zipFilePath;
	}

	/**
	 * 圧縮対象ディレクトリを追加
	 * @param targetPath 圧縮ディレクトリ名
	 * @throws SystemException
	 */
	public void addTargetDirectory(String targetPath) throws SystemException{
		this.targetPathList.add(targetPath);
	}

	/**
	 * 圧縮対象ファイルを追加
	 * @param targetPath 圧縮ディレクトリ名
	 * @throws SystemException
	 */
	public void addTargetFile(String targetPath) throws SystemException{
		this.targetPathList.add(targetPath);
	}

	/**
	 * 圧縮処理
	 * @throws SystemException
	 */
	public void pack() throws SystemException{

		// OS毎のディレクトリ区切りを取得
		String directorySeparator = "/";
		String osName = System.getProperty("os.name");
		if( "Windows".equalsIgnoreCase(osName)){
			directorySeparator = "\\";
		}

		// 対象ディレクトリの取得
		//ArrayList<File> fileList = new ArrayList<File>();
		File[] fileList = new File[this.targetPathList.size()];
		for( int i = 0; i < this.targetPathList.size(); i++){
			if(this.targetBaseDirectory != null && !"".equals(this.targetBaseDirectory)){
				// 基準ディレクトリ指定
				File baseDirectoryFile = new File(this.targetBaseDirectory);
				File targetFile = new File(this.targetPathList.get(i));
				// 相対か絶対パスかをチェック
				if(! targetFile.isAbsolute()){
					// 相対パス
					fileList[i] = new File(baseDirectoryFile.getPath() +
							  directorySeparator +
							  this.targetPathList.get(i));
				}else{
					// 絶対パス
					fileList[i] = targetFile;
				}
			}else{
				// 基準ディレクトリ未指定
				fileList[i] = new File(this.targetPathList.get(i));
			}
		}

		ZipOutputStream zos;
		try {
			zos = new ZipOutputStream(new FileOutputStream(this.zipFilePath));
		} catch (FileNotFoundException e) {
			throw new TecSystemException(e);
		}

		zos.setEncoding("MS932");
		zos.setUseLanguageEncodingFlag(true);

		try {
			if(this.targetBaseDirectory != null && ! "".equals(this.targetBaseDirectory)){
				zipprocess(zos, new File(this.targetBaseDirectory), fileList);
			}else{
				zipprocess(zos, null, fileList);
			}
		} catch (Exception e) {
			throw new TecSystemException(e);
		} finally {
			try {
				zos.close();
			} catch (IOException e) {
			}
		}
	}

	/**
	 * ZIP追加処理
	 * @param zos ZipOutputStream
	 * @param targetBaseDirectory 基準ディレクトリ
	 * @param files FILE リスト
	 * @throws Exception
	 */
	private static  void zipprocess(ZipOutputStream zos,File targetBaseDirectory, File[] files) throws Exception {
		byte[] buf = new byte[1024];
		String relativeTargetPath;	// 圧縮対象相対パス
		String absoluteTargetPath;	// 圧縮対象絶対パス
		String absoluteBasePath;	// 基準絶対パス

		for (File f : files) {
			if (f.isDirectory()) {
				zipprocess(zos, targetBaseDirectory, f.listFiles());
			} else {
				// 圧縮対象相対パスを取得
				if(targetBaseDirectory != null){
					// 基準絶対パスを取得（必ずディレクトリ指定）
					absoluteBasePath = targetBaseDirectory.getPath().replace('\\', '/') + "/";
					// 圧縮対象絶対パスを取得
					absoluteTargetPath = f.getPath().replace('\\', '/');

					// 圧縮対象絶対パスより、基準絶対パスをカット
					relativeTargetPath = absoluteTargetPath.replace(absoluteBasePath,"");
					// 基準ディレクトリパスがカットされていいない場合は、個別ファイルとみなす
					if(relativeTargetPath != null && relativeTargetPath.equals(absoluteTargetPath)){
						// ルートに配置
						relativeTargetPath = "/" + f.getName();
					}
				}else{
					// 相対パス未指定の場合
					relativeTargetPath = "/" + f.getName();
				}
				// 先頭がスラッシュであればカット
				if(relativeTargetPath.length() > 0 && "/".equals(relativeTargetPath.substring(0,1))){
					relativeTargetPath = relativeTargetPath.substring(1,relativeTargetPath.length());
				}

				ZipEntry ze = new ZipEntry(relativeTargetPath);
				zos.putNextEntry(ze);
				InputStream is = new BufferedInputStream(new FileInputStream(f));
				for (;;) {
					int len = is.read(buf);
					if (len < 0) break;
					zos.write(buf, 0, len);
				}
				is.close();
			}
		}
	}

	/**
	 * 基準ディレクトリ名を返却します
	 * @param 基準ディレクトリ名
	 */
	public void setTargetBaseDirectory(String targetBaseDirectory) {
		this.targetBaseDirectory = targetBaseDirectory;
	}
}
