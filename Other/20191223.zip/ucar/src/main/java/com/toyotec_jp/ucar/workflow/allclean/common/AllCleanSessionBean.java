package com.toyotec_jp.ucar.workflow.allclean.common;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;

/**
 * <strong>まるクリセッションBean。</strong>
 * <p>
 * セッションに格納するまるクリパッケージ共通セッションBean。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/17 新規作成<br>
 * @since 1.00
 * @category [[まるクリ(共通)]]
 */
public class AllCleanSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** サービスID */
	private String serviceId;
	/** メニューID */
	private String menuId;

	/**
	 * デフォルトコンストラクタ。
	 */
	public AllCleanSessionBean() {
		setDefaultParams();
	}

	/**
	 * デフォルトパラメータ設定。
	 * <pre>
	 * メニューID以外のパラメータ初期化。
	 * </pre>
	 */
	public void setDefaultParams(){
	}

	/**
	 * serviceIdを取得する。
	 * @return serviceId サービスID
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * serviceIdを設定する。
	 * @param serviceId サービスID
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * menuIdを取得する。
	 * @return menuId メニューID
	 */
	public String getMenuId() {
		return menuId;
	}

	/**
	 * menuIdを設定する。
	 * @param menuId メニューID
	 */
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

}
