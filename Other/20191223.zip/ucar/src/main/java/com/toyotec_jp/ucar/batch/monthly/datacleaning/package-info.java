/**
 * データ削除関連パッケージ
 * @version 1.00 2012/02/01 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.batch.monthly.datacleaning;
