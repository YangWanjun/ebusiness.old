/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】StringUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/05/06 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <strong>文字列系ユーティリティクラス。</strong>
 * <p>
 * 文字列関連支援処理を管理するクラス
 *
 * @author H.O(SCC)
 * @version 1.00 2010/05/17 新規作成<br>
 */
public class StringUtils {

	/** 文字コード */
	public static enum CharSet {
		/** ISO-8859-1 */
		ISO_8859_1("ISO-8859-1"),
		/** Windows-31J */
		WINDOWS_31J("Windows-31J"),
		/** Shift_JIS */
		SHIFT_JIS("Shift_JIS"),
		/** UTF-8 */
		UTF8("UTF-8");
		private String charSetName;
		private CharSet(String charSetName){
			this.charSetName = charSetName;
		}
		public String toString(){
			return charSetName;
		}
	}

	/** MessageDigest用アルゴリズム名 */
	public static enum MDAlgorithm {
		/** MD2 メッセージダイジェストアルゴリズム */
		@Deprecated
		MD2("MD2"),
		/** MD5 メッセージダイジェストアルゴリズム */
		MD5("MD5"),
		/** SHA-1 Hashアルゴリズム */
		SHA1("SHA-1"),
		/** SHA-256 Hashアルゴリズム */
		SHA256("SHA-256"),
		/** SHA-384 Hashアルゴリズム */
		SHA384("SHA-384"),
		/** SHA-512 Hashアルゴリズム */
		SHA512("SHA-512");
		private String algName;
		private MDAlgorithm(String algName){
			this.algName = algName;
		}
		public String toString(){
			return algName;
		}
	}

	/** エスケープ種別 */
	private static enum EscapeType {
		/** HTML */
		HTML,
		/** JavaScript */
		JS,
		/** Database */
		DB;
	}

	/** デフォルトコンストラクタ(インスタンス化不可) */
	private StringUtils(){
	}

	/**
	 * デフォルト文字設定関数。
	 * <pre>
	 * 対象文字列がnullの場合、空文字に変換する。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String defaultValue(String target) {
		return defaultValue(target, "");
	}

	/**
	 * デフォルト文字設定関数。
	 * <pre>
	 * 対象文字列がnull/空文字の場合にデフォルト文字列に変換する。
	 * </pre>
	 * @param target 対象文字列
	 * @param defaultString デフォルト文字列
	 * @return 結果文字列
	 */
	public static String defaultValue(String target, String defaultString) {
		if (StringCheckUtils.isEmpty(target)) {
			return defaultString;
		} else {
			return target;
		}
	}

	/**
	 * デフォルト文字設定関数
	 * <pre>
	 * 対象文字列がnull/空文字の場合にデフォルト文字列1に
	 * それ以外はデフォルト文字列2に変換する
	 * </pre>
	 * @param target 対象文字列
	 * @param defaultString1 対象がnull/空文字の場合返却する文字列
	 * @param defaultString2 対象がnull/空文字ではない場合返却する文字列
	 * @return 結果文字列
	 */
	public static String defaultValue(String target, String defaultString1, String defaultString2) {
		if (StringCheckUtils.isEmpty(target)) {
			return defaultString1;
		} else {
			return defaultString2;
		}
	}

	/**
	 * 右スペース除去関数。
	 * <pre>
	 * 対象文字列の後方に存在する半角、全角スペースを除去する。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String trimRight(String target){
		return trimRight(target, true);
	}

	/**
	 * 右スペース除去関数。
	 * <pre>
	 * 対象文字列の後方に存在するスペースを除去する。
	 * </pre>
	 * @param target 対象文字列
	 * @param isTrimMultiByteSpace true:全角スペースも除去対象とする false:半角スペースのみ除去対象とする
	 * @return 結果文字列
	 */
	public static String trimRight(String target, boolean isTrimMultiByteSpace){
		if (target == null || target.length() == 0) {
			return target;
		}
		String trimChars = " ";
		if (isTrimMultiByteSpace) {
			trimChars = trimChars + "　";
		}
		Pattern pat = Pattern.compile("[" + trimChars + "]*$");
		return pat.matcher(target).replaceFirst("");
	}

	/**
	 * 左スペース除去関数。
	 * <pre>
	 * 対象文字列の前方に存在する半角、全角スペースを除去する。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String trimLeft(String target){
		return trimLeft(target, true);
	}

	/**
	 * 左スペース除去関数。
	 * <pre>
	 * 対象文字列の前方に存在するスペースを除去する。
	 * </pre>
	 * @param target 対象文字列
	 * @param isTrimMultiByteSpace true:全角スペースも除去対象とする false:半角スペースのみ除去対象とする
	 * @return 結果文字列
	 */
	public static String trimLeft(String target, boolean isTrimMultiByteSpace){
		if(target == null || target.length() == 0){
			return target;
		}
		String trimChars = " ";
		if(isTrimMultiByteSpace){
			trimChars = trimChars + "　";
		}
		Pattern pat = Pattern.compile("^[" + trimChars + "]*");
		return pat.matcher(target).replaceFirst("");
	}

	/**
	 * 左右スペース除去関数。
	 * <pre>
	 * 対象文字列の前後に存在する半角、全角スペースを除去する。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String trim(String target){
		return trim(target, true);
	}

	/**
	 * 左右スペース除去関数。
	 * <pre>
	 * 対象文字列の前後に存在するスペースを除去する。
	 * </pre>
	 * @param target 対象文字列
	 * @param isTrimMultiByteSpace true:全角スペースも除去対象とする false:半角スペースのみ除去対象とする
	 * @return 結果文字列
	 */
	public static String trim(String target, boolean isTrimMultiByteSpace){
		return trimLeft(trimRight(target, isTrimMultiByteSpace), isTrimMultiByteSpace);
	}

	/**
	 * 右文字埋め関数。
	 * <pre>
	 * padCharを対象文字列の後方に埋める。<br>
	 * lenが0以下、対象文字列の長さがlen以上である場合、対象文字列をそのまま返却する。<br>
	 * バイト数ではなく文字数(ただし、3byte、4byte文字は2文字として扱うため注意)で処理。
	 * </pre>
	 * @param target 対象文字列
	 * @param padChar 埋める文字
	 * @param len 目標とする文字列長
	 * @return 結果文字列
	 */
	public static String padRight(String target, char padChar, int len){
		int setLen = 0;
		if(len > 0){
			setLen = len * -1;
		}
		return padding(target, padChar, setLen);
	}

	/**
	 * 左文字埋め関数。
	 * <pre>
	 * padCharを対象文字列の前方に埋める。<br>
	 * lenが0以下、対象文字列の長さがlen以上である場合、対象文字列をそのまま返却する。<br>
	 * バイト数ではなく文字数(ただし、3byte、4byte文字は2文字として扱うため注意)で処理。
	 * </pre>
	 * @param target 対象文字列
	 * @param padChar 埋める文字
	 * @param len 目標とする文字列長
	 * @return 結果文字列
	 */
	public static String padLeft(String target, char padChar, int len){
		int setLen = 0;
		if(len > 0){
			setLen = len;
		}
		return padding(target, padChar, setLen);
	}

	/** パディング処理 */
	private static String padding(String target, char padChar, int len){
		StringBuffer buf = new StringBuffer("");
		int targetLen = 0;
		int padLen = 0;
		if(target != null){
			targetLen = target.length();
		}
		padLen = Math.abs(len) - targetLen;
		// 指定文字数よりも対象文字数が長い、または指定文字数が0の場合は対象文字を返却
		if(padLen <= 0 || len == 0){
			return target;
		}
		for(int i = 0; i < padLen; i++){
			buf.append(padChar);
		}
		if(len > 0){
			buf.append(defaultValue(target,""));
		} else {
			buf.insert(0, defaultValue(target,""));
		}
		return new String(buf);
	}

	/**
	 * 文字数取得関数。
	 * <pre>
	 * サロゲートペアを考慮した文字数（コードポイントの個数）を数える。
	 * </pre>
	 * @param target 対象文字列
	 * @return 対象文字列の長さ
	 */
	public static int lengthOfCodePointBase(String target){
		if(StringCheckUtils.isEmpty(target)){
			return 0;
		}
		return target.codePointCount(0, target.length());
	}

	/**
	 * 指定文字列抽出関数。
	 * <pre>
	 * サロゲートペアを考慮した指定文字列を抽出する。
	 * </pre>
	 * @param target 対象文字列
	 * @param beginIndex 開始インデックス(この値を含む)
	 * @return 結果文字列
	 */
	public static String subStringOfCodePointBase(String target, int beginIndex) {
		return subStringOfCodePointBase(target, beginIndex, lengthOfCodePointBase(target));
	}

	/**
	 * 指定文字列抽出関数。
	 * <pre>
	 * サロゲートペアを考慮した指定文字列を抽出する。
	 * </pre>
	 * @param target 対象文字列
	 * @param beginIndex 開始インデックス(この値を含む)
	 * @param endIndex 終了インデックス(この値を含まない)
	 * @return 結果文字列
	 */
	public static String subStringOfCodePointBase(String target, int beginIndex, int endIndex) {
		if(StringCheckUtils.isEmpty(target)){
			return target;
		}
		int cpLen = lengthOfCodePointBase(target);
		int charLen = target.length();
		if(beginIndex < 0){
			throw new StringIndexOutOfBoundsException(beginIndex);
		}
		if(endIndex > cpLen){
			throw new StringIndexOutOfBoundsException(endIndex);
		}
		if(beginIndex > endIndex){
			throw new StringIndexOutOfBoundsException(endIndex - beginIndex);
		}
		if(beginIndex == 0 && endIndex == cpLen){
			return target;
		}
		int beginCharIdx = 0;
		int endCharIdx = 0;
		for(int charIdx = 0, cpIdx = 0; charIdx <= charLen; charIdx++, cpIdx++){
			if(cpIdx == beginIndex){
				beginCharIdx = charIdx;
				if(beginIndex == endIndex){
					endCharIdx = charIdx;
					break;
				}
				if(endIndex == cpLen){
					endCharIdx = charLen;
					break;
				}
			}
			if(cpIdx == endIndex){
				endCharIdx = charIdx;
				break;
			}
			if(Character.isHighSurrogate(target.charAt(charIdx))){
				if(charIdx + 1 < charLen && Character.isLowSurrogate(target.charAt(charIdx + 1))){
					charIdx++;
				}
			}
		}
		return target.substring(beginCharIdx, endCharIdx);
	}

	/**
	 * 結合関数。
	 * <pre>
	 * 配列の要素を文字列として結合し返却する。
	 * </pre>
	 * @param array 結合対象配列
	 * @return 結合した結果文字列
	 */
	public static String join(Object[] array) {
		return join(array, null);
	}

	/**
	 * 結合関数。
	 * <pre>
	 * 配列の要素を文字列として結合し返却する。<br>
	 * 各要素は指定したセパレータで区切る。
	 * </pre>
	 * @param array 結合対象配列
	 * @param separator セパレータ
	 * @return 結合した結果文字列
	 */
	public static String join(Object[] array, String separator) {
		if (array == null) {
			return null;
		}
		return join(array, separator, 0, array.length);
	}

	// 配列JOINの実装
	private static String join(Object[] array, String separator, int startIndex, int endIndex) {
		if (array == null) {
			return null;
		}
		if (separator == null) {
			separator = "";
		}
		int bufSize = (endIndex - startIndex);
		if (bufSize <= 0) {
			return "";
		}
		bufSize *= ((array[startIndex] == null ? 16 : array[startIndex].toString().length())
				+ separator.length());
		StringBuilder buf = new StringBuilder(bufSize);
		for (int i = startIndex; i < endIndex; i++) {
			if (i > startIndex) {
				buf.append(separator);
			}
			if (array[i] != null) {
				buf.append(array[i]);
			}
		}
		return buf.toString();
	}

	/**
	 * 結合関数。
	 * <pre>
	 * コレクションの要素を文字列として結合し返却する。
	 * </pre>
	 * @param collection 結合対象コレクション
	 * @return 結合した結果文字列
	 */
	public static String join(Collection<?> collection) {
		if (collection == null) {
			return null;
		}
		return join(collection.iterator(), null);
	}

	/**
	 * 結合関数。
	 * <pre>
	 * コレクションの要素を文字列として結合し返却する。<br>
	 * 各要素は指定したセパレータで区切る。
	 * </pre>
	 * @param collection 結合対象コレクション
	 * @param separator セパレータ
	 * @return 結合した結果文字列
	 */
	public static String join(Collection<?> collection, String separator) {
		if (collection == null) {
			return null;
		}
		return join(collection.iterator(), separator);
	}

	// コレクションJOINの実装
	private static String join(Iterator<?> iterator, String separator) {
		if (iterator == null) {
			return null;
		}
		if (!iterator.hasNext()) {
			return "";
		}
		Object first = iterator.next();
		if (!iterator.hasNext()) {
			if(first == null){
				return "";
			} else {
				return first.toString();
			}
		}
		StringBuilder buf = new StringBuilder(256);
		if (first != null) {
			buf.append(first);
		}
		while (iterator.hasNext()) {
			if (separator != null) {
				buf.append(separator);
			}
			Object obj = iterator.next();
			if (obj != null) {
				buf.append(obj);
			}
		}
		return buf.toString();
	}

	/**
	 * 文字コード変換関数。
	 * <pre>
	 * 対象文字列の文字コードを変換する。
	 * </pre>
	 * @param target 対象文字列
	 * @param fromCharset 変換前文字コード
	 * @param toCharset 変換文字コード
	 * @return 結果文字列
	 * @see CharSet
	 */
	public static String encode(String target, CharSet fromCharset, CharSet toCharset) {
		return encode(target, fromCharset.toString(), toCharset.toString());
	}

	/**
	 * 文字コード変換関数。
	 * <pre>
	 * 対象文字列の文字コードを変換する。
	 * </pre>
	 * @param target 対象文字列
	 * @param fromCharset 変換前文字コード
	 * @param toCharset 変換文字コード
	 * @return 結果文字列
	 */
	public static String encode(String target, String fromCharset, String toCharset) {
		String result = "";
		try {
			if (target != null) {
				result = new String(target.getBytes(fromCharset), toCharset);
			}
		} catch (UnsupportedEncodingException e) {
		}
		return result;
	}

	/**
	 * カンマ補完関数。
	 * <pre>
	 * 対象文字列にカンマを補完する。<br>
	 * 3桁カンマ区切り(マイナス符号付、小数点可能)(金額、数量等)。
	 * </pre>
	 * @param  strTarget 対象文字列
	 * @return カンマ補完後の文字列引数の文字列がnull、空文字、数値でない場合、編集は行わずそのまま返す
	 */
	public static String supplementOfComma(String strTarget) {
		int idx = 0;
		String decimalStr = null;
		String strResult = "";
		DecimalFormat dfFormat = null;
		BigDecimal bdNumber = null;
		try {
			if (! StringCheckUtils.isEmpty(strTarget)) {
				dfFormat = new DecimalFormat("#,##0");
				bdNumber = new BigDecimal(strTarget);
				//小数点チェック
				idx = strTarget.indexOf(".");
				if ( idx != -1 ) {
					decimalStr = subStringOfCodePointBase(strTarget, idx, strTarget.length());
				}
				strResult = dfFormat.format(bdNumber.longValue());

				if (bdNumber.signum() == -1 && strResult.equals("0")) {
					strResult = "-" + strResult;
				}
				if (decimalStr != null) {
					strResult = strResult + decimalStr;
				}
			} else {
				strResult = strTarget;
			}
		} catch(NumberFormatException e) {
			strResult = strTarget;
		}
		return strResult;
	}

	/**
	 * HTML表示用エスケープ関数。
	 * <pre>
	 * 変換対象は「&」、「<」、「>」、「"」、「'」、「 」(半角スペース)、改行。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String escapeForHtmlBrowse(String target){
		return escape(target, EscapeType.HTML, false, false);
	}

	/**
	 * HTMLの値(INPUTタグvalue属性等)用エスケープ関数。
	 * <pre>
	 * 変換対象は「&」、「<」、「>」、「"」、「'」。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String escapeForHtmlValue(String target){
		return escape(target, EscapeType.HTML, true, false);
	}

	/**
	 * HTMLのタグ属性内JavaScript関数呼び出し時引数用エスケープ関数。
	 * <pre>
	 * onClickイベント等のJavaScript関数呼び出し時に使用する引数<br>
	 * (「onClick="sampleFnc('xxx')"」の「xxx」部分)<br>
	 * をエスケープする場合に使用する。<br>
	 * 変換対象は「&」、「<」、「>」、「"」、「'」、「\」、改行。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String escapeForHtmlJavaScriptArg(String target){
		return escape(target, EscapeType.HTML, true, true);
	}

	/**
	 * JavaScript文字列用エスケープ関数。
	 * <pre>
	 * 変換対象は「"」、「'」。
	 * </pre>
	 * @param target 対象文字列
	 * @return 結果文字列
	 */
	public static String escapeForJavaScript(String target){
		return escape(target, EscapeType.JS, false, false);
	}

	/** エスケープ処理 */
	private static String escape(String target, EscapeType type, boolean isValue, boolean isJsArg) {
		String result = "";
		target = defaultValue(target, "");
		if (target.length() > 0) {
			result = target;
			switch (type) {
				// HTML用
				case HTML:
					result = result.replaceAll("&", "&amp;");
					result = result.replaceAll("<", "&lt;");
					result = result.replaceAll(">", "&gt;");
					result = result.replaceAll("\"", "&quot;");
					if(isJsArg){
						// 「\」→「\\」、「'」→「\'」、「\r」→「\r(文字)」、「\n」→「\n(文字)」
						result = result.replaceAll("\\\\", "\\\\\\\\");
						result = result.replaceAll("'", "\\\\\'");
						result = result.replaceAll("\\r", "\\\\r");
						result = result.replaceAll("\\n", "\\\\n");
					} else {
						result = result.replaceAll("'", "&#039;");
						// HTMLタグvalue属性用
						if(!isValue){
							result = result.replaceAll(" ", "&nbsp;");
							result = result.replaceAll("\\r\\n", "<BR>");
							result = result.replaceAll("\\r|\\n", "<BR>");
						}
					}
					break;
				// JavaScript文字列用
				case JS:
					result = result.replaceAll("\"", "\\\\\"");
					result = result.replaceAll("'", "\\\\\'");
					break;
				case DB:
					break;
				default:
					break;
			}
		}
		return result;
	}

	/**
	 * フィールド・カラム名変換関数。
	 * <p>
	 * Javaのネーミングルールに基づいた名称をHTML、
	 * DBのネーミングルールに基づいた名称に変換する。<br>
	 * 例:
	 * <blockquote><pre>
	 * 「abCdeFg」→「ab_cde_fg」
	 * </pre></blockquote>
	 * </p>
	 * @param fieldName フィールド名
	 * @return 結果文字列
	 */
	public static String convFieldToColumnName(String fieldName) {
		//final String STR_REGEXP_FIELD_NAME_FRAGMENT = "^[A-Z]?[^A-Z]*";
		StringBuilder sb = new StringBuilder();
//		fieldName = defaultValue(fieldName, "");
//		if (fieldName.length() > 0) {
//			String work = fieldName;
//			Pattern ptnFieldNameFragment = Pattern.compile(STR_REGEXP_FIELD_NAME_FRAGMENT);
//			Matcher matcher = null;
//			while(work.length() != 0) {
//				matcher = ptnFieldNameFragment.matcher(work);
//				while (matcher.find()) {
//					if (sb.length() > 0) {
//						sb.append("_");
//					}
//					sb.append(matcher.group().toLowerCase());
//					work = matcher.replaceAll("");
//				}
//			}
//		}
		if(fieldName != null && fieldName.length() > 0){
			char[] cList = fieldName.toCharArray();
			int size = cList.length;
			for(int i = 0; i < size; i++){
				if(Character.isUpperCase(cList[i])){
					sb.append('_');
				}
				sb.append(Character.toLowerCase(cList[i]));
			}
		}
		return new String(sb);
	}

	/**
	 * カラム・フィールド名変換関数。
	 * <p>
	 * HTML、DBのネーミングルールに基づいた名称を
	 * Javaのネーミングルールに基づいた名称に変換する。<br>
	 * 例:
	 * <blockquote><pre>
	 * 「ab_cde_fg」→「abCdeFg」
	 * </pre></blockquote>
	 * </p>
	 * @param columnName カラム名
	 * @return 結果文字列
	 */
	public static String convColumnToFieldName(String columnName) {
		StringBuilder sb = new StringBuilder();
		if(columnName != null && columnName.length() > 0){
			char[] cList = columnName.toCharArray();
			int size = cList.length;
			boolean isSep = false;
			for(int i = 0; i < size; i++){
				if(cList[i] == '_'){
					isSep = true;
				} else {
					if(isSep){
						sb.append(Character.toUpperCase(cList[i]));
						isSep = false;
					} else {
						sb.append(Character.toLowerCase(cList[i]));
					}
				}
			}
		}
		return new String(sb);
	}

	/**
	 * 文字列暗号化関数。
	 * <pre>
	 * 対象文字列を暗号化する。
	 * </pre>
	 * @param target 対象文字列
	 * @param algorithmName MessageDigest用アルゴリズム名
	 * @return 暗号化文字列
	 */
	public static String convStringToCipher(String target, String algorithmName){
		String result = "";
		algorithmName = defaultValue(algorithmName, "");
		target = defaultValue(target, "");

		try{
			if(target.length() > 0 && algorithmName.length() > 0){
				// アルゴリズムの指定
				MessageDigest md = MessageDigest.getInstance(algorithmName);

				md.update(target.getBytes());

				// 指定したアルゴリズムで計算
				byte[] key = md.digest();

				// 二桁の16進文字列に変換
				result = convByteToString(key);
			}
		} catch (NoSuchAlgorithmException e) {
		}

		return result;
	}

	/** byte型を16進コード文字列に変換する */
	private static String convByteToString(byte[] target){
		StringBuilder sb = new StringBuilder();

		if(target != null){
			for (int i = 0; i < target.length; i++) {
				int d = target[i];

				if (d < 0) {
					d += 256;
				}

				if (d < 16) {
					sb.append("0" + Integer.toString(d, 16));
				} else {
					sb.append(Integer.toString(d, 16));
				}
			}
		}

		return new String(sb);
	}

	private static final Pattern PAT_BOOLEAN_NAME = Pattern.compile("^is[A-Z]");

	/**
	 * フィールド名からゲッター名を取得する。
	 * <p>
	 * Javaのネーミングルールに基づいたゲッター名を取得する。<br>
	 * 例:
	 * <blockquote><pre>
	 * フィールド名「abcDef」→「getAbcDef」<br>
	 * フィールド名「abcDef」(boolean)→「isAbcDef」<br>
	 * フィールド名「isAbcDef」(boolean)→「isAbcDef」
	 * </pre></blockquote>
	 * </p>
	 * @param field フィールド
	 * @return ゲッター名
	 */
	public static String getGetterName(Field field){
		return getGetterName(field.getName(), field.getType());
	}

	/**
	 * フィールド名からゲッター名を取得する。
	 * <p>
	 * Javaのネーミングルールに基づいたゲッター名を取得する。<br>
	 * 例:
	 * <blockquote><pre>
	 * フィールド名「abcDef」→「getAbcDef」<br>
	 * フィールド名「abcDef」(boolean)→「isAbcDef」<br>
	 * フィールド名「isAbcDef」(boolean)→「isAbcDef」
	 * </pre></blockquote>
	 * </p>
	 * @param fieldName フィールド名
	 * @param fieldType フィールドタイプ
	 * @return ゲッター名
	 */
	public static String getGetterName(String fieldName, Class<?> fieldType){
		String getterName = null;
		// プリミティブのboolean
		if(fieldType == Boolean.TYPE){
			// フィールド名が「isXXX」である場合
			if(PAT_BOOLEAN_NAME.matcher(fieldName).find()){
				getterName = fieldName;
			} else {
				getterName = "is" + convHeadCharToUpper(fieldName);
			}
		} else {
			getterName = "get" + convHeadCharToUpper(fieldName);
		}
		return getterName;
	}

	/**
	 * フィールド名からセッター名を取得する。
	 * <p>
	 * Javaのネーミングルールに基づいたセッター名を取得する。<br>
	 * 例:
	 * <blockquote><pre>
	 * フィールド名「abcDef」→「setAbcDef」<br>
	 * フィールド名「abcDef」(boolean)→「setAbcDef」<br>
	 * フィールド名「isAbcDef」(boolean)→「setAbcDef」
	 * </pre></blockquote>
	 * </p>
	 * @param field フィールド
	 * @return セッター名
	 */
	public static String getSetterName(Field field){
		return getSetterName(field.getName(), field.getType());
	}

	/**
	 * フィールド名からセッター名を取得する。
	 * <p>
	 * Javaのネーミングルールに基づいたセッター名を取得する。<br>
	 * 例:
	 * <blockquote><pre>
	 * フィールド名「abcDef」→「setAbcDef」<br>
	 * フィールド名「abcDef」(boolean)→「setAbcDef」<br>
	 * フィールド名「isAbcDef」(boolean)→「setAbcDef」
	 * </pre></blockquote>
	 * </p>
	 * @param fieldName フィールド名
	 * @param fieldType フィールドタイプ
	 * @return セッター名
	 */
	public static String getSetterName(String fieldName, Class<?> fieldType){
		String setterName = null;
		// プリミティブのboolean
		if(fieldType == Boolean.TYPE){
			// フィールド名が「isXXX」である場合
			if(PAT_BOOLEAN_NAME.matcher(fieldName).find()){
				setterName = "set" + fieldName.substring(2, fieldName.length());
			} else {
				setterName = "set" + convHeadCharToUpper(fieldName);
			}
		} else {
			setterName = "set" + convHeadCharToUpper(fieldName);
		}
		return setterName;
	}

	// 先頭一文字を英大文字に変換
	private static String convHeadCharToUpper(String target){
		return target.substring(0, 1).toUpperCase() + target.substring(1, target.length());
	}

	/**
	 * 拡張子取得。
	 * <pre>
	 * ファイルパスからファイル拡張子を取得。<br>
	 * (「abc.csv」ならば「csv」を返却する。)
	 * </pre>
	 * @param filePath ファイルパス
	 * @return 拡張子
	 */
	public static String getFileExtension(String filePath){
		String fileExtension = null;
		String fileName = getFileName(filePath);
		if(fileName != null){
			Pattern pat = Pattern.compile(".*\\.");
			Matcher matcher = pat.matcher(fileName);
			if(matcher.find()){
				fileExtension = matcher.replaceAll("");
			}
		}
		return fileExtension;
	}

	/**
	 * ファイル名取得。
	 * <pre>
	 * ファイルパスからファイル名を取得。
	 * </pre>
	 * @param filePath ファイルパス
	 * @return ファイル名
	 */
	public static String getFileName(String filePath){
		String fileName = null;
		if(filePath != null){
			Pattern pat = Pattern.compile(".*[\\\\/]");
			fileName = pat.matcher(filePath).replaceAll("");
		}
		return fileName;
	}

	/**
	 * 拡張子置換。
	 * <pre>
	 * ファイル名の拡張子を置換。
	 * </pre>
	 * @param filePath ファイルパス
	 * @param newExtension 置換後の拡張子
	 * @return ファイル名の拡張子を置換したファイルパス
	 */
	public static String replaceFileExtension(String filePath, String newExtension){
		String newFilePath = null;
		if(filePath != null){
			String addExtension = "";
			if(newExtension != null){
				addExtension = "." + newExtension;
			}
			StringBuilder sb = new StringBuilder();
			String fileExtension = StringUtils.getFileExtension(filePath);
			if(fileExtension == null){
				sb.append(filePath + addExtension);
			} else {
				sb.append(filePath.substring(0, filePath.length() - fileExtension.length() - 1));
				sb.append(addExtension);
			}
			newFilePath = new String(sb);
		}
		return newFilePath;
	}

	/**
	 * フォルダパス取得。
	 * <pre>
	 * フォルダ用パスの整形(xxx/yyy/)。
	 * </pre>
	 * @param path パス
	 * @return フォルダパス
	 */
	public static String getFolderPath(String path){
		String pathSep = "/";
		// 「\」変換後、最初と最後の「/」を削除後、最後に「/」を追加
		return path.replaceAll("\\\\", pathSep).replaceAll(pathSep + "$", "").replaceAll("^" + pathSep, "") + pathSep;
	}

	/**
	 * 改行コード除去。
	 * <pre>
	 * 対象文字列から改行コードを取り除く。
	 * </pre>
	 * @param target 対象文字列
	 * @return 処理結果文字列
	 */
	public static String removeLineFeedCode(String target){
		if(target != null){
			target = target.replaceAll("\r", "");
			target = target.replaceAll("\n", "");
		}
		return target;
	}

    /**
     * 文字列切り出し（Byte単位）<br />
     * <br />
     * 先頭から指定バイト数分文字列を切り出す。<br />
     * 切り出し終了部分が日本語の途中にかかる場合は<br />
     * 直前の文字までを切り出す
     * @param str String 切り出し対象文字列
     * @param len Integer 切り出しバイト数
     * @param charset String 文字コード
     * @return    String 切り出し後の文字列
     */
    public static String substringByte(String str, Integer len, String charset){
        StringBuffer sb = new StringBuffer();
        int cnt = 0;

        try{
            for (int i = 0; i < str.length(); i++) {
              String tmpStr = str.substring(i, i + 1);
              byte[] b = tmpStr.getBytes(charset);
              if (cnt + b.length > len) {
                return sb.toString();
              } else {
                sb.append(tmpStr);
                cnt += b.length;
              }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return sb.toString();
    }

}
