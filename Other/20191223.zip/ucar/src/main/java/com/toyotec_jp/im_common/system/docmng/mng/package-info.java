/**
 * 文書エンジン操作関連パッケージ
 * @version 1.00 2010/05/17 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.im_common.system.docmng.mng;
