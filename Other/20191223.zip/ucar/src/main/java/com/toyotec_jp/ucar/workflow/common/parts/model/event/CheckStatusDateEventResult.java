package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>ステータスDB日付比較チェックイベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/25 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CheckStatusDateEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** チェック日付 */
	private String dtStatus;

	/**
	 * dtStatusを取得する。
	 * @return dtStatus
	 */
	public String getDtStatus() {
		return dtStatus;
	}

	/**
	 * dtStatusを設定する。
	 * @param dtStatus
	 */
	public void setDtStatus(String dtStatus) {
		this.dtStatus = dtStatus;
	}

}
