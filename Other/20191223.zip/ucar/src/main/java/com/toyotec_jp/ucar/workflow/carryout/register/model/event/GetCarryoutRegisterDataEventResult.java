package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.carryout.register.model.object.CarryoutRegisterDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出情報取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/04 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class GetCarryoutRegisterDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 車両搬出登録 画面出力値Bean */
	private CarryoutRegisterDataBean carryoutRegisterDataBean;
	/** 車両搬出登録 画面出力値有無フラグ
	 * (true：有／false：無) */
	private boolean existCarryoutRegisterData;
	/** 仕入種別情報Beanリスト */
	private ResultArrayList<Ucaa002gBean> t220002gList;
	/** チェック内容情報Beanリスト */
	private ResultArrayList<Ucaa003gBean> t220003gList;
	/** 車両搬出情報Bean */
//	private T220013gBean t220013gBean;
	private Uccb009gBean t220013gBean = new Uccb009gBean();	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
	/** 車両搬出情報 有無フラグ
	 * (true：有／false：無) */
	private boolean existT220013gData;

	/**
	 * carryoutRegisterDataBeanを取得する。
	 * @return carryoutRegisterDataBean
	 */
	public CarryoutRegisterDataBean getCarryoutRegisterDataBean() {
		return carryoutRegisterDataBean;
	}

	/**
	 * carryoutRegisterDataBeanを設定する。
	 * @param carryoutRegisterDataBean
	 */
	public void setCarryoutRegisterDataBean(
			CarryoutRegisterDataBean carryoutRegisterDataBean) {
		this.carryoutRegisterDataBean = carryoutRegisterDataBean;
	}

	/**
	 * existCarryoutRegisterDataを取得する。
	 * @return existCarryoutRegisterData
	 */
	public boolean isExistCarryoutRegisterData() {
		return existCarryoutRegisterData;
	}

	/**
	 * existCarryoutRegisterDataを設定する。
	 * @param existCarryoutRegisterData
	 */
	public void setExistCarryoutRegisterData(boolean existCarryoutRegisterData) {
		this.existCarryoutRegisterData = existCarryoutRegisterData;
	}

	/**
	 * t220002gListを取得する。
	 * @return t220002gList
	 */
	public ResultArrayList<Ucaa002gBean> getT220002gList() {
		return t220002gList;
	}

	/**
	 * t220002gListを設定する。
	 * @param t220002gList
	 */
	public void setT220002gList(ResultArrayList<Ucaa002gBean> t220002gList) {
		this.t220002gList = t220002gList;
	}

	/**
	 * t220003gListを取得する。
	 * @return t220003gList
	 */
	public ResultArrayList<Ucaa003gBean> getT220003gList() {
		return t220003gList;
	}

	/**
	 * t220003gListを設定する。
	 * @param t220003gList
	 */
	public void setT220003gList(ResultArrayList<Ucaa003gBean> t220003gList) {
		this.t220003gList = t220003gList;
	}

	/**
	 * t220013gBeanを取得する。
	 * @return t220013gBean
	 */
//	public T220013gBean getT220013gBean() {
	public Uccb009gBean getT220013gBean() {						// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		return t220013gBean;
	}

	/**
	 * t220013gBeanを設定する。
	 * @param t220013gBean
	 */
//	public void setT220013gBean(T220013gBean t220013gBean) {
	public void setT220013gBean(Uccb009gBean t220013gBean) {	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		this.t220013gBean = t220013gBean;
	}

	/**
	 * existT220013gDataを取得する。
	 * @return existT220013gData
	 */
	public boolean isExistT220013gData() {
		return existT220013gData;
	}

	/**
	 * existT220013gDataを設定する。
	 * @param existT220013gData
	 */
	public void setExistT220013gData(boolean existT220013gData) {
		this.existT220013gData = existT220013gData;
	}

}
