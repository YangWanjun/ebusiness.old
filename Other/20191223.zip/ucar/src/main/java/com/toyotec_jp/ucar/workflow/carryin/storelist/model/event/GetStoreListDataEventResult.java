package com.toyotec_jp.ucar.workflow.carryin.storelist.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListDataBean;

/**
 * <strong>展示店舗受取処理情報取得イベントリザルト</strong>
 * <p></p>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/27 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class GetStoreListDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 展示店舗受取処理 画面出力値リスト */
	private List<StoreListDataBean> storeListDataList;

	/** 合計レコード数 */
	private int totalRecordCount;
	/** ページ番号 */
	private int pageNo;
	/** ページサイズ */
	private int pageSize;


	/**
	 * storeListDataListを取得する。
	 * @return storeListDataList 展示店舗受取処理 画面出力値Bean
	 */
	public List<StoreListDataBean> getStoreListDataList() {
		return storeListDataList;
	}

	/**
	 * storeListDataListを設定する。
	 * @param storeListDataList 展示店舗受取処理 画面出力値Bean
	 */
	public void setStoreListDataList(List<StoreListDataBean> storeListDataList) {
		this.storeListDataList = storeListDataList;
	}

	/**
	 * totalRecordCountを取得する。
	 * @return totalRecordCount
	 */
	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	/**
	 * totalRecordCountを設定する。
	 * @param totalRecordCount
	 */
	public void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @param pageNo
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

}
