package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.math.BigDecimal;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcarCommonDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;

/**
 * <strong>消費税率取得イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/16 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetSyouhizeirituEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetSyouhizeirituEvent getEvent = (GetSyouhizeirituEvent)event;

		Ucba004mBean t220204mBean = new Ucba004mBean(getEvent.getCdKaisya(),
													getEvent.getCdJigyosyo(),
													null,
													null);

		UcarCommonDAOIF commonDao = getDAO(UcarDAOKey.UCARCOMMON_DAO,
											getEvent,
											UcarCommonDAOIF.class);

		// 消費税率を取得
		Ucba004mBean syouhizeiBean = commonDao.selectSyouhizei(t220204mBean, getEvent.getTargetDate());
		t220204mBean.setCdKubun(syouhizeiBean.getMjInfo3());
		// 端数処理を取得
		Ucba004mBean hasuuBean = commonDao.selectHasuu(t220204mBean);
		// 消費税率(パーセント)
		BigDecimal bdSyouhizeiPercent = new BigDecimal(syouhizeiBean.getMjKubun());
		// 消費税÷100
		BigDecimal bdSyouhizeiritu = bdSyouhizeiPercent.divide(new BigDecimal(100));

		GetSyouhizeirituEventResult getResult = new GetSyouhizeirituEventResult();

		getResult.setBdSyouhizeiPercent(bdSyouhizeiPercent);
		getResult.setBdSyouhizeiritu(bdSyouhizeiritu);
		getResult.setMjHasuu(hasuuBean.getMjKubun());

		return getResult;
	}

}
