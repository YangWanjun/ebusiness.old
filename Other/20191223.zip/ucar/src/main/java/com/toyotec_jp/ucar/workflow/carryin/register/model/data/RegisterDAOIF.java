package com.toyotec_jp.ucar.workflow.carryin.register.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;

/**
 * <strong>車両搬入登録DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public interface RegisterDAOIF {

	/**
	 * 管理番号最大値取得処理（車両搬入情報）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @return 管理番号
	 * @throws TecDAOException DAO例外クラス
	 */
	public String selectNoKanriMax(String cdKaisya,
									String cdHanbaitn,
									String ddHannyu
// 2014.7.18 H.Yamashita add start P相模原 連番対応								
									,String loginKbScenter
// 2014.7.18 H.Yamashita add start P相模原 連番対応
//--2019.3.20 from
									,String loginKbGyohan
									,String cdHantenpo
//--2019.3.20 to											
	) throws TecDAOException;

	/**
	 * 件数取得処理(仕入種別情報)
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param	loginKbScenter 商品化センター区分
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220002GCount(String cdKaisya,
									String cdHanbaitn,
									String ddHannyu,
									String noKanri,
									String loginKbScenter) throws TecDAOException;

	/**
	 * 件数取得処理(チェック内容情報)
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param	loginKbScenter 商品化センター区分
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220003GCount(String cdKaisya,
									String cdHanbaitn,
									String ddHannyu,
									String noKanri,
									String loginKbScenter) throws TecDAOException;

	/**
	 * 新規登録処理（車両搬入情報）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginKbScenter 商品化センター区分
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertSyaryoHannyu(RegisterInputBean registerInputBean,
													String loginKbScenter,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 新規登録処理（仕入種別情報）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbSiire 仕入種別
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220002G(RegisterInputBean registerInputBean,
													String loginKbScenter,
													String kbSiire,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 新規登録処理（チェック内容情報）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbCheck チェック内容区分
	 * @param	ddCheck チェック日
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220003G(RegisterInputBean registerInputBean,
													String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
													String loginKbScenter,
													String kbCheck,
													String ddCheck,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 新規登録処理（書類DB情報）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbCheck チェック内容区分
	 * @param	ddCheck チェック日
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220007G(RegisterInputBean registerInputBean,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
													String loginCdTenpo,
													String loginKbScenter,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
													Timestamp executeDate) throws TecDAOException;
	/**
	 * 新規登録処理（書類DB情報）
	 * @param	t220007gBean 書類チェックDBBean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbCheck チェック内容区分
	 * @param	ddCheck チェック日
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220007G(Ucab002gBean t220007gBean,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
													String loginCdTenpo,
													String loginKbScenter,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
													Timestamp executeDate) throws TecDAOException;

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/**
	 * 新規登録処理（ステータスDB情報）
	 * @param	t220012gInputDataBean
	 * @param  cdTenpoHanbaitnSel 
	 * @param	loginKbScenter 商品化センター区分
	 * @param	menuId
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean insertT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													String cdTenpoHanbaitnSel,     // 2019.04.04 T.Osada
													String loginKbScenter,
													String menuId,
													Timestamp executeDate) throws TecDAOException;
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

//	/**
//	 * 車両搬入情報取得処理
//	 * @param	t220001gPkBean 車両搬入情報 プライマリーキーBean
//	 * @throws LcmDAOException DAO例外クラス
//	 */
//	public ResultArrayList<Ucaa001gBean> selectSyaryoHannyu(Ucaa001gPKBean t220001gPkBean) throws TecDAOException;

	/**
	 * 車両搬入情報取得処理
	 * @param	t220001gPkBean 車両搬入情報(店舗用) プライマリーキーBean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucaa001gBean> selectT220001G(Ucaa001gPKBean t220001gPkBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String loginKbScenter) throws TecDAOException;

	/**
	 * 仕入種別情報取得処理
	 * @param	t220001gPkBean 車両搬入情報 プライマリーキーBean
	 * @param	loginKbScenter 商品化センター区分
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucaa002gBean> selectT220002G(Ucaa001gPKBean t220001gPkBean,
			String loginKbScenter) throws TecDAOException;


	/**
	 * 書類チェック情報取得処理
	 * @param	t220001gPkBean 車両搬入情報 プライマリーキーBean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @throws LcmDAOException DAO例外クラス
	 */
	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//	public ResultArrayList<Ucab002gBean> selectT220007G(Ucaa001gPKBean t220001gPkBean) throws TecDAOException;
	public ResultArrayList<Ucab002gBean> selectT220007G(Ucaa001gPKBean t220001gPkBean,
																		String loginCdTenpo,
																		String loginKbScenter) throws TecDAOException;
	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
	/**
	 * チェック内容情報取得処理
	 * @param	t220001gPkBean 車両搬入情報 プライマリーキーBean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	excludeKbCheck 除外対象チェック内容区分
	 * @throws LcmDAOException DAO例外クラス
	 * <pre>
	 * excludeKbCheckは検索から除外したいチェック内容区分がある場合に設定。
	 * 除外する必要が無い場合はnullを設定すること。
	 * </pre>
	 */
	public ResultArrayList<Ucaa003gBean> selectT220003G(Ucaa001gPKBean t220001gPkBean,
														String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
														String loginKbScenter,
														String excludeKbCheck) throws TecDAOException;

	/**
	 * 削除処理（車両搬入情報）
	 * @param	t220001gPkBean 車両搬入情報 プライマリーキーBean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbData データ区分
	 * @param	t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220001G(Ucaa001gPKBean t220001gPkBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String loginKbScenter,
			String kbData,		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String t220001gDtKosin) throws TecDAOException;

	/**
	 * 削除処理（仕入種別情報）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param	loginKbScenter 商品化センター区分
	 * @param	exclusionDtKosin データ更新日時(排他チェック用)
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220002G(String cdKaisya,
													String cdHanbaitn,
													String ddHannyu,
													String noKanri,
													String loginKbScenter,
													String exclusionDtKosin) throws TecDAOException;

	/**
	 * 削除処理（チェック内容情報）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri	管理番号
	 * @param 	loginCdTenpo 自店舗コード
	 * @param  kbCheck チェック内容区分
	 * @param	loginKbScenter 商品化センター区分
	 * @param	exclusionDtKosin データ更新日時(排他チェック用)
	 * @throws TecDAOException DAO例外クラス
	 * <pre>
	 * kbCheckは特定の削除したいチェック内容区分がある場合に設定。
	 * 必要が無い場合はnullを設定すること。
	 * </pre>
	 */
	public SimpleExecuteResultBean deleteT220003G(String cdKaisya,
													String cdHanbaitn,
													String ddHannyu,
													String noKanri,
													String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													String kbCheck,
													String loginKbScenter,
													String exclusionDtKosin) throws TecDAOException;

	/**
	 * 削除処理（書類チェック情報）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param 	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	exclusionDtKosin データ更新日時(排他チェック用)
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220007G(String cdKaisya,
													String cdHanbaitn,
													String ddHannyu,
													String noKanri,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
													String loginCdTenpo,
													String loginKbScenter,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
													String exclusionDtKosin) throws TecDAOException;

	/**
	 * 更新登録処理（車両搬入情報）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbData データ区分
	 * @param	t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220001G(RegisterInputBean registerInputBean,
													String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２	
													String loginKbScenter,
													String kbData,		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													String t220001gDtKosin,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新登録処理（車両搬入情報）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbData データ区分
	 * @param	t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220001GOnlyHannyuCheck(RegisterInputBean registerInputBean,
																String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２	
																String loginKbScenter,
																String kbData,		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																String t220001gDtKosin,
																Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新登録処理（車両搬入情報：備考のみ）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbData データ区分
	 * @param	t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220001GOnlyMjBikou(RegisterInputBean registerInputBean,
																String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２	
																String loginKbScenter,
																String kbData,		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																String t220001gDtKosin,
																Timestamp executeDate) throws TecDAOException;

	// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため start
	/**
	 * 更新登録処理（車両搬入情報：走行距離、備考のみ）
	 * @param	registerInputBean 車両搬入登録 画面入力値格納用Bean
	 * @param	loginCdTenpo 自店舗コード
	 * @param	loginKbScenter 商品化センター区分
	 * @param	kbData データ区分
	 * @param	t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220001GAlsoNuSoukukm(RegisterInputBean registerInputBean,
																String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２	
																String loginKbScenter,
																String kbData,		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																String t220001gDtKosin,
																Timestamp executeDate) throws TecDAOException;
	// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため end

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/**
	 * 更新登録処理（ステータスＤＢ）
	 * @param	t220012gInputDataBean
	 * @param  cdTenpoHanbaitnSel 
	 * @param	loginKbScenter 商品化センター区分
	 * @param	menuId
	 * @param	executeDate 実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean updateT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													String cdTenpoHanbaitnSel,  // 2019.04.04 T.Osada 
													String loginKbScenter,
													String menuId,
													Timestamp executeDate) throws TecDAOException;


	/**
	 * ステータス情報取得処理
	 * @param	t220001gPkBean 車両搬入情報 プライマリーキーBean
	 * @param  cdTenpoHanbaitnSel 
	 * @param	loginKbScenter 商品化センター区分
	 * @throws LcmDAOException DAO例外クラス
	 */
//	public ResultArrayList<Ucab007gBean> selectT220012G(Ucaa001gPKBean t220001gPkBean,
	public ResultArrayList<Ucab007gBean> selectT220012G(Uccb007gPKBean t220001gPkBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String cdTenpoHanbaitnSel,  // 2019.04.04 T.Osada 
			String loginKbScenter) throws TecDAOException;

	/**
	 * 削除処理（ステータス情報）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param	loginKbScenter 商品化センター区分
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220012G(String cdKaisya,
													String cdHanbaitn,
													String ddHannyu,
													String noKanri,
													String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２	
													String loginKbScenter) throws TecDAOException;
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * データ区分取得処理(車両搬入受取情報ビュー)
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param	loginCdTenpo 自店舗コード
	 * @throws LcmDAOException DAO例外クラス
	 */
	public String selectKbData(String cdKaisya,
								String cdHanbaitn,
								String ddHannyu,
								String noKanri,
								String loginCdTenpo) throws TecDAOException;
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end	

	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * 車台番号で搬入店舗コード取得処理（車両搬入情報）
	 * @param 	noSyadai 車台番号
	 * @param	loginKbScenter 商品化センター区分
	 * @throws TecDAOException DAO例外クラス
	 */
	
// 2014.10.20(2015.9.8再設定　H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加 start
	public ResultArrayList<Ucaa001gBean> selectCdHantenpo(String noSyadai,
//														String loginKbScenter) throws TecDAOException;
											String loginKbScenter, String cdHanbaitn) throws TecDAOException;
// 2014.10.20(2015.9.8再設定　H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加 end
	/**
	 * 店舗短縮名称取得処理（共通店舗DB）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	cdTenpo 店舗コード
	 * @return kjTentanms 店舗短縮名称
	 * @throws TecDAOException DAO例外クラス
	 */
	public String selectKjTentanms(String cdKaisya,
									String cdHanbaitn,
									String cdTenpo) throws TecDAOException;
	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　end
}