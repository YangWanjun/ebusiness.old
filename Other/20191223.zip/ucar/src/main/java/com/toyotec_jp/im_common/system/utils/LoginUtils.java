/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】LoginUtils.java
 * 【  説  明  】
 * 【  作  成  】2019/09/04 WJ.YANG(MBP)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import jp.co.intra_mart.foundation.context.Contexts;
import jp.co.intra_mart.foundation.context.model.AccountContext;
import jp.co.intra_mart.foundation.job_scheduler.JobSchedulerContext;

/**
 * @author WJ.YANG(MBP)
 * @version 1.00 2019/09/04 新規作成<br>
 */
public final class LoginUtils {

	/**
	 * デフォルトコンストラクタ
	 */
	private LoginUtils() {
	}

	/**
	 * バッチ実行時のテナントＩＤを取得
	 * @return テナントＩＤ
	 */
	public static String getBatchTenantId() {
		final AccountContext accountContext = Contexts
				.get(AccountContext.class);
		final JobSchedulerContext jobSchedulerContext = Contexts
				.get(JobSchedulerContext.class);
		return accountContext.getLoginGroupId();
	}
}
