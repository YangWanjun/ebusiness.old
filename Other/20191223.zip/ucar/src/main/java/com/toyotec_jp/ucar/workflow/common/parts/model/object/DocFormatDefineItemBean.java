package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import java.util.Date;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>書式項目定義Bean</strong>
 * <p>
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/10 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class DocFormatDefineItemBean extends TecBean {

	/**  */
	private static final long serialVersionUID = -992553345886069405L;

	/** 書式ID */
	private String docFormatId;
	/** シートインデックス */
	private int sheetIdx;
	/** 処理区分 */
	private String processType;
	/** 処理詳細区分 */
	private String processDetailType;
	/** 引数インデックス */
	private int argumentIdx;
	/** 配列インデックス */
	private int arrayIdx;
	/** リストID */
	private String listId;
	/** 項目名 */
	private String itemName;
	/** 項目区分 */
	private int itemType;
	/** 対象列 */
	private int targetCol;
	/** 対象行 */
	private int targetRow;
	/** オートシェイプ終点列 */
	private int shapeEndCol;
	/** オートシェイプ終点行 */
	private int shapeEndRow;
	/** オートシェイプ始点セルX座標 */
	private int shapeStartCellXPos;
	/** オートシェイプ始点セルY座標 */
	private int shapeStartCellYPos;
	/** オートシェイプ終点セルX座標 */
	private int shapeEndCellXPos;
	/** オートシェイプ終点セルY座標 */
	private int shapeEndCellYPos;
	/** 備考 */
	private String cmnt;
	/** 作成ユーザID */
	private String createdId;
	/** 作成日時 */
	private Date createdDt;
	/** 更新ユーザID */
	private String updatedId;
	/** 更新日時 */
	private Date updatedDt;

	/**
	 *
	 */
	public DocFormatDefineItemBean() {
		super();
	}

	/**
	 * docFormatIdを取得する。
	 * @return docFormatId
	 */
	public String getDocFormatId() {
		return docFormatId;
	}

	/**
	 * docFormatIdを設定する。
	 * @param docFormatId
	 */
	public void setDocFormatId(String docFormatId) {
		this.docFormatId = docFormatId;
	}

	/**
	 * sheetIdxを取得する。
	 * @return sheetIdx
	 */
	public int getSheetIdx() {
		return sheetIdx;
	}

	/**
	 * sheetIdxを設定する。
	 * @param sheetIdx
	 */
	public void setSheetIdx(int sheetIdx) {
		this.sheetIdx = sheetIdx;
	}

	/**
	 * processTypeを取得する。
	 * @return processType
	 */
	public String getProcessType() {
		return processType;
	}

	/**
	 * processTypeを設定する。
	 * @param processType
	 */
	public void setProcessType(String processType) {
		this.processType = processType;
	}

	/**
	 * processDetailTypeを取得する。
	 * @return processDetailType
	 */
	public String getProcessDetailType() {
		return processDetailType;
	}

	/**
	 * processDetailTypeを設定する。
	 * @param processDetailType
	 */
	public void setProcessDetailType(String processDetailType) {
		this.processDetailType = processDetailType;
	}

	/**
	 * argumentIdxを取得する。
	 * @return argumentIdx
	 */
	public int getArgumentIdx() {
		return argumentIdx;
	}

	/**
	 * argumentIdxを設定する。
	 * @param argumentIdx
	 */
	public void setArgumentIdx(int argumentIdx) {
		this.argumentIdx = argumentIdx;
	}

	/**
	 * arrayIdxを取得する。
	 * @return arrayIdx
	 */
	public int getArrayIdx() {
		return arrayIdx;
	}

	/**
	 * arrayIdxを設定する。
	 * @param arrayIdx
	 */
	public void setArrayIdx(int arrayIdx) {
		this.arrayIdx = arrayIdx;
	}

	/**
	 * listIdを取得する。
	 * @return listId
	 */
	public String getListId() {
		return listId;
	}

	/**
	 * listIdを設定する。
	 * @param listId
	 */
	public void setListId(String listId) {
		this.listId = listId;
	}

	/**
	 * itemNameを取得する。
	 * @return itemName
	 */
	public String getItemName() {
		return itemName;
	}

	/**
	 * itemNameを設定する。
	 * @param itemName
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**
	 * itemTypeを取得する。
	 * @return itemType
	 */
	public int getItemType() {
		return itemType;
	}

	/**
	 * itemTypeを設定する。
	 * @param itemType
	 */
	public void setItemType(int itemType) {
		this.itemType = itemType;
	}

	/**
	 * targetColを取得する。
	 * @return targetCol
	 */
	public int getTargetCol() {
		return targetCol;
	}

	/**
	 * targetColを設定する。
	 * @param targetCol
	 */
	public void setTargetCol(int targetCol) {
		this.targetCol = targetCol;
	}

	/**
	 * targetRowを取得する。
	 * @return targetRow
	 */
	public int getTargetRow() {
		return targetRow;
	}

	/**
	 * targetRowを設定する。
	 * @param targetRow
	 */
	public void setTargetRow(int targetRow) {
		this.targetRow = targetRow;
	}

	/**
	 * shapeEndColを取得する。
	 * @return shapeEndCol
	 */
	public int getShapeEndCol() {
		return shapeEndCol;
	}

	/**
	 * shapeEndColを設定する。
	 * @param shapeEndCol
	 */
	public void setShapeEndCol(int shapeEndCol) {
		this.shapeEndCol = shapeEndCol;
	}

	/**
	 * shapeEndRowを取得する。
	 * @return shapeEndRow
	 */
	public int getShapeEndRow() {
		return shapeEndRow;
	}

	/**
	 * shapeEndRowを設定する。
	 * @param shapeEndRow
	 */
	public void setShapeEndRow(int shapeEndRow) {
		this.shapeEndRow = shapeEndRow;
	}

	/**
	 * shapeStartCellXPosを取得する。
	 * @return shapeStartCellXPos
	 */
	public int getShapeStartCellXPos() {
		return shapeStartCellXPos;
	}

	/**
	 * shapeStartCellXPosを設定する。
	 * @param shapeStartCellXPos
	 */
	public void setShapeStartCellXPos(int shapeStartCellXPos) {
		this.shapeStartCellXPos = shapeStartCellXPos;
	}

	/**
	 * shapeStartCellYPosを取得する。
	 * @return shapeStartCellYPos
	 */
	public int getShapeStartCellYPos() {
		return shapeStartCellYPos;
	}

	/**
	 * shapeStartCellYPosを設定する。
	 * @param shapeStartCellYPos
	 */
	public void setShapeStartCellYPos(int shapeStartCellYPos) {
		this.shapeStartCellYPos = shapeStartCellYPos;
	}

	/**
	 * shapeEndCellXPosを取得する。
	 * @return shapeEndCellXPos
	 */
	public int getShapeEndCellXPos() {
		return shapeEndCellXPos;
	}

	/**
	 * shapeEndCellXPosを設定する。
	 * @param shapeEndCellXPos
	 */
	public void setShapeEndCellXPos(int shapeEndCellXPos) {
		this.shapeEndCellXPos = shapeEndCellXPos;
	}

	/**
	 * shapeEndCellYPosを取得する。
	 * @return shapeEndCellYPos
	 */
	public int getShapeEndCellYPos() {
		return shapeEndCellYPos;
	}

	/**
	 * shapeEndCellYPosを設定する。
	 * @param shapeEndCellYPos
	 */
	public void setShapeEndCellYPos(int shapeEndCellYPos) {
		this.shapeEndCellYPos = shapeEndCellYPos;
	}

	/**
	 * cmntを取得する。
	 * @return cmnt
	 */
	public String getCmnt() {
		return cmnt;
	}

	/**
	 * cmntを設定する。
	 * @param cmnt
	 */
	public void setCmnt(String cmnt) {
		this.cmnt = cmnt;
	}

	/**
	 * createdIdを取得する。
	 * @return createdId
	 */
	public String getCreatedId() {
		return createdId;
	}

	/**
	 * createdIdを設定する。
	 * @param createdId
	 */
	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	/**
	 * createdDtを取得する。
	 * @return createdDt
	 */
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * createdDtを設定する。
	 * @param createdDt
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * updatedIdを取得する。
	 * @return updatedId
	 */
	public String getUpdatedId() {
		return updatedId;
	}

	/**
	 * updatedIdを設定する。
	 * @param updatedId
	 */
	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

	/**
	 * updatedDtを取得する。
	 * @return updatedDt
	 */
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * updatedDtを設定する。
	 * @param updatedDt
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

}
