package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutDAOKey;
import com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出情報削除イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/05 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class DeleteCarryoutRegisterDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		TecLogger.trace("delete registerData start");

		DeleteCarryoutRegisterDataEvent targetEvent = (DeleteCarryoutRegisterDataEvent) event;
		// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため start
		Uccb009gBean t220013gBean = targetEvent.getT220013gBean();

		// DAOIF取得
		CarryoutRegisterDAOIF dao = getDAO(CarryoutDAOKey.REGISTER_DAO, targetEvent, CarryoutRegisterDAOIF.class);

		Ucaa001gPKBean t220001gPKBean = new Ucaa001gPKBean(t220013gBean.getCdKaisya(),
															t220013gBean.getCdHanbaitn(),
															t220013gBean.getDdHannyu(),
															t220013gBean.getNoKanri());

		ResultArrayList<Uccb009gBean> t220013gList = dao.selectT220013G(t220001gPKBean,
																		targetEvent.getUserInfoBean().getCdTenpo(),
																		targetEvent.getUserInfoBean().getKbScenter());

		SimpleExecuteResultBean deleteResult001G = null;

		if (t220013gList.get(0).getDdTenukt() == null) {
			deleteResult001G = dao.deleteT220013G(t220013gBean,
													targetEvent.getUserInfoBean().getCdTenpo(),
													targetEvent.getUserInfoBean().getKbScenter(),
													targetEvent.getT220013gDtKosin());
		} else {
			throw new TecExclusionException("他店受取済のため削除できません。");
		}
		// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため end

		if (deleteResult001G.getExecuteCount() == 0) {
			// 削除件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
		}

		// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため start
		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarryoutConst.APPID_CARRYOUT_REGISTER;

		// ステータスDB：会社コード・販売店コード・搬入日・管理番号
		//			   在庫店舗コード・商品化センター区分	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		//			   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
//      T220012gInputDataBean t220012gInputDataBean = new T220012gInputDataBean(targetEvent.getT220013gBean().getCdKaisya(),
		Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(t220013gBean.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																				t220013gBean.getCdHanbaitn(),
																				t220013gBean.getDdHannyu(),
																				t220013gBean.getNoKanri(),
																				// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																				targetEvent.getUserInfoBean().getCdTenpo(),
																				targetEvent.getUserInfoBean().getKbScenter(),
																				// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																				updateUserId,
																				updateUserId,
																				updateAppId,
																				updateAppId);

		// ステータスDB：ステータス19
		t220012gInputDataBean.setStrDtStatus19(null);
		// ステータスDB：ステータス21
		t220012gInputDataBean.setStrDtStatus21(null);

		// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため start
		// ステータスDB：作業工程区分⇒空白を設定
		t220012gInputDataBean.setKbSgyokt("");
		// ステータスDB：商品化日数⇒0を設定
		t220012gInputDataBean.setNuSyohn(0);
		// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため end

		// ステータス更新処理
		SimpleExecuteResultBean updateStatusResult = dao.updateT220012G(t220012gInputDataBean, executeDate);
		if (updateStatusResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合はInsert処理

			// Insertの場合はステータス01をセット
			String strDtStatus01 = UcarUtils.getStringDateFormatShort(t220013gBean.getDdHannyu());
			t220012gInputDataBean.setStrDtStatus01(strDtStatus01);

			dao.insertT220012G(t220012gInputDataBean, executeDate);
		}
		// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため end

		TecLogger.trace("delete registerData end");
		return null;
	}

}
