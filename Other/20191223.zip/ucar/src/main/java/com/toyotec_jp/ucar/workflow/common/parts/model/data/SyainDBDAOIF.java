package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;

/**
 * <strong>社員DB操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/17 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface SyainDBDAOIF {

	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
	/**
	 * 社員DBリスト取得。
	 * @param  cdKaisya 会社コード
	 * @param  cdHanbaitn 販売店コード
	 * @param  cdSyain 社員コード
	 * @return 社員DBリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<SyainDBBean> getSyainDBList(String cdKaisya, String cdHanbaitn, String cdSyain) throws TecDAOException;
	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

}
