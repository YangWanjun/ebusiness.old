package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.util.ArrayList;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.base.util.UserInfo;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapKey;
import com.toyotec_jp.im_common.system.docmng.data.DMSheetMap;
import com.toyotec_jp.im_common.system.docmng.data.DMYoshikiMap;
import com.toyotec_jp.im_common.system.docmng.mng.DMFilesMapManager;
import com.toyotec_jp.im_common.system.docmng.mng.excel.DMExcelManager;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.IMAppFileManager;
import com.toyotec_jp.im_common.system.utils.IMFileManagerIF;
import com.toyotec_jp.im_common.system.utils.IMStorageServiceManager;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultObject;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.DocFormatDAOIF;

/**
 * <strong>Excel書き込みイベントリスナ。</strong>
 * <p>
 * 「com.toyotec_jp.im_common.system.docmng」、「org.apache.poi」を使用してExcel書き込みを実行する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/13 新規作成<br>
 * @since 1.00
 */
public class ExcelFormatWriteEventListener extends UcarEventListener {

	/** 自動生成一時保存先ROOT */
	private static final String TEMP_SAVE_ROOT = UcarApplicationManager.getConfigValue(
			UcarApplicationManager.SYSTEM_COMMON_ROOT + ".file.temp.ExcelFormatWrite.Path");

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {
		UserInfo userInfo = event.getUserInfo();
		ExcelFormatWriteEvent exWriteEvent = (ExcelFormatWriteEvent)event;
		// Excel書き込み定義情報取得
		DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> mapYoshiki = getExcelWriteDef(exWriteEvent);

		// パス未指定の場合はDBの定義情報に設定した物理ファイル名(パス)を使用
		// 雛形に書き込む場合は未指定が基本
		String baseFilePath = exWriteEvent.getBaseFilePath();
		if(baseFilePath == null){
			baseFilePath = mapYoshiki.getButsuriFileNm();
		}
		// ファイル操作対象(雛形読み込み)
		IMFileManagerIF imFileMngForLoad = getIMFileManager(exWriteEvent.isAppBaseFilePath());
		byte[] originalByteArray = imFileMngForLoad.loadFile(baseFilePath);
		// Excelに値を設定
		DMExcelManager xlsMng = DMExcelManager.getInstance();
		byte[] byteArray;
		String[] writeStrings = exWriteEvent.getWriteStrings();
		String[][][] writeLists = exWriteEvent.getWriteLists();
		if((writeStrings != null && writeStrings.length > 0) || (writeLists != null && writeLists.length > 0)){
			// 雛形に対し書き込み
			byteArray = xlsMng.getFileByteArrayAfterSetData(
					originalByteArray, baseFilePath, mapYoshiki, writeStrings, writeLists);
		} else {
			byteArray = originalByteArray;
		}
		if(byteArray == null || byteArray.length == 0){
			String errorMsg = "ExcelWriteZeroByteFile[" + baseFilePath + "]";
			TecLogger.error(errorMsg);
			throw new TecSystemException(errorMsg);
		}
		// 一時保存先パス未指定の場合は自動生成
		String tempSavePath = exWriteEvent.getTempSavePath();
		if(tempSavePath == null){
			tempSavePath = getTempSavePath(baseFilePath, userInfo.getLoginGroupID(), userInfo.getUserID());
		}
		// ファイル操作対象(一時保存)
		IMFileManagerIF imFileMngForTempSave = getIMFileManager(exWriteEvent.isSaveAppSrv());
		imFileMngForTempSave.saveFile(tempSavePath, byteArray, true);
		return new ResultObject(tempSavePath);
	}

	// 定義情報(SET)取得
	private DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> getExcelWriteDef(
			ExcelFormatWriteEvent event) throws TecSystemException {
		// 定義情報取得
		String docFormatID = event.getDocFormatID();
		DocFormatDAOIF dfDAOIF = getDAO(UcarDAOKey.DOC_FORMAT_DAO, event, DocFormatDAOIF.class);
		ArrayList<DMFilesMapData> fileMapList = dfDAOIF.getDocFormatDefineList(docFormatID);
		// 定義情報を変換、Excel設定用の定義を抽出
		DMFilesMapManager fMapMng = DMFilesMapManager.getInstance();
		return fMapMng.convMapListToYoshikiMap(
				fileMapList.toArray(new DMFilesMapData[fileMapList.size()]), DMFilesMapData.ShoriKbn.SET);
	}

	// 一時保存先パス取得
	private String getTempSavePath(String baseFilePath, String loginGroupId, String userId){
		String fileExtension = StringUtils.getFileExtension(baseFilePath);
		StringBuilder sb = new StringBuilder();
		sb.append(StringUtils.getFolderPath(TEMP_SAVE_ROOT));
		sb.append(DateUtils.getCurrentDateStr(DateUtils.FORMAT_LONG_M_SIMPLE));
		sb.append("#" + loginGroupId + "#" + userId);
		if(fileExtension != null){
			sb.append("." + fileExtension);
		}
		return new String(sb);
	}

	// ファイル操作用クラス取得
	private IMFileManagerIF getIMFileManager(boolean isTargetAppSrv){
		if(isTargetAppSrv){
			// APサーバが対象
			return IMAppFileManager.getInstance();
		} else {
			// ストレージサービスが対象
			return IMStorageServiceManager.getInstance();
		}
	}

}
