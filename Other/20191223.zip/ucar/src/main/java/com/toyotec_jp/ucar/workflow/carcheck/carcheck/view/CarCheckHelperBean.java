package com.toyotec_jp.ucar.workflow.carcheck.carcheck.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jp.co.intra_mart.framework.base.event.EventException;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetEnterCheckDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetEnterCheckDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetEnterCheckReloadDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetEnterCheckReloadDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetEnterCheckSelectDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetEnterCheckSelectDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetWorkSortDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.GetWorkSortDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckSessionBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckEventKey;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckMenuId;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckServiceId;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckTitle;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinAjaxServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarButton;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarRadioButton;

/**
 * <strong>車両チェックヘルパービーン。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/05 新規作成<br>
 * @since 1.00
 * @category [[車両チェック]]
 */
public class CarCheckHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 8584928315609391060L;

	private static final String NOT_SEARCH 			= "NotSearch";
	private static final String LIST_DATA_ZERO 		= "listDataZero";
	private static final String LIST_DATA_NOT_ZERO 	= "listDataNotZero";

	/** 入庫検査一覧の最大表示件数 */
	private static final String ENTER_CHECK_PAGE_SIZE
		= UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".pazesize.carcheck.CarCheck.ENTERCHECK");
	/** 作業仕分一覧の最大表示件数 */
	private static final String WORK_SORT_PAGE_SIZE
		= UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".pazesize.carcheck.CarCheck.WORKSORT");

	private String serviceUrlInit;
	private String serviceUrlSearch;
	private String serviceUrlClear;
	private String serviceUrlSort;
	private String	serviceUrlRegisterAndDownload;
	private String	serviceUrlRegister;
	private String	serviceUrlCancel;
	private String serviceUrlTransRegister;
	private String serviceUrlDownloadHansyutu;
	// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
	private String	serviceUrlAjax;
	// 2012.03.26 T.Hayato 追加 チェック者 追加のため end

	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
	/** 選択処理(入庫検査画面のみ) */
	private String serviceUrlSelect;
	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end

	private CarCheckSessionBean sessionBean;

	private CarCheckServiceId targetServiceId;

	/** 工程セレクトボックスデータ */
	private ArrayList<HashMap<String, String>>	cdKouteiList;
	/** 表示リスト */
	private List<CarCheckDataBean> carCheckDataList;

	/** ページ番号 */
	private int pageNo;
	/** 合計レコード数 */
	private int totalRecordCount;
	/** 画面タイトル */
	private String titleLabel = "";
	/** 検索条件：検索日付 */
	private String labelConditionDate = "";
	/** 検索条件：工程ラジオボタンの値 */
	private String radiovaluesKoutei = "";
	/** 実行処理：区分ラジオボタンの値 */
	private String	radiovaluesKubun = "";

	/** 検索状況 */
	private String searchSituation = NOT_SEARCH;

	/** ダウンロードファイルパス */
	private String downloadFilePath = "";
	/** 1ページの表示件数 */
	private String pageSize = "";
	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
	/** 選択処理時表示メッセージ(入庫検査画面のみ) */
	private String selectMessage = "";
	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end

	/** デフォルトコンストラクタ。 */
	public CarCheckHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.base.view.TlsHelperBean#init()
	 */
	@Override
	public void init() throws HelperBeanException {

		// セッションの取得
		sessionBean = getApplicationSessionBean(CarCheckSessionBean.class);

		String serviceId = sessionBean.getServiceId();
		targetServiceId = CarCheckServiceId.getTargetCarCheckServiceId(serviceId);

		// サービス呼び出し用URL設定
		setServiceURLs();

		try {

			// サービスごとの処理
			if(targetServiceId != null){
				switch (targetServiceId) {
					case CAR_CHECK_INIT:
					case CAR_CHECK_SEARCH:
					case CAR_CHECK_SORTING:
					case CAR_CHECK_DOWNLOAD:
					case CAR_CHECK_CANCEL:
					// 2012.01.30 T.Hayato 修正 条件初期化動作 変更のため start
					case CAR_CHECK_CLEAR:
					// 2012.01.30 T.Hayato 修正 条件初期化動作 変更のため end
						getCarCheckData();
						break;
					case CAR_CHECK_REGISTER:
					case CAR_CHECK_REGISTER_AND_DOWNLOAD:
						// 2012.03.27 T.Hayato 追加 更新後表示ページ 初期化のため start
						// 更新時はページを初期化
						sessionBean.setPageNo("1");
						// 2012.03.27 T.Hayato 追加 更新後表示ページ 初期化のため end
						getCarCheckData();
						break;
					case CAR_CHECK_SELECT:
						// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
						enterCheckSelectData();
						// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
						break;
					case CAR_CHECK_RETURN_REGISTER:

						if (CarCheckConst.CarCheckMenuId.ENTER_CHECK.getMenuId().equals(sessionBean.getMenuId())) {
							// 入庫検査の場合

							if (sessionBean.getSelectDataList() != null) {
								// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start

								// 選択対象データのみの再取得(備考が更新されている可能性があるため)
								GetEnterCheckReloadDataEvent getTargetEvent = createEvent(
										CarCheckEventKey.GET_ENTER_CHECK_RELOAD_DATA, GetEnterCheckReloadDataEvent.class);

								getTargetEvent.setSelectDataList(sessionBean.getSelectDataList());

								pageSize = ENTER_CHECK_PAGE_SIZE;

								GetEnterCheckReloadDataEventResult getTargetResult
									= (GetEnterCheckReloadDataEventResult)dispatchEvent(getTargetEvent);

								carCheckDataList = getTargetResult.getCarCheckDataList();
								totalRecordCount = carCheckDataList.size();

								if (totalRecordCount > 0) {
									searchSituation = LIST_DATA_NOT_ZERO;
									sessionBean.setCarCheckDataList(carCheckDataList);
								} else {
									searchSituation = LIST_DATA_ZERO;
									sessionBean.setCarCheckDataList(null);
								}
								sessionBean.setCarCheckExecute(UcarConst.EXECUTE_SELECT);
								// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end
							} else {
								// 2012.02.23 T.Hayato 修正 共通メソッド化 start
								getEnterCheckData();
								setCommonData();
								// 2012.02.23 T.Hayato 修正 共通メソッド化 end
							}
						} else if (CarCheckConst.CarCheckMenuId.WORK_SORT.getMenuId().equals(sessionBean.getMenuId())) {
							// 作業仕分の場合
							// 2012.02.23 T.Hayato 修正 共通メソッド化 start
							getWorkSortData();
							setCommonData();
							// 2012.02.23 T.Hayato 修正 共通メソッド化 end
						}

						break;
					default:
						break;
				}
			}

			createSelectList();

			setDisplayContents();

		} catch (SystemException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		} catch (ApplicationException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		}
	}

	// 2012.03.27 T.Hayato 追加 修正 共通メソッド化 start
	/**
	 * 車両チェックデータ取得
	 * @throws HelperBeanException
	 * @throws EventException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void getCarCheckData() throws HelperBeanException, EventException,
			SystemException, ApplicationException {
		// 2012.02.23 T.Hayato 修正 共通メソッド化 start
		if (CarCheckConst.CarCheckMenuId.ENTER_CHECK.getMenuId().equals(sessionBean.getMenuId())) {
			// 入庫検査の場合
			getEnterCheckData();
		} else if (CarCheckConst.CarCheckMenuId.WORK_SORT.getMenuId().equals(sessionBean.getMenuId())) {
			// 作業仕分の場合
			getWorkSortData();
		}

		setCommonData();
		// 2012.02.23 T.Hayato 修正 共通メソッド化 end
	}
	// 2012.03.27 T.Hayato 追加 修正 共通メソッド化 end

	// 2012.02.23 T.Hayato 修正 共通メソッド化 start
	/**
	 * HelperBean共通データ設定
	 */
	private void setCommonData() {
		if (totalRecordCount > 0) {
			searchSituation = LIST_DATA_NOT_ZERO;
			sessionBean.setCarCheckDataList(carCheckDataList);
		} else {
			searchSituation = LIST_DATA_ZERO;
			sessionBean.setCarCheckDataList(null);
		}
		sessionBean.setSelectDataList(null);
	}

	/**
	 * 作業仕分データ取得
	 * @throws HelperBeanException
	 * @throws EventException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void getWorkSortData() throws HelperBeanException, EventException,
			SystemException, ApplicationException {
		GetWorkSortDataEvent getWorkSortEvent = createEvent(
				CarCheckEventKey.GET_WORK_SORT_DATA, GetWorkSortDataEvent.class);

		getWorkSortEvent.setCdKaisya(sessionBean.getCdKaisya());
		getWorkSortEvent.setCdHanbaitn(sessionBean.getCdHanbaitn());

		getWorkSortEvent.setPageNo(sessionBean.getPageNo());
		getWorkSortEvent.setPageSize(WORK_SORT_PAGE_SIZE);
		pageSize = WORK_SORT_PAGE_SIZE;

		getWorkSortEvent.setSortOrder(sessionBean.getSortOrder());
		getWorkSortEvent.setSortParam(sessionBean.getSortParam());
		getWorkSortEvent.setNarrowSearch(sessionBean.isNarrowSearch());

		getWorkSortEvent.setCarCheckParamBean(sessionBean.getCarCheckParamBean());

		GetWorkSortDataEventResult getWorkSortResult
			= (GetWorkSortDataEventResult)dispatchEvent(getWorkSortEvent);

		carCheckDataList = getWorkSortResult.getCarCheckDataList();
		totalRecordCount = getWorkSortResult.getTotalRecordCount();

		// PDFファイルパス
		downloadFilePath = sessionBean.getDownloadFilePath();
		// セッションのダウンロードファイルパスはクリア
		sessionBean.setDownloadFilePath("");
	}

	/**
	 * 入庫検査データ取得
	 * @throws HelperBeanException
	 * @throws EventException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void getEnterCheckData() throws HelperBeanException,
			EventException, SystemException, ApplicationException {
		GetEnterCheckDataEvent getEnterCheckEvent = createEvent(
				CarCheckEventKey.GET_ENTER_CHECK_DATA, GetEnterCheckDataEvent.class);

		getEnterCheckEvent.setCdKaisya(sessionBean.getCdKaisya());
		getEnterCheckEvent.setCdHanbaitn(sessionBean.getCdHanbaitn());

		getEnterCheckEvent.setPageNo(sessionBean.getPageNo());
		getEnterCheckEvent.setPageSize(ENTER_CHECK_PAGE_SIZE);
		pageSize = ENTER_CHECK_PAGE_SIZE;

		getEnterCheckEvent.setSortOrder(sessionBean.getSortOrder());
		getEnterCheckEvent.setSortParam(sessionBean.getSortParam());
		getEnterCheckEvent.setNarrowSearch(sessionBean.isNarrowSearch());

		getEnterCheckEvent.setCarCheckParamBean(sessionBean.getCarCheckParamBean());

		GetEnterCheckDataEventResult getResult
			= (GetEnterCheckDataEventResult)dispatchEvent(getEnterCheckEvent);

		carCheckDataList = getResult.getCarCheckDataList();
		totalRecordCount = getResult.getTotalRecordCount();
	}
	// 2012.02.23 T.Hayato 修正 共通メソッド化 end

	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
	/**
	 * 搬入日（管理№）選択データ取得
	 * <p>
	 * 入庫検査時のみ使用可能
	 * </p>
	 * @throws HelperBeanException
	 * @throws EventException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void enterCheckSelectData() throws HelperBeanException,
			EventException, SystemException, ApplicationException {

		GetEnterCheckSelectDataEvent getTargetEvent = createEvent(
				CarCheckEventKey.GET_ENTER_CHECK_SELECT_DATA, GetEnterCheckSelectDataEvent.class);

		getTargetEvent.setCdKaisya(sessionBean.getCdKaisya());
		getTargetEvent.setCdHanbaitn(sessionBean.getCdHanbaitn());
		getTargetEvent.setSelectDdHannyu(sessionBean.getSelectDdHannyu());
		getTargetEvent.setSelectNoKanri(sessionBean.getSelectNoKanri());

		pageSize = ENTER_CHECK_PAGE_SIZE;

		GetEnterCheckSelectDataEventResult getTargetResult
			= (GetEnterCheckSelectDataEventResult)dispatchEvent(getTargetEvent);

		List<CarCheckDataBean> selectList = getTargetResult.getCarCheckDataList();

		boolean existDdNkkns = getTargetResult.isExistDdNkkns();

		List<CarCheckDataBean> sessionCarCheckDataList = sessionBean.getSelectDataList();
		if (sessionCarCheckDataList == null) {
			// セッション内に保存しているリストが無い場合
			carCheckDataList = selectList;

			if (selectList == null) {
				totalRecordCount = 0;
				if (existDdNkkns) {
					selectMessage = "既に入庫検査が完了しています。";
				} else {
					selectMessage = "該当データがありません。";
				}
			} else {
				totalRecordCount = selectList.size();
			}
		} else {
			// セッション内に保存しているリストがある場合
			if (selectList == null) {
				// 選択対象データが無い場合
				carCheckDataList = sessionCarCheckDataList;
				if (existDdNkkns) {
					selectMessage = "既に入庫検査が完了しています。";
				} else {
					selectMessage = "該当データがありません。";
				}
			} else {
				// 選択対象データがある場合

				boolean isSelectSameData = false;

				// 同じデータがある場合は排除する
				for (CarCheckDataBean carCheckDataBean : sessionCarCheckDataList) {
					if (carCheckDataBean.getDdHannyu().equals(selectList.get(0).getDdHannyu())
						&& carCheckDataBean.getNoKanri().equals(selectList.get(0).getNoKanri())) {
						// 搬入日と管理番号が同じ場合
						isSelectSameData = true;
						selectMessage = "[搬入日]：" + sessionBean.getSelectDdHannyu() + "<br>"
									  + "[管理番号]：" + sessionBean.getSelectNoKanri() + " は、既に選択されています。";
						break;
					}
				}
				if (!isSelectSameData) {
					// セッションから取り出したリストに、今回選択したデータを付加
					sessionCarCheckDataList.addAll(selectList);
				}
				carCheckDataList = sessionCarCheckDataList;
			}
			totalRecordCount = carCheckDataList.size();
		}

		if (totalRecordCount > 0) {
			searchSituation = LIST_DATA_NOT_ZERO;
			sessionBean.setCarCheckDataList(carCheckDataList);
			sessionBean.setSelectDataList(carCheckDataList);
		} else {
			searchSituation = LIST_DATA_ZERO;
			sessionBean.setCarCheckDataList(null);
			sessionBean.setSelectDataList(null);
		}
	}
	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end

	/**
	 * セレクトボックスデータ作成
	 * @throws TecSystemException
	 */
	private void createSelectList() throws TecSystemException {
		cdKouteiList = UcarUtils.getT220014mSelectList(getRequest(), getResponse());
	}

	/**
	 * 画面表示内容を設定
	 * @throws TecSystemException
	 */
	private void setDisplayContents() {

		if (CarCheckMenuId.ENTER_CHECK.toString().equals(sessionBean.getMenuId())) {
			// 入庫検査
			titleLabel = CarCheckTitle.ENTER_CHECK.getTitleLabel();
			labelConditionDate = "入庫検査日";
			radiovaluesKoutei = CarCheckConst.ENTERCHECK_INCOMPLETE + "|入庫検査未完了,"
							  + CarCheckConst.ENTERCHECK_COMPLETE 	+ "|入庫検査完了,"
							  + CarCheckConst.ENTERCHECK_RESERVE 	+ "|保留";

			radiovaluesKubun  = CarCheckConst.ENTERCHECK_COMPLETE 	+ "|入庫検査完了,"
							  + CarCheckConst.ENTERCHECK_RESERVE 	+ "|保留(不備)";

		} else if (CarCheckMenuId.WORK_SORT.toString().equals(sessionBean.getMenuId())) {
			// 作業仕分
			titleLabel = CarCheckTitle.WORK_SORT.getTitleLabel();
			labelConditionDate = "仕分完了日";
			radiovaluesKoutei = CarCheckConst.WORKSORT_INCOMPLETE 	+ "|仕分未完了,"
							  + CarCheckConst.WORKSORT_COMPLETE 	+ "|仕分完了,"
							  + CarCheckConst.WORKSORT_RESERVE 		+ "|保留";

			radiovaluesKubun  = CarCheckConst.WORKSORT_COMPLETE 	+ "|仕分完了,"
							  + CarCheckConst.WORKSORT_RESERVE 		+ "|保留(不備)";
		}

	}

	/** サービス呼び出し用URL設定 */
	private void setServiceURLs() throws HelperBeanException {
		serviceUrlInit 		= getServiceUrl(CarCheckServiceId.CAR_CHECK_INIT);
		serviceUrlSearch	= getServiceUrl(CarCheckServiceId.CAR_CHECK_SEARCH);
		serviceUrlClear		= getServiceUrl(CarCheckServiceId.CAR_CHECK_CLEAR);
		serviceUrlSort		= getServiceUrl(CarCheckServiceId.CAR_CHECK_SORTING);
		serviceUrlRegister 	= getServiceUrl(CarCheckServiceId.CAR_CHECK_REGISTER);
		serviceUrlCancel 	= getServiceUrl(CarCheckServiceId.CAR_CHECK_CANCEL);

		serviceUrlRegisterAndDownload 	= getServiceUrl(CarCheckServiceId.CAR_CHECK_REGISTER_AND_DOWNLOAD);
		serviceUrlTransRegister 		= getServiceUrl(CarCheckServiceId.CAR_CHECK_TRANS_REGISTER);
		serviceUrlDownloadHansyutu 		= getServiceUrl(CarCheckServiceId.CAR_CHECK_DOWNLOAD);
		// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
		serviceUrlSelect	= getServiceUrl(CarCheckServiceId.CAR_CHECK_SELECT);
		// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end
		// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
		serviceUrlAjax 		= getServiceUrl(CarryinServiceId.AJAX);
		// 2012.03.26 T.Hayato 追加 チェック者 追加のため end
	}

	/** 選択ボタンラベル取得 */
	public String getButtonLabelSelect(){
		return UcarButton.SELECT.getButtonLabel();
	}

	/** 条件絞込みボタンラベル取得 */
	public String getButtonLabelSearchCondition(){
		return UcarButton.SEARCH_CONDITION.getButtonLabel();
	}

	/** 条件初期化ボタンラベル取得 */
	public String getButtonLabelClearCondition(){
		return UcarButton.CLEAR_CONDITION.getButtonLabel();
	}

	/** チェックしたデータを登録（搬出表印刷）ボタンラベル取得 */
	public String getButtonLabelCheckRegisterDownload(){
		return UcarButton.CHECK_REGISTER_DOWNLOAD.getButtonLabel();
	}

	/** チェックしたデータの搬出表を印刷ボタンラベル取得 */
	public String getButtonLabelCheckDownload(){
		return UcarButton.CHECK_DOWNLOAD.getButtonLabel();
	}

	/** チェックしたデータを登録ボタンラベル取得 */
	public String getButtonLabelCheckRegister(){
		return UcarButton.CHECK_REGISTER.getButtonLabel();
	}

	/** チェックしたデータを取消ボタンラベル取得 */
	public String getButtonLabelCheckCancel(){
		return UcarButton.CHECK_CANCEL.getButtonLabel();
	}

	/** 操作方法ラジオボタン出力値取得 */
	public String getRadiovalues(){
		return UcarRadioButton.operate_input.getRadiovalues();
	}

	/**
	 * serviceUrlInitを取得する。
	 * @return serviceUrlInit
	 */
	public String getServiceUrlInit() {
		return serviceUrlInit;
	}

	/**
	 * serviceUrlSearchを取得する。
	 * @return serviceUrlSearch
	 */
	public String getServiceUrlSearch() {
		return serviceUrlSearch;
	}

	/**
	 * serviceUrlClearを取得する。
	 * @return serviceUrlClear
	 */
	public String getServiceUrlClear() {
		return serviceUrlClear;
	}

	/**
	 * serviceUrlSortを取得する。
	 * @return serviceUrlSort
	 */
	public String getServiceUrlSort() {
		return serviceUrlSort;
	}

	/**
	 * serviceUrlRegisterAndDownloadを取得する。
	 * @return serviceUrlRegisterAndDownload
	 */
	public String getServiceUrlRegisterAndDownload() {
		return serviceUrlRegisterAndDownload;
	}

	/**
	 * serviceUrlRegisterを取得する。
	 * @return serviceUrlRegister
	 */
	public String getServiceUrlRegister() {
		return serviceUrlRegister;
	}

	/**
	 * serviceUrlCancelを取得する。
	 * @return serviceUrlCancel
	 */
	public String getServiceUrlCancel() {
		return serviceUrlCancel;
	}

	/**
	 * serviceUrlTransRegisterを取得する。
	 * @return serviceUrlTransRegister
	 */
	public String getServiceUrlTransRegister() {
		return serviceUrlTransRegister;
	}

	/**
	 * serviceUrlDownloadHansyutuを取得する。
	 * @return serviceUrlDownloadHansyutu
	 */
	public String getServiceUrlDownloadHansyutu() {
		return serviceUrlDownloadHansyutu;
	}

	public String getServiceUrlSelect() {
		return serviceUrlSelect;
	}

	/**
	 * serviceUrlAjaxを取得する。
	 * @return serviceUrlAjax
	 */
	public String getServiceUrlAjax() {
		return serviceUrlAjax;
	}

	/**
	 * sessionBeanを取得する。
	 * @return sessionBean
	 */
	public CarCheckSessionBean getSessionBean() {
		return sessionBean;
	}

	/**
	 * targetServiceIdを取得する。
	 * @return targetServiceId
	 */
	public CarCheckServiceId getTargetServiceId() {
		return targetServiceId;
	}

	/**
	 * cdKouteiListを取得する。
	 * @return cdKouteiList
	 */
	public ArrayList<HashMap<String, String>> getCdKouteiList() {
		return cdKouteiList;
	}

	/**
	 * carCheckDataListを取得する。
	 * @return carCheckDataList
	 */
	public List<CarCheckDataBean> getCarCheckDataList() {
		return carCheckDataList;
	}

	/**
	 * totalRecordCountを取得する。
	 * @return totalRecordCount
	 */
	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	/**
	 * titleLabelを取得する。
	 * @return titleLabel
	 */
	public String getTitleLabel() {
		return titleLabel;
	}

	/**
	 * labelConditionDateを取得する。
	 * @return labelConditionDate
	 */
	public String getLabelConditionDate() {
		return labelConditionDate;
	}

	/**
	 * radiovaluesKouteiを取得する。
	 * @return radiovaluesKoutei
	 */
	public String getRadiovaluesKoutei() {
		return radiovaluesKoutei;
	}

	public String getMenuIdEnterCheck() {
		return CarCheckMenuId.ENTER_CHECK.getMenuId();
	}

	public String getMenuIdWorkSort() {
		return CarCheckMenuId.WORK_SORT.getMenuId();
	}

	// 2012.01.30 T.Hayato 修正 システム全体 共通定数化 start
	public String getCarCheckExecuteRegister() {
		return UcarConst.EXECUTE_REGISTER;
	}
	public String getCarCheckExecuteReserve() {
		return UcarConst.EXECUTE_RESERVE;
	}
	public String getCarCheckExecuteCancel() {
		return UcarConst.EXECUTE_CANCEL;
	}
	public String getCarCheckExecuteSelect() {
		return UcarConst.EXECUTE_SELECT;
	}
	// 2012.01.30 T.Hayato 修正 システム全体 共通定数化 end

	/**
	 * radiovaluesKubunを取得する。
	 * @return radiovaluesKubun
	 */
	public String getRadiovaluesKubun() {
		return radiovaluesKubun;
	}

	/**
	 * searchSituationを取得する。
	 * @return searchSituation
	 */
	public String getSearchSituation() {
		return searchSituation;
	}

	/**
	 * NOT_SEARCHを取得する。
	 * @return NOT_SEARCH
	 */
	public String getNOT_SEARCH() {
		return NOT_SEARCH;
	}

	/**
	 * lIST_DATA_ZEROを取得する。
	 * @return lIST_DATA_ZERO
	 */
	public String getLIST_DATA_ZERO() {
		return LIST_DATA_ZERO;
	}

	/**
	 * lIST_DATA_NOT_ZEROを取得する。
	 * @return lIST_DATA_NOT_ZERO
	 */
	public String getLIST_DATA_NOT_ZERO() {
		return LIST_DATA_NOT_ZERO;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize
	 */
	public String getPageSize() {
		return pageSize;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}

	public CarCheckServiceId getServiceIdSorting() {
		return CarCheckServiceId.CAR_CHECK_SORTING;
	}

	public CarCheckServiceId getServiceIdSearch() {
		return CarCheckServiceId.CAR_CHECK_SEARCH;
	}

	public CarCheckServiceId getServiceIdReturnRegister() {
		return CarCheckServiceId.CAR_CHECK_RETURN_REGISTER;
	}

	public CarCheckServiceId getServiceIdRegister() {
		return CarCheckServiceId.CAR_CHECK_REGISTER;
	}

	public CarCheckServiceId getServiceIdRegisterAndDownload() {
		return CarCheckServiceId.CAR_CHECK_REGISTER_AND_DOWNLOAD;
	}

	/**
	 * downloadFilePathを取得する。
	 * @return downloadFilePath
	 */
	public String getDownloadFilePath() {
		return downloadFilePath;
	}

	/**
	 * selectMessageを取得する。
	 * @return selectMessage
	 */
	public String getSelectMessage() {
		return selectMessage;
	}

	/**
	 * ENTER_CHECK_PAGE_SIZEを取得する。
	 * @return ENTER_CHECK_PAGE_SIZE
	 */
	public String getENTER_CHECK_PAGE_SIZE() {
		return ENTER_CHECK_PAGE_SIZE;
	}

	// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
	/**
	 * 車両搬入関連AjaxサービスID
	 * CarryinAjaxServiceId.GET_KJ_SYAINMEIを取得する。
	 * @return CarryinAjaxServiceId.GET_KJ_SYAINMEI
	 */
	public String getKjSyainmei() {
		return CarryinAjaxServiceId.GET_KJ_SYAINMEI.toString();
	}
	// 2012.03.26 T.Hayato 追加 チェック者 追加のため end
}
