package com.toyotec_jp.ucar.workflow.carryout.register.model.data;

import java.sql.Timestamp;
import java.util.Date;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryout.register.model.object.CarryoutRegisterDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出登録DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public interface CarryoutRegisterDAOIF {

	/**
	 * 車両搬出登録 画面出力値取得処理
	 * @param	t220001gPkBean  車両搬入情報 プライマリーキーBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<CarryoutRegisterDataBean> selectT220001G(Ucaa001gPKBean t220001gPkBean,
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																	String loginCdTenpo,
																	String loginKbScenter) throws TecDAOException;
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	/**
	 * 仕入種別情報取得処理
	 * @param	t220001gPkBean  車両搬入情報 プライマリーキーBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucaa002gBean> selectT220002G(Ucaa001gPKBean t220001gPkBean) throws TecDAOException;														

	/**
	 * チェック内容情報取得処理
	 * @param	t220001gPkBean  車両搬入情報 プライマリーキーBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucaa003gBean> selectT220003G(Ucaa001gPKBean t220001gPkBean,
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
														String loginCdTenpo,
														String loginKbScenter) throws TecDAOException;
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	/**
	 * 車両搬出情報取得処理
	 * <pre>
	 * 取得項目：作業工程区分、搬出日、更新日
	 * </pre>
	 * @param	t220001gPkBean  車両搬入情報 プライマリーキーBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//	public ResultArrayList<T220013gBean> selectT220013G(Ucaa001gPKBean t220001gPkBean) throws TecDAOException;
	public ResultArrayList<Uccb009gBean> selectT220013G(Ucaa001gPKBean t220001gPkBean,
														String loginCdTenpo,
														String loginKbScenter) throws TecDAOException;
														// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

	/**
	 * 加修フラグ取得処理
	 * @param	t220014mBean    作業工程マスタBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucac002mBean> selectKbKasyu(String cdKaisya,
														String cdHanbaitn,
														String kbSgyokt) throws TecDAOException;

	/**
	 * 新規登録処理（車両搬出情報）
	 * @param	t220013gBean    車両搬出情報Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//	public SimpleExecuteResultBean insertT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean insertT220013G(Uccb009gBean t220013gBean,
													String loginCdTenpo,
													String loginKbScenter,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（車両搬出情報）
	 * @param	t220013gBean    車両搬出情報Bean
	 * @param	t220013gDtKosin 車両搬出情報：データ更新日時(排他チェック用)
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//	public SimpleExecuteResultBean updateT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean updateT220013G(Uccb009gBean t220013gBean,
													String loginCdTenpo,
													String loginKbScenter,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
													String t220013gDtKosin,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 削除処理（車両搬出情報）
	 * @param	t220013gBean    車両搬出情報Bean
	 * @param	t220013gDtKosin 車両搬出情報：データ更新日時(排他チェック用)
	 * @throws TecDAOException DAO例外クラス
	 */
	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//	public SimpleExecuteResultBean deleteT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean deleteT220013G(Uccb009gBean t220013gBean,
													String loginCdTenpo,
													String loginKbScenter,
													// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
												   String t220013gDtKosin) throws TecDAOException;

	// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため start
	/**
	 * 新規登録処理（ステータスDB）
	 * @param	t220012gInputDataBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean insertT220012G(Uccb007gInputDataBean t220012gInputDataBean,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（ステータスDB）
	 * @param	t220012gInputDataBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean updateT220012G(Uccb007gInputDataBean t220012gInputDataBean,
													Timestamp executeDate) throws TecDAOException;
	// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため end

	// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため start
	/**
	 * ステータス19取得処理
	 * @param	t220001gPkBean	車両搬入情報 プライマリーキーBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public Date selectDtStatus09(Ucaa001gPKBean t220001gPkBean,
												// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
												String loginCdTenpo,
												String loginKbScenter) throws TecDAOException;
												// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
	// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため end
	
	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * 在庫店舗コード取得処理（車両搬出情報(店舗用)）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param	cdHstenpo 配車店舗コード
	 * @throws TecDAOException DAO例外クラス
	 */
	public ResultArrayList<Uccb009gBean> selectCdZaitenpo(String cdKaisya,
															String cdHanbaitn,
															String ddHannyu,
															String noKanri,
															String cdHstenpo) throws TecDAOException;

	/**
	 * 店舗短縮名称取得処理（共通店舗DB）
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	cdTenpo 店舗コード
	 * @return kjTentanms 店舗短縮名称
	 * @throws TecDAOException DAO例外クラス
	 */
	public String selectKjTentanms(String cdKaisya,
									String cdHanbaitn,
									String cdTenpo) throws TecDAOException;
	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　end
	

	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
	/**
	 * 更新処理（車両搬入情報）
	 * @param	t220001gBean    車両搬入情報Bean
	 * @param	t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220001G(Ucaa001gBean t220001gBean,
	public SimpleExecuteResultBean updateT220001G(Ucaa001gBean t220001gBean,
													String loginKbScenter,
													String t220001gDtKosin,
													Timestamp executeDate) throws TecDAOException;
	
	/**
	 * 更新処理（ステータスDB）
	 * @param	t220012gBean    ステータスDBBean
	 * @param	t220012gDtKosin ステータスDB：データ更新日時(排他チェック用)
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220001G(Ucaa001gBean t220001gBean,
	public SimpleExecuteResultBean updateT220012G(Ucab007gBean t220012gBean,
													String loginKbScenter,
													String t220012gDtKosin,
													Timestamp executeDate) throws TecDAOException;
	
	/**
	 * 社員DBリスト取得。
	 * @param  cdKaisya 会社コード
	 * @param  cdHanbaitn 販売店コード
	 * @param  cdSyain 社員コード
	 * @return 社員DBリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<SyainDBBean> getSyainDBList(String cdKaisya, String cdHanbaitn, String cdSyain) throws TecDAOException;
	
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end
	
}