package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;

/**
 * <strong>作業仕分取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/24 新規作成<br>
 * @since 1.00
 * @category [[作業仕分]]
 */
public class GetWorkSortDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 作業仕分Beanリスト */
	private List<CarCheckDataBean> carCheckDataList;
	/** 合計レコード数 */
	private int totalRecordCount;

	/**
	 * carCheckDataListを取得する。
	 * @return carCheckDataList
	 */
	public List<CarCheckDataBean> getCarCheckDataList() {
		return carCheckDataList;
	}

	/**
	 * carCheckDataListを設定する。
	 * @param carCheckDataList
	 */
	public void setCarCheckDataList(List<CarCheckDataBean> carCheckDataList) {
		this.carCheckDataList = carCheckDataList;
	}

	/**
	 * totalRecordCountを取得する。
	 * @return totalRecordCount
	 */
	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	/**
	 * totalRecordCountを設定する。
	 * @param totalRecordCount
	 */
	public void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

}
