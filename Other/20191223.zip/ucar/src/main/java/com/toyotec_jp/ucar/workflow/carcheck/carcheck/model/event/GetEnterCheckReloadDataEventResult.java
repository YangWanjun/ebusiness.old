package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;

/**
 * <strong>入庫検査再取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/23 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class GetEnterCheckReloadDataEventResult implements UcarEventResult {

	/**  */
	private static final long serialVersionUID = 5660570503669216103L;

	/** 入庫検査Beanリスト */
	private List<CarCheckDataBean> carCheckDataList;

	/**
	 * carCheckDataListを取得する。
	 * @return carCheckDataList
	 */
	public List<CarCheckDataBean> getCarCheckDataList() {
		return carCheckDataList;
	}

	/**
	 * carCheckDataListを設定する。
	 * @param carCheckDataList
	 */
	public void setCarCheckDataList(List<CarCheckDataBean> carCheckDataList) {
		this.carCheckDataList = carCheckDataList;
	}

}
