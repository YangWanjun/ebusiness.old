package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean;

/**
 * <strong>配送候補連携DB操作用イベントリスナ(作業仕分用)</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/22 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class WorkSortHaisoKouhoRenkeiEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		WorkSortHaisoKouhoRenkeiEvent targetEvent = (WorkSortHaisoKouhoRenkeiEvent) event;
		Ucaa001gPKBean t220001gPKBean = targetEvent.getUcaa001gPKBean();

		// 実行日時の生成
		Timestamp executeDate 	= new Timestamp(System.currentTimeMillis());
		String executeUserId 	= targetEvent.getUserInfo().getUserID();

		HaisoKouhoRenkeiDAOIF dao
			= getDAO(UcarDAOKey.HAISO_KOUHO_RENKEI_DAO, event, HaisoKouhoRenkeiDAOIF.class);

		// 配送候補連携に登録するデータ取得
		Tbjla24mBean tbjla24mBean = dao.selectHaisorenkei(t220001gPKBean.getCdKaisya(),
														t220001gPKBean.getCdHanbaitn(),
														t220001gPKBean.getDdHannyu(),
														t220001gPKBean.getNoKanri());

		tbjla24mBean.setCdSksisya(executeUserId);
		tbjla24mBean.setCdKsnsya(executeUserId);
		tbjla24mBean.setCdSksiapp(targetEvent.getExecuteAppId());
		tbjla24mBean.setCdKsnapp(targetEvent.getExecuteAppId());

		try {
			// 接続確認(アドイン)
			dao.selectTbjla24mCount(t220001gPKBean.getCdKaisya(),
									t220001gPKBean.getCdHanbaitn());

			// 配送候補連携への処理
			executeTbjla24m(dao,
							targetEvent.getExecuteMode(),
							tbjla24mBean,
							executeDate);

		} catch (TecDAOException e) {
			// 配送候補連携(アドイン)に接続できなかった場合
//			if (e.getMessage().indexOf(UcarConst.ERROR_NO_CONNECT) != -1) {

				// 配送候補連携BUFFERへの処理
				executeT220015w(dao,
								targetEvent.getExecuteMode(),
								tbjla24mBean,
								executeDate);

//			} else {
//				// それ以外はエラー
//				throw e;
//			}
		}
		return null;
	}

	/**
	 * 配送候補連携処理
	 * <pre>
	 * アドインへの接続が可能な場合
	 * </pre>
	 * @param dao
	 * @param ExecuteMode
	 * @param tbjla24mBean
	 * @param executeDate
	 * @throws TecDAOException
	 */
	private void executeTbjla24m(HaisoKouhoRenkeiDAOIF dao,
									String ExecuteMode,
									Tbjla24mBean tbjla24mBean, Timestamp executeDate)
									throws TecDAOException {

		ResultArrayList<Tbjla24mBean> tbjla24mList = dao.selectTbjla24m(tbjla24mBean.getCdKaisya(),
																		tbjla24mBean.getCdHanbaitn(),
																		tbjla24mBean.getDdHannyu(),
																		tbjla24mBean.getNoKanri(),
																		false);

		if (UcarConst.EXECUTE_REGISTER.equals(ExecuteMode)) {
			// 完了登録の場合
			if (tbjla24mList.size() > 0) {
				dao.updateTbjla24mWorkSort(tbjla24mBean, executeDate);
			} else {
				dao.insertTbjla24m(tbjla24mBean, executeDate);
			}
		} else {
			// 保留登録、取消の場合
			if (tbjla24mList.size() > 0) {
				// 削除処理
				dao.deleteTbjla24m(tbjla24mBean.getCdKaisya(),
									tbjla24mBean.getCdHanbaitn(),
									tbjla24mBean.getDdHannyu(),
									tbjla24mBean.getNoKanri());
			}
		}
	}

	/**
	 * 配送候補連携BUFFER処理
	 * <pre>
	 * アドインへの接続が不可能な場合
	 * </pre>
	 * @param dao
	 * @param ExecuteMode
	 * @param tbjla24mBean
	 * @param executeDate
	 * @throws TecDAOException
	 */
	private void executeT220015w(HaisoKouhoRenkeiDAOIF dao,
									String ExecuteMode,
									Tbjla24mBean tbjla24mBean,
									Timestamp executeDate) throws TecDAOException {

		Ucac003wBean t220015wBean = new Ucac003wBean(tbjla24mBean);

		ResultArrayList<Ucac003wBean> t220015wList
			= dao.selectT220015w(tbjla24mBean.getCdKaisya(),
								tbjla24mBean.getCdHanbaitn(),
								tbjla24mBean.getDdHannyu(),
								tbjla24mBean.getNoKanri());

		if (UcarConst.EXECUTE_REGISTER.equals(ExecuteMode)) {
			// 完了登録
			if (t220015wList.size() > 0) {
				dao.updateT220015wWorkSort(t220015wBean, executeDate);
			} else {
				dao.insertT220015w(t220015wBean, executeDate);
			}
		} else {
			// 保留登録、取消の場合
			Ucac003wBean t220015wDelBean = new Ucac003wBean(t220015wBean.getCdKaisya(),
															t220015wBean.getCdHanbaitn(),
															t220015wBean.getDdHannyu(),
															t220015wBean.getNoKanri(),
															t220015wBean.getCdSksisya(),
															t220015wBean.getCdKsnsya(),
															t220015wBean.getCdSksiapp(),
															t220015wBean.getCdKsnapp());

			t220015wDelBean.setCdNorikusi(UcarConst.CD_NORIKUSI_DEL);

			if (t220015wList.size() > 0) {
				dao.updateT220015wDel(t220015wDelBean, executeDate);
			} else {
				dao.insertT220015w(t220015wDelBean, executeDate);
			}
		}
	}
}
