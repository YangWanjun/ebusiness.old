/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】ReflectionUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/07/21 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map.Entry;

import com.toyotec_jp.im_common.system.model.object.MethodInfoBean;


/**
 * <strong>リフレクション系ユーティリティクラス。</strong>
 * <p>
 * リフレクション関連支援処理を管理するクラス。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/21 新規作成<br>
 * @since 1.00
 */
public class ReflectionUtils {

	// ビーン用メソッド種別
	private static enum BeanMethodType{
		GETTER, SETTER;
	}

	/**
	 * ビーンのゲッターを取得。
	 * @param beanClass
	 * @return ビーン用ゲッターハッシュマップ(キー：フィールド名、値：ビーン用ゲッターを格納したメソッド情報ビーン)
	 */
	public static HashMap<String, MethodInfoBean> getBeanGetterMap(Class<?> beanClass){
		HashMap<String, Field> fieldMap = getBeanFieldMap(beanClass);
		return getBeanGetterMap(beanClass, fieldMap);
	}

	/**
	 * ビーンのゲッターを取得。
	 * @param beanClass
	 * @param fieldMap
	 * @return ビーン用ゲッターハッシュマップ(キー：フィールド名、値：ビーン用ゲッターを格納したメソッド情報ビーン)
	 */
	public static HashMap<String, MethodInfoBean> getBeanGetterMap(Class<?> beanClass, HashMap<String, Field> fieldMap){
		HashMap<String, MethodInfoBean> resultMap = new HashMap<String, MethodInfoBean>();
		setMethodMap(resultMap, fieldMap, beanClass, BeanMethodType.GETTER);
		return resultMap;
	}

	/**
	 * ビーンのセッターを取得。
	 * @param beanClass
	 * @return ビーン用セッターハッシュマップ(キー：フィールド名、値：ビーン用セッターを格納したメソッド情報ビーン)
	 */
	public static HashMap<String, MethodInfoBean> getBeanSetterMap(Class<?> beanClass){
		HashMap<String, Field> fieldMap = getBeanFieldMap(beanClass);
		return getBeanSetterMap(beanClass, fieldMap);
	}

	/**
	 * ビーンのセッターを取得。
	 * @param beanClass
	 * @param fieldMap
	 * @return ビーン用セッターハッシュマップ(キー：フィールド名、値：ビーン用セッターを格納したメソッド情報ビーン)
	 */
	public static HashMap<String, MethodInfoBean> getBeanSetterMap(Class<?> beanClass, HashMap<String, Field> fieldMap){
		HashMap<String, MethodInfoBean> resultMap = new HashMap<String, MethodInfoBean>();
		setMethodMap(resultMap, fieldMap, beanClass, BeanMethodType.SETTER);
		return resultMap;
	}

	// メソッドマップ設定
	private static void setMethodMap(
			HashMap<String, MethodInfoBean> methodInfoMap, HashMap<String, Field> fieldMap,
			Class<?> beanClass, BeanMethodType type){
		if(beanClass != null && !Object.class.equals(beanClass)){
			for(Entry<String, Field> fieldEntry : fieldMap.entrySet()){
				// サブクラスのメソッド優先のため取得済みの場合は無視
				String fieldName = fieldEntry.getKey();
				Field field = fieldEntry.getValue();
				if(!methodInfoMap.containsKey(fieldName)){
					// メソッド情報取得
					Method method = null;
					switch (type) {
						case GETTER:
							method = getGetterMethod(beanClass, field);
							break;
						case SETTER:
							method = getSetterMethod(beanClass, field);
							break;
						default:
							break;
					}
					// メソッドがある場合のみ設定
					if(method != null){
						MethodInfoBean methodInfoBean = new MethodInfoBean();
						methodInfoBean.setFieldType(field.getType());
						methodInfoBean.setFieldName(fieldName);
						methodInfoBean.setColumnName(StringUtils.convFieldToColumnName(fieldName));
						methodInfoBean.setMethod(method);
						methodInfoMap.put(fieldName, methodInfoBean);
					}
				}
			}
			// 再帰
			setMethodMap(methodInfoMap, fieldMap, beanClass.getSuperclass(), type);
		}
	}

	// ゲッターメソッド取得
	private static Method getGetterMethod(Class<?> beanClass, Field field){
		Method method = null;
		try {
			String methodName = StringUtils.getGetterName(field);
			method = beanClass.getMethod(methodName);
		} catch (SecurityException e) {
			// メソッドがpublicではない場合は対象外
		} catch (NoSuchMethodException e) {
			// メソッド無しの場合は対象外
		}
		return method;
	}

	// セッターメソッド取得
	private static Method getSetterMethod(Class<?> beanClass, Field field){
		Method method = null;
		try {
			String methodName = StringUtils.getSetterName(field);
			method = beanClass.getMethod(methodName, field.getType());
		} catch (SecurityException e) {
			// メソッドがpublicではない場合は対象外
		} catch (NoSuchMethodException e) {
			// メソッド無しの場合は対象外
		}
		return method;
	}

//	// メソッドマップ設定
//	private static void setMethodMap(
//			HashMap<String, Method> setterMap, HashMap<String, Field> fieldMap, Class<?> beanClass, BeanMethodType type){
//		if(beanClass != null && !Object.class.equals(beanClass)){
//			for(Entry<String, Field> fieldEntry : fieldMap.entrySet()){
//				// サブクラスのメソッド優先のため取得済みの場合は無視
//				String fieldName = fieldEntry.getKey();
//				if(!setterMap.containsKey(fieldName)){
//					Field field = fieldEntry.getValue();
//					// メソッド名取得
//					String methodName = null;
//					Method method = null;
//					try {
//						switch (type) {
//							case GETTER:
//								methodName = StringUtils.getGetterName(field);
//								method = beanClass.getMethod(methodName);
//								break;
//							case SETTER:
//								methodName = StringUtils.getSetterName(field);
//								method = beanClass.getMethod(methodName, field.getType());
//								break;
//							default:
//								break;
//						}
//						setterMap.put(fieldName, method);
//					} catch (SecurityException e) {
//						// メソッドがpublicではない場合は対象外
//					} catch (NoSuchMethodException e) {
//						// メソッド無しの場合は対象外
//					}
//				}
//			}
//			// 再帰
//			setMethodMap(setterMap, fieldMap, beanClass.getSuperclass(), type);
//		}
//	}

	/**
	 * ビーンのフィールドを取得。
	 * @param beanClass
	 * @return ビーン用フィールドハッシュマップ(キー：フィールド名、値：フィールド)
	 */
	public static HashMap<String, Field> getBeanFieldMap(Class<?> beanClass){
		HashMap<String, Field> resultMap = new HashMap<String, Field>();
		setFieldMap(resultMap, beanClass);
		return resultMap;
	}

	// フィールドマップ設定
	private static void setFieldMap(HashMap<String, Field> fieldMap, Class<?> beanClass){
		if(beanClass != null && !Object.class.equals(beanClass)){
			Field[] fields = beanClass.getDeclaredFields();
			for(Field field : fields){
				String fieldName = field.getName();
				if(!fieldMap.containsKey(fieldName)){
					fieldMap.put(fieldName, field);
				}
			}
			// 再帰
			setFieldMap(fieldMap, beanClass.getSuperclass());
		}
	}

}
