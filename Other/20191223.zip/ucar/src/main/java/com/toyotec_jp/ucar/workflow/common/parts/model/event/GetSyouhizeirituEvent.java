package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.util.Date;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;


/**
 * <strong>消費税率取得イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/16 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetSyouhizeirituEvent extends UcarEvent {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** 会社コード */
	private String cdKaisya;
	/** 事業所コード */
	private String cdJigyosyo;
	/** 取得対象日付
	 * <p>
	 * 日付をセットすることで、対象日付時点の消費税を取得する
	 * <p>
	 *  */
	private Date targetDate;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdJigyosyoを取得する。
	 * @return cdJigyosyo
	 */
	public String getCdJigyosyo() {
		return cdJigyosyo;
	}

	/**
	 * cdJigyosyoを設定する。
	 * @param cdJigyosyo
	 */
	public void setCdJigyosyo(String cdJigyosyo) {
		this.cdJigyosyo = cdJigyosyo;
	}

	/**
	 * targetDateを取得する。
	 * @return targetDate
	 */
	public Date getTargetDate() {
		return targetDate;
	}

	/**
	 * targetDateを設定する。
	 * @param targetDate
	 */
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

}
