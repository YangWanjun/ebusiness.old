package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>checkvalues用データ取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/17 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetCheckvaluesEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 仕入種別マスタcheckvalues */
	private String t220004mCheckvalues;
	/** チェック内容マスタcheckvalues */
	private String t220005mCheckvalues;
	/** 作業工程マスタ(加修なし)checkvalues */
	private String t220014mNotRepairCheckvalues;
	/** 作業工程マスタ(加修あり)checkvalues */
	private String t220014mRepairCheckvalues;

	/**
	 * t220004mCheckvaluesを取得する。
	 * @return t220004mCheckvalues
	 */
	public String getT220004mCheckvalues() {
		return t220004mCheckvalues;
	}

	/**
	 * t220004mCheckvaluesを設定する。
	 * @param t220004mCheckvalues
	 */
	public void setT220004mCheckvalues(String t220004mCheckvalues) {
		this.t220004mCheckvalues = t220004mCheckvalues;
	}

	/**
	 * t220005mCheckvaluesを取得する。
	 * @return t220005mCheckvalues
	 */
	public String getT220005mCheckvalues() {
		return t220005mCheckvalues;
	}

	/**
	 * t220005mCheckvaluesを設定する。
	 * @param t220005mCheckvalues
	 */
	public void setT220005mCheckvalues(String t220005mCheckvalues) {
		this.t220005mCheckvalues = t220005mCheckvalues;
	}

	/**
	 * t220014mNotRepairCheckvaluesを取得する。
	 * @return t220014mNotRepairCheckvalues
	 */
	public String getT220014mNotRepairCheckvalues() {
		return t220014mNotRepairCheckvalues;
	}

	/**
	 * t220014mNotRepairCheckvaluesを設定する。
	 * @param t220014mNotRepairCheckvalues
	 */
	public void setT220014mNotRepairCheckvalues(String t220014mNotRepairCheckvalues) {
		this.t220014mNotRepairCheckvalues = t220014mNotRepairCheckvalues;
	}

	/**
	 * t220014mRepairCheckvaluesを取得する。
	 * @return t220014mRepairCheckvalues
	 */
	public String getT220014mRepairCheckvalues() {
		return t220014mRepairCheckvalues;
	}

	/**
	 * t220014mRepairCheckvaluesを設定する。
	 * @param t220014mRepairCheckvalues
	 */
	public void setT220014mRepairCheckvalues(String t220014mRepairCheckvalues) {
		this.t220014mRepairCheckvalues = t220014mRepairCheckvalues;
	}

}
