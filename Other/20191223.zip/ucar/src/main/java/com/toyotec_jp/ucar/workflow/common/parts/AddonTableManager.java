package com.toyotec_jp.ucar.workflow.common.parts;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarIdentifier;

/**
 * <strong>アドオンテーブル管理クラス</strong>
 * <p>
 * </p>
 * @author H.T(TEC)
 * @version 1.00 2013/02/06 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通) アドオンテーブル管理クラス]]
 */
public class AddonTableManager {

	private static String KyoutuTenpoTBL = UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.addonTable.KyoutuTenpo");
	private static String RikusiCodeTBL = UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.addonTable.RikusiCode");
	private static String SyainTBL  = UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.addonTable.Syain");
	private static String CodeKubunTBL = UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.addonTable.CodeKubun");
	private static String HaisoKouhoRenkeiTBL = UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.addonTable.HaisoKouhoRenkei");
	
	/**
	 * 共通店舗DB（TBV0201M）取得
	 * <pre>
	 * 販売店コードに合わせた正式なテーブル名を取得する
	 * </pre>
	 * @param cdHanbaitn 販売店コード
	 * @return テーブル名<br>
	 * （例）：引数が13601の場合、TBV0201M_PTがString型で返却される
	 * @throws TecSystemException
	 */
	public static String getKyoutuTenpo(String cdHanbaitn) {
		return getAddonTable(cdHanbaitn, KyoutuTenpoTBL);
	}
	public static String getKyoutuTenpo(String cdHanbaitn,String alias) {
		return getAddonTable(cdHanbaitn, KyoutuTenpoTBL+alias);
	}

	/**
	 * 陸支コードDB（TBV0213M）取得
	 * <pre>
	 * 販売店コードに合わせた正式なテーブル名を取得する
	 * </pre>
	 * @param cdHanbaitn 販売店コード
	 * @return テーブル名<br>
	 * （例）：引数が13601の場合、TBV0213M_PTがString型で返却される
	 * @throws TecSystemException
	 */
	public static String getRikusiCode(String cdHanbaitn) {
		return getAddonTable(cdHanbaitn, RikusiCodeTBL);
	}

	/**
	 * 社員DB（TBV0214M）取得
	 * <pre>
	 * 販売店コードに合わせた正式なテーブル名を取得する
	 * </pre>
	 * @param cdHanbaitn 販売店コード
	 * @return テーブル名<br>
	 * （例）：引数が13601の場合、TBV0214M_PTがString型で返却される
	 * @throws TecSystemException
	 */
	public static String getSyain(String cdHanbaitn) {
		return getAddonTable(cdHanbaitn, SyainTBL);
	}

	/**
	 * コード区分DB（TBV0231M）取得
	 * <pre>
	 * 販売店コードに合わせた正式なテーブル名を取得する
	 * </pre>
	 * @param cdHanbaitn 販売店コード
	 * @return テーブル名<br>
	 * （例）：引数が13601の場合、TBV0231M_PTがString型で返却される
	 * @throws TecSystemException
	 */
	public static String getCodeKubun(String cdHanbaitn) {
		return getAddonTable(cdHanbaitn, CodeKubunTBL);
	}

	/**
	 * 配送候補連携（TBJLA24M）取得
	 * <pre>
	 * 販売店コードに合わせた正式なテーブル名を取得する
	 * </pre>
	 * @param cdHanbaitn 販売店コード
	 * @return テーブル名<br>
	 * （例）：引数が13601の場合、TBJLA24M_PTがString型で返却される
	 * @throws TecSystemException
	 */
	public static String getHaisoKouhoRenkei(String cdHanbaitn) {
		return getAddonTable(cdHanbaitn, HaisoKouhoRenkeiTBL);
	}

	/**
	 * アドオンテーブル名取得
	 * @param cdHanbaitn 販売店コード
	 * @param tableName テーブル名
	 * @return テーブル名 + テーブル接尾辞
	 * @throws TecSystemException
	 */
	public static String getAddonTable(String cdHanbaitn, String tableName) {
		String tableSuffix = getTableSuffix(cdHanbaitn, tableName.substring(0, 8));
/*2019.4.24 from
		return tableName + tableSuffix;
*/		
		StringBuilder rtn = new StringBuilder();
		if(tableSuffix.equals("")){
			//共通店舗テーブルでCW,TML以外はTPCNとLEXUSを合成
			rtn.append(" (");
			rtn.append(" SELECT * FROM TBV0201M P1 ");
			rtn.append("  WHERE P1.CD_KAISYA IN ('01','02','03','05') ");
			rtn.append("    AND P1.KB_DUOTENPO != '6' ");
			rtn.append("    AND P1.CD_TENPO > '000' ");
			rtn.append("    AND P1.CD_TENPO < '98' ");
			rtn.append("    AND EXISTS ( ");
			rtn.append("    SELECT 1 FROM TBV0201M P2 "); 
			rtn.append("    WHERE P2.CD_KAISYA IN ('01','02','03','05') ");
			rtn.append("    AND P1.CD_TENPO = P2.CD_TENPO "); 
			rtn.append("    GROUP BY P2.CD_TENPO ");
			rtn.append("    HAVING COUNT(1) = 1) ");
			rtn.append(" UNION ");
			rtn.append(" SELECT * FROM TBV0201M ");
			rtn.append("  WHERE CD_KAISYA = '06' ");
			rtn.append("    AND KB_DUOTENPO = '6' ");
			rtn.append(") ");
			/*2019.04.26 T.O 削除 tableName不要
			if(tableName.trim().length() == 8){
				rtn.append(tableName);
			}else{
				rtn.append(tableName.substring(8));
			}
			*/
			rtn.append(" ");
		}else{
			if (tableName.equals("TBV0201M")) {
				rtn.append(" (");
				rtn.append(" SELECT * FROM TBV0201M ");
				rtn.append("  WHERE CD_KAISYA = '04' ");
				rtn.append(") ");
				rtn.append(" ");
			} else {
				rtn.append(tableName );
				rtn.append(tableSuffix);
			}
		}
		return rtn.toString();
//2019.4.24 to		
	}

	/**
	 * テーブル接尾辞取得
	 * @param cdHanbaitn 販売店コード
	 * @return 販売店接尾辞（該当しない場合は空白を返す）
	 */
	private static String getTableSuffix(String cdHanbaitn, String tableName) {

		String tableSuffix = "";

		// 販売店ごとの識別子をテーブル名に付加
/*--2019.3.19 from		
		if(UcarConst.TOYOTA.equals(cdHanbaitn)){
			tableSuffix = UcarIdentifier.TOYOTA.toString();
		} else if(UcarConst.TOYOPET.equals(cdHanbaitn)){
			tableSuffix = UcarIdentifier.TOYOPET.toString();
		} else if(UcarConst.COROLLA.toString().equals(cdHanbaitn)){
			tableSuffix = UcarIdentifier.COROLLA.toString();
		} else if(UcarConst.WCOROLLA.toString().equals(cdHanbaitn)){
			tableSuffix = UcarIdentifier.WCOROLLA.toString();
		} else if(UcarConst.NETZ.toString().equals(cdHanbaitn)){
			tableSuffix = UcarIdentifier.NETZ.toString();
		} else {
			tableSuffix = UcarIdentifier.TML.toString();
		}
*/
		if(KyoutuTenpoTBL.equals(tableName)){
			//共通店舗テーブル
			if(UcarConst.WCOROLLA.toString().equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.WCOROLLA.toString();
			} else if(UcarConst.TML.toString().equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.TML.toString();
			}
			
		}else{
			//共通店舗テーブル以外
			if(UcarConst.TOYOTA.equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.TOYOTA.toString();
			} else if(UcarConst.TOYOPET.equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.TOYOPET.toString();
			} else if(UcarConst.COROLLA.toString().equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.COROLLA.toString();
			} else if(UcarConst.WCOROLLA.toString().equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.WCOROLLA.toString();
			} else if(UcarConst.NETZ.toString().equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.NETZ.toString();
//---2019.4.24 from
			} else if(UcarConst.LEXUS.toString().equals(cdHanbaitn)){
				tableSuffix = UcarIdentifier.LEXUS.toString();
//---2019.4.24 to
			} else {
				tableSuffix = UcarIdentifier.TML.toString();
			}
			
		}
//--2019.3.19 to		
		return tableSuffix;
	}

	/**
	 * テーブルの種類
	 * @author 00496_010175
	 */
	public enum tblFormat{
		HANBAITEN,
		RIKUSHI,
		SYAIN,
		IRO,
		HAISO
	}

	/**
	 * ＴＭＬ工程管理用　addonデータ接続先設定
	 * @param cdHanbaitn　		データ販売店
	 * @param cdHanbaitn　		データ販売店
	 * @param loginHanbaitn  	ログイン者　販売店
	 * @return	接続先テーブル
	 */
	public static String getTablesForTml(tblFormat tbl, String cdHanbaitn, String loginHanbaitn){
		String ret = "";
		String hanbaiten = loginHanbaitn;
		//プロパティより取得
		String cdTml = UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.TML");

		//	販売店がＴＭＬなら　データの販売店に仕向け先を変える。
		if(cdTml.equals(loginHanbaitn) && !StringCheckUtils.isEmpty(cdHanbaitn)){
			hanbaiten = cdHanbaitn;
		}
		if (tbl == tblFormat.HANBAITEN){
			ret	=	getKyoutuTenpo(hanbaiten);
		}else if (tbl == tblFormat.RIKUSHI){
			ret	=	getRikusiCode(hanbaiten);
		}else if (tbl == tblFormat.SYAIN){
			ret	=	getSyain(hanbaiten);
		}else if (tbl == tblFormat.IRO){
			ret	=	getCodeKubun(hanbaiten);
		}else if (tbl == tblFormat.HAISO){
			ret	=	getHaisoKouhoRenkei(hanbaiten);
		}

		return ret;
	}

}
