package com.toyotec_jp.ucar.batch.common;

import com.toyotec_jp.im_common.TecApplicationManager.TecApplicationIdIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;
import com.toyotec_jp.ucar.UcarApplicationManager;

/**
 * <strong>バッチ共通定数管理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/09/02 新規作成<br>
 * @since 1.00
 * @category [[バッチ(共通)]]
 */
public class BatchConst {

	/** 月次バッチパッケージルート */
	public static final String MONTHLY_ROOT = UcarApplicationManager.BATCH_ROOT + ".monthly";
	/** 日次バッチパッケージルート */
	public static final String DAILY_ROOT = UcarApplicationManager.BATCH_ROOT + ".daily";

	/** データ削除処理パッケージルート */
	public static final String DATA_CLEANING_ROOT = MONTHLY_ROOT + ".datacleaning";
	/** ファイル削除処理パッケージルート */
	public static final String FILE_CLEANING_ROOT = MONTHLY_ROOT + ".filecleaning";

	/** データ作成処理パッケージルート */
	public static final String DATA_CREATE_ROOT 	= DAILY_ROOT + ".datacreate";

	/** 作業受付台数 */
	public static final String DATA_FLG_SU_SAGYOUKE 		= "SU_SAGYOUKE";
	/** 作業仕掛台数 */
	public static final String DATA_FLG_SU_SAGYOSIKA 		= "SU_SAGYOSIKA";
	/** 作業完成台数 */
	public static final String DATA_FLG_SU_SAGYOKAN 		= "SU_SAGYOKAN";

	/** ヘッドライトクリーニング */
	public static final String DATA_FLG_SU_HEADLIGHT 		= "SU_HEADLIGHT";
	/** BP簡易台数 */
	public static final String DATA_FLG_SU_BPKANI 		= "SU_BPKANI";

	/** 手直し件数 */
	public static final String DATA_FLG_SU_TENAOSI 		= "SU_TENAOSI";

	/** 受注件数：受注日 */
	public static final String DATA_FLG_SU_JUCYU 			= "SU_JUCYU";
	/** 受注件数：受注取消日 */
	public static final String DATA_FLG_SU_JUCYU_CANCEL 	= "SU_JUCYU_CANCEL";

	/** 外注仕入 */
	public static final String DATA_FLG_KI_GAISIIRE		= "KI_GAISIIRE";
	/** 外注仕掛金額 */
	public static final String DATA_FLG_KI_GAISIKA 		= "KI_GAISIKA";

	/** 仕掛件数 */
	public static final String DATA_FLG_SU_SIKAKARI 		= "SU_SIKAKARI";
	/** 売上件数：売上 */
	public static final String DATA_FLG_SU_URIAGE			= "SU_URIAGE";
	/** 売上件数：売上取消 */
	public static final String DATA_FLG_SU_URIAGE_CANCEL 	= "SU_URIAGE_CANCEL";
	/** 売上金額 */
	public static final String DATA_FLG_KI_URIAGE 		= "KI_URIAGE";

	/** インスタンスを生成しない。 */
	private BatchConst(){
	}

	/** バッチ関連メッセージキー */
	public enum BatchMessage implements TecMessageKeyIF {
		/** 該当データがありません。 */
		NOT_FOUND(UcarApplicationManager.WF_ROOT, "I0006"),
		;
		private String messageKey;
		private BatchMessage(String base, String key){
			this.messageKey = base + "." + key;
		}
		public String toString(){
			return messageKey;
		}
		@Override
		public String getMessageKey() {
			return messageKey;
		}
	}

	/** バッチ関連アプリケーションID */
	public enum BatchApplicationId implements TecApplicationIdIF {
		/** データ削除処理 */
		DATA_CLEANING(DATA_CLEANING_ROOT + ".DataCleaning"),
		/** ファイル削除処理 */
		FILE_CLEANING(FILE_CLEANING_ROOT + ".FileCleaning"),
		/** データ作成処理 */
		DATA_CREATE(DATA_CREATE_ROOT + ".DataCreate"),
		;
		private String applicationId;
		private BatchApplicationId(String applicationId){
			this.applicationId = applicationId;
		}
		public String toString(){
			return applicationId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
	}

	/** バッチ関連イベントキー */
	public enum BatchEventKey implements TecEventKeyIF {
		/** データ削除処理 */
		DELETE_DATA_CLEANING(BatchApplicationId.DATA_CLEANING, "DeleteDataCleaningEvent"),
		/** ファイル削除処理 */
		DELETE_FILE_CLEANING(BatchApplicationId.FILE_CLEANING, "DeleteFileCleaningEvent"),
		/** 整備売上日報情報作成処理 */
		CREATE_DATA_SEIBIURIAGENIPPOU(BatchApplicationId.DATA_CREATE, "CreateSeibiUriageNippouEvent"),
		;
		private String applicationId;
		private String eventKey;
		private BatchEventKey(TecApplicationIdIF appId, String eventKey){
			this.applicationId = appId.getApplicationId();
			this.eventKey = eventKey;
		}
		public String toString(){
			return eventKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getEventKey(){
			return eventKey;
		}
	}

	/** バッチ関連DAOキー */
	public enum BatchDAOKey implements TecDAOKeyIF {
		/** データ削除用DAO */
		DATA_CLEANING_DAO(BatchApplicationId.DATA_CLEANING, "DataCleaningDAO"),
		/** 整備売上日報情報作成用DAO */
		DATA_SEIBIURIAGENIPPOU_DAO(BatchApplicationId.DATA_CREATE, "CreateSeibiUriageNippouDAO"),
		;
		private String applicationId;
		private String daoKey;
		private BatchDAOKey(TecApplicationIdIF appId, String daoKey){
			this.applicationId = appId.getApplicationId();
			this.daoKey = daoKey;
		}
		public String toString(){
			return daoKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getDAOKey(){
			return daoKey;
		}
	}

}
