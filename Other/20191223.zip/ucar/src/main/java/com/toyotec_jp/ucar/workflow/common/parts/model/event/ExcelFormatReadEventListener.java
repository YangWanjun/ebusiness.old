package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapKey;
import com.toyotec_jp.im_common.system.docmng.data.DMResultColumn;
import com.toyotec_jp.im_common.system.docmng.data.DMResultList;
import com.toyotec_jp.im_common.system.docmng.data.DMResultSheet;
import com.toyotec_jp.im_common.system.docmng.data.DMSheetMap;
import com.toyotec_jp.im_common.system.docmng.data.DMYoshikiMap;
import com.toyotec_jp.im_common.system.docmng.mng.DMFilesMapManager;
import com.toyotec_jp.im_common.system.docmng.mng.excel.DMExcelManager;
import com.toyotec_jp.im_common.system.docmng.mng.excel.DMCellManager.DMValueKbn;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.exception.TecUnsupportedDataTypeException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageKey;
import com.toyotec_jp.im_common.system.model.object.MethodInfoBean;
import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.im_common.system.utils.IMAppFileManager;
import com.toyotec_jp.im_common.system.utils.IMFileManagerIF;
import com.toyotec_jp.im_common.system.utils.IMStorageServiceManager;
import com.toyotec_jp.im_common.system.utils.ReflectionUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.DocFormatDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.ExcelSheetInfoBean;

/**
 * <strong>Excel読み込みイベントリスナ。</strong>
 * <p>
 * 「com.toyotec_jp.im_common.system.docmng」、「org.apache.poi」を使用してExcel読み込みを実行する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/13 新規作成<br>
 * @since 1.00
 */
public class ExcelFormatReadEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {
		ExcelFormatReadEvent exReadEvent = (ExcelFormatReadEvent)event;
		// Excel読み込み定義情報取得
		DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> mapYoshiki = getExcelReadDef(exReadEvent);

		// ロード
		IMFileManagerIF imFileMng = getIMFileManager(exReadEvent.isAppFilePath());
		byte[] byteArray = imFileMng.loadFile(exReadEvent.getFilePath());
		// ファイル内の値を取得
		DMExcelManager xlsMng = DMExcelManager.getInstance();
		DMResultSheet[] resultSheetInfoArray;
		resultSheetInfoArray = xlsMng.getData(byteArray, mapYoshiki);

		Class<? extends TecBean> singleParamBeanClass = exReadEvent.getSingleParamBeanClass();
		HashMap<String, Class<? extends TecBean>> listParamBeanClassMap = exReadEvent.getListParamBeanClassMap();
		ResultArrayList<ExcelSheetInfoBean> result = new ResultArrayList<ExcelSheetInfoBean>();
		// シート毎の処理
		for(DMResultSheet resultSheetInfo : resultSheetInfoArray){
			ExcelSheetInfoBean excelSheetBean = new ExcelSheetInfoBean();
			setExcelSheetInfo(excelSheetBean, resultSheetInfo);
			setExcelSheetSingleParam(excelSheetBean, resultSheetInfo.getSimpleColumns(), singleParamBeanClass);
			setExcelSheetListParam(excelSheetBean, resultSheetInfo.getResultLists(), listParamBeanClassMap);
			result.add(excelSheetBean);
		}

		return result;
	}

	// 定義情報(GET)取得
	private DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> getExcelReadDef(
			ExcelFormatReadEvent event) throws TecSystemException {
		// 定義情報取得
		String docFormatID = event.getDocFormatID();
		DocFormatDAOIF dfDAOIF = getDAO(UcarDAOKey.DOC_FORMAT_DAO, event, DocFormatDAOIF.class);
		ArrayList<DMFilesMapData> fileMapList = dfDAOIF.getDocFormatDefineList(docFormatID);
		// 定義情報を変換、Excel取得用の定義を抽出
		DMFilesMapManager fMapMng = DMFilesMapManager.getInstance();
		return fMapMng.convMapListToYoshikiMap(
				fileMapList.toArray(new DMFilesMapData[fileMapList.size()]), DMFilesMapData.ShoriKbn.GET);
	}

	// Excelシート情報設定
	private void setExcelSheetInfo(ExcelSheetInfoBean excelSheetBean, DMResultSheet resultSheetInfo){
		excelSheetBean.setSheetIdx(resultSheetInfo.getSheetIdx());
		excelSheetBean.setSheetName(resultSheetInfo.getSheetName());
	}

	// Excelシート通常項目設定
	private void setExcelSheetSingleParam(
			ExcelSheetInfoBean excelSheetBean, DMResultColumn<?>[] simpleColumns,
			Class<?> singleParamBeanClass) throws TecSystemException {
		if(singleParamBeanClass != null){
			// セッター取得
			HashMap<String, MethodInfoBean> setterMap = ReflectionUtils.getBeanSetterMap(singleParamBeanClass);
			// デフォルトコンストラクタ取得
			Constructor<?> singleParamBeanConstructor = getDefaultConstructor(singleParamBeanClass);
			// インスタンス取得
			Object singleParamBeanInstance = getNewInstanceByDefaultConstructor(singleParamBeanConstructor);
			for(DMResultColumn<?> simpleColumn : simpleColumns){
				String colName = simpleColumn.getName();
				if(colName != null){
					String fieldName = StringUtils.convColumnToFieldName(colName);
					if(setterMap.containsKey(fieldName)){
						String value = null;
						if(simpleColumn.getValue() != null){
							value = simpleColumn.getValue().toString();
						}
						// ビーンに対してExcelの値を設定
						setExcelValueToBean(
								singleParamBeanInstance, fieldName, setterMap.get(fieldName).getMethod(),
								simpleColumn.getType(), value);
					}
				}
			}
			excelSheetBean.setSingleParams(singleParamBeanInstance);
		}
	}

	// Excelシートリスト項目設定
	private void setExcelSheetListParam(
			ExcelSheetInfoBean excelSheetBean, DMResultList[] resultLists,
			HashMap<String, Class<? extends TecBean>> listParamBeanClassMap) throws TecSystemException {
		// ビーン側のハッシュマップ参照
		HashMap<String, ArrayList<Object>> listParams = excelSheetBean.getListParams();
		// リスト毎の処理
		for(DMResultList resultList : resultLists){
			String listId = resultList.getListId();
			// リストIDに対応するクラスが存在しない場合は処理しない
			if(listParamBeanClassMap.containsKey(listId)){
				Class<?> listParamBeanClass = listParamBeanClassMap.get(listId);
				// セッター取得
				HashMap<String, MethodInfoBean> setterMap = ReflectionUtils.getBeanSetterMap(listParamBeanClass);
				// デフォルトコンストラクタ取得
				Constructor<?> listParamBeanConstructor = getDefaultConstructor(listParamBeanClass);
				// リストの値を格納するArrayList
				ArrayList<Object> listValue = new ArrayList<Object>();
				DMResultColumn<?>[] listColumns = resultList.getListColumns();
				// リストに設定されている文字列配列の長さ
				int listRecLen = getListRecLength(listColumns);
				for(int i = 0; i < listRecLen; i++){
					// インスタンス取得
					Object listParamBeanInstance = getNewInstanceByDefaultConstructor(listParamBeanConstructor);
					for(DMResultColumn<?> listColumn : listColumns){
						String colName = listColumn.getName();
						if(colName != null){
							String fieldName = StringUtils.convColumnToFieldName(colName);
							if(setterMap.containsKey(fieldName)){
								String value = ((String[])listColumn.getValue())[i];
								// ビーンに対してExcelの値を設定
								setExcelValueToBean(
										listParamBeanInstance, fieldName, setterMap.get(fieldName).getMethod(),
										listColumn.getType(), value);
							}
						}
					}
					listValue.add(listParamBeanInstance);
				}
				listValue.trimToSize();
				listParams.put(resultList.getListId(), listValue);
			}
		}
	}

	// ビーンに対してExcelの値を設定
	private void setExcelValueToBean(
			Object targetBean, String fieldName, Method setterMethod,
			int colType, String value) throws TecSystemException {
		if(value != null){
			// セッター引数の型
			Class<?>[] argTypes = setterMethod.getParameterTypes();
			if(argTypes != null && argTypes.length > 0){
				Class<?> argType = argTypes[0];
				boolean isExcelDate = false;
				if(DMValueKbn.EXCEL_DATE.equals(DMValueKbn.getTargetValueKbn(colType))){
					isExcelDate = true;
				}
				// ビーンの型が対象外の場合
				if(!isTargetType(argType, isExcelDate)){
					TecLogger.error("UnsupportedDataType[" + fieldName + "]");
					throw new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
				}
				try {
					// セッター実行
					setterMethod.invoke(targetBean, convValueForSetter(value, argType, isExcelDate));
				} catch (IllegalArgumentException e) {
					TecLogger.error(e);
					throw new TecSystemException(e);
				} catch (IllegalAccessException e) {
					TecLogger.error(e);
					throw new TecSystemException(e);
				} catch (InvocationTargetException e) {
					TecLogger.error(e);
					throw new TecSystemException(e);
				}
			}
		}
	}

	// ビーンの型が対象かどうか
	private static boolean isTargetType(Class<?> fieldType, boolean isExcelDate){
		boolean isTarget = false;
		// Excel用日付型の場合、long、String、Date(java.util)のみ対応
		// ただし、Stringの場合はlongと同じミリ秒の文字列表現を返却
		if(isExcelDate){
			if(fieldType == Long.TYPE || String.class.equals(fieldType) || Date.class.equals(fieldType)){
				isTarget = true;
			}
		} else {
			if(fieldType.isPrimitive()){
				if(
						fieldType == Double.TYPE || fieldType == Float.TYPE ||
						fieldType == Integer.TYPE || fieldType == Long.TYPE || fieldType == Short.TYPE ||
						fieldType == Boolean.TYPE){
					isTarget = true;
				}
			} else {
				if(String.class.equals(fieldType)){
					isTarget = true;
				}
			}
		}
		return isTarget;
	}

	// セッター引数用に値を変換
	private static Object convValueForSetter(String value, Class<?> fieldType, boolean isExcelDate){
		Object ret = null;
		// Excel用日付型の場合、long、String、Date(java.util)のみ対応
		// ただし、Stringの場合はlongと同じミリ秒の文字列表現を返却
		if(isExcelDate){
			if(fieldType == Long.TYPE){
				ret = Long.parseLong(value, 10);
			} else if(String.class.equals(fieldType)){
				ret = value;
			} else if(Date.class.equals(fieldType)){
				Date dt = new Date();
				dt.setTime(Long.parseLong(value, 10));
				ret = dt;
			}
		} else {
			if(fieldType == Double.TYPE){
				ret = Double.parseDouble(value);
			} else if(fieldType == Float.TYPE){
				ret = Float.parseFloat(value);
			} else if(fieldType == Integer.TYPE){
				ret = Integer.parseInt(value, 10);
			} else if(fieldType == Long.TYPE){
				ret = Long.parseLong(value, 10);
			} else if(fieldType == Short.TYPE){
				ret = Short.parseShort(value, 10);
			} else if(fieldType == Boolean.TYPE){
				ret = Boolean.parseBoolean(value);
			} else if(String.class.equals(fieldType)){
				ret = value;
			}
		}
		return ret;
	}

	// リストのレコード数
	private int getListRecLength(DMResultColumn<?>[] listColumns){
		int listRecLen = 0;
		if(listColumns != null && listColumns.length > 0){
			for(DMResultColumn<?> listColumn : listColumns){
				Object listColumnValue = listColumn.getValue();
				// 値がStringの一次配列である場合
				if(listColumnValue != null && String.class.equals(listColumnValue.getClass().getComponentType())){
					String[] columns = (String[])listColumnValue;
					for(int i = columns.length; i > 0; i--){
						// 値が入っている最後の行
						if(columns[i-1] != null){
							if(listRecLen < i){
								listRecLen = i;
							}
							break;
						}
					}
				}
			}
		}
		return listRecLen;
	}

	// デフォルトコンストラクタ取得
	private Constructor<?> getDefaultConstructor(Class<?> cls) throws TecSystemException {
		Constructor<?> constructor = null;
		try {
			constructor = cls.getConstructor();
		} catch (NoSuchMethodException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		return constructor;
	}

	// デフォルトコンストラクタを使用してインスタンスを生成
	private Object getNewInstanceByDefaultConstructor(Constructor<?> constructor) throws TecSystemException {
		Object resBean = null;
		try {
			resBean = constructor.newInstance();
		} catch (InstantiationException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (IllegalAccessException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (InvocationTargetException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		return resBean;
	}

	// ファイル操作用クラス取得
	private IMFileManagerIF getIMFileManager(boolean isTargetAppSrv){
		if(isTargetAppSrv){
			// APサーバが対象
			return IMAppFileManager.getInstance();
		} else {
			// ストレージサービスが対象
			return IMStorageServiceManager.getInstance();
		}
	}

}
