/*
 * 【システム名】
 * 【ファイル名】DMCellManager.java
 * 【  説  明  】Excelセル操作クラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】2010/09/01 H.O(SCC) version 1.02
 *                 POI 3.5.0対応
 */
package com.toyotec_jp.im_common.system.docmng.mng.excel;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFShape;
import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
import org.apache.poi.hssf.usermodel.HSSFTextbox;
import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.ShapeTypes;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFSimpleShape;
import org.apache.poi.xssf.usermodel.XSSFTextBox;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.exception.TecExcelMngException;
import com.toyotec_jp.im_common.system.log.TecLogger;

/**
 * <strong>DMCellManager</strong>
 * <p>
 * Excelセル操作クラス<br>
 * POI 3.5.0 版
 * </p>
 * @author H.O(SCC)
 * @version 1.03 2011/04/01 <br>
 */
public class DMCellManager {

	// TODO
	// POI 3.0.2 版だったが
	// 3.0.2では入力規則が消えるという問題が発生したため
	// 急遽3.2.0に変更になった
	// そのため対応し切れていない可能性あり
	// 次期バージョン開発時にはその対応も検討すること

	/** コンストラクタ */
	private DMCellManager() {
	}

	/** インスタンス */
	private static final DMCellManager instance = new DMCellManager();

	/** セル取得時のデフォルト日付フォーマット「yyyy/MM/dd」 */
	private static final String DEFAULT_DATE_FORMAT = "yyyy/MM/dd";

	/** 項目区分 */
	public static enum DMValueKbn {
		/** 項目区分 0:Numeric */
		NUMERIC(0, true, false),
		/** 項目区分 1:String */
		STRING(1, true, false),
		/** 項目区分 2:Formula(式) */
		FORMULA(2, true, false),
		/** 項目区分 3:Blank */
		BLANK(3, true, false),
		/** 項目区分 4:Boolean */
		BOOLEAN(4, true, false),
		/** 項目区分 5:Error */
		ERROR(5, true, false),
		/** 項目区分 6:Excel用日付 */
		EXCEL_DATE(6, true, false),
		/** 項目区分 10:オートシェイプ「○」 */
		SHAPE_OVAL(10, false, true),
		/** 項目区分 11:オートシェイプ「レ」(チェック) */
		SHAPE_CHECK(11, false, true);
		private int valueKbn;
		private boolean isForCell;
		private boolean isForShape;
		private DMValueKbn(int valueKbn, boolean isForCell, boolean isForShape){
			this.valueKbn = valueKbn;
			this.isForCell = isForCell;
			this.isForShape = isForShape;
		}
		public String toString(){
			return String.valueOf(valueKbn);
		}
		/** 対象取得 */
		public static DMValueKbn getTargetValueKbn(int valueKbn){
			DMValueKbn ret = null;
			for(DMValueKbn kbn : DMValueKbn.values()){
				if(kbn.valueKbn == valueKbn){
					ret = kbn;
					break;
				}
			}
			return ret;
		}
		/** 存在チェック */
		public static boolean isExistKbn(int valueKbn){
			boolean res = false;
			DMValueKbn eKbn = getTargetValueKbn(valueKbn);
			if(eKbn != null){
				res = true;
			}
			return res;
		}
		/** セル用項目区分チェック */
		public static boolean isForCellKbn(int valueKbn){
			boolean res = false;
			DMValueKbn eKbn = getTargetValueKbn(valueKbn);
			if(eKbn != null){
				res = eKbn.isForCell;
			}
			return res;
		}
		/** オートシェイプ用項目区分チェック */
		public static boolean isForShapeKbn(int valueKbn){
			boolean res = false;
			DMValueKbn eKbn = getTargetValueKbn(valueKbn);
			if(eKbn != null){
				res = eKbn.isForShape;
			}
			return res;
		}
	}

	/** オートシェイプ描画用:値が「1」の場合、オートシェイプを設定 */
	private static final String SHAPE_DISP_VALUE = "1";

	/** 警告メッセージ:対象外 */
	private static final String MSG_WARN_UNSUPPORTED_TYPE = "対象外の型です";

	/** エラーメッセージ:ブックNull */
	private static final String MSG_ERR_NULL_BOOK = "対象ブックがNullになっています";
	/** エラーメッセージ:シートNull */
	private static final String MSG_ERR_NULL_SHEET = "対象シートがNullになっています";
	/** エラーメッセージ:行Null */
	private static final String MSG_ERR_NULL_ROW = "対象行がNullになっています";
	/** エラーメッセージ:マッピング用データNull */
	private static final String MSG_ERR_NULL_MAP_DATA = "マッピング用データがNullになっています";

	/** エラーメッセージ:取得失敗 */
	private static final String MSG_ERR_GET_VALUE = "値の取得に失敗しました";
	/** エラーメッセージ:設定失敗 */
	private static final String MSG_ERR_SET_VALUE = "値の設定に失敗しました";

	/** エラーメッセージ:項目区分不正 */
	private static final String MSG_ERR_KBN = "項目区分不正";
	/** エラーメッセージ:行インデックス不正 */
	private static final String MSG_ERR_ROW_IDX = "行インデックス不正(0-65535)";
	/** エラーメッセージ:列インデックス不正 */
	private static final String MSG_ERR_COL_IDX = "列インデックス不正(0-255)";
	/** エラーメッセージ:コピー行数不正 */
	private static final String MSG_ERR_COPY_ROW_CNT = "コピー行数が不正です";
	/** エラーメッセージ:結合領域不正 */
	private static final String MSG_ERR_CELL_MERGED_REGION = "結合領域の指定が不正です";

	/**
	 * インスタンス取得
	 * @return Excelセル操作インスタンス
	 * @since 1.00
	 */
	protected static DMCellManager getInstance(){
		return instance;
	}

//	/**
//	 * セルの値を取得
//	 * @param targetSheet ワークシート
//	 * @param rowIdx 行インデックス
//	 * @param colIdx 列インデックス
//	 * @return 値
//	 * @throws TecExcelMngException
//	 * @since 1.00
//	 */
//	public String getCellValue(HSSFSheet targetSheet, int rowIdx, int colIdx) throws TecExcelMngException{
//		return getCellValue(getRow(targetSheet, rowIdx), colIdx);
//	}
//
//	/**
//	 * セルの値を取得
//	 * @param targetRow 行
//	 * @param colIdx 列インデックス
//	 * @return 値
//	 * @throws TecExcelMngException
//	 * @since 1.00
//	 */
//	public String getCellValue(HSSFRow targetRow, int colIdx) throws TecExcelMngException{
//		return getCellValue(getCell(targetRow, getExcelColNum(colIdx)));
//	}

	/**
	 * セルの値を取得
	 * @param targetSheet ワークシート
	 * @param baseRowIdx 基準行インデックス
	 * @param baseColIdx 基準列インデックス
	 * @param fileMapRec マッピング用データ
	 * @return 値
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected String getCellValue(
			DMSheet targetSheet, int baseRowIdx, int baseColIdx,
			DMFilesMapData fileMapRec) throws TecExcelMngException{

		String ret = null;
		if(targetSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		if(fileMapRec == null){
			throw new TecExcelMngException(MSG_ERR_NULL_MAP_DATA);
		}
		try{
			int rowIdx = fileMapRec.getTaishogyo() + baseRowIdx;
			int colIdx = fileMapRec.getTaishoretsu() + baseColIdx;
			int valueKbn = fileMapRec.getKomokuKbn();
			try{
				checkExcelRowIdx(rowIdx);
				checkExcelColIdx(colIdx);
			} catch(TecExcelMngException e){
				TecLogger.debug("[" + rowIdx + "][" + colIdx + "]");
				throw e;
			}
			Row row = targetSheet.sheet.getRow(rowIdx);
			if(row != null){
				Cell cell = row.getCell(colIdx);
				if(cell != null){
					// 項目区分Excel用日付指定時
					if(valueKbn == DMValueKbn.EXCEL_DATE.valueKbn){
						ret = getCellValue(cell, DEFAULT_DATE_FORMAT, false, false);
						if(ret != null && ret.length() > 0){
							// Excel日付数値→Java日付ミリ秒変換
							ret = String.valueOf(DateUtil.getJavaDate(Double.parseDouble(ret)).getTime());
						}
					} else {
						ret = getCellValue(cell, DEFAULT_DATE_FORMAT, true, false);
					}
				}
			}
			TecLogger.trace("row[" + rowIdx + "]col[" + colIdx + "]val[" + ret + "]");
		} catch(Exception e){
			TecLogger.debug(getRecInfoMsg(baseRowIdx, baseColIdx, fileMapRec, ret));
			throw new TecExcelMngException(MSG_ERR_GET_VALUE, e);
		}
		return ret;
	}

	/**
	 * セルの値を取得
	 * @param targetCell セル
	 * @param dateFormat 日付フォーマット
	 * @param doConvDate true:日付は日付に変換、false:日付も数値で取得
	 * @param doGetFunction true:式を取得、false:値を取得
	 * @return 値
	 * @since 1.00
	 */
	private String getCellValue(
			Cell targetCell, String dateFormat, boolean doConvDate, boolean doGetFunction){
		String ret = null;
		short cellDataFormat = targetCell.getCellStyle().getDataFormat();
		SimpleDateFormat sdfFormat = new SimpleDateFormat(dateFormat);
		int cellType = targetCell.getCellType();
		// セル種別が式であり、値を取得する場合は式の結果種別を使用する
		if(!doGetFunction && cellType == Cell.CELL_TYPE_FORMULA){
			cellType = targetCell.getCachedFormulaResultType();
		}
		switch(cellType){
			case Cell.CELL_TYPE_NUMERIC:
				// 日付
				if(doConvDate && DateUtil.isInternalDateFormat(cellDataFormat)){
					ret = sdfFormat.format(targetCell.getDateCellValue());
				// 数値
				} else {
					ret = String.valueOf(targetCell.getNumericCellValue());
				}
				break;
			case Cell.CELL_TYPE_STRING:
				ret = targetCell.getRichStringCellValue().getString();
				break;
			case Cell.CELL_TYPE_FORMULA:
				if(doGetFunction){
					ret = targetCell.getCellFormula();
				}
				//ret = getFormulaCellValue(targetCell, dateFormat, doGetFunction);
				break;
			case Cell.CELL_TYPE_BLANK:
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				ret = String.valueOf(targetCell.getBooleanCellValue());
				break;
			case Cell.CELL_TYPE_ERROR:
				break;
			default:
				break;
		}
		return ret;
	}

//	/**
//	 * セル種別が式であるセルの式または値を取得
//	 * <br>
//	 * 値としてboolは取得不可(POI 3.0.2)
//	 * @param targetCell セル
//	 * @param dateFormat 日付フォーマット
//	 * @param doGetFunction true:式を取得、false:値を取得
//	 * @return 式または値
//	 * @since 1.00
//	 */
//	private String getFormulaCellValue(HSSFCell targetCell, String dateFormat, boolean doGetFunction){
//		String ret = null;
//		short cellDataFormat = targetCell.getCellStyle().getDataFormat();
//		SimpleDateFormat sdfFormat = new SimpleDateFormat(dateFormat);
//		if(doGetFunction){
//			ret = targetCell.getCellFormula();
//		} else {
//			//targetCell.getCachedFormulaResultType();
//			double numVal = targetCell.getNumericCellValue();
//			if(Double.isNaN(numVal)){
//				// bool取得不可
//				ret = targetCell.getRichStringCellValue().getString();
//			} else {
//				// 日付
//				if(HSSFDateUtil.isInternalDateFormat(cellDataFormat)){
//					ret = sdfFormat.format(targetCell.getDateCellValue());
//				// 数値
//				} else {
//					ret = String.valueOf(numVal);
//				}
//			}
//		}
//		return ret;
//	}

	/**
	 * 値を設定
	 * @param targetBook ワークブック
	 * @param targetSheet シート
	 * @param baseRowIdx 基準行インデックス
	 * @param baseColIdx 基準列インデックス
	 * @param fileMapRec マッピング用データ
	 * @param value 値
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected void setValue(
			DMWorkbook targetBook, DMSheet targetSheet, int baseRowIdx, int baseColIdx,
			DMFilesMapData fileMapRec, String value) throws TecExcelMngException{

		if(targetBook == null){
			throw new TecExcelMngException(MSG_ERR_NULL_BOOK);
		}
		if(targetSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		if(fileMapRec == null){
			throw new TecExcelMngException(MSG_ERR_NULL_MAP_DATA);
		}
		try{
			// 項目区分がセル用
			if(isKbnForCell(fileMapRec.getKomokuKbn())){
				setCellValue(targetSheet, baseRowIdx, baseColIdx, fileMapRec, value);
			// 項目区分がオートシェイプ用
			} else if(isKbnForShape(fileMapRec.getKomokuKbn())){
				setShape(targetBook, targetSheet, baseRowIdx, baseColIdx, fileMapRec, value);
			} else {
				throw new TecExcelMngException(MSG_ERR_KBN);
			}
		} catch(Exception e){
			TecLogger.debug(getRecInfoMsg(baseRowIdx, baseColIdx, fileMapRec, value));
			throw new TecExcelMngException(MSG_ERR_SET_VALUE, e);
		}
	}

	/**
	 * セルに値を設定
	 * @param targetSheet ワークシート
	 * @param baseRowIdx 基準行インデックス
	 * @param baseColIdx 基準列インデックス
	 * @param fileMapRec マッピング用データ
	 * @param value 値
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private void setCellValue(
			DMSheet targetSheet, int baseRowIdx, int baseColIdx,
			DMFilesMapData fileMapRec, String value) throws TecExcelMngException{

		int rowIdx = fileMapRec.getTaishogyo() + baseRowIdx;
		int colIdx = fileMapRec.getTaishoretsu() + baseColIdx;
		try{
			checkExcelRowIdx(rowIdx);
			checkExcelColIdx(colIdx);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + rowIdx + "][" + colIdx + "]");
			throw e;
		}

		Cell targetCell = targetSheet.getCellForSetData(rowIdx, colIdx);
		int valueKbn = fileMapRec.getKomokuKbn();
		// 項目区分Excel用日付指定時
		if(valueKbn == DMValueKbn.EXCEL_DATE.valueKbn){
			if(value != null && value.length() > 0){
				// Java日付ミリ秒→Excel日付数値変換
				try {
					Date dt = new Date();
					dt.setTime(Long.parseLong(value));
					value = String.valueOf(DateUtil.getExcelDate(dt));
				} catch(NumberFormatException e){
					// 数値型でない場合は文字として設定
					valueKbn = Cell.CELL_TYPE_STRING;
				}
			}
		}
		// セル種別設定
		int initCellType = targetCell.getCellType();
		int newCellType = getCellType(valueKbn);
		targetCell.getCellStyle().getDataFormat();
		if(initCellType != newCellType){
			// ブランクで初期化(3.5?で必要なくなった？むしろフォーマットまで消してしまうので初期化しない)
			//targetCell.setCellType(Cell.CELL_TYPE_BLANK);
			targetCell.setCellType(newCellType);
		}
		setCellValue(targetCell, value);
		TecLogger.trace("row[" + rowIdx + "]col[" + colIdx + "]val[" + value + "]");
	}

	/**
	 * セルに値を設定
	 * @param targetCell セル
	 * @param value 値
	 * @since 1.00
	 */
	private void setCellValue(Cell targetCell, String value){
		switch(targetCell.getCellType()){
			case Cell.CELL_TYPE_NUMERIC:
				if(value != null && value.length() > 0){
					targetCell.setCellValue(Double.parseDouble(value));
				} else {
					targetCell.setCellValue(value);
				}
				break;
			case Cell.CELL_TYPE_STRING:
				targetCell.setCellValue(value);
				break;
			case Cell.CELL_TYPE_FORMULA:
				targetCell.setCellFormula(value);
				break;
			case Cell.CELL_TYPE_BLANK:
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				targetCell.setCellValue(Boolean.parseBoolean(value));
				break;
			case Cell.CELL_TYPE_ERROR:
				break;
			default:
				break;
		}
	}

	/**
	 * オートシェイプ設定<br>
	 * 値が「1」の場合、オートシェイプを設定
	 * @param targetBook ワークブック
	 * @param targetSheet シート
	 * @param baseRowIdx 基準行インデックス
	 * @param baseColIdx 基準列インデックス
	 * @param fileMapRec マッピング用データ
	 * @param value 値
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private void setShape(
			DMWorkbook targetBook, DMSheet targetSheet, int baseRowIdx, int baseColIdx,
			DMFilesMapData fileMapRec, String value) throws TecExcelMngException{

		if(SHAPE_DISP_VALUE.equals(value)){
			int startColIdx = fileMapRec.getTaishoretsu() + baseColIdx;
			int startRowIdx = fileMapRec.getTaishogyo() + baseRowIdx;
			int endColIdx = fileMapRec.getShutenretsu() + baseColIdx;
			int endRowIdx = fileMapRec.getShutengyo() + baseRowIdx;
			try{
				checkExcelColIdx(startColIdx);
				checkExcelRowIdx(startRowIdx);
				checkExcelColIdx(endColIdx);
				checkExcelRowIdx(endRowIdx);
			} catch(TecExcelMngException e){
				TecLogger.debug("[" + startColIdx + "][" + startRowIdx + "][" + endColIdx + "][" + endRowIdx + "]");
				throw e;
			}

			ClientAnchor anchor = targetBook.createClientAnchor(
					fileMapRec.getShitenXZahyo(), fileMapRec.getShitenYZahyo(),
					fileMapRec.getShutenXZahyo(), fileMapRec.getShutenYZahyo(),
					getExcelColIdx(startColIdx), startRowIdx, getExcelColIdx(endColIdx), endRowIdx);
			DMValueKbn eKbn = DMValueKbn.getTargetValueKbn(fileMapRec.getKomokuKbn());
			if(eKbn != null){
				switch (eKbn) {
					case SHAPE_OVAL:
						setOval(targetSheet.getPatriarch(), anchor);
						break;
					case SHAPE_CHECK:
						setTextBox(targetSheet.getPatriarch(), anchor, targetBook.getTextForCheckBox());
						break;
					default:
						break;
				}
			}
		}
	}

	/**
	 * 項目区分 10:オートシェイプ「○」設定
	 * @param drawPatriarch オートシェイプ生成用クラス
	 * @param anchor 座標
	 * @since 1.00
	 */
	private void setOval(Drawing drawPatriarch, ClientAnchor anchor){
		if(drawPatriarch instanceof HSSFPatriarch){
			HSSFSimpleShape shape = ((HSSFPatriarch)drawPatriarch).createSimpleShape((HSSFClientAnchor)anchor);
			shape.setShapeType(HSSFSimpleShape.OBJECT_TYPE_OVAL);
			shape.setLineWidth(19050); // 12700 = 1 pt.
			shape.setNoFill(true); // 塗りつぶしなし
		} else if(drawPatriarch instanceof XSSFDrawing){
			XSSFSimpleShape shape = ((XSSFDrawing)drawPatriarch).createSimpleShape((XSSFClientAnchor)anchor);
			shape.setShapeType(ShapeTypes.ELLIPSE);
			shape.setLineWidth(19050); // 12700 = 1 pt.
			shape.setNoFill(true); // 塗りつぶしなし
		} else {
			TecLogger.warn(MSG_WARN_UNSUPPORTED_TYPE);
		}
	}

	/**
	 * 項目区分 11:オートシェイプ「レ」設定
	 * @param drawPatriarch オートシェイプ生成用クラス
	 * @param anchor 座標
	 * @param textForCheck オートシェイプ(レ)(チェック)用定義情報
	 * @since 1.00
	 */
	private void setTextBox(
			Drawing drawPatriarch, ClientAnchor anchor, RichTextString textForCheck){
		if(drawPatriarch instanceof HSSFPatriarch){
			HSSFTextbox txtBox = ((HSSFPatriarch)drawPatriarch).createTextbox((HSSFClientAnchor)anchor);
			txtBox.setString(textForCheck);
			txtBox.setLineStyle(HSSFShape.LINESTYLE_NONE);
			txtBox.setNoFill(true); // 塗りつぶしなし
		} else if(drawPatriarch instanceof XSSFDrawing){
			XSSFTextBox txtBox = ((XSSFDrawing)drawPatriarch).createTextbox((XSSFClientAnchor)anchor);
			txtBox.setText((XSSFRichTextString)textForCheck);
			txtBox.setLineWidth(0);
			txtBox.setNoFill(true); // 塗りつぶしなし
		} else {
			TecLogger.warn(MSG_WARN_UNSUPPORTED_TYPE);
		}
	}

	/**
	 * セル種別取得<br>
	 * オートシェイプ用項目区分の場合はセル種別「ブランク」を返却
	 * @param valKbn 項目区分
	 * @return セル種別
	 * @since 1.00
	 */
	private int getCellType(int valKbn){
		int ret = Cell.CELL_TYPE_BLANK;
		DMValueKbn eKbn = DMValueKbn.getTargetValueKbn(valKbn);
		if(eKbn != null){
			switch (eKbn) {
				case NUMERIC:
					ret = Cell.CELL_TYPE_NUMERIC;
					break;
				case STRING:
					ret = Cell.CELL_TYPE_STRING;
					break;
				case FORMULA:
					ret = Cell.CELL_TYPE_FORMULA;
					break;
				case BLANK:
					ret = Cell.CELL_TYPE_BLANK;
					break;
				case BOOLEAN:
					ret = Cell.CELL_TYPE_BOOLEAN;
					break;
				case ERROR:
					ret = Cell.CELL_TYPE_ERROR;
					break;
				case EXCEL_DATE:
					ret = Cell.CELL_TYPE_NUMERIC;
					break;
				default:
					break;
			}
		}
		return ret;
	}

	/**
	 * 項目区分存在チェック
	 * @param valKbn 項目区分
	 * @return true:項目区分が存在する
	 * @since 1.00
	 */
	protected boolean existsValKbn(int valKbn){
		return DMValueKbn.isExistKbn(valKbn);
	}

	/**
	 * セル用項目区分チェック
	 * @param valKbn 項目区分
	 * @return true:セル用項目区分
	 * @since 1.00
	 */
	protected boolean isKbnForCell(int valKbn){
		return DMValueKbn.isForCellKbn(valKbn);
	}

	/**
	 * オートシェイプ用項目区分チェック
	 * @param valKbn 項目区分
	 * @return true:オートシェイプ用項目区分
	 * @since 1.00
	 */
	protected boolean isKbnForShape(int valKbn){
		return DMValueKbn.isForShapeKbn(valKbn);
	}

	/**
	 * 指定した行インデックスの行を取得
	 * @param targetSheet ワークシート
	 * @param rowIdx 行インデックス
	 * @return 行
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected Row getRow(Sheet targetSheet, int rowIdx) throws TecExcelMngException {
		if(targetSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		try{
			checkExcelRowIdx(rowIdx);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + rowIdx + "]");
			throw e;
		}
		Row row = targetSheet.getRow(rowIdx);
		if(row == null) {
			row = targetSheet.createRow(rowIdx);
		}
		return row;
	}

	/**
	 * 指定した行、列インデックスのセルを取得
	 * @param targetSheet ワークシート
	 * @param rowIdx 行インデックス
	 * @param colIdx 列インデックス
	 * @return セル
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected Cell getCell(Sheet targetSheet, int rowIdx, short colIdx) throws TecExcelMngException {
		if(targetSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		try{
			checkExcelRowIdx(rowIdx);
			checkExcelColIdx(colIdx);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + rowIdx + "][" + colIdx + "]");
			throw e;
		}
		return getCell(getRow(targetSheet, rowIdx), colIdx);
	}

	/**
	 * 指定した列インデックスのセルを取得
	 * @param targetRow 行
	 * @param colIdx 列インデックス
	 * @return セル
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected Cell getCell(Row targetRow, int colIdx) throws TecExcelMngException {
		if(targetRow == null){
			throw new TecExcelMngException(MSG_ERR_NULL_ROW);
		}
		try{
			checkExcelColIdx(colIdx);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + colIdx + "]");
			throw e;
		}
		Cell cell = targetRow.getCell(colIdx);
		if(cell == null) {
			cell = targetRow.createCell(colIdx);
		}
		return cell;
	}

	/**
	 * 列インデックス取得<br>(int→short変換)
	 * @param colIdx 列インデックス
	 * @return 列インデックス
	 * @throws TecExcelMngException 列インデックスが範囲外である場合
	 * @since 1.00
	 */
	private short getExcelColIdx(int colIdx) throws TecExcelMngException{
		checkExcelColIdx(colIdx);
		return (short)colIdx;
	}

	/**
	 * 行インデックスチェック
	 * @param rowIdx 行インデックス
	 * @return true:正しい
	 * @throws TecExcelMngException 行インデックスが範囲外である場合
	 * @since 1.00
	 */
	protected boolean checkExcelRowIdx(int rowIdx) throws TecExcelMngException{
		if(rowIdx < 0 || rowIdx > 65535){
			throw new TecExcelMngException(MSG_ERR_ROW_IDX);
		}
		return true;
	}

	/**
	 * 列インデックスチェック
	 * @param colIdx 列インデックス
	 * @return true:正しい
	 * @throws TecExcelMngException 列インデックスが範囲外である場合
	 * @since 1.00
	 */
	protected boolean checkExcelColIdx(int colIdx) throws TecExcelMngException{
		if(colIdx < 0 || colIdx > 255){
			throw new TecExcelMngException(MSG_ERR_COL_IDX);
		}
		return true;
	}

	/**
	 * セルのコピー(行単位)
	 * @param fromBook コピー元ブック
	 * @param fromSheet コピー元シート
	 * @param fromRowIdx コピー元行インデックス
	 * @param toBook コピー先ブック
	 * @param toSheet コピー先シート
	 * @param toRowIdx コピー先行インデックス
	 * @param doCopyStyle true:スタイルをコピーする
	 * @param doCopyValue true:値をコピーする
	 * @param isSameBookCopy true:同一ブック上のコピー
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected void copyCell(
			Workbook fromBook, Sheet fromSheet, int fromRowIdx,
			Workbook toBook, Sheet toSheet, int toRowIdx,
			boolean doCopyStyle, boolean doCopyValue, boolean isSameBookCopy) throws TecExcelMngException{

		if(fromBook == null || toBook == null){
			throw new TecExcelMngException(MSG_ERR_NULL_BOOK);
		}
		if(fromSheet == null || toSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		try{
			checkExcelRowIdx(fromRowIdx);
			checkExcelRowIdx(toRowIdx);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + fromRowIdx + "][" + toRowIdx + "]");
			throw e;
		}
		// 行取得
		Row fromRow = getRow(fromSheet, fromRowIdx);
		Row toRow = getRow(toSheet, toRowIdx);
		// スタイルコピー時のみ
		if(doCopyStyle){
			toRow.setHeight(fromRow.getHeight());
			toRow.setZeroHeight(fromRow.getZeroHeight());
		}
		int cellLen = fromRow.getLastCellNum();
		if(cellLen < toRow.getLastCellNum()){
			cellLen = toRow.getLastCellNum();
		}
		// セル設定
		for(int i = 0; i < cellLen; i++) {
			Cell fromCell = getCell(fromRow, i);
			Cell toCell = getCell(toRow, i);
			// セルスタイル
			if(doCopyStyle){
				copyCellStyle(fromBook, fromCell, toBook, toCell, isSameBookCopy);
			}
			if(doCopyValue){
				// セル種別
				toCell.setCellType(fromCell.getCellType());
				// 値設定
				setCellValue(toCell, getCellValue(fromCell, DEFAULT_DATE_FORMAT, false, true));
			}
		}
	}

	/**
	 * セルスタイルのコピー
	 * @param fromBook コピー元ブック
	 * @param fromCell コピー元セル
	 * @param toBook コピー先ブック
	 * @param toCell コピー先セル
	 * @param isSameBookCopy true:同一ブック上のコピー
	 * @since 1.00
	 */
	private void copyCellStyle(
		Workbook fromBook, Cell fromCell, Workbook toBook, Cell toCell,
		boolean isSameBookCopy){

		// 同一ブックの場合は単純コピー
		if(isSameBookCopy){
			toCell.setCellStyle(toBook.getCellStyleAt(fromCell.getCellStyle().getIndex()));
			//toCell.setCellStyle(fromCell.getCellStyle());
		// 異なるブック間の場合
		} else {
			int cellStyleIdx = -1;
			int beforeFontCnt = toBook.getNumberOfFonts();
			Font fromFont = fromBook.getFontAt(fromCell.getCellStyle().getFontIndex());
			Font font = toBook.findFont(
					fromFont.getBoldweight(), fromFont.getColor(), fromFont.getFontHeight(), fromFont.getFontName(),
					fromFont.getItalic(), fromFont.getStrikeout(), fromFont.getTypeOffset(), fromFont.getUnderline());
			if(font == null){
				font = toBook.createFont();
				font.setBoldweight(fromFont.getBoldweight());
				font.setColor(fromFont.getColor());
				font.setFontHeight(fromFont.getFontHeight());
				font.setFontName(fromFont.getFontName());
				font.setItalic(fromFont.getItalic());
				font.setStrikeout(fromFont.getStrikeout());
				font.setTypeOffset(fromFont.getTypeOffset());
				font.setUnderline(fromFont.getUnderline());
			}
			// 既存のフォント設定を使用している場合
			if(beforeFontCnt == toBook.getNumberOfFonts()){
				cellStyleIdx = findCellStyleIdx(toBook, fromCell.getCellStyle(), font);
			}
			CellStyle style = null;
			// 既存のセルスタイルが使用可能な場合
			if(cellStyleIdx >= 0){
				style = toBook.getCellStyleAt((short)cellStyleIdx);
			// 新規のセルスタイルを作成する場合
			} else {
				style = toBook.createCellStyle();
				style.setAlignment(fromCell.getCellStyle().getAlignment());
				style.setBorderBottom(fromCell.getCellStyle().getBorderBottom());
				style.setBorderLeft(fromCell.getCellStyle().getBorderLeft());
				style.setBorderRight(fromCell.getCellStyle().getBorderRight());
				style.setBorderTop(fromCell.getCellStyle().getBorderTop());
				style.setBottomBorderColor(fromCell.getCellStyle().getBottomBorderColor());
				// フォーマット
				short dataFmtIdx = fromCell.getCellStyle().getDataFormat();
				short newDataFmtIdx = 0;
				if(dataFmtIdx >= BuiltinFormats.FIRST_USER_DEFINED_FORMAT_INDEX){
					// 対象フォーマットがコピー先に存在する場合はそのインデックスを返却し、
					// 存在しない場合は新規フォーマットを作成し、インデックスを返却する
					newDataFmtIdx = toBook.createDataFormat().getFormat(fromCell.getCellStyle().getDataFormatString());
					style.setDataFormat(newDataFmtIdx);
				} else {
					// ビルトインフォーマットはそのまま設定
					style.setDataFormat(dataFmtIdx);
				}
				style.setFillBackgroundColor(fromCell.getCellStyle().getFillBackgroundColor());
				style.setFillForegroundColor(fromCell.getCellStyle().getFillForegroundColor());
				style.setFillPattern(fromCell.getCellStyle().getFillPattern());
				style.setFont(font);
				style.setHidden(fromCell.getCellStyle().getHidden());
				style.setIndention(fromCell.getCellStyle().getIndention());
				style.setLeftBorderColor(fromCell.getCellStyle().getLeftBorderColor());
				style.setLocked(fromCell.getCellStyle().getLocked());
				style.setRightBorderColor(fromCell.getCellStyle().getRightBorderColor());
				style.setTopBorderColor(fromCell.getCellStyle().getTopBorderColor());
				style.setVerticalAlignment(fromCell.getCellStyle().getVerticalAlignment());
				style.setWrapText(fromCell.getCellStyle().getWrapText());
			}
			toCell.setCellStyle(style);
		}
	}

	/**
	 * 同じスタイル、フォントを持つ既存のスタイル設定を検索<br>
	 * @param targetBook 対象ワークブック
	 * @param findStyle セルスタイル設定
	 * @param findFont フォント設定<br>
	 *        (フォント設定インデックスによる比較を行うため、対象ワークブックの設定を使用すること)
	 * @return -1:既存スタイル設定無し、0以上:スタイル設定インデックス
	 * @since 1.00
	 */
	private int findCellStyleIdx(Workbook targetBook, CellStyle findStyle, Font findFont){
		for(int i = 0; i < targetBook.getNumCellStyles(); i++){
			CellStyle style = targetBook.getCellStyleAt((short)i);
			if(
					style.getAlignment() == findStyle.getAlignment() &&
					style.getBorderBottom() == findStyle.getBorderBottom() &&
					style.getBorderLeft() == findStyle.getBorderLeft() &&
					style.getBorderRight() == findStyle.getBorderRight() &&
					style.getBorderTop() == findStyle.getBorderTop() &&
					style.getBottomBorderColor() == findStyle.getBottomBorderColor() &&
					style.getDataFormat() == findStyle.getDataFormat() &&
					style.getFillBackgroundColor() == findStyle.getFillBackgroundColor() &&
					style.getFillForegroundColor() == findStyle.getFillForegroundColor() &&
					style.getFillPattern() == findStyle.getFillPattern() &&
					style.getFontIndex() == findFont.getIndex() &&
					style.getHidden() == findStyle.getHidden() &&
					style.getIndention() == findStyle.getIndention() &&
					style.getLeftBorderColor() == findStyle.getLeftBorderColor() &&
					style.getLocked() == findStyle.getLocked() &&
					style.getRightBorderColor() == findStyle.getRightBorderColor() &&
					style.getTopBorderColor() == findStyle.getTopBorderColor() &&
					style.getVerticalAlignment() == findStyle.getVerticalAlignment() &&
					style.getWrapText() == findStyle.getWrapText()){
				return i;
			}
		}
		return -1;
	}

	/**
	 * セル結合状態のコピー<br>
	 * コピー元のセル結合状態をコピー先に適用<br>
	 * (コピー元の範囲外の結合は対象外<br>
	 * また、範囲内にあるが範囲外に出ているものは範囲内の部分のみ対象)
	 * @param targetSheet コピー先ワークシート
	 * @param insStartRowIdx コピー先挿入開始行インデックス
	 * @param fromSheet コピー元ワークシート
	 * @param fromRowIdx コピー元開始行インデックス
	 * @param copyRowCnt コピー行数
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected void copyMergeCellStyle(
			Sheet targetSheet, int insStartRowIdx, Sheet fromSheet, int fromRowIdx, int copyRowCnt) throws TecExcelMngException {
		if(targetSheet == null || fromSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		if(copyRowCnt < 0){
			throw new TecExcelMngException(MSG_ERR_COPY_ROW_CNT);
		} else if(copyRowCnt > 0){
			try{
				checkExcelRowIdx(insStartRowIdx);
				checkExcelRowIdx(fromRowIdx);
				checkExcelRowIdx(insStartRowIdx + copyRowCnt -1);
				checkExcelRowIdx(fromRowIdx + copyRowCnt -1);
			} catch(TecExcelMngException e){
				TecLogger.debug("[" + insStartRowIdx + "][" + fromRowIdx + "][" + copyRowCnt + "]");
				throw e;
			}
			int toRowIdx = fromRowIdx + copyRowCnt -1;
			for(int i = 0; i < fromSheet.getNumMergedRegions(); i++) {
				CellRangeAddress region = fromSheet.getMergedRegion(i);
				int startRow = region.getFirstRow();
				int endRow = region.getLastRow();
				//Region region = fromSheet.getMergedRegionAt(i);
				//int startRow = region.getRowFrom();
				//int endRow = region.getRowTo();
				// コピー元範囲にかかっている結合のみ対象
				if(startRow <= toRowIdx && endRow >= fromRowIdx){
					if(startRow < fromRowIdx){
						startRow = 0;
					} else {
						startRow -= fromRowIdx;
					}
					if(endRow > toRowIdx){
						endRow = toRowIdx - fromRowIdx;
					} else {
						endRow -= fromRowIdx;
					}
					// セル結合
					mergeCell(targetSheet,
							insStartRowIdx + startRow, region.getFirstColumn(),
							insStartRowIdx + endRow, region.getLastColumn());
							//insStartRowIdx + startRow, region.getColumnFrom(),
							//insStartRowIdx + endRow, region.getColumnTo());
				}
			}
		}
	}

	/**
	 * セルを結合
	 * @param targetSheet ワークシート
	 * @param fromRowIdx 結合範囲開始(左上)セル列インデックス
	 * @param fromColIdx 結合範囲開始(左上)セル行インデックス
	 * @param toRowIdx 結合範囲終了(右下)セル列インデックス
	 * @param toColIdx 結合範囲終了(右下)セル行インデックス
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected void mergeCell(
			Sheet targetSheet, int fromRowIdx, int fromColIdx, int toRowIdx, int toColIdx) throws TecExcelMngException {
		if(targetSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		try{
			checkExcelRowIdx(fromRowIdx);
			checkExcelColIdx(fromColIdx);
			checkExcelRowIdx(toRowIdx);
			checkExcelColIdx(toColIdx);
			targetSheet.addMergedRegion(new CellRangeAddress(fromRowIdx, toRowIdx, fromColIdx, toColIdx));
			//targetSheet.addMergedRegion(new Region(fromRowIdx, fromColIdx, toRowIdx, toColIdx));
		} catch(IllegalArgumentException e){
			TecLogger.debug("[" + fromRowIdx + "][" + fromColIdx + "][" + toRowIdx + "][" + toColIdx + "]");
			throw new TecExcelMngException(MSG_ERR_CELL_MERGED_REGION, e);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + fromRowIdx + "][" + fromColIdx + "][" + toRowIdx + "][" + toColIdx + "]");
			throw e;
		}
	}

	/**
	 * 識別用文字列取得
	 * @param baseRowIdx 基準行インデックス
	 * @param baseColIdx 基準列インデックス
	 * @param fileMapRec マッピング用データ
	 * @param value 値
	 * @return 識別用文字列
	 * @since 1.00
	 */
	private String getRecInfoMsg(
			int baseRowIdx, int baseColIdx,
			DMFilesMapData fileMapRec, String value){
		StringBuffer buf = new StringBuffer();
		buf.append("BaseRowIdx[" + baseRowIdx + "]");
		buf.append("BaseColIdx[" + baseColIdx + "]");
		buf.append("YoshikiId[" + fileMapRec.getYoshikiId() + "]");
		buf.append("SheetIdx[" + fileMapRec.getSheetIdx() + "]");
		buf.append("ShoriKbn[" + fileMapRec.getShoriKbn() + "]");
		buf.append("ShoriShosaiKbn[" + fileMapRec.getShoriShosaiKbn() + "]");
		buf.append("HikisuIdx[" + fileMapRec.getHikisuIdx() + "]");
		buf.append("HairetsuIdx[" + fileMapRec.getHairetsuIdx() + "]");
		buf.append("Value[" + value + "]");
		return new String(buf);
	}

}
