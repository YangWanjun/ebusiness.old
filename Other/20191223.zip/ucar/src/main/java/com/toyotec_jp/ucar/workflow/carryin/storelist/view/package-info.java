/**
 * 車両情報詳細表示ユーザインターフェース出力関連パッケージ
 * @version 1.00 2012/02/22 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.carryin.storelist.view;
