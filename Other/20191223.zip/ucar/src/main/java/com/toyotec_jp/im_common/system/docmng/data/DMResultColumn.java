/*
 * 【システム名】
 * 【ファイル名】DMResultColumn.java
 * 【  説  明  】結果返却用項目クラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

/**
 * <strong>DMResultColumn</strong>
 * <p>
 * 結果返却用項目クラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMResultColumn<E> {

	/**
	 * コンストラクタ
	 * @param name 項目名称
	 * @param type 項目タイプ
	 */
	public DMResultColumn(String name, int type) {
		this.name = name;
		this.type = type;
	}

	/**
	 * コンストラクタ
	 * @param name 項目名称
	 * @param type 項目タイプ
	 * @param value 項目値
	 */
	public DMResultColumn(String name, int type, E value) {
		this.name = name;
		this.type = type;
		this.value = value;
	}

	/** 項目名称 */
	private String name;

	/** 項目タイプ */
	private int type;

	/** 項目値 */
	private E value;

	/**
	 * 項目名称取得
	 * @return 項目名称
	 * @since 1.00
	 */
	public String getName() {
		return name;
	}

	/**
	 * 項目タイプ取得
	 * @return 項目タイプ
	 * @since 1.00
	 */
	public int getType() {
		return type;
	}

	/**
	 * 項目値取得
	 * @return 項目値
	 * @since 1.00
	 */
	public E getValue() {
		return value;
	}

	/**
	 * 項目値設定
	 * @param value 項目値
	 * @since 1.00
	 */
	public void setValue(E value) {
		this.value = value;
	}

}
