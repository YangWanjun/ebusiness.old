package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import java.util.Date;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>書式Bean</strong>
 * <p>
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/10 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class DocFormatBean extends TecBean {

	/**  */
	private static final long serialVersionUID = -2480761318087829389L;

	/** 書式ID */
	private String docFormatId;
	/** 書式名 */
	private String docFormatName;
	/** ソート番号 */
	private int sortNo;
	/** 出力方法 */
	private String outputType;
	/** 書式パス */
	private String docFormatPath;
	/** 作成ユーザID */
	private String createdId;
	/** 作成日時 */
	private Date createdDt;
	/** 更新ユーザID */
	private String updatedId;
	/** 更新日時 */
	private Date updatedDt;

	/**
	 *
	 */
	public DocFormatBean() {
		super();
	}

	/**
	 * docFormatIdを取得する。
	 * @return docFormatId
	 */
	public String getDocFormatId() {
		return docFormatId;
	}

	/**
	 * docFormatIdを設定する。
	 * @param docFormatId
	 */
	public void setDocFormatId(String docFormatId) {
		this.docFormatId = docFormatId;
	}

	/**
	 * docFormatNameを取得する。
	 * @return docFormatName
	 */
	public String getDocFormatName() {
		return docFormatName;
	}

	/**
	 * docFormatNameを設定する。
	 * @param docFormatName
	 */
	public void setDocFormatName(String docFormatName) {
		this.docFormatName = docFormatName;
	}

	/**
	 * sortNoを取得する。
	 * @return sortNo
	 */
	public int getSortNo() {
		return sortNo;
	}

	/**
	 * sortNoを設定する。
	 * @param sortNo
	 */
	public void setSortNo(int sortNo) {
		this.sortNo = sortNo;
	}

	/**
	 * outputTypeを取得する。
	 * @return outputType
	 */
	public String getOutputType() {
		return outputType;
	}

	/**
	 * outputTypeを設定する。
	 * @param outputType
	 */
	public void setOutputType(String outputType) {
		this.outputType = outputType;
	}

	/**
	 * docFormatPathを取得する。
	 * @return docFormatPath
	 */
	public String getDocFormatPath() {
		return docFormatPath;
	}

	/**
	 * docFormatPathを設定する。
	 * @param docFormatPath
	 */
	public void setDocFormatPath(String docFormatPath) {
		this.docFormatPath = docFormatPath;
	}

	/**
	 * createdIdを取得する。
	 * @return createdId
	 */
	public String getCreatedId() {
		return createdId;
	}

	/**
	 * createdIdを設定する。
	 * @param createdId
	 */
	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	/**
	 * createdDtを取得する。
	 * @return createdDt
	 */
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * createdDtを設定する。
	 * @param createdDt
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * updatedIdを取得する。
	 * @return updatedId
	 */
	public String getUpdatedId() {
		return updatedId;
	}

	/**
	 * updatedIdを設定する。
	 * @param updatedId
	 */
	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

	/**
	 * updatedDtを取得する。
	 * @return updatedDt
	 */
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * updatedDtを設定する。
	 * @param updatedDt
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

}
