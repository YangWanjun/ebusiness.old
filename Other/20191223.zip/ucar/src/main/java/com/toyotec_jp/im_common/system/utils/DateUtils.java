/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】DateUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/05/12 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * <strong>日付系ユーティリティクラス</strong>
 * <p>
 * 日付関連支援処理を管理するクラス
 * </p>
 * @author
 * @version 1.00 2010/05/17 新規作成<br>
 */
public class DateUtils {

	/** DB用(ODBC標準型)日付書式(yyyy-MM-dd) */
	public static final String DB_FORMAT_SHORT = "yyyy-MM-dd";
	/** DB用(ODBC標準型)日付書式(yyyy-MM-dd HH:mm:ss) */
	public static final String DB_FORMAT_LONG = "yyyy-MM-dd HH:mm:ss";
	/** DB用(ODBC標準型)日付書式(yyyy-MM-dd HH:mm:ss.SSS) */
	public static final String DB_FORMAT_LONG_M = "yyyy-MM-dd HH:mm:ss.SSS";
	/** DB用(ODBC標準型)日付書式(yy-MM-dd HH:mm:ss.SSS) */
	public static final String DB_FORMAT_TIMESTAMP_M = "yy-MM-dd HH:mm:ss.SSS";
	/** アプリケーション固有の日付書式(yyyy/MM/dd|HH:mm:ss) */
	public static final String FORMAT_LONG = "yyyy/MM/dd|HH:mm:ss";
	/** アプリケーション固有の日付書式(yyyy/MM/dd HH:mm:ss) */
	public static final String FORMAT_LONG_SPACE = "yyyy/MM/dd HH:mm:ss";
	/** アプリケーション固有の日付書式(yyyy/MM/dd HH:mm:ss.SSS) */
	public static final String FORMAT_LONG_M_SPACE = "yyyy/MM/dd HH:mm:ss.SSS";
	/** アプリケーション固有の日付書式(yyyy/MM/dd|HH:mm) */
	public static final String FORMAT_LONG_MIN = "yyyy/MM/dd|HH:mm";
	/** アプリケーション固有の日付書式(yyyy/MM/dd HH:mm) */
	public static final String FORMAT_LONG_MIN_SPACE = "yyyy/MM/dd HH:mm";
	/** アプリケーション固有の日付書式(yyyyMMddHHmmss) */
	public static final String FORMAT_LONG_SIMPLE = "yyyyMMddHHmmss";
	/** アプリケーション固有の日付書式(yyyyMMddHHmmssSSS) */
	public static final String FORMAT_LONG_M_SIMPLE = "yyyyMMddHHmmssSSS";
	/** アプリケーション固有の日付書式(yyyy/MM/dd) */
	public static final String FORMAT_SHORT = "yyyy/MM/dd";
	/** アプリケーション固有の日付書式(yyyy/MM) */
	public static final String FORMAT_YM = "yyyy/MM";
	/** アプリケーション固有の日付書式(MM/dd) */
	public static final String FORMAT_MD = "MM/dd";
	/** アプリケーション固有の日付書式(yyyyMMdd) */
	public static final String FORMAT_SHORT_SIMPLE = "yyyyMMdd";
	/** アプリケーション固有の日付書式(yyyyMM) */
	public static final String FORMAT_YM_SIMPLE = "yyyyMM";
	/** アプリケーション固有の日付書式(MMdd) */
	public static final String FORMAT_MD_SIMPLE = "MMdd";
	/** アプリケーション固有の日付書式(yyyy) */
	public static final String FORMAT_Y = "yyyy";
	/** アプリケーション固有の日付書式(MM) */
	public static final String FORMAT_M = "MM";
	/** アプリケーション固有の日付書式(dd) */
	public static final String FORMAT_D = "dd";
	/** アプリケーション固有の日付書式(HH:mm) */
	public static final String FORMAT_HHMM = "HH:mm";

	/** 曜日表現. */
	private static final String[] DAY_OF_WEEK  = {"日", "月", "火", "水", "木", "金", "土"};

	/** 有効年月日：始点 */
	public static String FORMAT_SHORT_VALID_START = "1867/01/01";
	/** 有効年月日：終点 */
	public static String FORMAT_SHORT_VALID_END   = "2200/12/31";

	/*
	 * デフォルトコンストラクタ
	 */
	private DateUtils() {
	}

	/**
	 * 日付型文字列変換関数
	 * <pre>
	 * dateをformatの書式に変換した文字列を返却する
	 * </pre>
	 * @param date フォーマット対象の<code>java.util.Date</code>
	 * @param format 書式
	 * @return 日付文字列
	 */
	public static String dateToString(Date date, String format) {
		DateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(date);
	}

	/**
	 * 日付型取得関数
	 * <pre>
	 * 日付文字列より日付型を作成する
	 * </pre>
	 * @param strDate 書式に従った日付文字列
	 * @param format 書式
	 * @return 日付Object
	 */
	public static Date getDate(String strDate, String format) {
		DateFormat formatter = new SimpleDateFormat(format);
		Date date = null;
		try {
			date = formatter.parse(strDate);
		} catch (ParseException e) {
		}
		return date;
	}

	/**
	 * 日付型取得関数。
	 * <pre>
	 * ODBC標準型の日付文字列から日付型を取得する。
	 * </pre>
	 * @param strDate 日付文字列
	 * @return 日付
	 */
	public static Date getDateFromOdbcFormat(String strDate){
		Date date = null;
		DateFormat formatter = null;
		if(strDate != null){
			try {
				int len = strDate.length();
				// 「yyyy-MM-dd」
				if(len == 10){
					formatter = new SimpleDateFormat(DB_FORMAT_SHORT);
					date = formatter.parse(strDate);
				// 「yyyy-MM-dd HH:mm:ss」
				} else if(len == 19){
					formatter = new SimpleDateFormat(DB_FORMAT_LONG);
					date = formatter.parse(strDate);
				// 「yyyy-MM-dd HH:mm:ss.SSS」
				} else if(len > 19){
					formatter = new SimpleDateFormat(DB_FORMAT_LONG_M);
					String tempDate = StringUtils.padRight(strDate, '0', 23);
					// ミリ秒より小さい値は切り捨て
					date = formatter.parse(tempDate.substring(0, 23));
				}
			} catch (ParseException e) {
				// フォーマット不正によるParse例外は無視
			}
		}
		return date;
	}

	/**
	 * 現在日付取得関数
	 * <pre>
	 * 現在日付を取得する
	 * </pre>
	 * @return 現在日付
	 */
	public static Date getCurrentDate() {
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		return date;
	}

	/**
	 * 現在日付文字列取得関数
	 * <pre>
	 * 指定のフォーマットに従い現在時刻を文字列で取得する
	 * </pre>
	 * @param format フォーマット文字列
	 * @see #FORMAT_LONG
	 * @see #FORMAT_SHORT
	 * @see #FORMAT_YM
	 * @see #FORMAT_MD
	 * @see #FORMAT_Y
	 * @see #FORMAT_M
	 * @see #FORMAT_D
	 * @return フォーマットされた現在時刻の文字列
	 */
	public static String getCurrentDateStr(String format) {
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		DateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(date);
	}

	/**
	 * 曜日表現取得関数
	 * <pre>
	 * インデックスから曜日表示文字列を取得します
	 * </pre>
	 * @param i 0 ~ 7 day of week
	 * @return 曜日文字列
	 */
	public static final String getDayOfWeek(int i) {
		return DAY_OF_WEEK[i];
	}

	/**
	 * 曜日配列取得関数
	 * <pre>
	 * 曜日表示文字列配列を取得します
	 * </pre>
	 * @return String[]「日」～「土」
	 */
	public static String[] getYobiArray() {
		return DAY_OF_WEEK;
	}

	/**
	 * 現在曜日取得関数
	 * <pre>
	 * 現在の曜日を取得します
	 * </pre>
	 * @return 「日,月,火,水,木,金,土」
	 */
	public static String getCurrentYobi() {
		return getYobi(getCurrentDateStr(FORMAT_SHORT));
	}

	/**
	 * 対象曜日取得関数
	 * <pre>
	 * 指定日付の曜日を取得します<br>
	 * ※引数のフォーマットが正しくない場合、空文字を返します
	 * </pre>
	 * @param ymd yyyy/MM/dd
	 * @return 「日～土」
	 */
	public static String getYobi(String ymd) {
		return getDayOfWeek(getYobiNo(ymd));
	}

	/** 対象の年月日の曜日Noを取得 */
	private static int getYobiNo(String ymd) {

		Calendar cal = Calendar.getInstance();
		Date dt = null;
		SimpleDateFormat sdfFormat = null;

		sdfFormat = new SimpleDateFormat("yyyy/MM/dd");
		try {
			dt = sdfFormat.parse(ymd);
		} catch (Exception e) {
			return 0;
		}
		cal.setTime(dt);
		return cal.get(Calendar.DAY_OF_WEEK) - 1;
	}

	/**
	 * 対象年月最終日取得関数
	 * <pre>
	 * 対象の年月の最終日を取得します
	 * </pre>
	 * @param ym   [yyyy/MM|yyyyMM]
	 * @return day [dd]
	 */
	public static String getLastMonth(String ym) {

		Calendar cal = Calendar.getInstance();
		Date dt = null;
		SimpleDateFormat sdfFormat = null;

		sdfFormat = new SimpleDateFormat("yyyyMM");
		try {
			dt = sdfFormat.parse(ym.replaceAll("/", ""));
		} catch (Exception e) {
			return null;
		}
		cal.setTime(dt);
		int day = cal.getActualMaximum(Calendar.DATE);

		return String.valueOf(day);
	}

	/**
	 * 日加減算関数
	 * <pre>
	 * 対象の年月日に日を足した年月日を取得します
	 * </pre>
	 * @param ymd [yyyy/MM/dd]
	 * @param addDay +-可
	 * @return 結果日付
	 */
	public static String addDay(String ymd, int addDay) {

		Calendar cal = Calendar.getInstance();
		Date dt = null;
		SimpleDateFormat sdfFormat = null;

		sdfFormat = new SimpleDateFormat("yyyy/MM/dd");
		try {
			dt = sdfFormat.parse(ymd);
		} catch (Exception e) {
			return null;
		}

		cal.setTime(dt);

		cal.add(Calendar.DATE, addDay);

		DateFormat formatter = new SimpleDateFormat(FORMAT_SHORT);
		return formatter.format(cal.getTime());
	}

	/**
	 * 月加減算関数
	 * <pre>
	 * 対象の年月日に月を足した年月日を取得します
	 * </pre>
	 * @param ymd [yyyy/MM/dd]
	 * @param addMonth +-可
	 * @return 結果日付
	 */
	public static String addMonth(String ymd, int addMonth) {

		Calendar cal = Calendar.getInstance();
		Date dt = null;
		SimpleDateFormat sdfFormat = null;

		sdfFormat = new SimpleDateFormat("yyyy/MM/dd");
		try {
			dt = sdfFormat.parse(ymd);
		} catch (Exception e) {
			return null;
		}

		cal.setTime(dt);

		cal.add(Calendar.MONTH, addMonth);

		DateFormat formatter = new SimpleDateFormat(FORMAT_SHORT);
		return formatter.format(cal.getTime());
	}

	/**
	 * 年加減算関数
	 * <pre>
	 * 対象の年月日に月を足した年月日を取得します
	 * </pre>
	 * @param ymd [yyyy/MM/dd]
	 * @param addYear +-可
	 * @return 結果日付
	 */
	public static String addYear(String ymd, int addYear) {

		Calendar cal = Calendar.getInstance();
		Date dt = null;
		SimpleDateFormat sdfFormat = null;

		sdfFormat = new SimpleDateFormat("yyyy/MM/dd");
		try {
			dt = sdfFormat.parse(ymd);
		} catch (Exception e) {
			return null;
		}

		cal.setTime(dt);

		cal.add(Calendar.YEAR, addYear);

		DateFormat formatter = new SimpleDateFormat(FORMAT_SHORT);
		return formatter.format(cal.getTime());
	}

	/**
	 * 現在年齢取得関数
	 * <pre>
	 * 現在年齢を取得します
	 * </pre>
	 * @param birthYmd
	 * @return 年齢（エラー：-1）
	 */
	public static int getAge(String birthYmd) {
		return getAge(birthYmd, getCurrentDateStr(FORMAT_SHORT));
	}

	/**
	 *
	 * 指定日付年齢取得関数
	 * <pre>
	 * ある日付における年齢を取得します
	 * </pre>
	 * @param birthYmd
	 * @param baseYmd
	 * @return 年齢（エラー：-1）
	 */
	public static int getAge(String birthYmd, String baseYmd) {

		if ((birthYmd == null)||(birthYmd.length() == 0)) {
			return -1;
		}
		if ((baseYmd == null)||(baseYmd.length() == 0)) {
			return -1;
		}

		String[] splBirthYmd = birthYmd.split("/");
		String[] splBaseYmd = baseYmd.split("/");

		//誕生日を数値に分解
		int biYear = Integer.parseInt(splBirthYmd[0]);
		int biMonth = Integer.parseInt(splBirthYmd[1]);
		int biDay = Integer.parseInt(splBirthYmd[2]);

		//基準日を数値に分解
		int baYear = Integer.parseInt(splBaseYmd[0]);
		int baMonth = Integer.parseInt(splBaseYmd[1]);
		int baDay = Integer.parseInt(splBaseYmd[2]);

		//現在年-誕生年=概算年齢
		int age = baYear - biYear;

		//今年の誕生月が来ていなければ
		if (baMonth < biMonth) {
			age--; //概算年齢から１年引く
		//今が誕生月で
		} else if (baMonth == biMonth) {
			//まだ誕生日が来ていなければ
			if (baDay < biDay) {
				age--; //概算年齢から１年引く
			}
		}

		//誕生日が今日より大きければエラーとする
		if (age < 0) {
			return -1;	// エラー
		} else {
			return age; // 年齢を返す
		}
	}

}
