/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarServiceController.java
 * 【  説  明  】
 * 【  作  成  】2010/05/10 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.service.controller;

import java.io.IOException;
import java.lang.reflect.Constructor;

import javax.servlet.http.HttpServletRequest;

import jp.co.intra_mart.common.aid.javaee.http.MultipartFormData;
import jp.co.intra_mart.common.platform.util.NameUtil;
import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.service.ServiceControllerAdapter;
import jp.co.intra_mart.framework.base.service.ServiceControllerException;
import jp.co.intra_mart.framework.base.service.ServiceServlet;
import jp.co.intra_mart.framework.base.util.UserInfo;

import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.FileBean;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.im_common.system.utils.DownloadServlet;
import com.toyotec_jp.im_common.system.utils.SimpleRequestMapper;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.system.session.ApplicationSessionBeanIF;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;

/**
 * <strong>基本サービスコントローラー。</strong>
 * <p>
 * サービスコントローラー作成時は本クラスを継承すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/17 新規作成<br>
 * @since 1.00
 */
public abstract class UcarServiceController extends ServiceControllerAdapter {

	/**
	 * 画面入力値をマッピングしたビーンを取得する。
	 * <pre>
	 * リクエストとして受け取った画面入力値をビーンにマッピングする。<br>
	 * 画面name属性「ab_cde_fg」はビーンのプロパティ「abCdeFg」に
	 * メソッド「setAbCdeFg」を使用してマッピングされる。
	 * </pre>
	 * @param <E> TBeanを継承している型
	 * @param cls マッピング対象となるビーンのクラス
	 * @return リクエストの値をマッピングしたビーン
	 * @throws TecSystemException
	 * @see com.toyotec_jp.im_common.system.utils.SimpleRequestMapper#setRequest(HttpServletRequest, TecBean)
	 */
	protected <E extends TecBean> E getRequestParamMappedBean(Class<E> cls) throws TecSystemException{
		E bean = null;
		Constructor<E> constructor = null;
		try {
			constructor = cls.getConstructor();
			bean = constructor.newInstance();
		} catch (Exception e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		SimpleRequestMapper.setRequest(getRequest(), bean);
		return bean;
	}

	/**
	 * ログインセッションビーン取得。
	 * <pre>
	 * ログインユーザの情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、ログインセッションビーンを生成しセッションに設定した後、返却する。
	 * </pre>
	 * @return ログインセッションビーン
	 * @throws TecSystemException
	 * @see UcarSessionManager#getLoginSessionBean(HttpServletRequest, jp.co.intra_mart.framework.base.util.UserInfo)
	 */
	protected LoginSessionBean getLoginSessionBean() throws TecSystemException {
		UserInfo userInfo = null;
		try {
			userInfo = getUserInfo();
		} catch (ServiceControllerException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getLoginSessionBean(getRequest(), userInfo);
	}

	/**
	 * 新規アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * セッションキーはクラス名を使用する。<br>
	 * 既存の値をセッションから削除し、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 * @see UcarSessionManager#getNewApplicationSessionBean(HttpServletRequest, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getNewApplicationSessionBean(Class<E> cls) throws TecSystemException{
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getNewApplicationSessionBean(getRequest(), cls);
	}

	/**
	 * 新規アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * 既存の値をセッションから削除し、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 * @see UcarSessionManager#getNewApplicationSessionBean(HttpServletRequest, String, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getNewApplicationSessionBean(String key, Class<E> cls) throws TecSystemException{
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getNewApplicationSessionBean(getRequest(), key, cls);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * セッションキーはクラス名を使用する。<br>
	 * 存在しない場合、または存在しているがそのクラスが引数として設定されたクラスと異なる場合、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 * @see UcarSessionManager#getApplicationSessionBean(HttpServletRequest, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(Class<E> cls) throws TecSystemException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getApplicationSessionBean(getRequest(), cls);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、または存在しているがそのクラスが引数として設定されたクラスと異なる場合、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 * @see UcarSessionManager#getApplicationSessionBean(HttpServletRequest, String, Class)
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			String key, Class<E> cls) throws TecSystemException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getApplicationSessionBean(getRequest(), key, cls);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			Class<E> cls, boolean doCreate) throws TecSystemException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getApplicationSessionBean(getRequest(), cls, doCreate);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	protected <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			String key, Class<E> cls, boolean doCreate) throws TecSystemException {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getApplicationSessionBean(getRequest(), key, cls, doCreate);
	}

	/**
	 * アプリケーションセッションビーンをセッションからクリアする。
	 * <pre>
	 * 指定したセッションキーの値を削除する。<br>
	 * セッションキーはクラス名を使用する。
	 * </pre>
	 * @param <E>
	 * @param cls アプリケーションセッションビーンのクラス
	 */
	protected <E extends ApplicationSessionBeanIF> void clearApplicationSession(Class<E> cls) {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		sessionMng.clearApplicationSession(getRequest(), cls);
	}

	/**
	 * アプリケーションセッションビーンをセッションからクリアする。
	 * <pre>
	 * 指定したセッションキーの値を削除する。
	 * </pre>
	 * @param key セッションキー
	 */
	protected void clearApplicationSession(String key) {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		sessionMng.clearApplicationSession(getRequest(), key);
	}

	/**
	 * 全てのアプリケーションセッションビーンをセッションからクリアする。
	 * <pre>
	 * {@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装しているものが対象となる。<br>
	 * ただし、スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。
	 * </pre>
	 * @see UcarSessionManager#clearAllApplicationSession(HttpServletRequest)
	 */
	protected void clearAllApplicationSession() {
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		sessionMng.clearAllApplicationSession(getRequest());
	}

	/**
	 * リクエストに画面遷移用ビーンを設定。
	 * @param <E>
	 * @param bean 画面遷移用ビーン
	 */
	protected <E> void setTransitBean(E bean){
		getRequest().setAttribute(UcarApplicationManager.REQ_ATTR_KEY_TRANSIT_BEAN, bean);
	}

	/**
	 * リクエストから画面遷移用ビーンを取得。
	 * <pre>
	 * 指定した画面遷移用ビーンクラスにCASTして返却する。<br>
	 * 対象が指定クラスまたは指定クラスを継承していない場合はNullを返却する。
	 * </pre>
	 * @param <E>
	 * @param cls 画面遷移用ビーンクラス
	 * @return 画面遷移用ビーン
	 */
	protected <E> E getTransitBean(Class<E> cls){
		E bean = null;
		Object val = getRequest().getAttribute(UcarApplicationManager.REQ_ATTR_KEY_TRANSIT_BEAN);
		if(val != null && cls.isAssignableFrom(val.getClass())){
			bean = cls.cast(val);
		}
		return bean;
	}

	/**
	 * リクエストに共通メッセージ画面遷移用ビーンを設定。
	 * @param bean 共通メッセージ画面遷移用ビーン
	 */
	protected void setMessageBean(MessageBean bean){
		getRequest().setAttribute(UcarApplicationManager.REQ_ATTR_KEY_MESSAGE_BEAN, bean);
	}

	/**
	 * リクエストから共通メッセージ画面遷移用ビーンを取得。
	 * <pre>
	 * 共通メッセージ画面遷移用ビーンではない場合はNullを返却する。
	 * </pre>
	 * @return 共通メッセージ画面遷移用ビーン
	 */
	protected MessageBean getMessageBean(){
		MessageBean bean = null;
		Object val = getRequest().getAttribute(UcarApplicationManager.REQ_ATTR_KEY_MESSAGE_BEAN);
		if(val != null && MessageBean.class.isAssignableFrom(val.getClass())){
			bean = MessageBean.class.cast(val);
		}
		return bean;
	}

	/**
	 * リクエストからメニューID取得。
	 * <pre>
	 * 存在しない場合Nullを返却。
	 * </pre>
	 * @return メニューID
	 */
	protected String getMenuId(){
		return (String)getRequest().getParameter(UcarApplicationManager.REQ_PARAM_NAME_MENU_ID);
	}

	/**
	 * メニューからの呼出かどうか。
	 * @return true:メニューからの呼び出し
	 */
	protected boolean isCallFromMenu(){
		boolean isCallFromMenu = false;
		if(getMenuId() != null){
			isCallFromMenu = true;
		}
		return isCallFromMenu;
	}

	/**
	 * アップロードしたファイルの内容を取得。
	 * <pre>
	 * 指定したパラメータ名になければNullを返却する。
	 * </pre>
	 * @param <E>
	 * @param reqParamName リクエストパラメータ名
	 * @param cls ファイル用ビーン
	 * @return ファイル用ビーン
	 * @throws TecSystemException
	 */
	protected <E extends FileBean> E getUploadFile(String reqParamName, Class<E> cls) throws TecSystemException{
		E fileBean = null;
		MultipartFormData reqFileData = null;
		MultipartFormData.Entity fileEntity = null;
		// リクエストから必要な情報を取得
		try {
			reqFileData = new MultipartFormData(getRequest());
			fileEntity = reqFileData.getEntity(reqParamName);
			// TODO サイズ制限、0バイトファイルについての処理>>AP例外
			if(fileEntity != null){
				Constructor<E> constructor = null;
				constructor = cls.getConstructor();
				fileBean = constructor.newInstance();
				// ファイルビーンに内容を設定
				fileBean.setFileName(fileEntity.getFileName());
				fileBean.setFileByte(fileEntity.getBytes());
			}
		} catch (IllegalArgumentException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (IOException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (Exception e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		return fileBean;
	}

	/**
	 * ダウンロード用の情報を設定(ストレージサービス)。
	 * <pre>
	 * 指定されたストレージサービスのパスにあるファイルを
	 * ダウンロードするための情報を設定する。<br>
	 * ダウンロードサーブレットと連携することでファイルをダウンロードする。
	 * </pre>
	 * @param fileName ダウンロード時のファイル名
	 * @param filePath ストレージサービスのパス
	 * @see DownloadServlet
	 */
	protected void setSSDownloadInformation(String fileName, String filePath){
		getRequest().setAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_FILE_NAME, fileName);
		getRequest().setAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_SS_FILE_PATH, filePath);
	}

	/**
	 * ダウンロード用の情報を設定(APサーバ)。
	 * <pre>
	 * 指定されたAPサーバのパス(work相対)にあるファイルを
	 * ダウンロードするための情報を設定する。<br>
	 * ダウンロードサーブレットと連携することでファイルをダウンロードする。
	 * </pre>
	 * @param fileName ダウンロード時のファイル名
	 * @param filePath APサーバのパス(work相対)
	 * @see DownloadServlet
	 */
	protected void setAPDownloadInformation(String fileName, String filePath){
		getRequest().setAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_FILE_NAME, fileName);
		getRequest().setAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_AP_FILE_PATH, filePath);
	}

	/**
	 * イベントを生成。
	 * <pre>
	 * イベントキーに対応するイベントを返却する。
	 * </pre>
	 * @param eventKey イベントキー
	 * @return イベントキーに対応するイベント
	 * @throws ServiceControllerException
	 */
	protected Event createEvent(TecEventKeyIF eventKey) throws ServiceControllerException {
		return createEvent(eventKey.getApplicationId(), eventKey.getEventKey());
	}

	/**
	 * イベントを生成。
	 * <pre>
	 * イベントキーに対応するイベントを返却する。
	 * </pre>
	 * @param <E>
	 * @param eventKey イベントキー
	 * @param cls 返却するイベントのクラス
	 * @return イベントキーに対応するイベント
	 * @throws TecSystemException
	 */
	protected <E extends Event> E createEvent(TecEventKeyIF eventKey, Class<E> cls) throws TecSystemException {
		E targetEvent = null;
		Event event = null;
		try {
			event = createEvent(eventKey);
		} catch (ServiceControllerException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
        //新環境構築疎通テストの一時修正 2019-09-01 Modify start
//		if(cls.isAssignableFrom(UcarEvent.class)){
		if(UcarEvent.class.isAssignableFrom(cls)){
		//新環境構築疎通テストの一時修正 2019-09-01 Modify end	
			UcarEvent targetEvent2 = (UcarEvent) event;
			LoginSessionBean se = getLoginSessionBean();
			targetEvent2.setUserInfoBean(se.getUserInfoBean());
			targetEvent = (E) targetEvent2;
		} else if(cls.isAssignableFrom(event.getClass())){
			targetEvent = cls.cast(event);
		}else {
			TecSystemException e = new TecSystemException(new ClassCastException());
			TecLogger.error(e);
			throw e;
		}
		return targetEvent;
	}

	/**
	 * サービスID取得。
	 * <pre>
	 * リクエストからサービスIDを取得する。
	 * </pre>
	 * @return サービスID
	 */
	protected String getServiceID(){
		String service = null;
		String baseString = getReqBasePath();
		String[] infoString = baseString.split(ServiceServlet.REQUEST_SEPARATOR, -1);
		if(infoString.length < 2) {
			return null;
		}
		if(NameUtil.isValidName(infoString[1])) {
			service = infoString[1];
		}
		return service;
	}

	/**
	 * アプリケーションID取得。
	 * <pre>
	 * リクエストからアプリケーションIDを取得する。
	 * </pre>
	 * @return アプリケーションID
	 */
	protected String getApplicationID(){
		String application = null;
		String baseString = getReqBasePath();
		String[] infoString = baseString.split(ServiceServlet.REQUEST_SEPARATOR, -1);
		if(infoString.length == 0) {
			return null;
		}
		if(NameUtil.isValidName(infoString[0])) {
			application = infoString[0];
		}
		return application;
	}

	// リクエストの基本パス文字列取得
	private String getReqBasePath(){
		String baseString;
		HttpServletRequest request = getRequest();
		String servletPath = request.getServletPath();
		String pathInfo = request.getPathInfo();
		if (pathInfo == null) {
			if(servletPath.charAt(0) == '/') {
				baseString = servletPath.substring(1, servletPath.lastIndexOf('.'));
			} else {
				baseString = servletPath.substring(0, servletPath.lastIndexOf('.'));
			}
		} else {
			baseString = pathInfo;
		}
		return baseString;
	}

}
