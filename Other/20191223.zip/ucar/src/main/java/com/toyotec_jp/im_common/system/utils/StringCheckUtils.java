/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】StringCheckUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/06/08 T.H(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.util.regex.Pattern;

/**
 * <strong>文字列チェック系ユーティリティクラス</strong>
 * <p>
 * 数値チェック関連支援処理を管理するクラス
 *
 * @author T.H(SCC)
 * @version 1.00 2010/06/08 新規作成<br>
 */
public class StringCheckUtils {

	/*
     * デフォルトコンストラクタ
     */
	private StringCheckUtils() {
	}

	/**
	 * null/空文字判定関数。
	 * <pre>
	 * 対象文字列がnull/空文字かどうかを判定する。
	 * </pre>
	 * @param val 対象の文字列
	 * @return true:null/空文字である
	 */
	public static boolean isEmpty(String val) {
		if(val == null || val.length() == 0){
			return true;
		}
		return false;
	}

	/**
	 * null/空文字/スペースのみ判定関数。
	 * <pre>
	 * 対象文字列がnull/空文字/スペースのみかどうかを判定する。
	 * </pre>
	 * @param val 対象の文字列
	 * @return true:null/空文字/スペースのみである
	 */
	public static boolean isBlank(String val) {
		if(isEmpty(val)){
			return true;
		}
		int strLen = val.length();
		for(int i = 0; i < strLen; i++){
			if(!Character.isWhitespace(val.charAt(i))){
				return false;
			}
		}
		return true;
	}

	/**
	 * 文字列比較関数。
	 * <pre>
	 * 文字列1と文字列2を比較する。<br>
	 * 同じである場合はtrue。<br>
	 * (共にnullである場合もtrue)
	 * </pre>
	 * @param str1 文字列1
	 * @param str2 文字列2
	 * @return true:文字列1と文字列2が同じ
	 */
	public static boolean equals(String str1, String str2) {
		return str1 == null ? str2 == null : str1.equals(str2);
	}

	/**
	 * 指定バイト数以内判定関数
	 * <pre>
	 * 指定したバイト数以内かどうか判断します
	 * ※デフォルトエンコーディングを使用
	 * </pre>
	 * @param val 対象の文字列
	 * @param byteLength 指定サイズ
	 * @return 判定結果
	 */
	public static boolean isRange(String val, int byteLength) {
		if (val == null) return false;
		if (val.getBytes().length > byteLength) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 指定バイト数判定関数
	 * <pre>
	 * 指定したバイト数かどうか判断します
	 * ※デフォルトエンコーディングを使用
	 * </pre>
	 * @param val 対象の文字列
	 * @param byteLength 指定サイズ
	 * @return 判定結果
	 */
	public static boolean isSameByte(String val, int byteLength) {
		if (val == null) return false;
		if (val.getBytes().length == byteLength) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 半角英数判定関数
	 * <pre>
	 * 対象の文字列が半角英数か判断する
	 * 空文字はfalseを返却する
	 * </pre>
	 * @param val 対象の文字列
	 * @param isPermitEmpty 空文字を許可するか
	 * @return 判定結果
	 */
	public static boolean ishalfSizeEngNum(String val, boolean isPermitEmpty) {
		if (val == null) return false;
		if (isPermitEmpty) {
			return Pattern.matches("[0-9a-zA-Z]*", val);
		} else {
			return Pattern.matches("[0-9a-zA-Z]+", val);
		}
	}

	/**
	 * 半角数字判定関数
	 * <pre>
	 * 対象の文字列が半角数字か判断する
	 * 空文字はfalseを返却する
	 * </pre>
	 * @param val 対象の文字列
	 * @return 判定結果
	 * @author H.T(TOYOTEC)
	 * @since 2011/04/20
	 */
	public static boolean ishalfSizeNum(String val) {
		if (val == null) return false;

		return Pattern.matches("[0-9]+", val);
	}
}
