package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataListPagingBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckParamBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb005gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb006gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両チェックDAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/07 新規作成<br>
 * @since 1.00
 * @category [[車両チェック]]
 */
public class CarCheckDAOImpl extends UcarSharedDBDAO implements CarCheckDAOIF {

	/** 保証書と記録簿が存在する場合 */
	private static final int COUNT_HOSYO_KIROKU = 2;

	/** 加修フラグ取得処理（作業工程マスタ）SQL */
	private static final String SELECT_UCAB002M_KB_KASYU_SQL
		= "SELECT "
		+ "    KB_KASYU "
		+ "FROM "
		+ "  T220014M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_SGYOKT   = ? "
		+ "  AND KB_DISP     = ? ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#selectEnterCheckListPaging(java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckParamBean, boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public CarCheckDataListPagingBean selectEnterCheckListPaging(
			String cdKaisya, String cdHanbaitn,
			String cdHantenpo, String kbScenter,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			CarCheckParamBean carCheckParamBean, boolean isNarrowSearch,
			String sortOrder, String sortParam, String pageNo, String pageSize)
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "      , CD_ZAITENPO ";
			sqlTenpo2 = "    AND HANNYU.CD_HANTENPO = CHKNAIYO.CD_ZAITENPO ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		String selectT220003gJoinSql
			= "  LEFT JOIN ( "
			+ "    SELECT "
			+ "        CD_KAISYA "
			+ "      , CD_HANBAITN "
			+ "      , DD_HANNYU "
			+ "      , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "      , COUNT(*) COUNT_HOSYO_KIROKU "
			+ "    FROM "
			+ "      " + UcarTableManager.getCheckNaiyo(kbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    WHERE "
			+ "         KB_CHECK = ? "
			+ "      OR KB_CHECK = ? "
			+ "    GROUP BY "
			+ "        CD_KAISYA "
			+ "      , CD_HANBAITN "
			+ "      , DD_HANNYU "
			+ "      , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  ) CHKNAIYO "
			+ "    ON HANNYU.CD_KAISYA    = CHKNAIYO.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = CHKNAIYO.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = CHKNAIYO.DD_HANNYU  "
			+ "    AND HANNYU.NO_KANRI    = CHKNAIYO.NO_KANRI "
			+ sqlTenpo2;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		// 2013.05.09 T.Hayato 修正 搬入拠点分散対応2のため start
		/** 入庫検査 画面出力値取得処理 SQL */
		String selectEnterCheckSql
			= "SELECT "
			+ "    HANNYU.CD_KAISYA "
			+ "  , HANNYU.CD_HANBAITN "
			+ "  , HANNYU.DD_HANNYU "
			+ "  , HANNYU.NO_KANRI "
			+ "  , HANNYU.CD_SIRTENPO "
			+ "  , HANNYU.MJ_SYAMEI "
			+ "  , HANNYU.NO_SYADAI "
			+ "  , HANNYU.DD_SYODOTOR "
			+ "  , HANNYU.CD_TOSYOKU "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
			+ "  , HANNYU.DD_INKANKGN "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end
			+ "  , NYUKO.DD_NKKNS "
			+ "  , NYUKO.DD_NKKHR "
			+ "  , HANNYU.MJ_BIKOU "
			+ "  , CASE CHKNAIYO.COUNT_HOSYO_KIROKU "
			+ "         WHEN " + COUNT_HOSYO_KIROKU + " THEN 'true' " // 搬入時に保証書、記録簿が全て存在すれば"true"
			+ "         ELSE 'false' END EXIST_CHECK_CONTENTS "
			+ "  , NYUKO.DT_KOSIN NYUKO_DT_KOSIN " // 入庫チェックDB：データ更新日時
			+ "  , SYORUI.DD_SRKHR "
			+ "FROM "
			+ "  " + UcarTableManager.getSyaryoHannyuSelectOnly(kbScenter) + " HANNYU "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  LEFT JOIN " + UcarTableManager.getSyoruiCheck(kbScenter) + " SYORUI "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = SYORUI.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = SYORUI.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = SYORUI.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = SYORUI.NO_KANRI ";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			selectEnterCheckSql += "    AND HANNYU.CD_HANTENPO = SYORUI.CD_ZAITENPO ";
		}

		selectEnterCheckSql
			+= "  LEFT JOIN " + UcarTableManager.getNyuko(kbScenter) + " NYUKO "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = NYUKO.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = NYUKO.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = NYUKO.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = NYUKO.NO_KANRI ";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			selectEnterCheckSql += "    AND HANNYU.CD_HANTENPO = NYUKO.CD_ZAITENPO ";
		}

		// 2019.03.27 T.Osada 修正 会社融合対応 strat
		if (cdHanbaitn.equals(UcarConst.TOYOTA) || 
				cdHanbaitn.equals(UcarConst.TOYOPET) ||  
				cdHanbaitn.equals(UcarConst.COROLLA) || 
/*2019.4.24 FROM レクサス追加
				cdHanbaitn.equals(UcarConst.NETZ)){
*/
				cdHanbaitn.equals(UcarConst.NETZ) ||
				cdHanbaitn.equals(UcarConst.LEXUS)){
//2019.4.24 TO				
			selectEnterCheckSql
			+= selectT220003gJoinSql
			+ "WHERE "
			+ "      HANNYU.CD_HANTENPO = ? ";	
		} else {
			selectEnterCheckSql
			+= selectT220003gJoinSql
			+ "WHERE "
			+ "      HANNYU.CD_KAISYA   = ? "
			+ "  AND HANNYU.CD_HANBAITN = ? "
			+ "  AND HANNYU.CD_HANTENPO = ? ";	
		}
		// 2019.03.27 T.Osada 修正 会社融合対応 end
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			// 2012.02.21 T.Hayato 修正 搬入車両 全件表示のため start
//			// 書類チェックDBの書類完備日か書類完備保留日のどちらかに日付の入力がある
//			+ "  AND (SYORUI.DD_SRKNB IS NOT NULL "
//			+ "       OR SYORUI.DD_SRKHR IS NOT NULL) "
//		    ;
			// 2012.02.21 T.Hayato 修正 搬入車両 全件表示のため end
		// 2013.05.09 T.Hayato 修正 搬入拠点分散対応2のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		// パラメータセット<条件>
		paramBean.setString(UcarConst.KB_CHECK_HOSYOUSYO);	// 保証書
		paramBean.setString(UcarConst.KB_CHECK_KIROKUBO);	// 記録簿
		// 2019.03.27 T.Osada 修正 会社融合対応 strat
		if 	(cdHanbaitn.equals(UcarConst.TOYOTA) || 
						cdHanbaitn.equals(UcarConst.TOYOPET) ||  
						cdHanbaitn.equals(UcarConst.COROLLA) || 
/*2019.4.24 FROM レクサス追加						
						cdHanbaitn.equals(UcarConst.NETZ)){
*/
						cdHanbaitn.equals(UcarConst.NETZ) ||
						cdHanbaitn.equals(UcarConst.LEXUS)){
//2019.4.24 TO						
			paramBean.setString(cdHantenpo);	// 搬入店舗コード	
		} else {
			paramBean.setString(cdKaisya);		// 会社コード
			paramBean.setString(cdHanbaitn);	// 販売店コード
			paramBean.setString(cdHantenpo);	// 搬入店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		}
		// 2019.03.27 T.Osada 修正 会社融合対応 end

		String strSql = "";
		// 検索条件
		StringBuilder sqlCondition = new StringBuilder();

		if (isNarrowSearch) {
			// 絞り込み検索実行時
			if(!carCheckParamBean.getDdConditionFrom().equals("")){
				// 入庫検査日
				sqlCondition.append("  AND NYUKO.DD_NKKNS BETWEEN ? AND ? ");
				paramBean.setString(carCheckParamBean.getDdConditionFrom().replace("/", ""));	// 入庫検査日(From)
				paramBean.setString(carCheckParamBean.getDdConditionTo().replace("/", ""));		// 入庫検査日(To)
			}
			if(!carCheckParamBean.getNoSyadai().equals("")){
				sqlCondition.append(" AND HANNYU.NO_SYADAI LIKE '%" + carCheckParamBean.getNoSyadai() + "%'");
			}
			if(!carCheckParamBean.getRdoKoutei().equals("")){
				if(CarCheckConst.ENTERCHECK_INCOMPLETE.equals(carCheckParamBean.getRdoKoutei())) {
					// 入庫検査未完了
					sqlCondition.append("  AND NYUKO.DD_NKKNS IS NULL ");
				} else if (CarCheckConst.ENTERCHECK_COMPLETE.equals(carCheckParamBean.getRdoKoutei())) {
					// 入庫検査完了
					sqlCondition.append("  AND NYUKO.DD_NKKNS IS NOT NULL ");
				} else if (CarCheckConst.ENTERCHECK_RESERVE.equals(carCheckParamBean.getRdoKoutei())) {
					// 保留
					sqlCondition.append("  AND NYUKO.DD_NKKHR IS NOT NULL ");
				}
			}
		} else {
			// 絞り込み検索未実行時
			// 入庫検査未完了
			sqlCondition.append("  AND NYUKO.DD_NKKNS IS NULL ");
		}
		strSql = selectEnterCheckSql + sqlCondition.toString();

		paramBean.setSql(strSql);

		StringBuilder orderSql = createOrderSql(sortOrder, sortParam);
		// ソート条件
		paramBean.setOrderSql(orderSql.toString());

		// ページ設定
		paramBean.setPageNo(Integer.parseInt(pageNo));

		paramBean.setPageSize(Integer.parseInt(pageSize));

		CarCheckDataListPagingBean resultPagingBean
			= executeSimplePagingQuery(paramBean, CarCheckDataListPagingBean.class, CarCheckDataBean.class);

		return resultPagingBean;
	}

	// 2012.02.23 T.Hayato 修正 Order by SQL 共通メソッド化 start
	/**
	 * Order by句作成
	 * @param orderSql
	 * @param sortOrder
	 * @param sortParam
	 */
	private StringBuilder createOrderSql(String sortOrder, String sortParam) {

		StringBuilder orderSql = new StringBuilder();

		//並び順がない場合は昇順とする
		if (sortOrder.equals("")){
			sortOrder = "ASC";
		}
		//ソート条件(テーブル名のエイリアスを入れるとエラーになるので、意図的に列名のみを記述)
		if(!sortParam.equals("")){
			if (sortParam.equals("DD_HANNYU")){
				// 搬入日
				orderSql.append(" ORDER BY CD_KAISYA "   +
						        "         ,CD_HANBAITN " +
						        "         ,DD_HANNYU "   + sortOrder +
						        "         ,NO_KANRI ");
			} else if (sortParam.equals("DD_NKKNS")) {
				// 入庫検査日
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,DD_NKKNS "    + sortOrder +
								"         ,DD_HANNYU "   +
								"         ,NO_KANRI ");
			// 2012.03.26 T.Hayato 追加 印鑑証明期限日ソート機能 追加のため start
			} else if (sortParam.equals("DD_INKANKGN")) {
				// 印鑑証明期限日
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,DD_INKANKGN " + sortOrder +
								"         ,DD_HANNYU "   +
								"         ,NO_KANRI ");
			// 2012.03.26 T.Hayato 追加 印鑑証明期限日ソート機能 追加のため end
			} else {
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,DD_HANNYU "   + sortOrder +
								"         ,NO_KANRI ");
			}
		} else {
			orderSql.append(" ORDER BY CD_KAISYA "   +
					        "         ,CD_HANBAITN " +
					        "         ,DD_HANNYU "   + sortOrder +
					        "         ,NO_KANRI ");
		}
		return orderSql;
	}
	// 2012.02.23 T.Hayato 修正 Order by SQL 共通メソッド化 end

	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#selectEnterCheckList(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public ResultArrayList<CarCheckDataBean> selectEnterCheckList(
			String cdKaisya,
			String cdHanbaitn,
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
			String cdHantenpo,
			String kbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			String ddHannyu,
			String noKanri,
			boolean isNullDdNkkns) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "      , CD_ZAITENPO ";
			sqlTenpo2 = "    AND HANNYU.CD_HANTENPO = CHKNAIYO.CD_ZAITENPO ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		String selectT220003gJoinSql
			= "  LEFT JOIN ( "
			+ "    SELECT "
			+ "        CD_KAISYA "
			+ "      , CD_HANBAITN "
			+ "      , DD_HANNYU "
			+ "      , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "      , COUNT(*) COUNT_HOSYO_KIROKU "
			+ "    FROM "
	//		+ "      T220003G "
			+ "      " + UcarTableManager.getCheckNaiyo(kbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    WHERE "
			+ "         KB_CHECK = ? "
			+ "      OR KB_CHECK = ? "
			+ "    GROUP BY "
			+ "        CD_KAISYA "
			+ "      , CD_HANBAITN "
			+ "      , DD_HANNYU "
			+ "      , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  ) CHKNAIYO "
			+ "    ON HANNYU.CD_KAISYA    = CHKNAIYO.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = CHKNAIYO.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = CHKNAIYO.DD_HANNYU  "
			+ "    AND HANNYU.NO_KANRI    = CHKNAIYO.NO_KANRI "
			+ sqlTenpo2;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		/** 入庫検査 画面出力値取得処理 SQL */
		final String SELECT_ENTER_CHECK_SQL
			= "SELECT "
			+ "    HANNYU.CD_KAISYA "
			+ "  , HANNYU.CD_HANBAITN "
			+ "  , HANNYU.DD_HANNYU "
			+ "  , HANNYU.NO_KANRI "
			+ "  , HANNYU.CD_SIRTENPO "
			+ "  , HANNYU.MJ_SYAMEI "
			+ "  , HANNYU.NO_SYADAI "
			+ "  , HANNYU.DD_SYODOTOR "
			+ "  , HANNYU.CD_TOSYOKU "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
			+ "  , HANNYU.DD_INKANKGN "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end
			+ "  , NYUKO.DD_NKKNS "
			+ "  , NYUKO.DD_NKKHR "
			+ "  , HANNYU.MJ_BIKOU "
			+ "  , CASE CHKNAIYO.COUNT_HOSYO_KIROKU "
			+ "         WHEN " + COUNT_HOSYO_KIROKU + " THEN 'true' " // 搬入時に保証書、記録簿が全て存在すれば"true"
			+ "         ELSE 'false' END EXIST_CHECK_CONTENTS "
			+ "  , NYUKO.DT_KOSIN NYUKO_DT_KOSIN " // 入庫チェックDB：データ更新日時
			+ "  , SYORUI.DD_SRKHR "
			+ "FROM "
//			+ "  T220001G HANNYU "
			+ "  " + UcarTableManager.getSyaryoHannyuSelectOnly(kbScenter) + " HANNYU "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
//			+ "  LEFT JOIN T220007G SYORUI "
			+ "  LEFT JOIN " + UcarTableManager.getSyoruiCheck(kbScenter) + " SYORUI "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = SYORUI.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = SYORUI.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = SYORUI.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = SYORUI.NO_KANRI "
//			+ "  LEFT JOIN T220008G NYUKO "
			+ "  LEFT JOIN " + UcarTableManager.getNyuko(kbScenter) + " NYUKO "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = NYUKO.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = NYUKO.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = NYUKO.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = NYUKO.NO_KANRI "

			+ selectT220003gJoinSql
			//2019.05.11 T.Osada レクサス対応 start
			//+ "WHERE "
			//+ "      HANNYU.CD_KAISYA   = ? "
			//+ "  AND HANNYU.CD_HANBAITN = ? "
			//+ "  AND HANNYU.CD_HANTENPO = ? "	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "WHERE "
			+ "        HANNYU.CD_HANTENPO = ? "	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			//2019.05.11 T.Osada レクサス対応 end
			// 2012.02.21 T.Hayato 修正 搬入車両 全件表示のため start
//			// 書類チェックDBの書類完備日か書類完備保留日のどちらかに日付の入力がある
//			+ "  AND (SYORUI.DD_SRKNB IS NOT NULL "
//			+ "       OR SYORUI.DD_SRKHR IS NOT NULL) "
			;
			// 2012.02.21 T.Hayato 修正 搬入車両 全件表示のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		// パラメータセット<条件>
		paramBean.setString(UcarConst.KB_CHECK_HOSYOUSYO);	// 保証書
		paramBean.setString(UcarConst.KB_CHECK_KIROKUBO);	// 記録簿
		//2019.05.11 T.Osada レクサス対応 start
		//paramBean.setString(cdKaisya);		// 会社コード
		//paramBean.setString(cdHanbaitn);	// 販売店コード
		//2019.05.11 T.Osada レクサス対応 end
		paramBean.setString(cdHantenpo);	// 搬入店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		// 検索条件
		StringBuilder sqlCondition = new StringBuilder();

		if (isNullDdNkkns) {
			// 入庫検査未完了
			sqlCondition.append("  AND NYUKO.DD_NKKNS IS NULL ");
		} else {
			// 入庫検査完了
			sqlCondition.append("  AND NYUKO.DD_NKKNS IS NOT NULL ");
		}

		// 搬入日
		sqlCondition.append("  AND HANNYU.DD_HANNYU = ? ");
		paramBean.setString(ddHannyu);
		// 管理番号
		sqlCondition.append("  AND HANNYU.NO_KANRI = ? ");
		paramBean.setString(noKanri);

		String strSql = SELECT_ENTER_CHECK_SQL + sqlCondition.toString();
		paramBean.setSql(strSql);

		ResultArrayList<CarCheckDataBean> resultList = executeSimpleSelectQuery(paramBean, CarCheckDataBean.class);

		return resultList;
	}
	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.EnterCheckDAOIF#selectT220008GCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb005gBean)
	 */
	@Override
//	public int selectT220008GCount(T220008gBean t220008gBean) throws TecDAOException {
	public int selectT220008GCount(Uccb005gBean t220008gBean) throws TecDAOException {	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 入庫チェックDB取得処理（入庫チェックDB）SQL */
		final String SELECT_T220008G_SQL
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "FROM "
//			+ "  T220008G "
			+ "  " + UcarTableManager.getNyuko(t220008gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		int count = 0;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220008G_SQL);

			// パラメータセット<条件>
			paramBean.setString(t220008gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220008gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220008gBean.getDdHannyu());	// 搬入日
			paramBean.setString(t220008gBean.getNoKanri());		// 管理番号
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
			if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
				paramBean.setString(t220008gBean.getCdZaitenpo());	// 在庫店舗コード
			}
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			// 取得
			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	@Override
//	public SimpleExecuteResultBean insertT220008G(T220008gBean t220008gBean,
	public SimpleExecuteResultBean insertT220008G(Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 新規登録処理（入庫チェックDB）SQL */
		final String INSERT_T220008G_SQL
			= "INSERT "
//			+ "INTO T220008G( "
			+ "INTO " + UcarTableManager.getNyuko(t220008gBean.getKbScenter()) + "( "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , DD_NKKNS "
			+ "  , DD_NKKHR "
			+ "  , DD_NKKFK "
			+ "  , MJ_NKKBK "
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
			+ "  , CD_NKKTAN "
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため end
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
			+ "  , ? "
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため end
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220008G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220008gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220008gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220008gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220008gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220008gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(t220008gBean.getDdNkkns());		// 入庫検査日
		paramBean.setString(t220008gBean.getDdNkkhr());		// 入庫検査保留日
		paramBean.setString(t220008gBean.getDdNkkfk());		// 入庫検査保留復帰予定日
		paramBean.setString(t220008gBean.getMjNkkbk());		// 入庫検査備考
		// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
		paramBean.setString(t220008gBean.getCdNkktan());	// 入庫検査担当者コード
		// 2012.03.26 T.Hayato 追加 チェック者 追加のため end

		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220008gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220008gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220008gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220008gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	@Override
//	public SimpleExecuteResultBean updateT220008G(T220008gBean t220008gBean,
	public SimpleExecuteResultBean updateT220008G(Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String nyukoDtKosin, Timestamp executeDate)
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 更新処理（入庫チェックDB）SQL */
		String UPDATE_T220008G_SQL
//			= "UPDATE T220008G "
			= "UPDATE " + UcarTableManager.getNyuko(t220008gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    DD_NKKNS = ? "
			+ "  , DD_NKKHR = ? "
			+ "  , DD_NKKFK = ? "
			+ "  , MJ_NKKBK = ? "
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
			+ "  , CD_NKKTAN = ? "
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため end
			+ "  , DT_KOSIN = ? "
			+ "  , CD_KSNSYA = ? "
			+ "  , CD_KSNAPP = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220008G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220008gBean.getDdNkkns());		// 入庫検査日
		paramBean.setString(t220008gBean.getDdNkkhr());		// 入庫検査日保留日
		paramBean.setString(t220008gBean.getDdNkkfk());		// 入庫検査保留復帰予定日
		paramBean.setString(t220008gBean.getMjNkkbk());		// 入庫検査備考
		// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
		paramBean.setString(t220008gBean.getCdNkktan());	// 入庫検査担当者コード
		// 2012.03.26 T.Hayato 追加 チェック者 追加のため end

		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220008gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220008gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220008gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220008gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220008gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220008gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220008gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(nyukoDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	@Override
//	public SimpleExecuteResultBean deleteT220008G(T220008gBean t220008gBean,
	public SimpleExecuteResultBean deleteT220008G(Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String nyukoDtKosin) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 削除処理（入庫チェックDB）SQL */
		final String DELETE_T220008G_SQL
			= "DELETE  "
			+ "FROM "
//			+ "  T220008G  "
			+ "  " + UcarTableManager.getNyuko(t220008gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220008G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220008gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220008gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220008gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220008gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220008gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220008gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(nyukoDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	@Override
//	public SimpleExecuteResultBean insertT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean insertT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 新規登録処理（ステータスDB） SQL */
		final String INSERT_T220012G_SQL
			= "INSERT "
//			+ "INTO T220012G( "
			+ "INTO " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + "( "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , DT_STATUS01 "
			+ "  , DT_STATUS02 "
			+ "  , DT_STATUS03 "
			+ "  , DT_STATUS04 "
			+ "  , DT_STATUS05 "
			+ "  , DT_STATUS06 "
			+ "  , DT_STATUS07 "
			+ "  , DT_STATUS08 "
			+ "  , DT_STATUS09 "
			+ "  , DT_STATUS10 "
			+ "  , DT_STATUS11 "
			+ "  , DT_STATUS12 "
			+ "  , DT_STATUS13 "
			+ "  , DT_STATUS14 "
			+ "  , DT_STATUS15 "
			+ "  , DT_STATUS16 "
			+ "  , DT_STATUS17 "
			+ "  , DT_STATUS18 "
			+ "  , DT_STATUS19 "
			+ "  , DT_STATUS20 "
			+ "  , DT_STATUS21 "
			+ "  , DT_STATUS22 "
			+ "  , DT_STATUS23 "
			+ "  , DT_STATUS24 "
			// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため start
			+ "  , KB_SGYOKT "
			// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため end
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
			+ "  , NU_AZONE "
			+ "  , NU_BZONE "
			+ "  , NU_ABZONE "
			+ "  , NU_SYOHN "
			+ "  , MJ_KASYU "
			+ "  , MJ_MARUCL "
			+ "  , MJ_SEIBI "
			+ "  , MJ_AMUSU "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため start
			+ "  , ? "
			// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため end
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220012G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		paramBean.setString(t220012gInputDataBean.getStrDtStatus01());	// ステータス01
		paramBean.setString(t220012gInputDataBean.getStrDtStatus02());	// ステータス02
		paramBean.setString(t220012gInputDataBean.getStrDtStatus03());	// ステータス03
		paramBean.setString(t220012gInputDataBean.getStrDtStatus04());	// ステータス04
		paramBean.setString(t220012gInputDataBean.getStrDtStatus05());	// ステータス05
		paramBean.setString(t220012gInputDataBean.getStrDtStatus06());	// ステータス06
		paramBean.setString(t220012gInputDataBean.getStrDtStatus07());	// ステータス07
		paramBean.setString(t220012gInputDataBean.getStrDtStatus08());	// ステータス08
		paramBean.setString(t220012gInputDataBean.getStrDtStatus09());	// ステータス09
		paramBean.setString(t220012gInputDataBean.getStrDtStatus10());	// ステータス10
		paramBean.setString(t220012gInputDataBean.getStrDtStatus11());	// ステータス11
		paramBean.setString(t220012gInputDataBean.getStrDtStatus12());	// ステータス12
		paramBean.setString(t220012gInputDataBean.getStrDtStatus13());	// ステータス13
		paramBean.setString(t220012gInputDataBean.getStrDtStatus14());	// ステータス14
		paramBean.setString(t220012gInputDataBean.getStrDtStatus15());	// ステータス15
		paramBean.setString(t220012gInputDataBean.getStrDtStatus16());	// ステータス16
		paramBean.setString(t220012gInputDataBean.getStrDtStatus17());	// ステータス17
		paramBean.setString(t220012gInputDataBean.getStrDtStatus18());	// ステータス18
		paramBean.setString(t220012gInputDataBean.getStrDtStatus19());	// ステータス19
		paramBean.setString(t220012gInputDataBean.getStrDtStatus20());	// ステータス20
		paramBean.setString(t220012gInputDataBean.getStrDtStatus21());	// ステータス21
		paramBean.setString(t220012gInputDataBean.getStrDtStatus22());	// ステータス22
		paramBean.setString(t220012gInputDataBean.getStrDtStatus23());	// ステータス23
		paramBean.setString(t220012gInputDataBean.getStrDtStatus24());	// ステータス24

		// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため start
		paramBean.setString(t220012gInputDataBean.getKbSgyokt());		// 作業工程区分
		// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため end

		// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
		paramBean.setInt(0);		// Aゾーン日数
		paramBean.setInt(0);		// Bゾーン日数
		paramBean.setInt(0);		// ABゾーン日数
		paramBean.setInt(0);		// 商品化日数
		paramBean.setString("0");	// 加修フラグ
		paramBean.setString("0");	// まるクリフラグ
		paramBean.setString("0");	// 整備フラグ
		paramBean.setString("0");	// アムスフラグ
		// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	@Override
	public SimpleExecuteResultBean updateT220012GEnterCheck(
//			T220012gInputDataBean t220012gInputDataBean, Timestamp executeDate) throws TecDAOException {
			Uccb007gInputDataBean t220012gInputDataBean, Timestamp executeDate) throws TecDAOException {	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		/** 更新処理（ステータスDB）入庫検査用 SQL */
		final String UPDATE_T220012G_ENTERCHECK_SQL
//			= "UPDATE T220012G "
			= "UPDATE " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    DT_STATUS05 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , DT_STATUS06 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , DT_KOSIN    = ? "
			+ "  , CD_KSNSYA   = ? "
			+ "  , CD_KSNAPP   = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220012G_ENTERCHECK_SQL);

		// パラメータセット<値>
		paramBean.setString(t220012gInputDataBean.getStrDtStatus05());	// ステータス05
		paramBean.setString(t220012gInputDataBean.getStrDtStatus06());	// ステータス06

		paramBean.setTimestamp(executeDate);						// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	@Override
	public SimpleExecuteResultBean updateT220012GWorkSort(
//			T220012gInputDataBean t220012gInputDataBean, Timestamp executeDate) throws TecDAOException {
			Uccb007gInputDataBean t220012gInputDataBean, Timestamp executeDate) throws TecDAOException {	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 更新処理（ステータスDB）作業仕分用 SQL */
		final String UPDATE_T220012G_WORKSORTT_SQL
//			= "UPDATE T220012G "
			= "UPDATE " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    DT_STATUS07 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , DT_STATUS08 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			// 2013.03.13 T.Hayato 修正 現行機能アップ 修正のため start
			+ "  , DT_STATUS19 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			// 2013.03.13 T.Hayato 修正 現行機能アップ 修正のため end
			// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため start
			+ "  , KB_SGYOKT   = ? "
			// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため end
			+ "  , DT_KOSIN    = ? "
			+ "  , CD_KSNSYA   = ? "
			+ "  , CD_KSNAPP   = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220012G_WORKSORTT_SQL);

		// パラメータセット<値>
		paramBean.setString(t220012gInputDataBean.getStrDtStatus07());	// ステータス07
		paramBean.setString(t220012gInputDataBean.getStrDtStatus08());	// ステータス08
		paramBean.setString(t220012gInputDataBean.getStrDtStatus19());	// ステータス19
		// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため start
		paramBean.setString(t220012gInputDataBean.getKbSgyokt());		// 作業工程区分
		// 2012.03.28 T.Hayato 追加 作業工程区分 更新のため end

		paramBean.setTimestamp(executeDate);						// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#selectT220013GCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean)
	 */
	@Override
//	public int selectT220013GCount(T220013gBean t220013gBean)
	public int selectT220013GCount(Uccb009gBean t220013gBean)	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 車両搬出情報取得処理（車両搬出情報）SQL */
		String SELECT_T220013G_SQL
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "FROM "
//			+ "  T220013G "
			+ "  " + UcarTableManager.getSyaryoHansyutu(t220013gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		int count = 0;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220013G_SQL);

			// パラメータセット<条件>
			paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
			paramBean.setString(t220013gBean.getNoKanri());		// 管理番号
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
			if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
				paramBean.setString(t220013gBean.getCdZaitenpo());	// 在庫店舗コード
			}
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			// 取得
			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#selectT220013G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean)
	 */
	@Override
	public ResultArrayList<Uccb009gBean> selectT220013G(
			Uccb009gBean t220013gBean) throws TecDAOException {

		String sqlTenpo = "";
		if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}

		/** 車両搬出情報取得処理（車両搬出情報）SQL */
		String SELECT_T220013G_SQL
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , DD_TENUKT "
			+ "FROM "
			+ "  " + UcarTableManager.getSyaryoHansyutu(t220013gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220013G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220013gBean.getNoKanri());		// 管理番号

		if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220013gBean.getCdZaitenpo());	// 在庫店舗コード
		}

		// 取得
		ResultArrayList<Uccb009gBean> t220013gList = executeSimpleSelectQuery(paramBean, Uccb009gBean.class);

		return t220013gList;
	}
	// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため end

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#insertT220013G(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220013gBean, java.sql.Timestamp)
	 */
	@Override
//	public SimpleExecuteResultBean insertT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean insertT220013G(Uccb009gBean t220013gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 新規登録処理（車両搬出情報） SQL */
		final String INSERT_T220013G_SQL
			= "INSERT "
//			+ "INTO T220013G( "
			+ "INTO " + UcarTableManager.getSyaryoHansyutu(t220013gBean.getKbScenter()) + "( "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , DD_HANSYT "
			+ "  , KB_SGYOKT "
			+ "  , KB_KASYU "
			+ "  , CD_HSTENPO "
			+ "  , DD_KANKENBI "
			+ "  , DD_HANSYTYT "
			+ "  , DT_HANSYPRT "
			+ "  , MJ_HANSYTBK "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220013G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220013gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220013gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		paramBean.setString(t220013gBean.getDdHansyt());	// 搬出日
		paramBean.setString(t220013gBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(t220013gBean.getKbKasyu());		// 加修フラグ
		paramBean.setString(t220013gBean.getCdHstenpo());	// 配車店舗コード
		paramBean.setString(t220013gBean.getDdKankenbi());	// 完検日
		paramBean.setString(t220013gBean.getDdHansytyt());	// 搬出予定日
		paramBean.setString(t220013gBean.getDdHansyprt());	// 搬出表印刷日時
		paramBean.setString(t220013gBean.getMjHansytbk());	// 搬出備考

		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220013gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220013gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220013gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220013gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#updateT220013G(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220013gBean, java.sql.Timestamp)
	 */
	@Override
//	public SimpleExecuteResultBean updateT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean updateT220013G(Uccb009gBean t220013gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String hansyutuDtKosin,
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 更新処理（車両搬出情報） SQL */
		final String UPDATE_T220013G_SQL
//			= "UPDATE T220013G "
			= "UPDATE " + UcarTableManager.getSyaryoHansyutu(t220013gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    KB_SGYOKT  = ? "
			+ "  , KB_KASYU   = ? "
			+ "  , CD_HSTENPO = ? "
			+ "  , DT_KOSIN   = ? "
			+ "  , CD_KSNSYA  = ? "
			+ "  , CD_KSNAPP  = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220013G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220013gBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(t220013gBean.getKbKasyu());		// 加修フラグ
		paramBean.setString(t220013gBean.getCdHstenpo());	// 配車店舗コード

		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220013gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220013gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220013gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220013gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220013gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(hansyutuDtKosin);				// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	@Override
	public CarCheckDataListPagingBean selectWorkSortListPaging(String cdKaisya,
//			String cdHanbaitn, CarCheckParamBean carCheckParamBean,
			String cdHanbaitn, String cdHantenpo, String kbScenter, CarCheckParamBean carCheckParamBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			boolean isNarrowSearch, String sortOrder, String sortParam,
			String pageNo, String pageSize) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "      , CD_ZAITENPO ";
			sqlTenpo2 = "    AND HANNYU.CD_HANTENPO = CHKNAIYO.CD_ZAITENPO ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		String selectT220003gJoinSql
			= "  LEFT JOIN ( "
			+ "    SELECT "
			+ "        CD_KAISYA "
			+ "      , CD_HANBAITN "
			+ "      , DD_HANNYU "
			+ "      , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "      , COUNT(*) COUNT_HOSYO_KIROKU "
			+ "    FROM "
			+ "      " + UcarTableManager.getCheckNaiyo(kbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    WHERE "
			+ "         KB_CHECK = ? "
			+ "      OR KB_CHECK = ? "
			+ "    GROUP BY "
			+ "        CD_KAISYA "
			+ "      , CD_HANBAITN "
			+ "      , DD_HANNYU "
			+ "      , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  ) CHKNAIYO "
			+ "    ON HANNYU.CD_KAISYA    = CHKNAIYO.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = CHKNAIYO.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = CHKNAIYO.DD_HANNYU  "
			+ "    AND HANNYU.NO_KANRI    = CHKNAIYO.NO_KANRI "
			+ sqlTenpo2;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		// 2013.05.09 T.Hayato 修正 搬入拠点分散対応2のため start
		/** 作業仕分 画面出力値取得処理 SQL */
		String selectWorkSortSql
			= "SELECT "
			+ "    HANNYU.CD_KAISYA "
			+ "  , HANNYU.CD_HANBAITN "
			+ "  , HANNYU.DD_HANNYU "
			+ "  , HANNYU.NO_KANRI "
			+ "  , HANNYU.CD_SIRTENPO "
			+ "  , HANNYU.MJ_SYAMEI "
			+ "  , HANNYU.NO_SYADAI "
			+ "  , HANNYU.DD_SYODOTOR "
			+ "  , HANNYU.CD_TOSYOKU "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
			+ "  , HANNYU.DD_INKANKGN "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end
			+ "  , NYUKO.DD_NKKNS "
			+ "  , SIWAKE.DD_SIWAKE "
			+ "  , SIWAKE.DD_SWKHR "
			+ "  , HANSYUTU.KB_SGYOKT "
			+ "  , SAGYO.MJ_SGYOKT "
			// 2014.9.20 H.Yamashita 一覧表示の行先店舗表示不具合 対応 start
//			+ "  , HANSYUTU.CD_HSTENPO "
			+ "  ,TRIM(' ' FROM HANSYUTU.CD_HSTENPO) AS CD_HSTENPO"
			// 2014.9.20 H.Yamashita 一覧表示の行先店舗表示不具合 対応 end
			+ "  , HANNYU.MJ_BIKOU "
			+ "  , CASE CHKNAIYO.COUNT_HOSYO_KIROKU "
			+ "         WHEN " + COUNT_HOSYO_KIROKU + " THEN 'true' " // 搬入時に保証書、記録簿が全て存在すれば"true"
			+ "         ELSE 'false' END EXIST_CHECK_CONTENTS "
			+ "  , SIWAKE.DT_KOSIN SIWAKE_DT_KOSIN "		// 仕分作業DB：データ更新日時
			+ "  , HANSYUTU.DT_KOSIN HANSYUTU_DT_KOSIN "	// 車両搬出情報：データ更新日時
			+ "  , SYORUI.DD_SRKHR "
			+ "  , NYUKO.DD_NKKHR "
			+ "FROM "
			+ "  " + UcarTableManager.getSyaryoHannyuSelectOnly(kbScenter) + " HANNYU "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  LEFT JOIN " + UcarTableManager.getSyoruiCheck(kbScenter) + " SYORUI "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = SYORUI.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = SYORUI.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = SYORUI.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = SYORUI.NO_KANRI ";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			selectWorkSortSql += "    AND HANNYU.CD_HANTENPO = SYORUI.CD_ZAITENPO ";
		}

		selectWorkSortSql
			+= "  LEFT JOIN " + UcarTableManager.getNyuko(kbScenter) + " NYUKO "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = NYUKO.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = NYUKO.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = NYUKO.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = NYUKO.NO_KANRI ";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			selectWorkSortSql += "    AND HANNYU.CD_HANTENPO = NYUKO.CD_ZAITENPO ";
		}

		selectWorkSortSql
			+= "  LEFT JOIN " + UcarTableManager.getWorkSort(kbScenter) + " SIWAKE "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = SIWAKE.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = SIWAKE.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = SIWAKE.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = SIWAKE.NO_KANRI ";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			selectWorkSortSql += "    AND HANNYU.CD_HANTENPO = SIWAKE.CD_ZAITENPO ";
		}

		selectWorkSortSql
			+= "  LEFT JOIN " + UcarTableManager.getSyaryoHansyutu(kbScenter) + " HANSYUTU "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    ON HANNYU.CD_KAISYA    = HANSYUTU.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN = HANSYUTU.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU   = HANSYUTU.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI    = HANSYUTU.NO_KANRI ";
		if (!kbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			selectWorkSortSql += "    AND HANNYU.CD_HANTENPO = HANSYUTU.CD_ZAITENPO ";
		}

		selectWorkSortSql
			+= "  LEFT JOIN T220014M SAGYO "
			+ "    ON HANSYUTU.CD_KAISYA    = SAGYO.CD_KAISYA "
			+ "    AND HANSYUTU.CD_HANBAITN = SAGYO.CD_HANBAITN "
			+ "    AND HANSYUTU.KB_SGYOKT   = SAGYO.KB_SGYOKT "

			+ selectT220003gJoinSql;

		// 2019.03.28 T.Osada 修正 会社融合対応 strat
		if (cdHanbaitn.equals(UcarConst.TOYOTA) || 
						cdHanbaitn.equals(UcarConst.TOYOPET) ||  
						cdHanbaitn.equals(UcarConst.COROLLA) || 
/*2019.4.24 FROM
						cdHanbaitn.equals(UcarConst.NETZ)){
*/
						cdHanbaitn.equals(UcarConst.NETZ) ||
						cdHanbaitn.equals(UcarConst.LEXUS)){
//2019.4.24 TO
			selectWorkSortSql
				+= "WHERE "
				+ "      HANNYU.CD_HANTENPO = ? ";				
		} else {
			selectWorkSortSql
				+= "WHERE "
				+ "      HANNYU.CD_KAISYA   = ? "
				+ "  AND HANNYU.CD_HANBAITN = ? "
				+ "  AND HANNYU.CD_HANTENPO = ? ";	
		}
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			// 入庫チェックDBの入庫検査日か入庫検査保留日のどちらかに日付の入力がある
		selectWorkSortSql
			+= "  AND (NYUKO.DD_NKKNS IS NOT NULL "
			+ "       OR NYUKO.DD_NKKHR IS NOT NULL) ";
		// 2019.03.28 T.Osada 修正 会社融合対応 strat
		// 2013.05.09 T.Hayato 修正 搬入拠点分散対応2のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		// パラメータセット<条件>
		paramBean.setString(UcarConst.KB_CHECK_HOSYOUSYO);	// 保証書
		paramBean.setString(UcarConst.KB_CHECK_KIROKUBO);	// 記録簿
		// 2019.03.28 T.Osada 修正 会社融合対応 strat
		if 	(cdHanbaitn.equals(UcarConst.TOYOTA) || 
						cdHanbaitn.equals(UcarConst.TOYOPET) ||  
						cdHanbaitn.equals(UcarConst.COROLLA) || 
/*2019.4.27 T.Osada FROM
						cdHanbaitn.equals(UcarConst.NETZ)){
*/
						cdHanbaitn.equals(UcarConst.NETZ) ||
						cdHanbaitn.equals(UcarConst.LEXUS)){
//2019.04.27 to
			paramBean.setString(cdHantenpo);	// 搬入店舗コード	
		} else {
			paramBean.setString(cdKaisya);		// 会社コード
			paramBean.setString(cdHanbaitn);	// 販売店コード
			paramBean.setString(cdHantenpo);	// 搬入店舗コード	
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		// 2019.03.28 T.Osada 修正 会社融合対応 strat

		String strSql = "";
		// 検索条件
		StringBuilder sqlCondition = new StringBuilder();

		if (isNarrowSearch) {
			// 絞り込み検索実行時
			if(!carCheckParamBean.getDdConditionFrom().equals("")){
				// 仕分日
				sqlCondition.append("  AND SIWAKE.DD_SIWAKE BETWEEN ? AND ? ");
				paramBean.setString(carCheckParamBean.getDdConditionFrom().replace("/", ""));	// 仕分日(From)
				paramBean.setString(carCheckParamBean.getDdConditionTo().replace("/", ""));		// 仕分日(To)
			}
			if(!carCheckParamBean.getNoSyadai().equals("")){
				sqlCondition.append(" AND HANNYU.NO_SYADAI LIKE '%" + carCheckParamBean.getNoSyadai() + "%'");
			}
			if(!carCheckParamBean.getRdoKoutei().equals("")){
				if(CarCheckConst.WORKSORT_INCOMPLETE.equals(carCheckParamBean.getRdoKoutei())) {
					// 仕分未完了
					sqlCondition.append("  AND SIWAKE.DD_SIWAKE IS NULL ");
				} else if (CarCheckConst.WORKSORT_COMPLETE.equals(carCheckParamBean.getRdoKoutei())) {
					// 仕分完了
					sqlCondition.append("  AND SIWAKE.DD_SIWAKE IS NOT NULL ");
				} else if (CarCheckConst.WORKSORT_RESERVE.equals(carCheckParamBean.getRdoKoutei())) {
					// 保留
					sqlCondition.append("  AND SIWAKE.DD_SWKHR IS NOT NULL ");
				}
			}
		} else {
			// 絞り込み検索未実行時
			// 仕分未完了
			sqlCondition.append("  AND SIWAKE.DD_SIWAKE IS NULL ");
		}
		strSql = selectWorkSortSql + sqlCondition.toString();

		paramBean.setSql(strSql);

		StringBuilder orderSql = new StringBuilder();
		//並び順がない場合は昇順とする
		if (sortOrder.equals("")){
			sortOrder = "ASC";
		}
		//ソート条件(テーブル名のエイリアスを入れるとエラーになるので、意図的に列名のみを記述)
		if(!sortParam.equals("")){
			if (sortParam.equals("DD_HANNYU")){
				// 搬入日
				orderSql.append(" ORDER BY CD_KAISYA "   +
						        "         ,CD_HANBAITN " +
						        "         ,DD_HANNYU "   + sortOrder +
						        "         ,NO_KANRI ");
			} else if (sortParam.equals("DD_SIWAKE")) {
				// 完了日
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,DD_SIWAKE "   + sortOrder +
								"         ,DD_HANNYU "   +
								"         ,NO_KANRI ");
			} else if (sortParam.equals("KB_SGYOKT")) {
				// 作業
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,KB_SGYOKT "   + sortOrder +
								"         ,DD_HANNYU "   +
								"         ,NO_KANRI ");
			} else if (sortParam.equals("CD_HSTENPO")) {
				// 行先
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,CD_HSTENPO "  + sortOrder +
								"         ,DD_HANNYU "   +
								"         ,NO_KANRI ");
			// 2012.03.26 T.Hayato 追加 印鑑証明期限日ソート機能 追加のため start
			} else if (sortParam.equals("DD_INKANKGN")) {
				// 印鑑証明期限日
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,DD_INKANKGN " + sortOrder +
								"         ,DD_HANNYU "   +
								"         ,NO_KANRI ");
			// 2012.03.26 T.Hayato 追加 印鑑証明期限日ソート機能 追加のため end
			} else {
				orderSql.append(" ORDER BY CD_KAISYA "   +
								"         ,CD_HANBAITN " +
								"         ,DD_HANNYU "   + sortOrder +
								"         ,NO_KANRI ");
			}
		} else {
			orderSql.append(" ORDER BY CD_KAISYA "   +
					        "         ,CD_HANBAITN " +
					        "         ,DD_HANNYU "   + sortOrder +
					        "         ,NO_KANRI ");
		}
		// ソート条件
		paramBean.setOrderSql(orderSql.toString());

		// ページ設定
		paramBean.setPageNo(Integer.parseInt(pageNo));

		paramBean.setPageSize(Integer.parseInt(pageSize));

		CarCheckDataListPagingBean resultPagingBean
			= executeSimplePagingQuery(paramBean, CarCheckDataListPagingBean.class, CarCheckDataBean.class);

		return resultPagingBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#selectT220009GCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220009gBean)
	 */
	@Override
//	public int selectT220009GCount(T220009gBean t220009gBean)
	public int selectT220009GCount(Uccb006gBean t220009gBean)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
	throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 仕分作業DB取得処理（仕分作業DB）SQL */
		String SELECT_T220009G_SQL
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "FROM "
//			+ "  T220009G "
			+ "  " + UcarTableManager.getWorkSort(t220009gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		int count = 0;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220009G_SQL);

			// パラメータセット<条件>
			paramBean.setString(t220009gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220009gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220009gBean.getDdHannyu());	// 搬入日
			paramBean.setString(t220009gBean.getNoKanri());		// 管理番号
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
			if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
				paramBean.setString(t220009gBean.getCdZaitenpo());	// 在庫店舗コード
			}
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			// 取得
			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#insertT220009G(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220009gBean, java.sql.Timestamp)
	 */
	@Override
//	public SimpleExecuteResultBean insertT220009G(T220009gBean t220009gBean,
	public SimpleExecuteResultBean insertT220009G(Uccb006gBean t220009gBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 新規登録処理（仕分作業DB）SQL */
		final String INSERT_T220009G_SQL
			= "INSERT "
//			+ "INTO T220009G( "
			+ "INTO " + UcarTableManager.getWorkSort(t220009gBean.getKbScenter()) + "( "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , DD_SIWAKE "
			+ "  , DD_SWKHR "
			+ "  , DD_SWKFK "
			+ "  , MJ_SWKBK "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220009G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220009gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220009gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220009gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220009gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220009gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		paramBean.setString(t220009gBean.getDdSiwake());	// 仕分日
		paramBean.setString(t220009gBean.getDdSwkhr());		// 仕分保留日
		paramBean.setString(t220009gBean.getDdSwkfk());		// 仕分復帰予定日
		paramBean.setString(t220009gBean.getMjSwkbk());		// 仕分備考

		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220009gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220009gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220009gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220009gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#updateT220009G(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220009gBean, java.lang.String, java.sql.Timestamp)
	 */
	@Override
//	public SimpleExecuteResultBean updateT220009G(T220009gBean t220009gBean,
	public SimpleExecuteResultBean updateT220009G(Uccb006gBean t220009gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String siwakeDtKosin, Timestamp executeDate)
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 更新処理（仕分作業DB）SQL */
		final String UPDATE_T220009G_SQL
//			= "UPDATE T220009G "
			= "UPDATE " + UcarTableManager.getWorkSort(t220009gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    DD_SIWAKE = ? "
			+ "  , DD_SWKHR  = ? "
			+ "  , DD_SWKFK  = ? "
			+ "  , MJ_SWKBK  = ? "
			+ "  , DT_KOSIN  = ? "
			+ "  , CD_KSNSYA = ? "
			+ "  , CD_KSNAPP = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220009G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220009gBean.getDdSiwake());	// 仕分日
		paramBean.setString(t220009gBean.getDdSwkhr());		// 仕分保留日
		paramBean.setString(t220009gBean.getDdSwkfk());		// 仕分復帰予定日
		paramBean.setString(t220009gBean.getMjSwkbk());		// 仕分備考

		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220009gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220009gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220009gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220009gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220009gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220009gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220009gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(siwakeDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#deleteT220009G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb006gBean, java.lang.String)
	 */
	@Override
//	public SimpleExecuteResultBean deleteT220009G(T220009gBean t220009gBean,
	public SimpleExecuteResultBean deleteT220009G(Uccb006gBean t220009gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String siwakeDtKosin) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 削除処理（仕分作業DB）SQL */
		final String DELETE_T220009G_SQL
			= "DELETE  "
			+ "FROM "
//			+ "  T220009G  "
			+ "  " + UcarTableManager.getWorkSort(t220009gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220009G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220009gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220009gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220009gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220009gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220009gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220009gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(siwakeDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF#selectKbKasyu(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public String selectKbKasyu(String cdKaisya, String cdHanbaitn,
			String kbSgyokt) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_UCAB002M_KB_KASYU_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);				// 会社コード
		paramBean.setString(cdHanbaitn);			// 販売店コード
		paramBean.setString(kbSgyokt);				// 作業工程区分
		paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分

		ResultArrayList<Ucac002mBean> T220014mList = executeSimpleSelectQuery(paramBean, Ucac002mBean.class);

		String kbKasyu = "";
		if(T220014mList.size() > 0){
			kbKasyu = T220014mList.get(0).getKbKasyu();
			if(T220014mList.size() > 1){
				TecLogger.warn("作業工程マスタ 不整合");
			}
		}
		return kbKasyu;
	}

}
