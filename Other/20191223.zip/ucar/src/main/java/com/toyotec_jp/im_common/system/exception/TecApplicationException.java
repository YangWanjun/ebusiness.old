/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecApplicationException.java
 * 【  説  明  】
 * 【  作  成  】2010/06/15 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import java.util.ArrayList;

import jp.co.intra_mart.framework.system.exception.ApplicationException;

import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;
import com.toyotec_jp.im_common.system.message.TecMessageManager;

/**
 * <strong>基本アプリケーション例外クラス。</strong>
 * <p>
 * システムとして正常な例外。<br>
 * 入力値のエラーや排他エラー等。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/15 新規作成<br>
 * @since 1.00
 */
public class TecApplicationException extends ApplicationException {

	private static final long serialVersionUID = 2463942665958107347L;

	private TecExceptionLevel level = TecExceptionLevel.WARN;

	/**
	 * コンストラクタ。
	 */
	public TecApplicationException() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param message メッセージ
	 */
	public TecApplicationException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * @param cause
	 */
	public TecApplicationException(Throwable cause) {
		super(cause);
	}

	/**
	 * コンストラクタ。
	 * @param message メッセージ
	 * @param cause
	 */
	public TecApplicationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 */
	public TecApplicationException(TecMessageKeyIF messageKey) {
		super(getMsg(messageKey, null));
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 * @param args 置換文字列の配列
	 */
	public TecApplicationException(TecMessageKeyIF messageKey, ArrayList<Object> args) {
		super(getMsg(messageKey, args));
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 * @param cause
	 */
	public TecApplicationException(TecMessageKeyIF messageKey, Throwable cause) {
		super(getMsg(messageKey, null), cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 * @param args 置換文字列の配列
	 * @param cause
	 */
	public TecApplicationException(TecMessageKeyIF messageKey, ArrayList<Object> args, Throwable cause) {
		super(getMsg(messageKey, args), cause);
	}

	// 例外メッセージ取得
	private static String getMsg(TecMessageKeyIF messageKey, ArrayList<Object> args){
		String msg = null;
		try {
			if(args == null){
				msg = TecMessageManager.getMessage(messageKey);
			} else {
				msg = TecMessageManager.getMessage(messageKey, args);
			}
		} catch (TecMessageException e) {
			// 本来発生した例外がメインであるため、ここでのメッセージ取得失敗はスローしない。
			msg = messageKey.toString();
			TecLogger.warn("例外メッセージ取得に失敗しました。[" + msg + "]");
		}
		return msg;
	}

	/**
	 * levelを取得する。
	 * @return level
	 */
	public TecExceptionLevel getLevel() {
		return level;
	}

	/**
	 * levelを設定する。
	 * @param level
	 */
	public void setLevel(TecExceptionLevel level) {
		this.level = level;
	}

}
