package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>車両チェック 検索条件Bean。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/07 新規作成<br>
 * @since 1.00
 * @category [[車両チェック]]
 */
public class CarCheckParamBean extends TecBean {

	/**  */
	private static final long	serialVersionUID	= -3201171772188416794L;

	/** フレームNo. */
	private String noSyadai;
	/** 検索日付From
	 * <pre>
	 * 入庫検査画面：入庫検査日
	 * 作業仕分画面：仕分完了日
	 * </pre> */
	private String ddConditionFrom;
	/** 検索日付To
	 * <pre>
	 * 入庫検査画面：入庫検査日
	 * 作業仕分画面：仕分完了日
	 * </pre> */
	private String ddConditionTo;
	/** 工程
	 * <pre>
	 * 入庫検査画面：入庫検査未完了、入庫検査完了、保留
	 * 作業仕分画面：仕分未完了、仕分完了、行先未完了、行先完了、保留
	 * </pre> */
	private String rdoKoutei;

	public CarCheckParamBean(){
		this.noSyadai 			= "";
		this.ddConditionFrom 	= "";
		this.ddConditionTo 		= "";
		this.rdoKoutei 			= "1";
	}

	/**
	 * noSyadaiを取得する。
	 * @return noSyadai フレーム№
	 */
	public String getNoSyadai() {
		return noSyadai;
	}

	/**
	 * noSyadaiを設定する。
	 * @param noSyadai フレーム№
	 */
	public void setNoSyadai(String noSyadai) {
		this.noSyadai = noSyadai;
	}

	/**
	 * ddConditionFromを取得する。
	 * @return ddConditionFrom 検索日付From
	 */
	public String getDdConditionFrom() {
		return ddConditionFrom;
	}

	/**
	 * ddConditionFromを設定する。
	 * @param ddConditionFrom 検索日付From
	 */
	public void setDdConditionFrom(String ddConditionFrom) {
		this.ddConditionFrom = ddConditionFrom;
	}

	/**
	 * ddConditionToを取得する。
	 * @return ddConditionTo 検索日付To
	 */
	public String getDdConditionTo() {
		return ddConditionTo;
	}

	/**
	 * ddConditionToを設定する。
	 * @param ddConditionTo 検索日付To
	 */
	public void setDdConditionTo(String ddConditionTo) {
		this.ddConditionTo = ddConditionTo;
	}

	/**
	 * rdoKouteiを取得する。
	 * @return rdoKoutei 工程
	 */
	public String getRdoKoutei() {
		return rdoKoutei;
	}

	/**
	 * rdoKouteiを設定する。
	 * @param rdoKoutei工程
	 */
	public void setRdoKoutei(String rdoKoutei) {
		this.rdoKoutei = rdoKoutei;
	}

}
