package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object;

import com.toyotec_jp.im_common.system.model.object.SimplePagingResultBean;

/**
 * <strong>車両チェック 画面出力値 リストページングBean。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/27 新規作成<br>
 * @since 1.00
 * @category [[車両チェック]]
 */
public class CarCheckDataListPagingBean extends SimplePagingResultBean<CarCheckDataBean> {

	private static final long serialVersionUID = -7898490009941526316L;

}
