package com.toyotec_jp.ucar.workflow.carryout.register.model.data;

import java.sql.Timestamp;
import java.util.Date;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryout.register.model.object.CarryoutRegisterDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbv0201mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出登録DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterDAOImpl extends UcarSharedDBDAO implements CarryoutRegisterDAOIF {

	/** 加修フラグ取得処理（作業工程マスタ）SQL */
	private static final String SELECT_KB_KASYU_SQL
		= "SELECT "
		+ "    KB_KASYU "
		+ "FROM "
		+ "  T220014M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_SGYOKT   = ? ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220001G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<CarryoutRegisterDataBean> selectT220001G(Ucaa001gPKBean t220001gPkBean,
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																	String loginCdTenpo,
																	String loginKbScenter) throws TecDAOException {
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		String sqlOutplan1 = "";
		String sqlOutplan2 = "";
		// 2019.03.30 T.Osada 会社融合対応 start 
		String sqlOutplan3 = "";
		String sqlWhere1 = "";
		// 2019.03.30 T.Osada 会社融合対応 end 
		
		// 2014.08.18 00496_990215 追加 搬出予定情報取得のため start
		if (loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlOutplan1
			= "  , STATUS.DD_OUTPLN "
			+ "  , STATUS.DT_STATUS25 "
			+ "  , U001G.KB_SHODAN "
			+ "  , trim(U001G.CD_SHTAN) AS CD_SHTAN "
			+ "  , SYAIN2.KJ_SYAINMEI AS KJ_SHTAN "
			+ "  , U001G.MJ_SBIKOU ";
			
			sqlOutplan2
			= "  LEFT JOIN " +  UcarTableManager.getStatus(loginKbScenter) + " STATUS "
			+ "    ON U001G.CD_KAISYA    = STATUS.CD_KAISYA "
			+ "    AND U001G.CD_HANBAITN = STATUS.CD_HANBAITN "
			+ "    AND U001G.DD_HANNYU   = STATUS.DD_HANNYU "
			+ "    AND U001G.NO_KANRI    = STATUS.NO_KANRI "
			+ "  LEFT JOIN " + AddonTableManager.getSyain(t220001gPkBean.getCdHanbaitn()) + " SYAIN2 "
			+ "    ON U001G.CD_KAISYA    = SYAIN2.CD_KAISYA "
			+ "    AND U001G.CD_SHTAN    = SYAIN2.CD_SYAIN ";
		}
		
		// 2019.03.30 T.Osada 会社融合対応 start 
		if (t220001gPkBean.getCdHanbaitn().equals(UcarConst.TOYOTA) ||
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.TOYOPET) ||
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.COROLLA) ||
/*2019.4.24 FROM				
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.NETZ)) {
*/
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.NETZ) ||
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.LEXUS)) {
//2019.4.24 TO
					sqlOutplan3
					= "  LEFT JOIN " + AddonTableManager.getKyoutuTenpo(t220001gPkBean.getCdHanbaitn()) + " KYOTUTENPO "
					+ "    ON U001G.CD_SIRTENPO = KYOTUTENPO.CD_TENPO ";
					sqlWhere1
					= "WHERE "
						+ "      U001G.DD_HANNYU   = ? "
						+ "  AND U001G.NO_KANRI    = ? "
						+ "  AND U001G.CD_HANTENPO = ? ";	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		} else {
			sqlOutplan3
			= "  LEFT JOIN " + AddonTableManager.getKyoutuTenpo(t220001gPkBean.getCdHanbaitn()) + " KYOTUTENPO "
			/*2019.05.01 T.Osada Start
			+ "    ON U001G.CD_KAISYA    = KYOTUTENPO.CD_KAISYA "
			+ "    AND U001G.CD_SIRTENPO = KYOTUTENPO.CD_TENPO ";
			*/
			+ "    ON U001G.CD_SIRTENPO = KYOTUTENPO.CD_TENPO ";
			sqlWhere1
			= "WHERE "
			+ "      U001G.CD_KAISYA   = ? "
			+ "  AND U001G.CD_HANBAITN = ? "
			+ "  AND U001G.DD_HANNYU   = ? "
			+ "  AND U001G.NO_KANRI    = ? "
			+ "  AND U001G.CD_HANTENPO = ? ";	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		}
		// 2014.08.18 00496_990215 追加 搬出予定情報取得のため end
		// 2019.03.30 T.Osada 会社融合対応 end 

		/** 車両搬出登録 画面出力値取得処理（車両搬出情報）SQL */
		final String SELECT_T220001G_SQL
			= "SELECT "
			+ "    U001G.CD_KAISYA "
			+ "  , U001G.CD_HANBAITN "
			+ "  , U001G.DD_HANNYU "
			+ "  , U001G.NO_KANRI "
			+ "  , U001G.MJ_SYAMEI "
			+ "  , U001G.MJ_SITKATA "
			+ "  , U001G.NO_SYADAI "
			+ "  , RIKUSICODE.KJ_RIKUSIM "
			+ "  , U001G.CD_NORIKUSI "
			+ "  , U001G.KB_NOSYASYU "
			+ "  , U001G.CD_NOGYOTAI "
			+ "  , U001G.NO_NOSEIRI "
			+ "  , U001G.CD_TOSYOKU "
			+ "  , CODEKUBUN.MJ_KUBUNNAI "
			+ "  , U001G.DD_SYODOTOR "
			+ "  , U001G.DD_SYKNMANR "
			+ "  , U001G.NU_SOUKUKM "
			+ "  , U001G.NO_SYARYOU "
			+ "  , U001G.KJ_OKYAKUM "
			+ "  , U001G.CD_SIRTENPO "
			+ "  , KYOTUTENPO.KJ_TENTANMS "
			+ "  , U001G.CD_SDTAN "
			+ "  , SYAIN.KJ_SYAINMEI "
			+ "  , U001G.MJ_BIKOU "
			// 2014.08.18 00496_990215 追加 搬出予定情報取得のため start
			+ sqlOutplan1
			// 2014.08.18 00496_990215 追加 搬出予定情報取得のため end
			+ "FROM "
//			+ "  T220001G U001G "
			+ "  " + UcarTableManager.getSyaryoHannyuSelectOnly(loginKbScenter) + " U001G "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
			+ "  LEFT JOIN " + AddonTableManager.getRikusiCode(t220001gPkBean.getCdHanbaitn()) + " RIKUSICODE "
			+ "    ON U001G.CD_KAISYA    = RIKUSICODE.CD_KAISYA "
			+ "    AND U001G.CD_NORIKUSI = RIKUSICODE.CD_RIKUSI "
			+ "  LEFT JOIN " + AddonTableManager.getCodeKubun(t220001gPkBean.getCdHanbaitn()) + " CODEKUBUN "
			+ "    ON U001G.CD_KAISYA    = CODEKUBUN.CD_KAISYA "
			+ "    AND U001G.CD_TOSYOKU  = CODEKUBUN.CD_KUBUN "
			+ "    AND CODEKUBUN.MJ_BLOCKID = '03' "
			+ "    AND CODEKUBUN.MJ_KUBUNID = '0108' "
			// 2019.03.30 T.Osada 会社融合対応 start 
			+ sqlOutplan3
			// 2019.03.30 T.Osada 会社融合対応 end 
			+ "  LEFT JOIN " + AddonTableManager.getSyain(t220001gPkBean.getCdHanbaitn()) + " SYAIN "
			// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end
			+ "    ON U001G.CD_KAISYA    = SYAIN.CD_KAISYA "
			+ "    AND U001G.CD_SDTAN    = SYAIN.CD_SYAIN "
			// 2014.08.18 00496_990215 追加 搬出予定情報取得のため start
			+ sqlOutplan2
			// 2014.08.18 00496_990215 追加 搬出予定情報取得のため end
			// 2019.03.30 T.Osada 会社融合対応 start 
			+ sqlWhere1
			// 2019.03.30 T.Osada 会社融合対応 end
			;

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220001G_SQL);

		// パラメータセット<条件>
		// 2019.03.30 T.Osada 会社融合対応 start 
		if 	(t220001gPkBean.getCdHanbaitn().equals(UcarConst.TOYOTA) ||
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.TOYOPET) ||
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.COROLLA) ||
/*2019.4.24 FROM				
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.NETZ)) {
*/
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.NETZ)||
				t220001gPkBean.getCdHanbaitn().equals(UcarConst.LEXUS)) {
//2019.4.24 TO
			paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬出日
			paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
			paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		} else {
			paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
			paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬出日
			paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
			paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		}
		// 2019.03.30 T.Osada 会社融合対応 end 

		ResultArrayList<CarryoutRegisterDataBean> t220001gList
			= executeSimpleSelectQuery(paramBean, CarryoutRegisterDataBean.class);

		return t220001gList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220002G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<Ucaa002gBean> selectT220002G(Ucaa001gPKBean t220001gPkBean) throws TecDAOException {

		/** 仕入種別情報取得処理（仕入種別情報）SQL */
		final String SELECT_T220002G_SQL
			= "SELECT "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , KB_SIIRE "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
//			+ "  T220002G "
			+ "  T220903V "	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		// 2019.03.30 T.Osada 会社融合対応 start 
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? ";
		// 2019.03.30 T.Osada 会社融合対応 end 

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220002G_SQL);

		// パラメータセット<条件>
		// 2019.03.30 T.Osada 会社融合対応 start 
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬出日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		// 2019.03.30 T.Osada 会社融合対応 end 

		ResultArrayList<Ucaa002gBean> t220002gList = executeSimpleSelectQuery(paramBean, Ucaa002gBean.class);

		return t220002gList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<Ucaa003gBean> selectT220003G(Ucaa001gPKBean t220001gPkBean,
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
														String loginCdTenpo,
														String loginKbScenter) throws TecDAOException {

		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** チェック内容情報取得処理（チェック内容情報）SQL */
		final String SELECT_T220003G_SQL
			= "SELECT "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , KB_CHECK "
			+ "  , DD_CHECK "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
//			+ "  T220003G "
			+ "  " + UcarTableManager.getCheckNaiyo(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220003G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬出日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);					// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		ResultArrayList<Ucaa003gBean> t220003gList = executeSimpleSelectQuery(paramBean, Ucaa003gBean.class);

		return t220003gList;
	}

	@Override
	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//	public ResultArrayList<T220013gBean> selectT220013G(Ucaa001gPKBean t220001gPkBean) throws TecDAOException {
	public ResultArrayList<Uccb009gBean> selectT220013G(Ucaa001gPKBean t220001gPkBean,
														String loginCdTenpo,
														String loginKbScenter) throws TecDAOException {

		String sqlTenpo = "";
		String sqlTenpo2 = "";
		// 2019.03.31 T.Osada Start
		String sqlWhere = "";
		
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , KB_KASIDASI ";
			sqlTenpo2 = "  AND CD_ZAITENPO = ? ";
		}
		// 2019.03.31 T.Osada end
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		
		/** 車両搬出情報取得処理（車両搬出情報）SQL */
		final String SELECT_T220013G_SQL
			= "SELECT "
			+ "    DD_HANSYT "
			+ "  , KB_SGYOKT "
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			// 2014.9.20 H.Yamashita 車両搬出表行先店舗表示不具合 対応 start
//			+ "  , CD_HSTENPO "
			+ "  , TRIM(' ' FROM CD_HSTENPO) AS CD_HSTENPO"
			// 2014.9.20 H.Yamashita 車両搬出表行先店舗表示不具合 対応 end
			+ sqlTenpo
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			// 2013.05.27 T.Hayato 追加 搬入拠点分散対応2のため start
			+ "  , DD_TENUKT "
			// 2013.05.27 T.Hayato 追加 搬入拠点分散対応2のため end
			+ "  , DT_KOSIN "
			+ "FROM "
//			+ "  T220013G "
			+ "  " + UcarTableManager.getSyaryoHansyutu(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo2;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220013G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬出日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);					// 在庫店舗コード
		}

//		ResultArrayList<T220013gBean> t220013gList = executeSimpleSelectQuery(paramBean, T220013gBean.class);
		ResultArrayList<Uccb009gBean> t220013gList = executeSimpleSelectQuery(paramBean, Uccb009gBean.class);
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		return t220013gList;
	}

	@Override
	public ResultArrayList<Ucac002mBean> selectKbKasyu(String cdKaisya,
														String cdHanbaitn,
														String kbSgyokt) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_KB_KASYU_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(kbSgyokt);		// 作業工程区分

		ResultArrayList<Ucac002mBean> T220014mList = executeSimpleSelectQuery(paramBean, Ucac002mBean.class);

		return T220014mList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF#insertT220013G(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220013gBean, java.sql.Timestamp)
	 */
	@Override
//	public SimpleExecuteResultBean insertT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean insertT220013G(Uccb009gBean t220013gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String loginCdTenpo,
			String loginKbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		String sqlTenpo3 = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , KB_KASIDASI ";
			sqlTenpo3 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** 新規登録処理（車両搬出情報）SQL */
		final String INSERT_T220013G_SQL
			= "INSERT "
//			+ "INTO T220013G( "
			+ "INTO " + UcarTableManager.getSyaryoHansyutu(loginKbScenter) + "( "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "  , DD_HANSYT "
			+ "  , KB_SGYOKT "
			+ "  , KB_KASYU "
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			+ "  , CD_HSTENPO "
			+ sqlTenpo2
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo3	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			+ "  , ? "
			+ sqlTenpo3
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220013G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220013gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);				// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		paramBean.setString(t220013gBean.getDdHansyt());	// 搬出日
		paramBean.setString(t220013gBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(t220013gBean.getKbKasyu());		// 加修フラグ
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		paramBean.setString(t220013gBean.getCdHstenpo());	// 配車店舗コード
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220013gBean.getKbKasidasi());	// 他店貸出区分
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時

		paramBean.setString(t220013gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220013gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220013gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220013gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	@Override
//	public SimpleExecuteResultBean updateT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean updateT220013G(Uccb009gBean t220013gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String loginCdTenpo,
			String loginKbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			String t220013gDtKosin, Timestamp executeDate)
			throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
			sqlTenpo2 = "  , KB_KASIDASI = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** 更新処理（車両搬出情報）SQL */
		final String UPDATE_T220013G_SQL
//			= "UPDATE T220013G "
			= "UPDATE " + UcarTableManager.getSyaryoHansyutu(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    DD_HANSYT  = ? "
			+ "  , KB_SGYOKT  = ? "
			+ "  , KB_KASYU   = ? "
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			+ "  , CD_HSTENPO = ? "
			+ sqlTenpo2
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			+ "  , DT_KOSIN   = ? "
			+ "  , CD_KSNSYA  = ? "
			+ "  , CD_KSNAPP  = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220013G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220013gBean.getDdHansyt());	// 搬出日
		paramBean.setString(t220013gBean.getKbSgyokt());	// 作業工程区分
		paramBean.setString(t220013gBean.getKbKasyu());		// 加修フラグ
		paramBean.setString(t220013gBean.getCdHstenpo());	// 配車店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220013gBean.getKbKasidasi());	// 他店貸出区分
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220013gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220013gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220013gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);				// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		paramBean.setString(t220013gDtKosin);				// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	@Override
//	public SimpleExecuteResultBean deleteT220013G(T220013gBean t220013gBean,
	public SimpleExecuteResultBean deleteT220013G(Uccb009gBean t220013gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String loginCdTenpo,
			String loginKbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			String t220013gDtKosin) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** 削除処理（車両搬出情報）SQL */
		final String DELETE_T220013G_SQL
			= "DELETE  "
			+ "FROM "
//			+ "  T220013G  "
			+ "  " + UcarTableManager.getSyaryoHansyutu(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220013G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220013gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220013gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220013gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220013gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);				// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		paramBean.setString(t220013gDtKosin);				// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF#insertT220012G(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220012gInputDataBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean insertT220012G(
//			T220012gInputDataBean t220012gInputDataBean, Timestamp executeDate)
			Uccb007gInputDataBean t220012gInputDataBean, Timestamp executeDate)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** 新規登録処理（ステータスDB） SQL */
		final String INSERT_T220012G_SQL
			= "INSERT "
//			+ "INTO T220012G( "
			+ "INTO " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + "( "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "  , DT_STATUS01 "
			+ "  , DT_STATUS02 "
			+ "  , DT_STATUS03 "
			+ "  , DT_STATUS04 "
			+ "  , DT_STATUS05 "
			+ "  , DT_STATUS06 "
			+ "  , DT_STATUS07 "
			+ "  , DT_STATUS08 "
			+ "  , DT_STATUS09 "
			+ "  , DT_STATUS10 "
			+ "  , DT_STATUS11 "
			+ "  , DT_STATUS12 "
			+ "  , DT_STATUS13 "
			+ "  , DT_STATUS14 "
			+ "  , DT_STATUS15 "
			+ "  , DT_STATUS16 "
			+ "  , DT_STATUS17 "
			+ "  , DT_STATUS18 "
			+ "  , DT_STATUS19 "
			+ "  , DT_STATUS20 "
			+ "  , DT_STATUS21 "
			+ "  , DT_STATUS22 "
			+ "  , DT_STATUS23 "
			+ "  , DT_STATUS24 "
			// 2012.02.13 T.Hayato 追加 作業工程区分～アムスフラグ 初期値設定のため start
			+ "  , KB_SGYOKT "
			+ "  , NU_AZONE "
			+ "  , NU_BZONE "
			+ "  , NU_ABZONE "
			+ "  , NU_SYOHN "
			+ "  , MJ_KASYU "
			+ "  , MJ_MARUCL "
			+ "  , MJ_SEIBI "
			+ "  , MJ_AMUSU "
			// 2012.02.13 T.Hayato 追加 作業工程区分～アムスフラグ 初期値設定のため end
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			// 2012.02.13 T.Hayato 追加 作業工程区分～アムスフラグ 初期値設定のため start
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			// 2012.02.13 T.Hayato 追加 作業工程区分～アムスフラグ 初期値設定のため end
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";
		// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220012G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		paramBean.setString(t220012gInputDataBean.getStrDtStatus01());	// ステータス01
		paramBean.setString(t220012gInputDataBean.getStrDtStatus02());	// ステータス02
		paramBean.setString(t220012gInputDataBean.getStrDtStatus03());	// ステータス03
		paramBean.setString(t220012gInputDataBean.getStrDtStatus04());	// ステータス04
		paramBean.setString(t220012gInputDataBean.getStrDtStatus05());	// ステータス05
		paramBean.setString(t220012gInputDataBean.getStrDtStatus06());	// ステータス06
		paramBean.setString(t220012gInputDataBean.getStrDtStatus07());	// ステータス07
		paramBean.setString(t220012gInputDataBean.getStrDtStatus08());	// ステータス08
		paramBean.setString(t220012gInputDataBean.getStrDtStatus09());	// ステータス09
		paramBean.setString(t220012gInputDataBean.getStrDtStatus10());	// ステータス10
		paramBean.setString(t220012gInputDataBean.getStrDtStatus11());	// ステータス11
		paramBean.setString(t220012gInputDataBean.getStrDtStatus12());	// ステータス12
		paramBean.setString(t220012gInputDataBean.getStrDtStatus13());	// ステータス13
		paramBean.setString(t220012gInputDataBean.getStrDtStatus14());	// ステータス14
		paramBean.setString(t220012gInputDataBean.getStrDtStatus15());	// ステータス15
		paramBean.setString(t220012gInputDataBean.getStrDtStatus16());	// ステータス16
		paramBean.setString(t220012gInputDataBean.getStrDtStatus17());	// ステータス17
		paramBean.setString(t220012gInputDataBean.getStrDtStatus18());	// ステータス18
		paramBean.setString(t220012gInputDataBean.getStrDtStatus19());	// ステータス19
		paramBean.setString(t220012gInputDataBean.getStrDtStatus20());	// ステータス20
		paramBean.setString(t220012gInputDataBean.getStrDtStatus21());	// ステータス21
		paramBean.setString(t220012gInputDataBean.getStrDtStatus22());	// ステータス22
		paramBean.setString(t220012gInputDataBean.getStrDtStatus23());	// ステータス23
		paramBean.setString(t220012gInputDataBean.getStrDtStatus24());	// ステータス24

		// 2012.02.13 T.Hayato 追加 作業工程区分～アムスフラグ 初期値設定のため start
		paramBean.setString(t220012gInputDataBean.getKbSgyokt());		// 作業工程区分
		paramBean.setInt(0);		// Aゾーン日数
		paramBean.setInt(0);		// Bゾーン日数
		paramBean.setInt(0);		// ABゾーン日数
		paramBean.setInt(t220012gInputDataBean.getNuSyohn());			// 商品化日数
		paramBean.setString("0");	// 加修フラグ
		paramBean.setString("0");	// まるクリフラグ
		paramBean.setString("0");	// 整備フラグ
		paramBean.setString("0");	// アムスフラグ
		// 2012.02.13 T.Hayato 追加 作業工程区分～アムスフラグ 初期値設定のため end
		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF#updateT220012G(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220012gInputDataBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220012G(
//			T220012gInputDataBean t220012gInputDataBean, Timestamp executeDate)
			Uccb007gInputDataBean t220012gInputDataBean, Timestamp executeDate)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため start
		/** 更新処理（ステータスDB） SQL */
		final String UPDATE_T220012G_SQL
//			= "UPDATE T220012G "
			= "UPDATE " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + " "
			+ "SET "
			// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため start
			+ "    DT_STATUS19 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため end
			+ "  , DT_STATUS21 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため start
			+ "  , KB_SGYOKT   = ? "
			+ "  , NU_SYOHN    = ? "
			// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため end
			+ "  , DT_KOSIN    = ? "
			+ "  , CD_KSNSYA   = ? "
			+ "  , CD_KSNAPP   = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220012G_SQL);

		// パラメータセット<値>
		// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため start
		paramBean.setString(t220012gInputDataBean.getStrDtStatus19());	// ステータス19
		// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため end
		paramBean.setString(t220012gInputDataBean.getStrDtStatus21());	// ステータス21
		// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため start
		paramBean.setString(t220012gInputDataBean.getKbSgyokt());		// 作業工程区分
		paramBean.setInt(t220012gInputDataBean.getNuSyohn());			// 商品化日数
		// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため end

		paramBean.setTimestamp(executeDate);						// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}
	// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため end

	// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF#selectT220012G(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Date selectDtStatus09(Ucaa001gPKBean t220001gPkBean,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String loginCdTenpo,
			String loginKbScenter) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため start
		/** ステータスDB取得処理 SQL
		 * <pre>
		 * ステータス09を取得する
		 * </pre>
		 *  */
		final String SELECT_T220012G_DT_STATUS09_SQL
			= "SELECT "
			+ "    DT_STATUS09 "
			+ "FROM "
//			+ "  T220012G "
			+ "  " + UcarTableManager.getStatus(loginKbScenter) + " "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220012G_DT_STATUS09_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);					// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		ResultArrayList<Ucab007gBean> T220012gList = executeSimpleSelectQuery(paramBean, Ucab007gBean.class);

		Date dtStatus09 = null;
		if(T220012gList.size() > 0){
			dtStatus09 = T220012gList.get(0).getDtStatus09();
			if(T220012gList.size() > 1){
				TecLogger.warn("ステータスDB 不整合");
			}
		}

		return dtStatus09;
	}
	// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため end
	
	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectCdZaitenpo(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Uccb009gBean> selectCdZaitenpo(String cdKaisya,
															String cdHanbaitn,
															String ddHannyu,
															String noKanri,
															String cdHstenpo)	throws TecDAOException {

		/** 在庫店舗コード取得処理（車両搬出情報(店舗用)）SQL */
		final String SELECT_CD_ZAITENPO_SQL
			= "SELECT "
			+ "  CD_ZAITENPO "
			+ "FROM "
			+ "  T220109G "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ "  AND CD_HSTENPO  = ? "
			+ "  AND KB_KASIDASI IS NOT NULL ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_CD_ZAITENPO_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHannyu);		// 搬入日
		paramBean.setString(noKanri);		// 管理番号
		paramBean.setString(cdHstenpo);		// 配車店舗コード

		ResultArrayList<Uccb009gBean> t220109gList = executeSimpleSelectQuery(paramBean, Uccb009gBean.class);

		return t220109gList;
	}
	
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectKjTentanms(java.lang.String, java.lang.String)
	 */
	@Override
	public String selectKjTentanms(String cdKaisya,
									String cdHanbaitn,
									String cdTenpo) throws TecDAOException {

		final String SELECT_KJ_TENTANMS_SQL
			= "SELECT "
			+ "  TRIM('　' FROM KJ_TENTANMS) AS KJ_TENTANMS "
			+ "FROM "
			+ "  " + AddonTableManager.getKyoutuTenpo(cdHanbaitn) + " "
			+ "WHERE "
			+ "      CD_KAISYA = ? "
			+ "  AND CD_TENPO  = ? ";
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_KJ_TENTANMS_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdTenpo);		// 店舗コード

		ResultArrayList<Tbv0201mBean> tbv0201mList = executeSimpleSelectQuery(paramBean, Tbv0201mBean.class);

		String kjTentanms = "";
		if(tbv0201mList.size() > 0){
			kjTentanms = tbv0201mList.get(0).getKjTentanms();
			if(tbv0201mList.size() > 1){
				TecLogger.warn("共通店舗DB 不整合");
			}
		}
		return kjTentanms;
	}
	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　end

	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
	@Override
	public SimpleExecuteResultBean updateT220001G(Ucaa001gBean t220001gBean,
			String loginKbScenter, String t220001gDtKosin,
			Timestamp executeDate) throws TecDAOException {

			/** 更新処理（車両搬入情報）SQL */
			//商品化センター以外は不要 2019.03.31 T.Osada
			final String UPDATE_T220001G_SQL
				= "UPDATE " + UcarTableManager.getSyaryoHannyu(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
				+ "SET "
				+ "    KB_SHODAN  = ? "
				+ "  , CD_SHTAN	  = ? "
				+ "  , MJ_SBIKOU  = ? "
				+ "  , DT_KOSIN   = ? "
				+ "  , CD_KSNSYA  = ? "
				+ "  , CD_KSNAPP  = ? "
				+ "WHERE "
				+ "      CD_KAISYA   = ? "
				+ "  AND CD_HANBAITN = ? "
				+ "  AND DD_HANNYU   = ? "
				+ "  AND NO_KANRI    = ? ";

			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220001G_SQL);

			// パラメータセット<値>
			paramBean.setString(t220001gBean.getKbShodan());	// 商談中区分
			paramBean.setString(t220001gBean.getCdShtan());		// 商談担当者コード
			paramBean.setString(t220001gBean.getMjSbikou());	// 商談備考
			paramBean.setTimestamp(executeDate);				// データ更新日時
			paramBean.setString(t220001gBean.getCdKsnsya());	// 更新ユーザID
			paramBean.setString(t220001gBean.getCdKsnapp());	// 更新アプリID

			// パラメータセット<条件>
			paramBean.setString(t220001gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220001gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220001gBean.getDdHannyu());	// 搬入日
			paramBean.setString(t220001gBean.getNoKanri());		// 管理番号

			SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

			return resultBean;
	}

	@Override
	public SimpleExecuteResultBean updateT220012G(Ucab007gBean t220012gBean,
			String loginKbScenter, String t220012gDtKosin,
			Timestamp executeDate) throws TecDAOException {
		
			/** 更新処理（ステータスDB）SQL */
			final String UPDATE_T220012G_SQL
				= "UPDATE " + UcarTableManager.getStatus(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
				+ "SET "
				+ "    DD_OUTPLN 	 = ? "
				+ "  , DT_STATUS25	 = ? "
				+ "  , DT_KOSIN 	 = ? "
				+ "  , CD_KSNSYA 	 = ? "
				+ "  , CD_KSNAPP 	 = ? "
				+ "WHERE "
				+ "      CD_KAISYA   = ? "
				+ "  AND CD_HANBAITN = ? "
				+ "  AND DD_HANNYU   = ? "
				+ "  AND NO_KANRI    = ? ";

			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220012G_SQL);

			// パラメータセット<値>
			if(t220012gBean.getDdOutpln() != null){
				paramBean.setDate(t220012gBean.getDdOutpln());		// 搬出予定日
			}else{
				paramBean.setString(null);
			}

			if(t220012gBean.getDtStatus25() != null){
				paramBean.setDate(t220012gBean.getDtStatus25());	// 写真撮影日
			}else{
				paramBean.setString(null);
			}
			
			paramBean.setTimestamp(executeDate);				// データ更新日時
			paramBean.setString(t220012gBean.getCdKsnsya());	// 更新ユーザID
			paramBean.setString(t220012gBean.getCdKsnapp());	// 更新アプリID

			// パラメータセット<条件>
			paramBean.setString(t220012gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220012gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220012gBean.getDdHannyu());	// 搬入日
			paramBean.setString(t220012gBean.getNoKanri());		// 管理番号

			SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

			return resultBean;
	}

	@Override
	public ResultArrayList<SyainDBBean> getSyainDBList(String cdKaisya,
			String cdHanbaitn, String cdSyain) throws TecDAOException {

		final String SELECT_SYAIN_DB_LIST_SQL
			= "SELECT "
			+ "    KJ_SYAINMEI "
			+ "FROM "
			+ "  " + AddonTableManager.getSyain(cdHanbaitn) + " "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_SYAIN  = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_SYAIN_DB_LIST_SQL);
		
		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(cdSyain);	// 社員コード

		ResultArrayList<SyainDBBean> resList
			= executeSimpleSelectQuery(paramBean, SyainDBBean.class);

		return resList;
	}
	
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end
}
