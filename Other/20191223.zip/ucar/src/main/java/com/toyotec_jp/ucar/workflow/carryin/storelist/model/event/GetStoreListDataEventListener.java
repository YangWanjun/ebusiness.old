package com.toyotec_jp.ucar.workflow.carryin.storelist.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.data.StoreListDAOIF;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListPagingBean;

/**
 * <strong>展示店舗受取処理情報取得イベントリスナ</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/27 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class GetStoreListDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		// イベントのキャスト
		GetStoreListDataEvent targetEvent = (GetStoreListDataEvent) event;

		// DAOIF取得
		StoreListDAOIF getDao = getDAO(CarryinDAOKey.STORELIST_DAO, targetEvent, StoreListDAOIF.class);
		
		// 展示店舗受取処理 画面出力値取得
		StoreListPagingBean storeListPagingBean = getDao.selectStoreListPaging(targetEvent.getCdKaisya(),
																		       targetEvent.getCdHanbaitn(),
  																			   targetEvent.getStoreListParamBean(),
																			   targetEvent.getSortParam(),
																			   targetEvent.getSortOrder(),
																			   targetEvent.getPageNo(),
																			   targetEvent.getPageSize(),
																			   targetEvent.isInit());

		GetStoreListDataEventResult eventResult = new GetStoreListDataEventResult();

		eventResult.setStoreListDataList(storeListPagingBean.getResultRecordList());
		eventResult.setTotalRecordCount(storeListPagingBean.getTotalRecordCount());  // 合計レコード数
		eventResult.setPageNo(Integer.parseInt(targetEvent.getPageNo()));            // ページ番号
		eventResult.setPageSize(Integer.parseInt(targetEvent.getPageSize()));        // ページサイズ	

		// イベント処理結果を返す
		return eventResult;	
	}
}
