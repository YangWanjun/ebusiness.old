package com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.event;

import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.object.CleanPlanUnPlanDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;

/**
 * <strong>まるクリ作業計画入力取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/24 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public class GetCleanPlanDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 色コードリスト(コード区分マスタ) */
	private ResultArrayList<Ucba004mBean> t220204mList;
	/** 未計画情報リスト */
	private ResultArrayList<CleanPlanUnPlanDataBean> unPlanList;

	/**
	 * t220204mListを取得する。
	 * @return t220204mList
	 */
	public ResultArrayList<Ucba004mBean> getT220204mList() {
		return t220204mList;
	}

	/**
	 * t220204mListを設定する。
	 * @param t220204mList
	 */
	public void setT220204mList(ResultArrayList<Ucba004mBean> t220204mList) {
		this.t220204mList = t220204mList;
	}

	/**
	 * unPlanListを取得する。
	 * @return unPlanList
	 */
	public ResultArrayList<CleanPlanUnPlanDataBean> getUnPlanList() {
		return unPlanList;
	}

	/**
	 * unPlanListを設定する。
	 * @param unPlanList
	 */
	public void setUnPlanList(ResultArrayList<CleanPlanUnPlanDataBean> unPlanList) {
		this.unPlanList = unPlanList;
	}

}
