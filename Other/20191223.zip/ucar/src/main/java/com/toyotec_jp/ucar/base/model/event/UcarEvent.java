/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarEvent.java
 * 【  説  明  】
 * 【  作  成  】2010/06/02 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.model.event;

import jp.co.intra_mart.framework.base.event.Event;

import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>基本イベント。</strong>
 * <p>
 * イベント作成時は本クラスを継承すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/02 新規作成<br>
 * @since 1.00
 */
public abstract class UcarEvent extends Event {

	private static final long serialVersionUID = -5526293123651529025L;

	private UserInformationBean userInfoBean;

	/**
	 * userInfoBeanを取得する。
	 * @return userInfoBean
	 */
	public UserInformationBean getUserInfoBean() {
		return userInfoBean;
	}

	/**
	 * userInfoBeanを設定する。
	 * @param userInfoBean
	 */
	public void setUserInfoBean(UserInformationBean userInfoBean) {
		this.userInfoBean = userInfoBean;
	}


}
