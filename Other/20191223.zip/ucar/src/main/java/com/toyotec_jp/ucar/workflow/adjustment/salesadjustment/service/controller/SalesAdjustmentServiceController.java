package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.service.controller;

import java.util.ArrayList;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentSessionBean;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst.AdjustmentEventKey;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst.AdjustmentServiceId;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event.GetSalesAdjustmentDataEvent;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event.GetSalesAdjustmentDataEventResult;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event.SaveSalesAdjustmentDataEvent;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportUtils;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst.ReportEventKey;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportUriageDenpyoEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportUriageDenpyoEventResult;

/**
 * <strong>売上精算サービスコントローラ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SalesAdjustmentServiceController extends UcarServiceController {

	/** 精算セッションBean */
	private AdjustmentSessionBean sessionBean = null;

	private String serviceId = "";
	private AdjustmentServiceId targetServiceId = null;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {
		// セッション設定
		setupSession();
		// サービス個別処理
		executeServiceProcess();
		return null;
	}

	/** セッション設定 */
	private void setupSession() throws TecSystemException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = AdjustmentServiceId.getTargetAdjustmentServiceId(serviceId);

		// サービスごとの処理
		if(targetServiceId != null){
			switch (targetServiceId) {
				case SALESADJUSTMENT_INIT:
					clearSession();
					break;
				case SALESADJUSTMENT_EXECUTEAFTER_INIT:
					sessionBean = getApplicationSessionBean(AdjustmentSessionBean.class);
					// セッションクリア前にファイルパスリストを退避する
					ArrayList<String> arrayDownloadFilePath = sessionBean.getArrayDownloadFilePath();
					clearSession();
					sessionBean.setArrayDownloadFilePath(arrayDownloadFilePath);
					break;
				case SALESADJUSTMENT_SEARCH:
					sessionBean = getApplicationSessionBean(AdjustmentSessionBean.class);

					// 受注№(テキストボックス)
					String searchNoJucyu = getRequest().getParameter("search_no_jucyu");
					if (!StringCheckUtils.isEmpty(searchNoJucyu)) {
						// 受注NO
						sessionBean.setNoJucyu(searchNoJucyu);
					}
					break;
				case SALESADJUSTMENT_RELOAD_SEARCH:
				case SALESADJUSTMENT_CONFIRM:
				case SALESADJUSTMENT_ADJUSTMENT:
				case SALESADJUSTMENT_ADJUSTMENT_CANCEL:
				case SALESADJUSTMENT_EXECUTEAFTER_SEARCH:
					sessionBean = getApplicationSessionBean(AdjustmentSessionBean.class);
					break;
				default:
					sessionBean = getApplicationSessionBean(AdjustmentSessionBean.class);
					break;
			}

			sessionBean.setServiceId(serviceId);
		}
	}

	/**
	 * セッションクリア処理
	 * @throws TecSystemException
	 */
	private void clearSession() throws TecSystemException {
		// セッションのクリア
		clearAllApplicationSession();
		// セッションの取得(新規)
		sessionBean = getNewApplicationSessionBean(AdjustmentSessionBean.class);

		sessionBean.setCdKaisya(getLoginSessionBean().getUserInfoBean().getCdKasyukai()); 		// 会社 	2013.2.13(TEC) N.O);
		sessionBean.setCdJigyosyo(getLoginSessionBean().getUserInfoBean().getCdKasyujigyo());		// 事業所　	2013.2.13(TEC) N.O;
	}

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException, ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if(targetServiceId != null){
			switch (targetServiceId) {
				case SALESADJUSTMENT_SEARCH:
				case SALESADJUSTMENT_EXECUTEAFTER_SEARCH:
					executeSearch(false);
					break;
				case SALESADJUSTMENT_CONFIRM:
					executeSearch(true);
					break;
				case SALESADJUSTMENT_ADJUSTMENT:
					SalesAdjustmentDataBean salesAdjustmentDataBean = executeSearch(true);
					executeAdjustment(salesAdjustmentDataBean, true);
					// 売上伝票、請求明細書印刷処理
					executeReportUriageDenpyo(AdjustmentConst.REISSUE_FLG_ADJUSTMENT);
					break;
				case SALESADJUSTMENT_ADJUSTMENT_CANCEL:
					SalesAdjustmentDataBean CancelsalesAdjustmentDataBean = executeSearch(false);
					executeAdjustment(CancelsalesAdjustmentDataBean, false);
					// 売上伝票、請求明細書印刷処理
					executeReportUriageDenpyo(AdjustmentConst.REISSUE_FLG_ADJUSTMENT);
					break;
				case SALESADJUSTMENT_REISSUE:
					// 売上伝票、請求明細書印刷処理
					executeReportUriageDenpyo(AdjustmentConst.REISSUE_FLG_REISSUE);
					break;
				default:
					break;
			}
		}
		TecLogger.trace("executeServiceProcess end");
	}

	/**
	 * 精算処理
	 * @param salesAdjustmentDataBean
	 * @param executeAdjustment true:精算処理/false:精算取消処理
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void executeAdjustment(SalesAdjustmentDataBean salesAdjustmentDataBean, boolean executeAdjustment) throws SystemException, ApplicationException {

		SaveSalesAdjustmentDataEvent executeEvent = createEvent(
				AdjustmentEventKey.SAVE_SALESADJUSTMENT_DATA, SaveSalesAdjustmentDataEvent.class);
		try {
			executeEvent.setSalesAdjustmentDataBean(salesAdjustmentDataBean);
			executeEvent.setExecuteAdjustment(executeAdjustment);

			if (executeAdjustment == false) {
				// 精算取消時
				// 売上担当者
				executeEvent.setCdUritanCancel(getRequest().getParameter("cd_uritan"));
			}

			dispatchEvent(executeEvent);

		} catch (SystemException e) {
			TecLogger.error(e);
			throw e;
		} catch (ApplicationException e) {
			// アプリケーション例外時はメッセージ設定
			throw e;
		}

	}

	/**
	 * 検索処理
	 * @param	executeConfirm	true:確認処理/false:検索処理
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private SalesAdjustmentDataBean executeSearch(boolean executeConfirm) throws SystemException, ApplicationException {

		String rdoSearch = getRequest().getParameter("rdo_search");

		GetSalesAdjustmentDataEvent getEvent = createEvent(
				AdjustmentEventKey.GET_SALESADJUSTMENT_DATA, GetSalesAdjustmentDataEvent.class);

		SalesAdjustmentDataBean salesAdjustmentDataBean = null;

		try {
			getEvent.setCdKaisya(sessionBean.getCdKaisya());
			getEvent.setCdJigyosyo(sessionBean.getCdJigyosyo());
			getEvent.setNoJucyu(sessionBean.getNoJucyu());

			getEvent.setExecuteConfirm(executeConfirm);
			if (executeConfirm) {
				// 確認ボタン押下時
				// 得意先値引適用
				getEvent.setKbNebiki(getRequest().getParameter("kb_nebiki"));
				// 値引き
				getEvent.setKiNebiki(Integer.parseInt(StringUtils.defaultValue(getRequest().getParameter("ki_nebiki"), "0")));
			} else {
				// 検索ボタン押下時
				// 得意先値引適用
				getEvent.setKbNebiki("");
				// 値引き
				getEvent.setKiNebiki(0);
			}

			GetSalesAdjustmentDataEventResult getResult
				= (GetSalesAdjustmentDataEventResult)dispatchEvent(getEvent);

			salesAdjustmentDataBean = getResult.getSalesAdjustmentDataBean();

			if (executeConfirm) {
				// 確認ボタン押下時

				// 売上担当者
				salesAdjustmentDataBean.setCdUritan(getRequest().getParameter("cd_uritan"));
				// 請求先お客様名
				salesAdjustmentDataBean.setMjCustomer(getRequest().getParameter("mj_customer"));
				// 依頼伝票№
				salesAdjustmentDataBean.setNoIrdenpyo(getRequest().getParameter("no_irdenpyo"));
				// メッセージ
				salesAdjustmentDataBean.setMjMessage(getRequest().getParameter("mj_message"));
				// ご用命区分 2013/08/28 要望対応
				salesAdjustmentDataBean.setKbGoyomei(getRequest().getParameter("kb_goyomei"));
			}

			sessionBean.setSalesAdjustmentDataBean(salesAdjustmentDataBean);
			sessionBean.setConfirmMessage(getResult.isConfirmMessage());
			sessionBean.setRdoSearch(rdoSearch);
			sessionBean.setDisabledBtnReissue(getResult.isDisabledBtnReissue());

		} catch (SystemException e) {
			TecLogger.error(e);
			throw e;
		} catch (ApplicationException e) {
			// アプリケーション例外時はメッセージ設定
			if ("0".equals(rdoSearch)) {
				// バーコードの場合
				setApplicationExceptionMessageBean(e.getMessage(), AdjustmentServiceId.SALESADJUSTMENT_INIT);
			} else {
				// 手入力の場合
				setApplicationExceptionMessageBean(e.getMessage(), AdjustmentServiceId.SALESADJUSTMENT_RELOAD_SEARCH);
			}
			throw e;
		}

		return salesAdjustmentDataBean;
	}

	/** 帳票処理：売上伝票 */
	private void executeReportUriageDenpyo(String reissueFlg) throws SystemException, ApplicationException {

		try{
			// 帳票作成
			String downloadfileName = "";
			ArrayList<String> arrayDownloadFilePath = new ArrayList<String>();

			ReportUriageDenpyoEvent event = createEvent(ReportEventKey.REPORT_URIAGE_DENPYO,
														  ReportUriageDenpyoEvent.class);

			Ucbb001gBean t220211gBean = new Ucbb001gBean(sessionBean.getCdKaisya(),
															sessionBean.getCdJigyosyo(),
															sessionBean.getNoJucyu());
			
			// 依頼伝票№を取得
			String irdenpyo = getRequest().getParameter("no_irdenpyo");
			if (irdenpyo != null && irdenpyo != "") {

				// 文字数が20未満で依頼伝票№が変更されている場合
				if (irdenpyo.length() < 20 && !irdenpyo.equals(sessionBean.getSalesAdjustmentDataBean().getNoIrdenpyo())) {
					// 末尾が「R」ではない場合、語尾に「R」を追加
					if(!irdenpyo.endsWith("R")){
						irdenpyo = irdenpyo + "R";
					}
				}
			}

			// 依頼伝票№設定
			t220211gBean.setNoIrdenpyo(irdenpyo);
			
			ArrayList<Ucbb001gBean> t220211gList = new ArrayList<Ucbb001gBean>();
			t220211gList.add(t220211gBean);
			event.setT220211gList(t220211gList);

			// 再発行識別フラグ(0:精算、精算取消／1:再発行)
			event.setResikibetuFg(reissueFlg);

			event.setChkPrintSeikyu(getRequest().getParameter("chk_print_seikyu"));

			ReportUriageDenpyoEventResult eventResult = (ReportUriageDenpyoEventResult)dispatchEvent(event);

			// 同名のファイルが作成されないように出力カウンターをファイル名に入れる
			int outputFileCount = 1;
			// ファイルパスの配列
			for (String tempFilePath : eventResult.getArrayFilePath()) {

				// 売上伝票、請求明細書
				// ファイル名変更をする
				downloadfileName = ReportUtils.getDownloadFileName(ReportConst.FILE_NAME_URIAGE_DENPYO
													   + "_"
													   + outputFileCount++,
													   StringUtils.getFileExtension(tempFilePath));

				// ダウンロード用処理
				String currentDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
				String downloadFilePath = ReportUtils.copyPdf(tempFilePath, downloadfileName, currentDate);

				arrayDownloadFilePath.add(downloadFilePath);
			}
			sessionBean.setArrayDownloadFilePath(arrayDownloadFilePath);

		}catch(SystemException e){
			throw e;
		}catch(ApplicationException e){
			// TODO アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), AdjustmentServiceId.SALESADJUSTMENT_INIT);
			throw e;
		}
	}

	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, AdjustmentServiceId adjustmentServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(adjustmentServiceId.getApplicationId());
		messageBean.setReturnServiceId(adjustmentServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

}
