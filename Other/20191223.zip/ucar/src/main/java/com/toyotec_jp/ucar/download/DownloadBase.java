package com.toyotec_jp.ucar.download;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

import org.seasar.struts.util.ResponseUtil;

import com.toyotec_jp.ucarsa.common.exception.DownloadException;
import com.toyotec_jp.ucarsa.common.utils.ExcelWriter;

/**
 * <strong></strong>
 * @author MHH
 * @version 1.00
 * @since 1.00
 * @category [使わない既存ソースの移動]
 */
public class DownloadBase {

	protected static final String WORK_DIR = "pfjk";

	public enum CellType {
		STRING, NUMBER
	}

	protected void downloadCsv(List<List<String>> list) {

	}

	protected void downloadXls(String fileName, ExcelWriter xls)
			throws DownloadException {
		File dir = new File(WORK_DIR);
		if (!dir.exists()) {
			dir.mkdir();
		}

		try {
			String filePath = WORK_DIR + "/" + fileName;
					//+ new String(fileName.getBytes("Windows-31J"), "ISO8859_1");

			File file = new File(filePath);
			file.createNewFile();

			FileOutputStream out = new FileOutputStream(file);
			xls.save(out);
			out.close();

			FileInputStream fis = new FileInputStream(filePath);

			String downloadFileName = new String(fileName
					.getBytes("Windows-31J"), "ISO8859_1");
			ResponseUtil.download(downloadFileName, fis);
		} catch (Exception e) {

			e.printStackTrace();
			throw new DownloadException();
		}

	}
	protected void downloadPDF(String fileName, ExcelWriter xls)
			throws DownloadException {
		File dir = new File(WORK_DIR);
		if (!dir.exists()) {
			dir.mkdir();
		}

		try {
			String filePath = WORK_DIR + "/" + fileName;
			// + new String(fileName.getBytes("Windows-31J"), "ISO8859_1");

			File file = new File(filePath);
			file.createNewFile();

			FileOutputStream out = new FileOutputStream(file);
			xls.save(out);
			out.close();

			FileInputStream fis = new FileInputStream(filePath);

			String downloadFileName = new String(fileName
					.getBytes("Windows-31J"), "ISO8859_1");
			ResponseUtil.download(downloadFileName, fis);
		} catch (Exception e) {

			e.printStackTrace();
			throw new DownloadException();
		}

	}

}
