package com.toyotec_jp.ucar.workflow.carryin.storelist.service.controller;

import jp.co.intra_mart.framework.base.service.ServiceControllerException;
import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.utils.SimpleRequestMapper;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinEventKey;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.event.UpdateStoreListDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListParamBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListSessionBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>展示店舗受取処理サービスコントローラ</strong>
 *
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/23 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class StoreListServiceController extends UcarServiceController {

	// 2018.11.30 ISM 修正指示書:46
	///** 店舗コード：相模原SC */
	// private static final String CD_TENPO_SAGAMIHARA = "491";

	private String serviceId = "";
	private CarryinServiceId targetServiceId = null;

	/** 展示店舗受取処理 検索条件Bean */
	private StoreListParamBean storeListParamBean = new StoreListParamBean();
	/** 展示店舗受取処理セッションBean */
	private StoreListSessionBean storeListSessionBean;
	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean = new Ucaa001gPKBean();

	/*
	 * (非 Javadoc)
	 *
	 * @see
	 * jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service
	 * ()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {

		TecLogger.trace("service start");
		// セッション設定
		setupSession();
		// サービス個別処理
		executeServiceProcess();
		TecLogger.trace("service end");

		return null;
	}

	/** セッション設定
	 * @throws ServiceControllerException
	 * @throws TecApplicationException */
	private void setupSession() throws TecSystemException, ServiceControllerException, TecApplicationException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = CarryinServiceId.getTargetCarryinServiceId(serviceId);

		TecLogger.debug("serviceId[" + serviceId + "]");

		// 2013.06.06 T.Hayato 修正 ユーザコードマスタから店舗コードを取得するため start
//		String cdTenpo = getCdTenpo();
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());
		UserInformationBean userInfoBean = loginSessionBean.getUserInfoBean();
		String kbScenter = userInfoBean.getKbScenter();
		String cdTenpo = userInfoBean.getCdTenpo();

		if ("".equals(userInfoBean.getCdKaisya())
			&& "".equals(userInfoBean.getCdHanbaitn())
			&& "".equals(userInfoBean.getCdTenpo())) {
			throw new TecApplicationException("ユーザコードマスタにログインユーザが登録されていません。");
		}
		// 2013.06.06 T.Hayato 修正 ユーザコードマスタから店舗コードを取得するため end

		// サービスごとの処理
		if (targetServiceId != null) {
			switch (targetServiceId) {
				case STORELIST_INIT:
					// 初期処理
					// セッションのクリア
					clearAllApplicationSession();
					// セッション取得
					storeListSessionBean = getApplicationSessionBean(StoreListSessionBean.class);
					storeListSessionBean.setSortParam("");  // ソートキー
					storeListSessionBean.setSortOrder("");  // ソート順
					storeListSessionBean.setPageNo("1");    // ページ番号

					// 2012.04.04 A.Yoshinami 追加 受取チェック状態(初期値:受取未完了で固定)追加のため start
					String[] arrayChkUketori = new String[] {CarryinConst.UKETORI_MIKANRYOU}; // 受取チェック状態(受取未完了で固定)
					storeListParamBean.setArrayChkUketori(arrayChkUketori);
					storeListSessionBean.setStoreListParamBean(storeListParamBean);
					// 2012.04.04 A.Yoshinami 追加 受取チェック状態(初期値:受取未完了で固定)追加のため end

					// 2013.03.13 T.Hayato 修正 複数販売店化 修正のため start
					if (UcarConst.KB_SCENTER_SCENTER.equals(kbScenter)) {
						// 本部の場合
						storeListSessionBean.setHonbuLoginId(true);
					} else {
						storeListParamBean.setCdTenpo(cdTenpo);
						storeListSessionBean.setStoreListParamBean(storeListParamBean);
						storeListSessionBean.setHonbuLoginId(false);
					}
					// 2013.03.13 T.Hayato 修正 複数販売店化 修正のため end
					break;
				case STORELIST_SEARCH:
					// 検索処理
					// セッション取得
					storeListSessionBean = getApplicationSessionBean(StoreListSessionBean.class);

					storeListSessionBean.setSortParam(getRequest().getParameter("sort_param"));  // ソートキー
					storeListSessionBean.setSortOrder(getRequest().getParameter("sort_order"));  // ソート順
					storeListSessionBean.setPageNo("1");                                         // ページ番号

					// 2012.04.04 A.Yoshinami 追加 受取チェック状態を追加のため start
					storeListParamBean.setArrayChkUketori(getRequest().getParameterValues("chk_uketori"));  // 受取チェック状態
					storeListSessionBean.setStoreListParamBean(storeListParamBean);
					// 2012.04.04 A.Yoshinami 追加 受取チェック状態を追加のため end

					SimpleRequestMapper.setRequest(getRequest(), storeListParamBean);

					storeListSessionBean.setInit(false);

					// 2013.07.25 C.Ohta 修正 搬入拠点分散対応２ start
//					if (!CD_TENPO_SAGAMIHARA.equals(cdTenpo)) {
					if (!UcarConst.KB_SCENTER_SCENTER.equals(kbScenter)) {
					// 2013.07.25 C.Ohta 修正 搬入拠点分散対応２ end
						// 店舗コードを再セット
						storeListParamBean.setCdTenpo(cdTenpo);
					}
					storeListSessionBean.setStoreListParamBean(storeListParamBean);
					break;
				case STORELIST_SORTING:
					storeListSessionBean = getApplicationSessionBean(StoreListSessionBean.class);

					storeListSessionBean.setSortParam(getRequest().getParameter("sort_param"));  // ソートキー
					storeListSessionBean.setSortOrder(getRequest().getParameter("sort_order"));  // ソート順
					String currentPage = getRequest().getParameter("current_page");
					if (currentPage == null) {
						storeListSessionBean.setPageNo("1");
					} else {
						storeListSessionBean.setPageNo(currentPage);
					}
					break;
				case STORELIST_UPDATE:
					// 更新処理
					// セッション取得
					storeListSessionBean = getApplicationSessionBean(StoreListSessionBean.class);

					t220001gPkBean.setCdKaisya(getRequest().getParameter("cd_kaisya"));
					t220001gPkBean.setCdHanbaitn(getRequest().getParameter("cd_hanbaitn"));
					t220001gPkBean.setDdHannyu(getRequest().getParameter("dd_hannyu"));
					t220001gPkBean.setNoKanri(getRequest().getParameter("no_kanri"));
					break;
				case STORELIST_RELORD:
					storeListSessionBean = getApplicationSessionBean(StoreListSessionBean.class);
					break;
				default:
					break;
			}
			storeListSessionBean.setServiceId(serviceId);
		}
		TecLogger.trace("setupSession end");
	}

	// 2013.06.06 T.Hayato 修正 ユーザコードマスタから店舗コードを取得するため start
//	/**
//	 *
//	 * @return
//	 * @throws TecSystemException
//	 */
//	private String getCdTenpo() throws TecSystemException {
//
//		String cdTenpo = "";
//		try {
//			// ログインID取得
//			UserInfo userInfo = UserInfoUtil.createUserInfo(getRequest(), getResponse());
//			cdTenpo = userInfo.getUserID().substring(6,9);
//		} catch (UserInfoException e) {
//			throw new TecSystemException(e.getMessage());
//		}
//		return cdTenpo;
//	}
	// 2013.06.06 T.Hayato 修正 ユーザコードマスタから店舗コードを取得するため end

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException,ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if (targetServiceId != null) {
			  switch (targetServiceId) {
			  case STORELIST_UPDATE:
				  // 更新処理
 					  executeUpdate();
					  setExecuteEndMessageBean(TecMessageManager.getMessage(UcarMessage.EXEC_ANY, "受取処理が完了"),CarryinServiceId.STORELIST_RELORD);
				  break;
			}
		}
		TecLogger.trace("executeServiceProcess end");
	}

	/** 更新処理 */
	private void executeUpdate() throws SystemException, ApplicationException {

		// イベントの生成
		UpdateStoreListDataEvent event
		     = createEvent(CarryinEventKey.UPDATE_STORELIST_DATA, UpdateStoreListDataEvent.class);
		// 入力値設定
		event.setUcaa001gPKBean(t220001gPkBean);
		event.setDtKosin(getRequest().getParameter("dt_kosin"));
		// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため start
		event.setStoreListDataList(storeListSessionBean.getStoreListDataList());
		// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため end

		try {
			// イベントの実行
			dispatchEvent(event);

		}catch (SystemException e) {
			TecLogger.error(e);
			throw e;
		} catch (ApplicationException e) {
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.STORELIST_RELORD);
			throw e;
		}
	}

	/** 正常系メッセージ設定 */
	private void setExecuteEndMessageBean(String message,
		CarryinServiceId carryinServiceId) {
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carryinServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryinServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_INFORMATION);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message,
		CarryinServiceId carryinServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carryinServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryinServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}
}
