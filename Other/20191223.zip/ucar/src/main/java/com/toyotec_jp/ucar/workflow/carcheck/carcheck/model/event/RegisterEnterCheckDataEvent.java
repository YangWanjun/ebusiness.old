package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;

/**
 * <strong>入庫検査登録イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/18 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class RegisterEnterCheckDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 会社コード */
	private String	cdKaisya;
	/** 販売店コード */
	private String	cdHanbaitn;
	/** 搬入日、管理番号配列
	 * <pre>
	 * 形式：yyyymmdd,000(数値3桁)
	 * </pre>
	 *  */
	private String selectData[];
	/** 区分 */
	private String rdoKubun;
	/** 設定日付
	 * <pre>
	 * 入庫検査日、仕分日、保留日
	 * </pre>
	 *  */
	private String ddSetDate;

	/** 表示リスト(排他チェック用) */
	private List<CarCheckDataBean> carCheckDataList;
	// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
	/** 入庫検査担当者コード */
	private String cdNkktan;
	// 2012.03.26 T.Hayato 追加 チェック者 追加のため end

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * selectDataを取得する。
	 * @return selectData
	 */
	public String[] getSelectData() {
		return selectData;
	}

	/**
	 * selectDataを設定する。
	 * @param selectData
	 */
	public void setSelectData(String[] selectData) {
		this.selectData = selectData;
	}

	/**
	 * rdoKubunを取得する。
	 * @return rdoKubun
	 */
	public String getRdoKubun() {
		return rdoKubun;
	}

	/**
	 * rdoKubunを設定する。
	 * @param rdoKubun
	 */
	public void setRdoKubun(String rdoKubun) {
		this.rdoKubun = rdoKubun;
	}

	/**
	 * ddSetDateを取得する。
	 * @return ddSetDate
	 */
	public String getDdSetDate() {
		return ddSetDate;
	}

	/**
	 * ddSetDateを設定する。
	 * @param ddSetDate
	 */
	public void setDdSetDate(String ddSetDate) {
		this.ddSetDate = ddSetDate;
	}

	/**
	 * carCheckDataListを取得する。
	 * @return carCheckDataList
	 */
	public List<CarCheckDataBean> getCarCheckDataList() {
		return carCheckDataList;
	}

	/**
	 * carCheckDataListを設定する。
	 * @param carCheckDataList
	 */
	public void setCarCheckDataList(List<CarCheckDataBean> carCheckDataList) {
		this.carCheckDataList = carCheckDataList;
	}

	/**
	 * cdNkktanを取得する。
	 * @return cdNkktan
	 */
	public String getCdNkktan() {
		return cdNkktan;
	}

	/**
	 * cdNkktanを設定する。
	 * @param cdNkktan
	 */
	public void setCdNkktan(String cdNkktan) {
		this.cdNkktan = cdNkktan;
	}

}