package com.toyotec_jp.ucar.workflow.carryin.list.model.event;

import java.util.ArrayList;
import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListDataBean;

/**
 * <strong>書類チェック登録イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/18 新規作成<br>
 * @since 1.00
 * @category [[搬入書類チェック]]
 */
public class RegisterDocumentCheckDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 車両搬入情報 プライマリーキーBeanリスト */
	private ArrayList<Ucaa001gPKBean> t220001gPKList;

	/** 区分 */
	private String rdoKubun;

	/** 設定日付
	 * <pre>
	 * 書類完備日、保留日
	 * </pre>
	 *  */
	private String ddSetDate;

	/** 表示リスト(排他チェック用) */
	private List<ListDataBean> documentCheckDataList;

	/** 実行処理フラグ
	 * <pre>
	 * true:登録処理
	 * false:取消処理
	 * </pre>
	 *  */
	private boolean executeRegister;

	/**
	 * t220001gPKListを取得する。
	 * @return t220001gPKList 車両搬入情報 プライマリーキーBeanリスト
	 */
	public ArrayList<Ucaa001gPKBean> getT220001gPKList() {
		return t220001gPKList;
	}

	/**
	 * t220001gPKListを設定する。
	 * @param t220001gPKList 車両搬入情報 プライマリーキーBeanリスト
	 */
	public void setT220001gPKList(ArrayList<Ucaa001gPKBean> t220001gPKList) {
		this.t220001gPKList = t220001gPKList;
	}

	/**
	 * rdoKubunを取得する。
	 * @return rdoKubun 区分
	 */
	public String getRdoKubun() {
		return rdoKubun;
	}

	/**
	 * rdoKubunを設定する。
	 * @param rdoKubun 区分
	 */
	public void setRdoKubun(String rdoKubun) {
		this.rdoKubun = rdoKubun;
	}

	/**
	 * ddSetDateを取得する。
	 * @return ddSetDate 設定日付
	 */
	public String getDdSetDate() {
		return ddSetDate;
	}

	/**
	 * ddSetDateを設定する。
	 * @param ddSetDate 設定日付
	 */
	public void setDdSetDate(String ddSetDate) {
		this.ddSetDate = ddSetDate;
	}

	/**
	 * documentCheckDataListを取得する。
	 * @return documentCheckDataList 表示リスト(排他チェック用)
	 */
	public List<ListDataBean> getDocumentCheckDataList() {
		return documentCheckDataList;
	}

	/**
	 * documentCheckDataListを設定する。
	 * @param documentCheckDataList 表示リスト(排他チェック用)
	 */
	public void setDocumentCheckDataList(List<ListDataBean> documentCheckDataList) {
		this.documentCheckDataList = documentCheckDataList;
	}

	/**
	 * executeRegisterを取得する。
	 * @return executeRegister 実行処理フラグ
	 */
	public boolean isExecuteRegister() {
		return executeRegister;
	}

	/**
	 * executeRegisterを設定する。
	 * @param executeRegister 実行処理フラグ
	 */
	public void setExecuteRegister(boolean executeRegister) {
		this.executeRegister = executeRegister;
	}

}