package com.toyotec_jp.ucar.workflow.allclean.common;

import com.toyotec_jp.im_common.TecApplicationManager.TecApplicationIdIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecServiceIdIF;
import com.toyotec_jp.ucar.UcarApplicationManager;

/**
 * <strong>まるクリ関連共通定数管理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/17 新規作成<br>
 * @since 1.00
 * @category [[まるクリ(共通)]]
 */
public class AllCleanConst {

	/** パッケージカテゴリ:まるクリ */
	public static final String PKG_CAT_ALLCLEAN = ".allclean";

	/** まるクリ関連パッケージルート */
	public static final String ALLCLEAN_ROOT
		= UcarApplicationManager.WF_ROOT + PKG_CAT_ALLCLEAN;

	/** まるクリ作業計画入力パッケージルート */
	public static final String CLEANPLAN_ROOT
		= ALLCLEAN_ROOT + ".cleanplan";
	/** まるクリ_ステータス照会パッケージルート */
	public static final String STATUS_ROOT
		= ALLCLEAN_ROOT + ".status";

	/** アプリID:まるクリ-まるクリ作業計画入力 */
	public static final String APPID_ALLCLEAN_CLEANPLAN
		= UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.allclean.CleanPlan");
	/** アプリID:まるクリ-まるクリ_ステータス照会 */
	public static final String APPID_ALLCLEAN_STATUS
		= UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.allclean.Status");

	/** 区分ID：まるクリランク */
	public static final String KB_ID_MARURANK 	= "07";
	/** まるクリ計画区分：未計画 */
	public static final String KB_MPLAN_UNPLAN 	= "0";

	/** インスタンスを生成しない。 */
	private AllCleanConst(){
	}

	/** まるクリ関連タイトル */
	public enum AllCleanTitle {
		/** まるクリ作業計画入力 */
		CLEANPLAN(".CleanPlan"),
		/** まるクリ_ステータス照会 */
		STATUS(".Status"),
		;
		private String titleLabel;
		private AllCleanTitle(String key){
			this.titleLabel = UcarApplicationManager.getConstantValue(
					UcarApplicationManager.WF_ROOT + ".title" + PKG_CAT_ALLCLEAN + key);
		}
		public String toString(){
			return titleLabel;
		}
		/**
		 * 画面タイトルを取得する。
		 * @return titleLabel 画面タイトル
		 */
		public String getTitleLabel() {
			return titleLabel;
		}
	}

	/** まるクリ関連アプリケーションID */
	public enum AllCleanApplicationId implements TecApplicationIdIF {
		/** まるクリ作業計画入力 */
		CLEANPLAN(CLEANPLAN_ROOT + ".CleanPlan"),
		/** まるクリ_ステータス照会 */
		STATUS(STATUS_ROOT + ".Status"),
		;
		private String applicationId;
		private AllCleanApplicationId(String applicationId){
			this.applicationId = applicationId;
		}
		public String toString(){
			return applicationId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
	}

	/** まるクリ関連サービスID */
	public enum AllCleanServiceId implements TecServiceIdIF {
		/** 初期処理 */
		CLEANPLAN_INIT(AllCleanApplicationId.CLEANPLAN, "CleanPlanInit"),
		;
		private String applicationId;
		private String serviceId;
		private AllCleanServiceId(TecApplicationIdIF appId, String serviceId){
			this.applicationId = appId.getApplicationId();
			this.serviceId = serviceId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
		@Override
		public String getServiceId() {
			return serviceId;
		}
		/**
		 * まるクリ関連サービスID取得。
		 * <pre>
		 * まるクリ関連サービスIDを返却する。<br>
		 * 値として認められない場合はnullを返却する。
		 * </pre>
		 * @param serviceId サービスID
		 * @return まるクリ関連サービスID
		 */
		public static AllCleanServiceId getTargetAllCleanServiceId(String serviceId){
			AllCleanServiceId target = null;
			for(AllCleanServiceId enumElement : AllCleanServiceId.values()){
				if(enumElement.getServiceId().equals(serviceId)){
					target = enumElement;
					break;
				}
			}
			return target;
		}
	}

	/** まるクリ関連イベントキー */
	public enum AllCleanEventKey implements TecEventKeyIF {
		/** まるクリ情報取得イベント */
		GET_CLEANPLAN_DATA(AllCleanApplicationId.CLEANPLAN, "GetCleanPlanDataEvent"),
		;
		private String applicationId;
		private String eventKey;
		private AllCleanEventKey(TecApplicationIdIF appId, String eventKey){
			this.applicationId = appId.getApplicationId();
			this.eventKey = eventKey;
		}
		public String toString(){
			return eventKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getEventKey(){
			return eventKey;
		}
	}

	/** まるクリ関連DAOキー */
	public enum AllCleanDAOKey implements TecDAOKeyIF {
		/** まるクリ作業計画入力DAO */
		CLEANPLAN_DAO(AllCleanApplicationId.CLEANPLAN, "CleanPlanDAO"),
		;
		private String applicationId;
		private String daoKey;
		private AllCleanDAOKey(TecApplicationIdIF appId, String daoKey){
			this.applicationId = appId.getApplicationId();
			this.daoKey = daoKey;
		}
		public String toString(){
			return daoKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getDAOKey(){
			return daoKey;
		}
	}

}
