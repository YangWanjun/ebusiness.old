/**
 * カレンダービジネスロジック関連パッケージ
 * @version 1.00 2010/06/17 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.common.calendar.model;
