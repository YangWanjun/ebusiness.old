package com.toyotec_jp.ucar.workflow.common.parts.model.data;


import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>ユーザ関連情報操作DAOの実装。</strong>
 * @author Y.M(TEC)
 * @version 1.00 2011/11/18 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UserInformationDAOImpl extends UcarSharedDBDAO implements UserInformationDAOIF {

	// 2013.02.12 T.Hayato 修正 ユーザー情報取得先 変更の為 start
	private static final String SELECT_USER_INFO_SQL
		= "SELECT "
		+ "    CD_USER "
		+ "  , CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , CD_TENPO "
		+ "  , KB_SCENTER "
		// 2013.05.09 T.Hayato 修正 搬入拠点分散対応2のため start
		+ "  , KB_NCARTN "
		// 2013.05.09 T.Hayato 修正 搬入拠点分散対応2のため end
		+ "  , CD_KASYUKAI "
		+ "  , CD_KASYUJIGYO "
		+ "  , KB_KASYUKNR "
		// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 start
		+ "  , KB_GYOHAN "
		// 2016.02.16 H.Yamashita 追加 在庫カード 業販店舗対応 end
		+ "FROM "
		+ "  T220019M "
		+ "WHERE "
		+ "  CD_USER = ? "
		+ "ORDER BY "
		+ "  CD_USER ";
	// 2013.02.12 T.Hayato 修正 ユーザー情報取得先 変更の為 end

	/* (non-Javadoc)
	 * @see jp.co.core.lcm.workflow.common.parts.model.data.UserInformationDAOIF#getUserInformation(java.lang.String)
	 */
	@Override
	public UserInformationBean getUserInformation(String employeeCd) throws TecDAOException {

		UserInformationBean userInfoBean = null;

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_USER_INFO_SQL);
		paramBean.setString(employeeCd);

		ResultArrayList<UserInformationBean> userInfoList = executeSimpleSelectQuery(paramBean, UserInformationBean.class);

		if(userInfoList.size() > 0){
			userInfoBean = userInfoList.get(0);
			if(userInfoList.size() > 1){
				TecLogger.warn("ユーザ情報不整合");
			}
		}

		return userInfoBean;
	}
}
