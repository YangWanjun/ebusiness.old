package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>作業工程マスタ操作用イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/24 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SagyoKouteiEvent extends UcarEvent {

	private static final long serialVersionUID = -8975344836334571960L;

	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	/** 店舗識別区分 */
	private String	kbTenposk;	// 2013.05.16 S.Nishizaki 修正　搬入拠点分散対応２
	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn 販売店コード
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn 販売店コード
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}
	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

	// 2013.05.16 S.Nishizaki 修正　搬入拠点分散対応２　start
	/**
	 * kbTenposkを取得する。
	 * @return kbTenposk 店舗識別区分
	 */
	public String getKbTenposk() {
		return kbTenposk;
	}

	/**
	 * kbTenposkを設定する。
	 * @param kbTenposk 店舗識別区分
	 */
	public void setKbTenposk(String kbTenposk) {
		this.kbTenposk = kbTenposk;
	}
	// 2013.05.16 S.Nishizaki 修正　搬入拠点分散対応２　end
}
