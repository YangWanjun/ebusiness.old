/*
 * 【システム名】
 * 【ファイル名】DMResultSheet.java
 * 【  説  明  】結果返却用シートクラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

/**
 * <strong>DMResultSheet</strong>
 * <p>
 * 結果返却用シートクラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMResultSheet {

	/**
	 * コンストラクタ
	 * @param sheetIdx シートインデックス
	 * @param sheetName シート名
	 */
	public DMResultSheet(int sheetIdx, String sheetName){
		this.sheetIdx = sheetIdx;
		this.sheetName = sheetName;
	}

	private int sheetIdx;

	private String sheetName;

	@SuppressWarnings("rawtypes")
	private DMResultColumn[] simpleColumns;

	private DMResultList[] resultLists;

	/**
	 * リスト項目結果リスト取得
	 * @return リスト項目結果リスト
	 * @since 1.00
	 */
	public DMResultList[] getResultLists() {
		return resultLists;
	}

	/**
	 * リスト項目結果リスト設定
	 * @param resultLists リスト項目結果リスト
	 * @since 1.00
	 */
	public void setResultLists(DMResultList[] resultLists) {
		this.resultLists = resultLists;
	}

	/**
	 * シートインデックス取得
	 * @return シートインデックス
	 * @since 1.00
	 */
	public int getSheetIdx() {
		return sheetIdx;
	}

	/**
	 * シート名取得
	 * @return シート名
	 * @since 1.00
	 */
	public String getSheetName() {
		return sheetName;
	}

	/**
	 * 汎用項目取得
	 * @return 汎用項目
	 * @since 1.00
	 */
	@SuppressWarnings("rawtypes")
	public DMResultColumn[] getSimpleColumns() {
		return simpleColumns;
	}

	/**
	 * 汎用項目設定
	 * @param simpleColumns 汎用項目
	 * @since 1.00
	 */
	@SuppressWarnings("rawtypes")
	public void setSimpleColumns(DMResultColumn[] simpleColumns) {
		this.simpleColumns = simpleColumns;
	}

}
