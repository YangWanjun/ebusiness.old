package com.toyotec_jp.ucar.workflow.carryin.list.model.event;

import java.util.List;

import jp.co.intra_mart.framework.base.event.EventResult;

import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;

/**
 * @category [[車両搬入一覧]]
 */
public class ListSelectEventResult implements EventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private List<ListDataBean> rtnData;
	/** チェック内容情報Beanリスト */
	private ResultArrayList<Ucaa005mBean> t220005mList;

	private int pageSize;
	private int pageNo;
	private int totalRecordCount;

	public ListSelectEventResult() {

	}

	public List<ListDataBean> getRtnData() {
		return rtnData;
	}

	public void setRtnData(List<ListDataBean> rtnData) {
		this.rtnData = rtnData;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	public void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public ResultArrayList<Ucaa005mBean> getT220005mList() {
		return t220005mList;
	}

	public void setT220005mList(ResultArrayList<Ucaa005mBean> t220005mList) {
		this.t220005mList = t220005mList;
	}
}
