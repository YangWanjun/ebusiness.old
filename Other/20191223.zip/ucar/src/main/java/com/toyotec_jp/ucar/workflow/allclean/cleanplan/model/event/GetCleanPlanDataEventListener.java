package com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.data.CleanPlanDAOIF;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.object.CleanPlanUnPlanDataBean;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanConst.AllCleanDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;

/**
 * <strong>まるクリ作業計画入力取得イベントリスナ</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/24 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public class GetCleanPlanDataEventListener extends UcarEventListener {

	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetCleanPlanDataEvent targetEvent = (GetCleanPlanDataEvent)event;

		// DAOIF取得
		CleanPlanDAOIF getDao = getDAO(AllCleanDAOKey.CLEANPLAN_DAO, targetEvent, CleanPlanDAOIF.class);

//		ResultArrayList<CleanPlanUnPlanDataBean> unPlanList
//			= getDao.selectUnPlanList(targetEvent.getUserInfoBean().getCdKaisya(),
//									  targetEvent.getUserInfoBean().getCdKasyujigyo());

		ResultArrayList<Ucba004mBean> colorCodeList
			= getDao.selectColorCodeList("01", "001");

		ResultArrayList<CleanPlanUnPlanDataBean> unPlanList
			= getDao.selectUnPlanList("01", "001");

		GetCleanPlanDataEventResult getEventResult = new GetCleanPlanDataEventResult();
		getEventResult.setUnPlanList(unPlanList);
		getEventResult.setT220204mList(colorCodeList);

		return getEventResult;
	}
}