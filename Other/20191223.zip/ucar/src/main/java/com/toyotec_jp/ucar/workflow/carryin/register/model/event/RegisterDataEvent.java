package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;

/**
 * <strong>登録イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 車両搬入登録 画面入力値格納用Bean */
	private RegisterInputBean registerInputBean;
	/** メニューID */
	private String menuId;

	/**
	 * 車両搬入登録 画面入力値格納用Beanを取得する。
	 * @return registerInputBean 車両搬入登録 画面入力値格納用Bean
	 */
	public RegisterInputBean getRegisterInputBean() {
		return registerInputBean;
	}

	/**
	 * 車両搬入登録 画面入力値格納用Beanを設定する。
	 * @param registerInputBean 車両搬入登録 画面入力値格納用Bean
	 */
	public void setRegisterInputBean(RegisterInputBean registerInputBean) {
		this.registerInputBean = registerInputBean;
	}

	/**
	 * menuIdを取得する。
	 * @return menuId メニューID
	 */
	public String getMenuId() {
		return menuId;
	}

	/**
	 * menuIdを設定する。
	 * @param menuId メニューID
	 */
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

}
