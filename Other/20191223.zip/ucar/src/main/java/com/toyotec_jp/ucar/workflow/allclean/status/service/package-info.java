/**
 * まるクリ_ステータス照会サービスフレームワーク関連パッケージ
 * @version 1.00 2011/11/17 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.allclean.status.service;
