package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;

/**
 * <strong>更新登録イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class UpdateRegisterDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 車両搬入登録 画面入力値格納用Bean */
	private RegisterInputBean registerInputBean;
	/** 車両搬入情報：データ更新日時(排他チェック用) */
	private String t220001gDtKosin;

	/**メニューID */
	private String menuId;

	/**
	 * 車両搬入登録 画面入力値格納用Beanを取得する。
	 * @return registerInputBean 車両搬入登録 画面入力値格納用Bean
	 */
	public RegisterInputBean getRegisterInputBean() {
		return registerInputBean;
	}

	/**
	 * 車両搬入登録 画面入力値格納用Beanを設定する。
	 * @param registerInputBean 車両搬入登録 画面入力値格納用Bean
	 */
	public void setRegisterInputBean(RegisterInputBean registerInputBean) {
		this.registerInputBean = registerInputBean;
	}

	/**
	 * t220001gDtKosinを取得する。
	 * @return t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 */
	public String getT220001gDtKosin() {
		return t220001gDtKosin;
	}

	/**
	 * t220001gDtKosinを設定する。
	 * @param t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 */
	public void setT220001gDtKosin(String t220001gDtKosin) {
		this.t220001gDtKosin = t220001gDtKosin;
	}
	
	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

}
