/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecSystemException.java
 * 【  説  明  】
 * 【  作  成  】2010/05/24 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import java.util.ArrayList;

import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;
import com.toyotec_jp.im_common.system.message.TecMessageManager;

/**
 * <strong>基本システム例外クラス。</strong>
 * <p>
 * システムとして異常が起こった場合の例外。<br>
 * DBエラーやプロパティ取得エラー等。<br>
 * システムが正常であっても発生する例外<br>
 * (入力チェックエラーや排他エラー等)は<br>
 * 基本アプリケーション例外(及びそのサブクラス)を使用。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/24 新規作成<br>
 * @since 1.00
 */
public class TecSystemException extends SystemException {

	private static final long serialVersionUID = 2847787605028244736L;

	private TecExceptionLevel level = TecExceptionLevel.ERROR;

	/**
	 * コンストラクタ。
	 */
	public TecSystemException() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param message
	 */
	public TecSystemException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * @param cause
	 */
	public TecSystemException(Throwable cause) {
		super(cause);
	}

	/**
	 * コンストラクタ。
	 * @param message
	 * @param cause
	 */
	public TecSystemException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 */
	public TecSystemException(TecMessageKeyIF messageKey) {
		super(getMsg(messageKey, null));
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 * @param args 置換文字列の配列
	 */
	public TecSystemException(TecMessageKeyIF messageKey, ArrayList<Object> args) {
		super(getMsg(messageKey, args));
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 * @param cause
	 */
	public TecSystemException(TecMessageKeyIF messageKey, Throwable cause) {
		super(getMsg(messageKey, null), cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 * @param args 置換文字列の配列
	 * @param cause
	 */
	public TecSystemException(TecMessageKeyIF messageKey, ArrayList<Object> args, Throwable cause) {
		super(getMsg(messageKey, args), cause);
	}

	// 例外メッセージ取得
	private static String getMsg(TecMessageKeyIF messageKey, ArrayList<Object> args){
		String msg = null;
		try {
			if(args == null){
				msg = TecMessageManager.getMessage(messageKey);
			} else {
				msg = TecMessageManager.getMessage(messageKey, args);
			}
		} catch (TecMessageException e) {
			// 本来発生した例外がメインであるため、ここでのメッセージ取得失敗はスローしない。
			msg = messageKey.toString();
			TecLogger.error("例外メッセージ取得に失敗しました。[" + msg + "]");
		}
		return msg;
	}

	/**
	 * levelを取得する。
	 * @return level
	 */
	public TecExceptionLevel getLevel() {
		return level;
	}

	/**
	 * levelを設定する。
	 * @param level
	 */
	public void setLevel(TecExceptionLevel level) {
		this.level = level;
	}

}
