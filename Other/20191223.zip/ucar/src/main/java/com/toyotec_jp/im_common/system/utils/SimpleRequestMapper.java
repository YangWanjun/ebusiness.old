/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】SimpleRequestMapper.java
 * 【  説  明  】
 * 【  作  成  】2010/06/09 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.exception.TecUnsupportedDataTypeException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageKey;
import com.toyotec_jp.im_common.system.model.object.TecBean;


/**
 * <strong>リクエスト簡易マッピング用クラス。</strong>
 * <p>
 * リクエストの内容をビーンにマッピングする。<br>
 * ビーンのフィールド名が「abcDef」の場合、リクエストの項目名「abc_def」の値を設定する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/09 新規作成<br>
 * @since 1.00
 */
public class SimpleRequestMapper {

	private SimpleRequestMapper(){
	}

	/**
	 * リクエストの内容をビーンにマッピングする。
	 * @param req
	 * @param bean
	 * @throws TecSystemException
	 * @since 1.00
	 */
	public static void setRequest(HttpServletRequest req, TecBean bean) throws TecSystemException {
		Class<?> clsTarget = bean.getClass();

		while (clsTarget != null) {
			setRequest(req, bean, clsTarget);
			clsTarget = clsTarget.getSuperclass();
		}
	}

	// リクエストマッピング
	private static void setRequest(HttpServletRequest req, TecBean bean, Class<?> cls) throws TecSystemException {
		setRequest(req, bean, cls, 0);
	}

	// リクエストマッピング
	private static void setRequest(HttpServletRequest req, TecBean bean, Class<?> cls, int index) throws TecSystemException {
		Field[] fields = cls.getDeclaredFields();

		for (int i = 0; i < fields.length; i++) {
			Class<?> returnType = fields[i].getType();
			String fieldName = fields[i].getName();
			String methodName = StringUtils.getSetterName(fields[i]);
			String paramName = StringUtils.convFieldToColumnName(fieldName);

			// フィールドインデックスが指定されている場合はパラメータ名にインデックスを付加
			if (index != 0) {
				paramName += index;
			}

			try {
				Method method = bean.getClass().getMethod(methodName, returnType);
				String param = req.getParameter(paramName);
				Object obj = null;

				// プリミティブの場合
				if (returnType.isPrimitive()) {

					// 変数を生成
					if (param != null) {
						obj = convReqParamToPrimitiveType(param, returnType);
						// 変数が生成できた場合
						if (obj != null) {
							method.invoke(bean, obj);
						}
					}

				// 配列の場合
				} else if (returnType.isArray()) {

					// 対象が配列を含んでいない場合
					if (index == 0) {
						if (param != null && param.length() > 0) {
							// 配列が基本データビーンを継承している場合
							if (TecBean.class.isAssignableFrom(returnType.getComponentType())) {

								// 配列の長さを拡張
								int nArrayLength = new Integer(req.getParameter(paramName));
								Object objArray = Array.newInstance(returnType.getComponentType(), nArrayLength);

								// インスタンスを生成し、再帰処理
								for (int j = 1; j <= nArrayLength; j++) {
									Array.set(objArray, j - 1, returnType.getComponentType().newInstance());
									setRequest(req, (TecBean) Array.get(objArray, j - 1), Array.get(objArray, j - 1).getClass(), j);
								}
								method.invoke(bean, objArray);

							// 基本データビーンを継承していない場合はエラー処理
							} else {
								throw new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
							}

						}

					// 対象が配列を含んでいる場合はエラー処理
					} else {
						throw new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
					}

				// プリミティブ、配列以外のオブジェクト
				} else {
					Constructor<?> constructor = null;

					// 基本データビーンを継承している場合
					if(TecBean.class.isAssignableFrom(returnType)){
						constructor = returnType.getConstructor();
						obj = constructor.newInstance();
						// 再帰処理
						setRequest(req, (TecBean) obj, obj.getClass());
						method.invoke(bean, obj);

					// 基本データビーンを継承していない場合
					} else {
						if (param != null) {
							if (param.length() > 0 || returnType == String.class || returnType == Boolean.class) {
								if (returnType == Character.class) {
									constructor = returnType.getConstructor(Character.TYPE);
									obj = constructor.newInstance(param.charAt(0));
								} else {
									constructor = returnType.getConstructor(String.class);
									obj = constructor.newInstance(param);
								}
							}
							method.invoke(bean, obj);
						}
					}
				}

			// メソッドが存在しない場合は無視
			} catch (NoSuchMethodException e) {

			// その他例外はエラー処理
			} catch (InstantiationException e) {
				TecLogger.error(e.getMessage(), cls.getName());
				throw new TecSystemException(TecMessageKey.SYS_E_FAILED_REQUEST_MAPPING, e);
			} catch (IllegalAccessException e) {
				TecLogger.error(e.getMessage(), cls.getName());
				throw new TecSystemException(TecMessageKey.SYS_E_FAILED_REQUEST_MAPPING, e);
			} catch (InvocationTargetException e) {
				TecLogger.error(e.getMessage(), cls.getName());
				throw new TecSystemException(TecMessageKey.SYS_E_FAILED_REQUEST_MAPPING, e);
			} catch (TecUnsupportedDataTypeException e) {
				TecLogger.error(e.getMessage(), fieldName);
				throw new TecSystemException(TecMessageKey.SYS_E_FAILED_REQUEST_MAPPING, e);
			}
		}
	}

	// リクエストの値を指定のプリミティブ型に変換
	private static Object convReqParamToPrimitiveType(
			String reqParam, Class<?> fieldType) throws TecUnsupportedDataTypeException {
		Object obj = null;
		// 変換対象外の型の場合は例外生成
		if(
				!(fieldType == Byte.TYPE || fieldType == Character.TYPE ||
				fieldType == Double.TYPE || fieldType == Float.TYPE ||
				fieldType == Integer.TYPE || fieldType == Long.TYPE || fieldType == Short.TYPE ||
				fieldType == Boolean.TYPE)){
			throw new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
		}

		if (fieldType == Boolean.TYPE) {
			obj = Boolean.valueOf(reqParam);
		} else if (reqParam.length() > 0) {
			if (fieldType == Byte.TYPE) {
				obj = new Byte(reqParam);
			} else if (fieldType == Character.TYPE) {
				obj = Character.valueOf(reqParam.charAt(0));
			} else if (fieldType == Double.TYPE) {
				obj = new Double(reqParam);
			} else if (fieldType == Float.TYPE) {
				obj = new Float(reqParam);
			} else if (fieldType == Integer.TYPE) {
				obj = new Integer(reqParam);
			} else if (fieldType == Long.TYPE) {
				obj = new Long(reqParam);
			} else if (fieldType == Short.TYPE) {
				obj = new Short(reqParam);
			}
		}
		return obj;
	}
}
