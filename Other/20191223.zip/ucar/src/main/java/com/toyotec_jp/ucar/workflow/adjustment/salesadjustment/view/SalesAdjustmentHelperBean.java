package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.view;

import java.util.ArrayList;
import java.util.HashMap;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;

import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentSessionBean;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst.AdjustmentServiceId;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst.AdjustmentTitle;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarAjaxServiceId;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarServiceId;

/**
 * <strong>売上精算ヘルパービーン。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SalesAdjustmentHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 8584928315609391060L;

	/** 精算セッションBean */
	private AdjustmentSessionBean sessionBean;

	private AdjustmentServiceId targetServiceId;

	/** 売上精算 画面出力値Bean */
	private SalesAdjustmentDataBean salesAdjustmentDataBean = new SalesAdjustmentDataBean();
	/** 確認メッセージ表示 */
	private boolean confirmMessage;

	/** サービスID設定 */
	private String serviceUrlInit;
	private String serviceUrlSearch;
	private String serviceUrlReloadSearch;
	private String serviceUrlConfirm;
	private String serviceUrlAdjustment;
	private String serviceUrlAdjustmentCancel;
	private String serviceUrlReissue;
	private String	serviceUrlAjax;

	/** 受注№(検索条件) */
	private String searchNoJucyu = "";
	/** 再発行ボタン使用可否フラグ */
	private boolean disabledBtnReissue;

	/** ダウンロードファイルパス */
	private ArrayList<String> arrayDownloadFilePath;
	/** 請求明細書を印刷チェックボックスchecked値 */
	private String chkPrintSeikyuChecked;

	/** デフォルトコンストラクタ */
	public SalesAdjustmentHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.base.view.TlsHelperBean#init()
	 */
	@Override
	public void init() throws HelperBeanException {

		// セッションの取得
		sessionBean = getApplicationSessionBean(AdjustmentSessionBean.class);

		String serviceId = sessionBean.getServiceId();
		targetServiceId = AdjustmentServiceId.getTargetAdjustmentServiceId(serviceId);

		// サービス呼び出し用URL設定
		setServiceUrl();

		// サービスごとの処理
		if(targetServiceId != null){
			switch (targetServiceId) {
				case SALESADJUSTMENT_SEARCH:
				case SALESADJUSTMENT_EXECUTEAFTER_SEARCH:
					salesAdjustmentDataBean = sessionBean.getSalesAdjustmentDataBean();
					confirmMessage 			= sessionBean.isConfirmMessage();
					disabledBtnReissue 		= sessionBean.isDisabledBtnReissue();
					setChkPrintSeikyuChecked();
					break;
				case SALESADJUSTMENT_CONFIRM:
					salesAdjustmentDataBean = sessionBean.getSalesAdjustmentDataBean();
					disabledBtnReissue 		= sessionBean.isDisabledBtnReissue();
					setChkPrintSeikyuChecked();
					break;
				case SALESADJUSTMENT_RELOAD_SEARCH:
					searchNoJucyu = sessionBean.getNoJucyu();
					setChkPrintSeikyuChecked();
					break;
				default:
					break;
			}
			arrayDownloadFilePath = sessionBean.getArrayDownloadFilePath();
			// セッションのダウンロードファイルパスはクリア
			sessionBean.setArrayDownloadFilePath(null);
		}
	}

	/**
	 * 請求明細書を印刷 初期チェック状態設定
	 */
	private void setChkPrintSeikyuChecked() {
		if (!"13601".equals(salesAdjustmentDataBean.getCdHanbaitn())) {
			chkPrintSeikyuChecked = AdjustmentConst.PRINT_EXECUTE;
		}
	}

	/** サービス呼び出し用URL設定 */
	private void setServiceUrl() throws HelperBeanException {
		serviceUrlInit 				= getServiceUrl(AdjustmentServiceId.SALESADJUSTMENT_INIT);
		serviceUrlSearch			= getServiceUrl(AdjustmentServiceId.SALESADJUSTMENT_SEARCH);
		serviceUrlReloadSearch 		= getServiceUrl(AdjustmentServiceId.SALESADJUSTMENT_RELOAD_SEARCH);
		serviceUrlConfirm			= getServiceUrl(AdjustmentServiceId.SALESADJUSTMENT_CONFIRM);
		serviceUrlAdjustment		= getServiceUrl(AdjustmentServiceId.SALESADJUSTMENT_ADJUSTMENT);
		serviceUrlAdjustmentCancel	= getServiceUrl(AdjustmentServiceId.SALESADJUSTMENT_ADJUSTMENT_CANCEL);
		serviceUrlReissue			= getServiceUrl(AdjustmentServiceId.SALESADJUSTMENT_REISSUE);

		serviceUrlAjax				= getServiceUrl(UcarServiceId.COMMON_PARTS_AJAX);
	}

	/**
	 * targetServiceIdを取得する。
	 * @return targetServiceId
	 */
	public AdjustmentServiceId getTargetServiceId() {
		return targetServiceId;
	}

	/**
	 * @return
	 */
	public AdjustmentServiceId getServiceIdSalesAdjustmentInit() {
		return AdjustmentServiceId.SALESADJUSTMENT_INIT;
	}

	/**
	 * @return
	 */
	public AdjustmentServiceId getServiceIdSalesAdjustmentExecuteAfterInit() {
		return AdjustmentServiceId.SALESADJUSTMENT_EXECUTEAFTER_INIT;
	}

	/**
	 * @return
	 */
	public AdjustmentServiceId getServiceIdSalesAdjustmentReloadSearch() {
		return AdjustmentServiceId.SALESADJUSTMENT_RELOAD_SEARCH;
	}

	/** 画面タイトル取得 */
	public String getTitleLabel(){
		return AdjustmentTitle.SALESADJUSTMENT.getTitleLabel();
	}

	/**
	 * サービスID設定を取得します。
	 * @return サービスID設定
	 */
	public String getServiceUrlInit() {
	    return serviceUrlInit;
	}

	/**
	 * serviceUrlSearchを取得する。
	 * @return serviceUrlSearch
	 */
	public String getServiceUrlSearch() {
		return serviceUrlSearch;
	}

	/**
	 * serviceUrlReloadSearchを取得する。
	 * @return serviceUrlReloadSearch
	 */
	public String getServiceUrlReloadSearch() {
		return serviceUrlReloadSearch;
	}

	/**
	 * serviceUrlConfirmを取得する。
	 * @return serviceUrlConfirm
	 */
	public String getServiceUrlConfirm() {
		return serviceUrlConfirm;
	}

	/**
	 * serviceUrlAdjustmentを取得する。
	 * @return serviceUrlAdjustment
	 */
	public String getServiceUrlAdjustment() {
		return serviceUrlAdjustment;
	}

	/**
	 * serviceUrlAdjustmentCancelを取得する。
	 * @return serviceUrlAdjustmentCancel
	 */
	public String getServiceUrlAdjustmentCancel() {
		return serviceUrlAdjustmentCancel;
	}

	/**
	 * serviceUrlReissueを取得する。
	 * @return serviceUrlReissue
	 */
	public String getServiceUrlReissue() {
		return serviceUrlReissue;
	}

	/**
	 * serviceUrlAjaxを取得する。
	 * @return serviceUrlAjax
	 */
	public String getServiceUrlAjax() {
		return serviceUrlAjax;
	}

	/**
	 * 共通関連AjaxサービスID
	 * UcarAjaxServiceId.GET_WORKER_DATAを取得する。
	 * @return UcarAjaxServiceId.GET_WORKER_DATA
	 */
	public String getWorkerData() {
		return UcarAjaxServiceId.GET_WORKER_DATA.toString();
	}

	/**
	 * sessionBeanを取得する。
	 * @return sessionBean
	 */
	public AdjustmentSessionBean getSessionBean() {
		return sessionBean;
	}

	/**
	 * 得意先値引適用コンボボックスの値を取得する。
	 * @return
	 */
	public ArrayList<HashMap<String, String>> getKbNebikiSelectList() {
		return UcarUtils.getKbNebikiSelectList();
	}

	/**
	 * 得意先値引適用コンボボックスの初期値を取得する。
	 * @param selected
	 * @return
	 */
	public ArrayList<String> getKbNebikiSelected(String selected) {
		return UcarUtils.getKbNebikiSelected(selected);
	}

	/**
	 * salesAdjustmentDataBeanを取得する。
	 * @return salesAdjustmentDataBean
	 */
	public SalesAdjustmentDataBean getSalesAdjustmentDataBean() {
		return salesAdjustmentDataBean;
	}

	/**
	 * confirmMessageを取得する。
	 * @return confirmMessage
	 */
	public boolean isConfirmMessage() {
		return confirmMessage;
	}

	/**
	 * searchNoJucyuを取得する。
	 * @return searchNoJucyu
	 */
	public String getSearchNoJucyu() {
		return searchNoJucyu;
	}

	/**
	 * disabledBtnReissueを取得する。
	 * @return disabledBtnReissue
	 */
	public boolean isDisabledBtnReissue() {
		return disabledBtnReissue;
	}

	/**
	 * arrayDownloadFilePathを取得する。
	 * @return arrayDownloadFilePath
	 */
	public ArrayList<String> getArrayDownloadFilePath() {
		return arrayDownloadFilePath;
	}

	/**
	 * chkPrintSeikyuCheckvaluesを取得する。
	 * @return chkPrintSeikyuCheckvalues 請求明細書を印刷チェックボックスValue値
	 */
	public String getChkPrintSeikyuCheckvalues() {
		return AdjustmentConst.PRINT_EXECUTE + "|請求明細書を印刷";
	}

	/**
	 * chkPrintSeikyuCheckedを取得する。
	 * @return chkPrintSeikyuChecked
	 */
	public String getChkPrintSeikyuChecked() {
		return chkPrintSeikyuChecked;
	}

}
