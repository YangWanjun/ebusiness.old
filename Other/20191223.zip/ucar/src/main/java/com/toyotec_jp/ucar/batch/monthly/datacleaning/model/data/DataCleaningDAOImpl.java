package com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;

/**
 * <strong>データ削除DAOの実装</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/07 新規作成<br>
 * @since 1.00
 * @category [[バッチ：データ削除]]
 */
public class DataCleaningDAOImpl extends UcarSharedDBDAO implements DataCleaningDAOIF {

	/** 削除処理（車両搬入情報）SQL */
	private static final String DELETE_T220001G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220001G ";

	/** 削除処理（仕入種別情報）SQL */
	private static final String DELETE_T220002G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220002G ";

	/** 削除処理（チェック内容情報）SQL */
	private static final String DELETE_T220003G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220003G ";

	/** 削除処理（書類チェックDB）SQL */
	private static final String DELETE_T220007G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220007G ";

	/** 削除処理（入庫検査チェックDB）SQL */
	private static final String DELETE_T220008G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220008G ";

	/** 削除処理（仕分作業DB）SQL */
	private static final String DELETE_T220009G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220009G ";

	/** 削除処理（完成検査DB）SQL */
	private static final String DELETE_T220010G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220010G ";

	/** 削除処理（ステータスDB）SQL */
	private static final String DELETE_T220012G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220012G ";

	/** 削除処理（車両搬出情報）SQL */
	private static final String DELETE_T220013G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220013G ";

	/** 削除処理 WHERE部分 SQL */
	private static final String DELETE_WHERE_SUB_QUERY_SQL
		= "WHERE "
		+ "  (CD_KAISYA, CD_HANBAITN, DD_HANNYU, NO_KANRI) IN ( "
		+ "    SELECT "
		+ "        HANSYUTU.CD_KAISYA "
		+ "      , HANSYUTU.CD_HANBAITN "
		+ "      , HANSYUTU.DD_HANNYU "
		+ "      , HANSYUTU.NO_KANRI "
		+ "    FROM "
		+ "      T220013G HANSYUTU "
		+ "    WHERE "
		+ "          HANSYUTU.CD_KAISYA   = ? "
		+ "      AND HANSYUTU.CD_HANBAITN = ? "
		+ "      AND HANSYUTU.DD_HANSYT  <= ? "
		+ "  ) ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220001G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220001G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220001G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220002G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220002G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220002G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220003G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220003G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220003G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220007G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220007G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220007G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220008G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220008G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220008G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220009G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220009G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220009G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220010G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220010G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220010G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220012G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220012G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220012G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220013G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220013G(String cdKaisya,
			String cdHanbaitn, String ddHansyt) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220013G_SQL);
		targetSql.append(DELETE_WHERE_SUB_QUERY_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHansyt);		// 搬出日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

}
