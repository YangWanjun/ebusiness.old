package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentRuisekiDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb004gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb005gBean;
import com.toyotec_jp.ucar.workflow.receipt.common.ReceiptConst;

/**
 * <strong>売上精算DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SalesAdjustmentDAOImpl extends UcarSharedDBDAO implements SalesAdjustmentDAOIF {

	/** 売上精算 画面出力値取得処理（受注情報）SQL  */
	private static final String SELECT_T220211G_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , KB_CANCEL "
		+ "  , CD_HANBAITN "
		+ "  , MJ_SYAMEI "
		+ "  , NO_SYADAI "
		+ "  , MJ_CUSTOMER "
		+ "  , KB_NEBIKI "
		+ "  , NO_IRDENPYO "
		+ "  , KB_GOYOMEI "
		+ "  , DD_SEISAN "
		+ "  , SU_TAXRITU "  // 2013/08/28 要望対応
		+ "FROM "
		+ "  T220211G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? ";

	private static final String SELECT_T220213G_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , NO_DENPYO "
		+ "  , NO_DENEDA "
		+ "FROM "
		+ "  T220213G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? "
		+ "  AND KB_JISYA    = '0' "
		+ "  AND DD_SIIRE    IS NULL ";

	private static final String SELECT_T220212G_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , NO_SAGYO "
		+ "  , NO_BUHIN "
		+ "FROM "
		+ "  T220212G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? "
		+ "  AND KB_URIKAMO  is null ";

	private static final String SELECT_T220214G_SQL
		= "SELECT "
		+ "    URIAGE_SEISAN.CD_KAISYA "
		+ "  , URIAGE_SEISAN.CD_JIGYOSYO "
		+ "  , URIAGE_SEISAN.NO_JUCYU "
		+ "  , URIAGE_SEISAN.CD_HANBAITN "
		+ "  , URIAGE_SEISAN.MJ_CUSTOMER "
		+ "  , URIAGE_SEISAN.CD_URITAN "
		+ "  , URIAGE_SEISAN.KI_SEIKYU "
		+ "  , URIAGE_SEISAN.KI_TAX "
		+ "  , URIAGE_SEISAN.KI_TNEBIKI "
		+ "  , URIAGE_SEISAN.KI_NEBIKI "
		+ "  , URIAGE_SEISAN.KI_GENKA "
		+ "  , URIAGE_SEISAN.KI_URIAGE "
		+ "  , URIAGE_SEISAN.KI_SYANAI "
		+ "  , URIAGE_SEISAN.MJ_MESSAGE "
		+ "  , URIAGE_SEISAN.KI_GENKOU "
		+ "  , URIAGE_SEISAN.KI_GENBUHIN "
		+ "  , URIAGE_SEISAN.KI_GENYUSI "
		+ "  , URIAGE_SEISAN.KI_GENGAI "
		+ "  , URIAGE_SEISAN.KI_URIKOU "
		+ "  , URIAGE_SEISAN.KI_URIBUHIN "
		+ "  , URIAGE_SEISAN.KI_URIYUSI "
		+ "  , URIAGE_SEISAN.KI_URIGAI "
		+ "  , URIAGE_SEISAN.KI_SYAFKOU "
		+ "  , URIAGE_SEISAN.KI_SYAFBUHIN "
		+ "  , URIAGE_SEISAN.KI_SYAFYUSI "
		+ "  , URIAGE_SEISAN.KI_SYAFGAI "
		+ "  , JYUTYU.NO_JUCYU "
		+ "  , JYUTYU.MJ_SYAMEI "
		+ "  , JYUTYU.NO_SYADAI "
		+ "  , JYUTYU.KB_NEBIKI "
		+ "  , JYUTYU.NO_IRDENPYO "
		+ "  , JYUTYU.KB_GOYOMEI "
		+ "  , JYUTYU.DD_SEISAN "
		+ "FROM "
		+ "  T220214G URIAGE_SEISAN "
		+ "  LEFT JOIN T220211G JYUTYU "
		+ "    ON URIAGE_SEISAN.CD_KAISYA = JYUTYU.CD_KAISYA "
		+ "    AND URIAGE_SEISAN.CD_JIGYOSYO = JYUTYU.CD_JIGYOSYO "
		+ "    AND URIAGE_SEISAN.NO_JUCYU = JYUTYU.NO_JUCYU "
		+ "WHERE "
		+ "      URIAGE_SEISAN.CD_KAISYA   = ? "
		+ "  AND URIAGE_SEISAN.CD_JIGYOSYO = ? "
		+ "  AND URIAGE_SEISAN.NO_JUCYU    = ? "
		+ "  AND URIAGE_SEISAN.NO_RENBAN   = ( "
		+ "    SELECT "
		+ "        MAX(NO_RENBAN) "
		+ "    FROM "
		+ "      T220214G "
		+ "    WHERE "
		+ "          CD_KAISYA   = URIAGE_SEISAN.CD_KAISYA "
		+ "      AND CD_JIGYOSYO = URIAGE_SEISAN.CD_JIGYOSYO "
		+ "      AND NO_JUCYU    = URIAGE_SEISAN.NO_JUCYU "
		+ "  ) ";

	private static final String SELECT_T220212G_SUM_KI_GENKA_BAIKA_SQL
		= "SELECT "
		+ "    SUM(KI_BAIKA) KI_BAIKA "
		+ "  , SUM(KI_GENKA) KI_GENKA "
		+ "FROM "
		+ "  T220212G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? ";

	private static final String SELECT_T220213G_NO_DENPYO_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , NO_DENPYO "
		+ "FROM "
		+ "  T220213G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? "
		+ 	"AND KB_JISYA    = ? "
		+ "GROUP BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , NO_DENPYO ";

	private static final String SELECT_T220213G_KINGAKU_SQL
		= "SELECT "
		+ "    GAICHU.KI_SIIRE "
		+ "  , GAICHU.KI_TAX "
		+ "FROM "
		+ "  T220213G GAICHU "
		+ "WHERE "
		+ "      GAICHU.CD_KAISYA   = ? "
		+ "  AND GAICHU.CD_JIGYOSYO = ? "
		+ "  AND GAICHU.NO_JUCYU    = ? "
		+ "  AND GAICHU.NO_DENPYO   = ? "
		+ "  AND GAICHU.KB_CANCEL IS NULL "
		+ "  AND GAICHU.NO_DENEDA = ( "
		+ "    SELECT "
		+ "        MAX(NO_DENEDA) "
		+ "    FROM "
		+ "      T220213G "
		+ "    WHERE "
		+ "          CD_KAISYA   = GAICHU.CD_KAISYA "
		+ "      AND CD_JIGYOSYO = GAICHU.CD_JIGYOSYO "
		+ "      AND NO_JUCYU    = GAICHU.NO_JUCYU "
		+ "      AND NO_DENPYO 　= GAICHU.NO_DENPYO "
		+ "  ) ";

	private static final String SELECT_T220212G_SUM_KI_TAX_SQL
		= "SELECT "
		+ "    SUM(KI_TAX) KI_TAX "
		+ ",   SUM(KI_BAIKA) KI_BAIKA "  // 2013/08/28 要望対応
		+ "FROM "
		+ "  T220212G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? "
		+ "  AND KB_SYANAI   IS NULL ";

	/** 更新処理（受注明細情報）売上科目区分更新 SQL */
	private static final String UPDATE_T220212G_KB_URIKAMO_SQL
		= "UPDATE T220212G "
		+ "SET "
		+ "    KB_URIKAMO = ? "
		+ "  , DT_KOSIN   = ? "
		+ "  , CD_KSNSYA  = ? "
		+ "  , CD_KSNAPP  = ? "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? "
		+ "  AND KB_URIKAMO  IS NULL ";

	/** 新規登録処理（売上精算情報） SQL */
	private static final String INSERT_T220214G_SQL
		= "INSERT "
		+ "INTO T220214G( "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , NO_RENBAN "
		+ "  , KB_CANCEL "
		+ "  , CD_HANBAITN "
		+ "  , MJ_CUSTOMER "
		+ "  , DD_URIAGE "
		+ "  , CD_URITAN "
		+ "  , KI_SEIKYU "
		+ "  , KI_TAX "
		+ "  , KI_TNEBIKI "
		+ "  , KI_NEBIKI "
		+ "  , KI_GENKA "
		+ "  , KI_URIAGE "
		+ "  , KI_SYANAI "
		+ "  , MJ_MESSAGE "
		+ "  , KB_URIKAKE "
		+ "  , KI_GENKOU "
		+ "  , KI_GENBUHIN "
		+ "  , KI_GENYUSI "
		+ "  , KI_GENGAI "
		+ "  , KI_URIKOU "
		+ "  , KI_URIBUHIN "
		+ "  , KI_URIYUSI "
		+ "  , KI_URIGAI "
		+ "  , KI_SYAFKOU "
		+ "  , KI_SYAFBUHIN "
		+ "  , KI_SYAFYUSI "
		+ "  , KI_SYAFGAI "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ ") "
		+ "VALUES ( "
		+ "  ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ ") ";

	/** 売上精算情報 連番 最大値取得 */
	private static final String SELECT_T220214G_MAX_NO_RENBAN_SQL
		= "SELECT "
		+ "    MAX(NO_RENBAN) NO_RENBAN "
		+ "FROM "
		+ "  T220214G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? ";

	/** コード区分マスタ 売掛金管理区分取得 */
	private static final String SELECT_UCBA004G_KB_URIKAKE_SQL
		= "SELECT "
		+ "    MJ_INFO3 "
		+ "FROM "
		+ "  T220204M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND KB_ID       = ? "
		+ "  AND MJ_INFO2    = ? ";

	/** 売上精算情報 件数取得 */
	private static final String SELECT_T220214G_COUNT_SQL
		= "SELECT "
		+ "    * "
		+ "FROM "
		+ "  T220214G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? "
		+ "ORDER BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , NO_RENBAN ";

	/** コード区分マスタ 仕訳区分取得 */
	private static final String SELECT_T220204M_CD_KUBUN_SQL
		= "SELECT "
		+ "    CD_KUBUN "
		+ "FROM "
		+ "  T220204M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND KB_ID       = '22' "
		+ "  AND MJ_INFO1 IS NULL "
		+ "ORDER BY "
		+ "  CD_KUBUN ";

	/** 新規登録処理（売上集計累積情報） SQL */
	private static final String INSERT_T220215G_SQL
		= "INSERT "
		+ "INTO T220215G( "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "  , NO_RENBAN "
		+ "  , KB_SIWAKE "
		+ "  , KB_CANCEL "
		+ "  , CD_HANBAITN "
		+ "  , CD_FRBUMON "
		+ "  , DD_URIAGE "
		+ "  , KI_GENKOU "
		+ "  , KI_GENBUHIN "
		+ "  , KI_GENYUSI "
		+ "  , KI_GENGAI "
		+ "  , KI_BAIKOU "
		+ "  , KI_BAIBUHIN "
		+ "  , KI_BAIYUSI "
		+ "  , KI_BAIGAI "
		+ "  , KI_TAX "
		+ "  , SU_TAXRITU "
		+ "  , MJ_BIKOU "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ ") "
		+ "VALUES ( "
		+ "  ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ ") ";

	/** 売上精算情報 連番 最大値取得 */
	private static final String SELECT_T220215G_MAX_NO_RENBAN_SQL
		= "SELECT "
		+ "    MAX(NO_RENBAN) NO_RENBAN "
		+ "FROM "
		+ "  T220215G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND NO_JUCYU    = ? ";

	private static final String SELECT_T220215G_CANCEL_SQL
		= "SELECT "
		+ "    URIAGE_RUISEKI.CD_KAISYA "
		+ "  , URIAGE_RUISEKI.CD_JIGYOSYO "
		+ "  , URIAGE_RUISEKI.NO_JUCYU "
		+ "  , URIAGE_RUISEKI.NO_RENBAN "
		+ "  , URIAGE_RUISEKI.KB_SIWAKE "
		+ "  , URIAGE_RUISEKI.KB_CANCEL "
		+ "  , URIAGE_RUISEKI.CD_HANBAITN "
		+ "  , URIAGE_RUISEKI.CD_FRBUMON "
		+ "  , URIAGE_RUISEKI.DD_URIAGE "
		+ "  , URIAGE_RUISEKI.KI_GENKOU "
		+ "  , URIAGE_RUISEKI.KI_GENBUHIN "
		+ "  , URIAGE_RUISEKI.KI_GENYUSI "
		+ "  , URIAGE_RUISEKI.KI_GENGAI "
		+ "  , URIAGE_RUISEKI.KI_BAIKOU "
		+ "  , URIAGE_RUISEKI.KI_BAIBUHIN "
		+ "  , URIAGE_RUISEKI.KI_BAIYUSI "
		+ "  , URIAGE_RUISEKI.KI_BAIGAI "
		+ "  , URIAGE_RUISEKI.KI_TAX "
		+ "  , URIAGE_RUISEKI.SU_TAXRITU "
		+ "  , URIAGE_RUISEKI.MJ_BIKOU "
		+ "FROM "
		+ "  T220215G URIAGE_RUISEKI "
		+ "WHERE "
		+ "      URIAGE_RUISEKI.CD_KAISYA   = ? "
		+ "  AND URIAGE_RUISEKI.CD_JIGYOSYO = ? "
		+ "  AND URIAGE_RUISEKI.NO_JUCYU    = ? "
		+ "  AND URIAGE_RUISEKI.DT_KOSIN    = ( "
		+ "    SELECT "
		+ "        MAX(DT_KOSIN) "
		+ "    FROM "
		+ "      T220215G "
		+ "    WHERE "
		+ "          CD_KAISYA   = URIAGE_RUISEKI.CD_KAISYA "
		+ "      AND CD_JIGYOSYO = URIAGE_RUISEKI.CD_JIGYOSYO "
		+ "      AND NO_JUCYU    = URIAGE_RUISEKI.NO_JUCYU "
		+ "  ) "
		+ "ORDER BY "
		+ "    URIAGE_RUISEKI.CD_KAISYA "
		+ "  , URIAGE_RUISEKI.CD_JIGYOSYO "
		+ "  , URIAGE_RUISEKI.NO_JUCYU "
		+ "  , URIAGE_RUISEKI.NO_RENBAN "
		+ "  , URIAGE_RUISEKI.KB_SIWAKE ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.receipt.workregister.model.data.WorkRegisterDAOIF#selectT220211G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean)
	 */
	@Override
	public SalesAdjustmentDataBean selectT220211G(
			Ucbb001gBean t220211gBean) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder selectSql = new StringBuilder(SELECT_T220211G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220211gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220211gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220211gBean.getNoJucyu());		// 受注NO

		paramBean.setSql(selectSql.toString());

		ResultArrayList<SalesAdjustmentDataBean> resultList
			= executeSimpleSelectQuery(paramBean, SalesAdjustmentDataBean.class);

		SalesAdjustmentDataBean resultBean = null;
		if (resultList.size() > 0) {
			resultBean = resultList.get(0);
		}

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220213G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb003gBean)
	 */
	@Override
	public int selectT220213GCount(Ucbb001gBean t220211gBean) throws TecDAOException {

		int count = 0;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220213G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220211gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220211gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220211gBean.getNoJucyu());		// 受注NO

		// 取得
		count = getRecordCount(paramBean);

		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220212GCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean)
	 */
	@Override
	public int selectT220212GCount(Ucbb001gBean t220211gBean)
			throws TecDAOException {

		int count = 0;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220212G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220211gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220211gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220211gBean.getNoJucyu());		// 受注NO

		// 取得
		count = getRecordCount(paramBean);

		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220213GNoDenpyo(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean)
	 */
	@Override
	public ResultArrayList<Ucbb003gBean> selectT220213GNoDenpyo(
			Ucbb002gBean t220212gBean) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220213G_NO_DENPYO_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220212gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220212gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220212gBean.getNoJucyu());		// 受注NO
		paramBean.setString("0");							// 自社区分

		paramBean.setSql(executeSql.toString());

		ResultArrayList<Ucbb003gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb003gBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220213GKingaku(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean)
	 */
	@Override
	public Ucbb003gBean selectT220213GKingaku(Ucbb003gBean t220213gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220213G_KINGAKU_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220213gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220213gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220213gBean.getNoJucyu());		// 受注NO
		paramBean.setString(t220213gBean.getNoDenpyo());	// 伝票NO

		paramBean.setSql(executeSql.toString());

		ResultArrayList<Ucbb003gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb003gBean.class);

		Ucbb003gBean resultBean = null;
		if (resultList.size() > 0) {
			resultBean = resultList.get(0);
		}

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220212GSumKiGenka(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean)
	 */
	@Override
	public Ucbb002gBean selectT220212GSumKingaku(Ucbb002gBean t220212gBean, boolean addWhereKbSyanai)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220212G_SUM_KI_GENKA_BAIKA_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220212gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220212gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220212gBean.getNoJucyu());		// 受注NO

		if (addWhereKbSyanai) {
			if (ReceiptConst.KB_SYANAI_SYANAI.equals(t220212gBean.getKbSyanai())) {
				executeSql.append("  AND KB_SYANAI = ? ");
				paramBean.setString(ReceiptConst.KB_SYANAI_SYANAI);
			} else {
				executeSql.append("  AND KB_SYANAI   IS NULL ");
			}
		}

		if (ReceiptConst.KB_URIKAMO_KOUTIN.equals(t220212gBean.getKbUrikamo())) {
			executeSql.append("  AND (KB_URIKAMO = ? OR KB_URIKAMO IS NULL) ");
			paramBean.setString(ReceiptConst.KB_URIKAMO_KOUTIN);
		} else if (ReceiptConst.KB_URIKAMO_BUHIN.equals(t220212gBean.getKbUrikamo())) {
			executeSql.append("  AND KB_URIKAMO = ? ");
			paramBean.setString(ReceiptConst.KB_URIKAMO_BUHIN);
		} else if (ReceiptConst.KB_URIKAMO_YUSI.equals(t220212gBean.getKbUrikamo())) {
			executeSql.append("  AND KB_URIKAMO = ? ");
			paramBean.setString(ReceiptConst.KB_URIKAMO_YUSI);
		} else if (ReceiptConst.KB_URIKAMO_GAICHU.equals(t220212gBean.getKbUrikamo())) {
			executeSql.append("  AND KB_URIKAMO = ? ");
			paramBean.setString(ReceiptConst.KB_URIKAMO_GAICHU);
		}

		paramBean.setSql(executeSql.toString());

		ResultArrayList<Ucbb002gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb002gBean.class);

		Ucbb002gBean resultBean = new Ucbb002gBean();
		if (resultList.size() > 0) {
			resultBean = resultList.get(0);
		}

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220212GSumKiTax(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean)
	 */
	@Override
	public Ucbb002gBean selectT220212GSumKiTax(Ucbb001gBean t220211gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220212G_SUM_KI_TAX_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220211gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220211gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220211gBean.getNoJucyu());		// 受注NO

		paramBean.setSql(executeSql.toString());

		ResultArrayList<Ucbb002gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb002gBean.class);

		Ucbb002gBean resultBean = new Ucbb002gBean();
		if (resultList.size() > 0) {
			resultBean = resultList.get(0);
		}

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220214G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean)
	 */
	@Override
	public SalesAdjustmentDataBean selectT220214G(
			Ucbb001gBean t220211gBean) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder selectSql = new StringBuilder(SELECT_T220214G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220211gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220211gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220211gBean.getNoJucyu());		// 受注NO

		paramBean.setSql(selectSql.toString());

		ResultArrayList<SalesAdjustmentDataBean> resultList
			= executeSimpleSelectQuery(paramBean, SalesAdjustmentDataBean.class);

		SalesAdjustmentDataBean resultBean = null;
		if (resultList.size() > 0) {
			resultBean = resultList.get(0);
		}

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#updateT220212GKbUrikamo(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean)
	 */
	@Override
	public SimpleExecuteResultBean updateT220212GKbUrikamo(
			Ucbb002gBean t220212gBean) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220212G_KB_URIKAMO_SQL);

		// パラメータセット<値>
		paramBean.setString(t220212gBean.getKbUrikamo());	// 売上科目区分
		paramBean.setTimestamp(new Timestamp(t220212gBean.getDtKosin().getTime()));	// データ更新日時
		paramBean.setString(t220212gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220212gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220212gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220212gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220212gBean.getNoJucyu());		// 受注NO

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#insertT220214g(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb004gBean)
	 */
	@Override
	public SimpleExecuteResultBean insertT220214g(Ucbb004gBean t220214gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220214G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220214gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220214gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220214gBean.getNoJucyu());		// 受注NO
		paramBean.setString(t220214gBean.getNoRenban());	// 連番
		paramBean.setString(t220214gBean.getKbCancel());	// キャンセル区分

		paramBean.setString(t220214gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220214gBean.getMjCustomer());	// 請求先お客様名
		paramBean.setDate(t220214gBean.getDdUriage());		// 売上日
		paramBean.setString(t220214gBean.getCdUritan());	// 売上担当者

		paramBean.setInt(t220214gBean.getKiSeikyu());		// 請求金額
		paramBean.setInt(t220214gBean.getKiTax());			// 消費税
		paramBean.setInt(t220214gBean.getKiTnebiki());		// 得意先値引き
		paramBean.setInt(t220214gBean.getKiNebiki());		// 値引き
		paramBean.setInt(t220214gBean.getKiGenka());		// 原価額
		paramBean.setInt(t220214gBean.getKiUriage());		// 売上額
		paramBean.setInt(t220214gBean.getKiSyanai());		// 社内振替

		paramBean.setString(t220214gBean.getMjMessage());	// メッセージ
		paramBean.setString(t220214gBean.getKbUrikake());	// 売掛金管理区分

		paramBean.setInt(t220214gBean.getKiGenkou());		// 工賃　原価
		paramBean.setInt(t220214gBean.getKiGenbuhin());		// 部品　原価
		paramBean.setInt(t220214gBean.getKiGenyusi());		// 油脂　原価
		paramBean.setInt(t220214gBean.getKiGengai());		// 外注　原価
		paramBean.setInt(t220214gBean.getKiUrikou());		// 工賃　売上
		paramBean.setInt(t220214gBean.getKiUribuhin());		// 部品　売上
		paramBean.setInt(t220214gBean.getKiUriyusi());		// 油脂　売上
		paramBean.setInt(t220214gBean.getKiUrigai());		// 外注　売上
		paramBean.setInt(t220214gBean.getKiSyafkou());		// 工賃　社内振替
		paramBean.setInt(t220214gBean.getKiSyafbuhin());	// 部品　社内振替
		paramBean.setInt(t220214gBean.getKiSyafyusi());		// 油脂　社内振替
		paramBean.setInt(t220214gBean.getKiSyafgai());		// 外注　社内振替

		paramBean.setTimestamp(new Timestamp(t220214gBean.getDtSakusei().getTime()));	// データ作成日時
		paramBean.setTimestamp(new Timestamp(t220214gBean.getDtKosin().getTime()));		// データ更新日時

		paramBean.setString(t220214gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220214gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220214gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220214gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220214GMaxNoRenban(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb004gBean)
	 */
	@Override
	public String selectT220214GMaxNoRenban(Ucbb004gBean t220214gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220214G_MAX_NO_RENBAN_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220214gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220214gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220214gBean.getNoJucyu());		// 受注NO

		ResultArrayList<Ucbb004gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb004gBean.class);

		String maxNoRenban = null;

		if (resultList.size() > 0) {
			maxNoRenban = resultList.get(0).getNoRenban();
		}

		return maxNoRenban;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectUcba004GKbUrikake(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean)
	 */
	@Override
	public String selectUcba004GKbUrikake(Ucba004mBean ucba004gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_UCBA004G_KB_URIKAKE_SQL);

		// パラメータセット<条件>
		paramBean.setString(ucba004gBean.getCdKaisya());	// 会社コード
		paramBean.setString(ucba004gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(ucba004gBean.getKbId());		// 区分ID
		paramBean.setString(ucba004gBean.getMjInfo2());		// 情報2

		ResultArrayList<Ucba004mBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucba004mBean.class);

		String KbUrikake = null;

		if (resultList.size() > 0) {
			KbUrikake = resultList.get(0).getMjInfo3();
		}

		return KbUrikake;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#updateT220211GDdSeisan(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean)
	 */
	@Override
	public SimpleExecuteResultBean updateT220211GDdSeisan(
			Ucbb001gBean t220211gBean) throws TecDAOException {

		String updateT220211gDdSeisanSql
			= "UPDATE T220211G "
			+ "SET ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(updateT220211gDdSeisanSql);

		// パラメータセット<値>
		if (t220211gBean.getDdSeisan() != null) {
			executeSql.append("    DD_SEISAN = ? ");
			paramBean.setDate(t220211gBean.getDdSeisan());		// 精算日
			executeSql.append("  , KB_NEBIKI = ? ");
			paramBean.setString(t220211gBean.getKbNebiki());	// 得意先値引き適用区分
			executeSql.append("  , NO_IRDENPYO = ? ");
			paramBean.setString(t220211gBean.getNoIrdenpyo());	// 依頼伝票NO
			// 2013/08/28 要望対応 start
			executeSql.append("  , KB_GOYOMEI = ? ");
			paramBean.setString(t220211gBean.getKbGoyomei());	// ご用命区分
			// 2013/08/28 要望対応 end
		} else {
			executeSql.append("    DD_SEISAN = NULL ");
		}

		String updateT220211gDdSeisanWhereSql
			= "  , DT_KOSIN  = ? "
			+ "  , CD_KSNSYA = ? "
			+ "  , CD_KSNAPP = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_JIGYOSYO = ? "
			+ "  AND NO_JUCYU    = ? ";
		executeSql.append(updateT220211gDdSeisanWhereSql);

		paramBean.setTimestamp(new Timestamp(t220211gBean.getDtKosin().getTime()));	// データ更新日時
		paramBean.setString(t220211gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220211gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220211gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220211gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220211gBean.getNoJucyu());		// 受注NO

		paramBean.setSql(executeSql.toString());

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220214GCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean)
	 */
	@Override
	public int selectT220214GCount(Ucbb001gBean t220211gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220214G_COUNT_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220211gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220211gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220211gBean.getNoJucyu());		// 受注NO

		int count = getRecordCount(paramBean);

		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220212GSumKiBaika(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean)
	 */
	@Override
	public ResultArrayList<SalesAdjustmentRuisekiDataBean> selectT220212GSumKiBaika(Ucbb002gBean t220212gBean,
																					boolean kbSyanaiIsNull) throws TecDAOException {

		// 売上精算情報 仕訳区分/売上科目区分 売価算出取得
		final String SELECT_T220212G_SUM_KI_BAIKA_SQL
			= "SELECT "
			+ "    KB_SIWAKE "
			+ "  , KB_URIKAMO "
			+ "  , KB_SYANAI "
			+ "  , SUM(KI_GENKA) SUM_KI_GENKA "
			+ "  , SUM(KI_BAIKA) SUM_KI_BAIKA "
			+ "  , SUM(KI_TAX) SUM_KI_TAX "
			+ "FROM "
			+ "  T220212G "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_JIGYOSYO = ? "
			+ "  AND NO_JUCYU    = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220212G_SUM_KI_BAIKA_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220212gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220212gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220212gBean.getNoJucyu());		// 受注NO

		if (kbSyanaiIsNull) {
			executeSql.append("  AND KB_SYANAI   IS NULL ");
		}

		final String SELECT_T220212G_SUM_KI_BAIKA_GROUPBY_SQL
			= "GROUP BY "
			+ "    KB_SIWAKE "
			+ "  , KB_URIKAMO "
			+ "  , KB_SYANAI "
			+ "ORDER BY "
			+ "    KB_SIWAKE "
			+ "  , KB_URIKAMO ";

		executeSql.append(SELECT_T220212G_SUM_KI_BAIKA_GROUPBY_SQL);

		paramBean.setSql(executeSql.toString());

		ResultArrayList<SalesAdjustmentRuisekiDataBean> resultList
			= executeSimpleSelectQuery(paramBean, SalesAdjustmentRuisekiDataBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220204M(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean)
	 */
	@Override
	public ResultArrayList<Ucba004mBean> selectT220204MCdKubun(
			Ucbb002gBean t220212gBean) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220204M_CD_KUBUN_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220212gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220212gBean.getCdJigyosyo());	// 事業所コード

		paramBean.setSql(executeSql.toString());

		ResultArrayList<Ucba004mBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucba004mBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#insertT220215g(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb005gBean)
	 */
	@Override
	public SimpleExecuteResultBean insertT220215g(Ucbb005gBean t220215gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220215G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220215gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220215gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220215gBean.getNoJucyu());		// 受注NO
		paramBean.setString(t220215gBean.getNoRenban());	// 連番
		paramBean.setString(t220215gBean.getKbSiwake());	// 仕訳区分
		paramBean.setString(t220215gBean.getKbCancel());	// キャンセル区分

		paramBean.setString(t220215gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220215gBean.getCdFrbumon());	// 振替部門コード
		paramBean.setDate(t220215gBean.getDdUriage());		// 売上日

		paramBean.setInt(t220215gBean.getKiGenkou());		// 工賃　原価
		paramBean.setInt(t220215gBean.getKiGenbuhin());		// 部品　原価
		paramBean.setInt(t220215gBean.getKiGenyusi());		// 油脂　原価
		paramBean.setInt(t220215gBean.getKiGengai());		// 外注　原価

		paramBean.setInt(t220215gBean.getKiBaikou());		// 工賃　売価
		paramBean.setInt(t220215gBean.getKiBaibuhin());		// 部品　売価
		paramBean.setInt(t220215gBean.getKiBaiyusi());		// 油脂　売価
		paramBean.setInt(t220215gBean.getKiBaigai());		// 外注　売価
		paramBean.setInt(t220215gBean.getKiTax());			// 消費税
		paramBean.setInt(t220215gBean.getSuTaxritu());		// 消費税率
		paramBean.setString(t220215gBean.getMjBikou());		// 備考

		paramBean.setTimestamp(new Timestamp(t220215gBean.getDtSakusei().getTime()));	// データ作成日時
		paramBean.setTimestamp(new Timestamp(t220215gBean.getDtKosin().getTime()));		// データ更新日時

		paramBean.setString(t220215gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220215gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220215gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220215gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220215GMaxNoRenban(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb005gBean)
	 */
	@Override
	public String selectT220215GMaxNoRenban(Ucbb005gBean t220215gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220215G_MAX_NO_RENBAN_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220215gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220215gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220215gBean.getNoJucyu());		// 受注NO

		ResultArrayList<Ucbb005gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb005gBean.class);

		String maxNoRenban = null;

		if (resultList.size() > 0) {
			maxNoRenban = resultList.get(0).getNoRenban();
		}

		return maxNoRenban;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220212G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean)
	 */
	@Override
	public ResultArrayList<SalesAdjustmentRuisekiDataBean> selectT220212G(Ucbb002gBean t220212gBean) throws TecDAOException {

		// 売上精算情報 仕訳区分/売上科目区分 売価算出取得
		final String SELECT_T220212G_SUM_KI_BAIKA_SQL
			= "SELECT "
			+ "    KB_SIWAKE "
			+ "  , KB_SYANAI "
			+ "FROM "
			+ "  T220212G "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_JIGYOSYO = ? "
			+ "  AND NO_JUCYU    = ? "
			+ "GROUP BY "
			+ "    KB_SIWAKE "
			+ "  , KB_SYANAI "
			+ "ORDER BY "
			+ "  KB_SIWAKE ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220212G_SUM_KI_BAIKA_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220212gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220212gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220212gBean.getNoJucyu());		// 受注NO

		paramBean.setSql(executeSql.toString());

		ResultArrayList<SalesAdjustmentRuisekiDataBean> resultList
			= executeSimpleSelectQuery(paramBean, SalesAdjustmentRuisekiDataBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF#selectT220215GCancel(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean)
	 */
	@Override
	public ResultArrayList<Ucbb005gBean> selectT220215GCancel(
			Ucbb005gBean t220215gBean) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220215G_CANCEL_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220215gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220215gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220215gBean.getNoJucyu());		// 受注NO

		paramBean.setSql(executeSql.toString());

		ResultArrayList<Ucbb005gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb005gBean.class);

		return resultList;
	}

}