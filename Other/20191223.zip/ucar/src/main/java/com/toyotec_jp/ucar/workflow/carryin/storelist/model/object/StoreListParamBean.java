package com.toyotec_jp.ucar.workflow.carryin.storelist.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>展示店舗受取処理 検索条件Bean</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/24 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class StoreListParamBean extends TecBean {

	/**  */
	private static final long	serialVersionUID	= -3201171772188416794L;

	/** 店舗コード */
	private String cdTenpo;
	/** 検索日付From(搬出日) */
	private String ddHansytFrom;
	/** 検索日付To(搬出日) */
	private String ddHansytTo;
	/** フレームNo. */
	private String noSyadai;
	/** 受取チェック 2012.04.04 A.Yoshinami add */
	private String[] arrayChkUketori;

//	/** 受取済チェックフラグ */
//	private String chkUketori;

	public StoreListParamBean(){
		this.cdTenpo       = "";
		this.ddHansytFrom  = "";
		this.ddHansytTo    = "";
		this.noSyadai      = "";
//		this.chkUketori    = "";
	}

	
	/**
	 * cdTenpoを取得する。
	 * @return cdTenpo 店舗コード
	 */
	public String getCdTenpo() {
		return cdTenpo;
	}

	/**
	 * cdTenpoを設定する。
	 * @param cdTenpo 店舗コード
	 */
	public void setCdTenpo(String cdTenpo) {
		this.cdTenpo = cdTenpo;
	}

	/**
	 * ddHansytFromを取得する。
	 * @return ddHansytFrom 検索日付From
	 */
	public String getDdHansytFrom() {
		return ddHansytFrom;
	}

	/**
	 * ddHansytFromを設定する。
	 * @param ddHansytFrom 検索日付From
	 */
	public void setDdHansytFrom(String ddHansytFrom) {
		this.ddHansytFrom = ddHansytFrom;
	}

	/**
	 * ddHansytToを取得する。
	 * @return ddHansytTo 検索日付To
	 */
	public String getDdHansytTo() {
		return ddHansytTo;
	}

	/**
	 * ddHansytToを設定する。
	 * @param ddHansytTo 検索日付To
	 */
	public void setDdHansytTo(String ddHansytTo) {
		this.ddHansytTo = ddHansytTo;
	}

	/**
	 * noSyadaiを取得する。
	 * @return noSyadai フレームNo.
	 */
	public String getNoSyadai() {
		return noSyadai;
	}

	/**
	 * noSyadaiを設定する。
	 * @param noSyadai フレームNo.
	 */
	public void setNoSyadai(String noSyadai) {
		this.noSyadai = noSyadai;
	}

	/**
	 * arrayChkUketoriを取得する。
	 * @return arrayChkUketori 受取チェック
	 */
	public String[] getArrayChkUketori() {
		return arrayChkUketori;
	}

	/**
	 * arrayChkUketoriを設定する。
	 * @param arrayChkUketori 受取チェック
	 */
	public void setArrayChkUketori(String[] arrayChkUketori) {
		this.arrayChkUketori = arrayChkUketori;
	}

//	/**
//	 * chkUketoriを取得する。
//	 * @return chkUketoriFlg 受取済チェック
//	 */
//	public String getChkUketori() {
//		return chkUketori;
//	}

//	/**
//	 * chkUketoriを設定する。
//	 * @param chkUketori 受取済チェック
//	 */
//	public void setChkUketori(String chkUketori) {
//		this.chkUketori = chkUketori;
//	}

}
