package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean;

/**
 * <strong>配送候補連携DB操作用イベントリスナ(初期表示用)</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/19 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class InitHaisoKouhoRenkeiEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		InitHaisoKouhoRenkeiEvent targetEvent = (InitHaisoKouhoRenkeiEvent) event;

		HaisoKouhoRenkeiDAOIF dao
			= getDAO(UcarDAOKey.HAISO_KOUHO_RENKEI_DAO, event, HaisoKouhoRenkeiDAOIF.class);

		try {
			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
			// 接続確認(アドイン)
			dao.selectTbjla24mCount(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn());

			// 実行日時の生成
			Timestamp executeDate 	= new Timestamp(System.currentTimeMillis());
			String executeUserId 	= targetEvent.getUserInfo().getUserID();

			// U-Car商品化システム側更新処理
			updateUcarData(dao,
							targetEvent,
							executeDate,
							executeUserId,
							targetEvent.getExecuteAppId());

			// 削除処理
			deleteData(dao, targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn());

			// アドイン側にデータ転送
			moveAddinData(dao, targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn(), executeDate, executeUserId,
					targetEvent.getExecuteAppId());
			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

		} catch (TecDAOException e) {
			// 配送候補連携DB(アドイン)に接続できなかった場合は処理なし
//			if (e.getMessage().indexOf(UcarConst.ERROR_NO_CONNECT) != -1) {

//			} else {
//				// それ以外はエラー
//				throw e;
//			}
		}

		return null;
	}

	/**
	 * U-Car商品化システム側更新処理
	 * <pre>
	 * 車両搬出情報・ステータスDBに対して更新処理
	 * </pre>
	 * @param dao
	 * @param targetEvent
	 * @param executeDate
	 * @param executeUserId
	 * @param executeAppId
	 * @throws TecDAOException
	 */
	private void updateUcarData(HaisoKouhoRenkeiDAOIF dao,
								InitHaisoKouhoRenkeiEvent targetEvent,
								Timestamp executeDate,
								String executeUserId,
								String executeAppId) throws TecDAOException {

		// データ取得
		ResultArrayList<Tbjla24mBean> tbjla24mList
			= dao.selectTbjla24m(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn());

		for (Tbjla24mBean tbjla24mBean : tbjla24mList) {
			// 配送候補連携DB(アドイン)の内容を車両搬出情報・ステータスDBに更新する

			Ucac001gBean t220013gBean = new Ucac001gBean(tbjla24mBean.getCdKaisya(),
														tbjla24mBean.getCdHanbaitn(),
														tbjla24mBean.getDdHannyu(),
														tbjla24mBean.getNoKanri(),
														executeUserId,
														executeUserId,
														executeAppId,
														executeAppId);

			// 配送希望日をセット
			t220013gBean.setDdHiskib(tbjla24mBean.getDdHiskib());
			// 配送依頼№をセット
			t220013gBean.setNoHisiri(tbjla24mBean.getNoHisiri());
			// 配送備考をセット
			t220013gBean.setMjHansytbk(tbjla24mBean.getMjBikou());

			// 車両搬出情報更新
			dao.updateT220013g(t220013gBean, executeDate);

			Ucab007gBean t220012gBean = new Ucab007gBean(tbjla24mBean.getCdKaisya(),
														tbjla24mBean.getCdHanbaitn(),
														tbjla24mBean.getDdHannyu(),
														tbjla24mBean.getNoKanri(),
														executeUserId,
														executeUserId,
														executeAppId,
														executeAppId);

			// ステータス20をセット
			t220012gBean.setDtStatus20(tbjla24mBean.getDdHiskib());

			// ステータスDB更新
			dao.updateT220012g(t220012gBean, executeDate);

		}
	}

	/**
	 * データ削除処理
	 * @param dao
	 * @throws TecDAOException
	 */
	private void deleteData(HaisoKouhoRenkeiDAOIF dao,
			String cdKaisya,
			String cdHanbaitn) throws TecDAOException {

		// DELデータ(削除対象データ)の取得
		ResultArrayList<Ucac003wBean> t220015wList = dao.selectT220015w(cdKaisya, cdHanbaitn, UcarConst.CD_NORIKUSI_DEL);

		for (Ucac003wBean t220015wBean : t220015wList) {

			// 配送候補連携BUFFER削除
			dao.deleteT220015w(t220015wBean.getCdKaisya(),
								t220015wBean.getCdHanbaitn(),
								t220015wBean.getDdHannyu(),
								t220015wBean.getNoKanri());

			// 配送候補連携削除
			dao.deleteTbjla24m(t220015wBean.getCdKaisya(),
								t220015wBean.getCdHanbaitn(),
								t220015wBean.getDdHannyu(),
								t220015wBean.getNoKanri());
		}
	}

	/**
	 * アドイン側にデータ転送
	 * @param dao
	 * @throws TecDAOException
	 */
	private void moveAddinData(HaisoKouhoRenkeiDAOIF dao,
							String cdKaisya,
							String cdHanbaitn,
							Timestamp executeDate,
							String executeUserId,
							String executeAppId) throws TecDAOException {

		// 配送候補連携へのコピー対象データ取得
		ResultArrayList<Ucac003wBean> t220015wList = dao.selectT220015w(cdKaisya, cdHanbaitn);

		for (Ucac003wBean t220015wBean : t220015wList) {

			Tbjla24mBean tbjla24mBean = new Tbjla24mBean(t220015wBean);

			tbjla24mBean.setCdSksisya(executeUserId);
			tbjla24mBean.setCdKsnsya(executeUserId);
			tbjla24mBean.setCdSksiapp(executeAppId);
			tbjla24mBean.setCdKsnapp(executeAppId);

			ResultArrayList<Tbjla24mBean> tbjla24mTargetList = dao.selectTbjla24m(tbjla24mBean.getCdKaisya(),
																			tbjla24mBean.getCdHanbaitn(),
																			tbjla24mBean.getDdHannyu(),
																			tbjla24mBean.getNoKanri(),
																			false);

			if (tbjla24mTargetList.size() > 0) {
				dao.updateTbjla24m(tbjla24mBean, executeDate);
			} else {
				dao.insertTbjla24m(tbjla24mBean, executeDate);
			}

			// 移動元の配送候補連携BUFFERデータを削除
			dao.deleteT220015w(t220015wBean.getCdKaisya(),
								t220015wBean.getCdHanbaitn(),
								t220015wBean.getDdHannyu(),
								t220015wBean.getNoKanri());

		}
	}

}
