package com.toyotec_jp.ucar.workflow.carryin.register.model.object;

import java.util.ArrayList;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;

/**
 * <strong>車両搬入セッションBean。</strong>
 * <p>
 * セッションに格納する車両搬入パッケージ共通セッションBean。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[車両搬入(共通)]]
 */
public class ListDummySessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** 戻り先URL */
	private String backUrl;
	
	
	private String downloadFilePath;

	/** ダウンロードファイルパス */
	private ArrayList<String> arrayDownloadFilePath;

	/**
	 * デフォルトコンストラクタ。
	 */
	public ListDummySessionBean() {
		setDefaultParams();
	}

	/**
	 * デフォルトパラメータ設定。
	 */
	public void setDefaultParams(){

	}

	/**
	 * backUrlを取得する。
	 * @return backUrl
	 */
	public String getBackUrl() {
		return backUrl;
	}

	/**
	 * backUrlを設定する。
	 * @param backUrl
	 */
	public void setBackUrl(String backUrl) {
		this.backUrl = backUrl;
	}

	public String getDownloadFilePath() {
		return downloadFilePath;
	}

	public void setDownloadFilePath(String downloadFilePath) {
		this.downloadFilePath = downloadFilePath;
	}

	public ArrayList<String> getArrayDownloadFilePath() {
		return arrayDownloadFilePath;
	}

	public void setArrayDownloadFilePath(ArrayList<String> arrayDownloadFilePath) {
		this.arrayDownloadFilePath = arrayDownloadFilePath;
	}

}
