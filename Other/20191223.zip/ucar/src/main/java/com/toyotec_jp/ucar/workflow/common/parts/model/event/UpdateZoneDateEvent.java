package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.sql.Timestamp;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;


/**
 * <strong>ゾーン日数更新イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/13 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UpdateZoneDateEvent extends UcarEvent {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** ステータスDBBean(新規登録・更新用) */
	private Ucab007gInputDataBean t220012gInputDataBean;
	/** ステータスDB(店舗用)Bean(新規登録・更新用) */
	private Uccb007gInputDataBean t220107gInputDataBean;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;
	/** ステータスDB(店舗用) プライマリーキーBean */
	private Uccb007gPKBean t220107gPkBean;					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
	/** ステータス03比較処理
	 * (true:実行する／false:実行しない) */
	private boolean executeDtStatus03;
	/** ステータス05
	 * (true:実行する／false:実行しない) */
	private boolean executeDtStatus05;
	/** ステータス07
	 * (true:実行する／false:実行しない) */
	private boolean executeDtStatus07;
	/** 更新日時 */
	private Timestamp executeDate;

	public UpdateZoneDateEvent() {
		super();
	}

	/**
	 * t220012gInputDataBeanを取得する。
	 * @return t220012gInputDataBean
	 */
	public Ucab007gInputDataBean getUcab007gInputDataBean() {
		return t220012gInputDataBean;
	}

	/**
	 * t220012gInputDataBeanを設定する。
	 * @param t220012gInputDataBean
	 */
	public void setUcab007gInputDataBean(Ucab007gInputDataBean t220012gInputDataBean) {
		this.t220012gInputDataBean = t220012gInputDataBean;
	}

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * t220107gInputDataBeanを取得する。
	 * @return t220107gInputDataBean
	 */
	public Uccb007gInputDataBean getUccb007gInputDataBean() {
		return t220107gInputDataBean;
	}

	/**
	 * t220107gInputDataBeanを設定する。
	 * @param t220107gInputDataBean
	 */
	public void setUccb007gInputDataBean(Uccb007gInputDataBean t220107gInputDataBean) {
		this.t220107gInputDataBean = t220107gInputDataBean;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * t220107gPkBeanを取得する。
	 * @return t220107gPkBean
	 */
	public Uccb007gPKBean getT220107gPkBean() {
		return t220107gPkBean;
	}

	/**
	 * t220107gPkBeanを設定する。
	 * @param t220107gPkBean
	 */
	public void setT220107gPkBean(Uccb007gPKBean t220107gPkBean) {
		this.t220107gPkBean = t220107gPkBean;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	/**
	 * executeDtStatus03を取得する。
	 * @return executeDtStatus03
	 */
	public boolean isExecuteDtStatus03() {
		return executeDtStatus03;
	}

	/**
	 * executeDtStatus03を設定する。
	 * @param executeDtStatus03
	 */
	public void setExecuteDtStatus03(boolean executeDtStatus03) {
		this.executeDtStatus03 = executeDtStatus03;
	}

	/**
	 * executeDtStatus05を取得する。
	 * @return executeDtStatus05
	 */
	public boolean isExecuteDtStatus05() {
		return executeDtStatus05;
	}

	/**
	 * executeDtStatus05を設定する。
	 * @param executeDtStatus05
	 */
	public void setExecuteDtStatus05(boolean executeDtStatus05) {
		this.executeDtStatus05 = executeDtStatus05;
	}

	/**
	 * executeDtStatus07を取得する。
	 * @return executeDtStatus07
	 */
	public boolean isExecuteDtStatus07() {
		return executeDtStatus07;
	}

	/**
	 * executeDtStatus07を設定する。
	 * @param executeDtStatus07
	 */
	public void setExecuteDtStatus07(boolean executeDtStatus07) {
		this.executeDtStatus07 = executeDtStatus07;
	}

	/**
	 * executeDateを取得する。
	 * @return executeDate
	 */
	public Timestamp getExecuteDate() {
		return executeDate;
	}

	/**
	 * executeDateを設定する。
	 * @param executeDate
	 */
	public void setExecuteDate(Timestamp executeDate) {
		this.executeDate = executeDate;
	}

}
