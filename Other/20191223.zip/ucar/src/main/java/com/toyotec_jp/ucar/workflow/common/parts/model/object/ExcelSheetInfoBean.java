/*
 * 【システム名】リース管理システム
 * 【ファイル名】ExcelSheetInfoBean.java
 * 【  説  明  】
 * 【  作  成  】2010/07/14 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import java.util.ArrayList;
import java.util.HashMap;

import com.toyotec_jp.im_common.system.model.object.TecBean;


/**
 * <strong>Excelシート情報ビーン。</strong>
 * <p>
 * Excelから取得したシート毎の情報を格納する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/14 新規作成<br>
 * @since 1.00
 */
public class ExcelSheetInfoBean extends TecBean {

	private static final long serialVersionUID = 6107473661415508672L;

	private int sheetIdx = 0;

	private String sheetName;

	private Object singleParams;

	private HashMap<String, ArrayList<Object>> listParams = new HashMap<String, ArrayList<Object>>();

	/**
	 * シートインデックスを取得する。
	 * @return sheetIdx
	 */
	public int getSheetIdx() {
		return sheetIdx;
	}

	/**
	 * シートインデックスを設定する。
	 * @param sheetIdx
	 */
	public void setSheetIdx(int sheetIdx) {
		this.sheetIdx = sheetIdx;
	}

	/**
	 * シート名を取得する。
	 * @return sheetName
	 */
	public String getSheetName() {
		return sheetName;
	}

	/**
	 * シート名を設定する。
	 * @param sheetName
	 */
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	/**
	 * 通常GET項目を取得する。<br>
	 * ExcelFormatReadEventのsingleParamBeanClassをインスタンス化し、
	 * 通常GET項目を格納した結果を返却する。
	 * @return singleParams
	 */
	public Object getSingleParams() {
		return singleParams;
	}

	/**
	 * 通常GET項目を設定する。
	 * @param singleParams
	 */
	public void setSingleParams(Object singleParams) {
		this.singleParams = singleParams;
	}

	/**
	 * リストGET項目を取得する。<br>
	 * ExcelFormatReadEventのlistParamBeanClassMapに設定したクラスをインスタンス化し、
	 * リストGET項目を格納した結果を返却する。<br>
	 * キー：リストID(LIST_ID)、値：リストGET項目を格納したビーン。
	 * @return listParams
	 */
	public HashMap<String, ArrayList<Object>> getListParams() {
		return listParams;
	}

}
