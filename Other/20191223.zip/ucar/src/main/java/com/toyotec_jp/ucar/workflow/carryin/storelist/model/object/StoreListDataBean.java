package com.toyotec_jp.ucar.workflow.carryin.storelist.model.object;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;

/**
 * <strong>展示店舗受取処理 画面出力値Bean</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/24 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class StoreListDataBean extends TecBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	/** 搬入日 */
	private String ddHannyu;
	/** 管理番号 */
	private String noKanri;
	/** 配送予定日 */
	private Date dtStatus20;
	/** 搬出日 */
	private String ddHansyt;
	/** 車種 */
	private String mjSyamei;
	/** フレームNo. */
	private String noSyadai;
	/** 色 */
	private String mjKubunnai;
	/** 初度登録 */
	private String ddSyodotor;
	/** BP */
	private Date dtStatus11;
	/** 整備 */
	private Date dtStatus17;
	/** まるクリ */
	private Date dtStatus14;
	/** アムス */
	private Date dtStatus23;
	/** 写真撮影 */
	private Date dtStatus25;
	/** 作業仕分 */
	private String mjSgyokt;
	/** 店舗 */
	private String kjTentanms;
	/** 備考 */
	private String mjBikou;

	/** データ更新日時
	 * <pre>
	 * 排他制御時に使用する
	 * </pre>
	 */
	private Date dtKosin;

	/** ステータス26:店舗受取日
	 * <pre>
	 * 受取が完了か未完了かの判断
	 * </pre>
	 */
	private Date dtStatus26;

	// 2012.04.05 A.Yoshinami 追加 受取欄表示の条件追加のため start
	/** ステータス21:搬出日
	 * <pre>
	 * 受取が完了か未完了かの判断
	 * </pre>
	 */
	private Date dtStatus21;
	// 2012.04.05 A.Yoshinami 追加 受取欄表示の条件追加のため end

	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため start
	/** データ区分 */
	private String kbData;
	/** 搬入店舗コード・受取店舗コード */
	private String cdHantenpo;
	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため end

	/**
	 *
	 */
	public StoreListDataBean() {
		super();
	}

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn 販売店コード
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn 販売店コード
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * ddHannyuを取得する。
	 * @return ddHannyu 搬入日
	 */
	public String getDdHannyu() {
		return ddHannyu;
	}

	/**
	 * ddHannyuを設定する。
	 * @param ddHannyu 搬入日
	 */
	public void setDdHannyu(String ddHannyu) {
		this.ddHannyu = ddHannyu;
	}

	/**
	 * noKanriを取得する。
	 * @return noKanri 管理番号
	 */
	public String getNoKanri() {
		return noKanri;
	}

	/**
	 * noKanriを設定する。
	 * @param noKanri 管理番号
	 */
	public void setNoKanri(String noKanri) {
		this.noKanri = noKanri;
	}

	/**
	 * dtStatus20を取得する。
	 * @return dtStatus20 配送予定日
	 */
	public String getDtStatus20() {
		String strDtStatus20 = null;
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (dtStatus20 != null && UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			strDtStatus20 = DateUtils.dateToString(dtStatus20, DateUtils.FORMAT_SHORT);
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end
		return strDtStatus20;
	}

	/**
	 * dtStatus20を設定する。
	 * @param dtStatus20 配送予定日
	 */
	public void setDtStatus20(Date dtStatus20) {
		this.dtStatus20 = dtStatus20;
	}

	/**
	 * ddHansytを取得する。
	 * @return ddHansyt 搬出日
	 */
	public String getDdHansyt() {
		return ddHansyt;
	}

	/**
	 * ddHansytを設定する。
	 * @param ddHansyt 搬出日
	 */
	public void setDdHansyt(String ddHansyt) {
		this.ddHansyt = ddHansyt;
	}

	/**
	 * mjSyameiを取得する。
	 * @return mjSyamei 車種
	 */
	public String getMjSyamei() {
		return mjSyamei;
	}

	/**
	 * mjSyameiを設定する。
	 * @param mjSyamei 車種
	 */
	public void setMjSyamei(String mjSyamei) {
		this.mjSyamei = mjSyamei;
	}

	/**
	 * noSyadaiを取得する。
	 * @return noSyadai フレームNo.
	 */
	public String getNoSyadai() {
		return noSyadai;
	}

	/**
	 * noSyadaiを設定する。
	 * @param noSyadai フレームNo.
	 */
	public void setNoSyadai(String noSyadai) {
		this.noSyadai = noSyadai;
	}

	/**
	 * mjKubunnaiを取得する。
	 * @return mjKubunnai 色
	 */
	public String getMjKubunnai() {
		return mjKubunnai;
	}

	/**
	 * mjKubunnaiを設定する。
	 * @param mjKubunnai 色
	 */
	public void setMjKubunnai(String mjKubunnai) {
		this.mjKubunnai = mjKubunnai;
	}

	/**
	 * ddSyodotorを取得する。
	 * @return ddSyodotor 初度登録
	 */
	public String getDdSyodotor() {
		if (ddSyodotor != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("Gyy/MM", new Locale("ja","JP","JP"));

			String str = UcarUtils.getStringDateFormatShort(ddSyodotor);
			Date date = DateUtils.getDate(str, DateUtils.FORMAT_SHORT);

			ddSyodotor = sdf.format(date);
		}
		return ddSyodotor;
	}

	/**
	 * ddSyodotorを設定する。
	 * @param ddSyodotor 初度登録
	 */
	public void setDdSyodotor(String ddSyodotor) {
		this.ddSyodotor = ddSyodotor;
	}

	/**
	 * dtStatus11を取得する。
	 * @return dtStatus11 ＢＰ
	 */
	public String getDtStatus11() {
		String strDtStatus11 = "";
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (dtStatus11 != null && UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			strDtStatus11 = "○";
		} else {
			strDtStatus11 = "－";
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end
		return strDtStatus11;
	}

	/**
	 * dtStatus11を設定する。
	 * @param dtStatus11 ＢＰ
	 */
	public void setDtStatus11(Date dtStatus11) {
		this.dtStatus11 = dtStatus11;
	}

	/**
	 * dtStatus17を取得する。
	 * @return dtStatus17 整備
	 */
	public String getDtStatus17() {
		String strDtStatus17 = "";
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (dtStatus17 != null && UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			strDtStatus17 = "○";
		} else {
			strDtStatus17 = "－";
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end
		return strDtStatus17;
	}

	/**
	 * dtStatus17を設定する。
	 * @param dtStatus17 整備
	 */
	public void setDtStatus17(Date dtStatus17) {
		this.dtStatus17 = dtStatus17;
	}

	/**
	 * dtStatus14を取得する。
	 * @return dtStatus14 まるクリ
	 */
	public String getDtStatus14() {
		String strDtStatus14 = "";
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (dtStatus14 != null && UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			strDtStatus14 = "○";
		} else {
			strDtStatus14 = "－";
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end
		return strDtStatus14;
	}

	/**
	 * dtStatus14を設定する。
	 * @param dtStatus14 まるクリ
	 */
	public void setDtStatus14(Date dtStatus14) {
		this.dtStatus14 = dtStatus14;
	}

	/**
	 * dtStatus23を取得する。
	 * @return dtStatus23 アムス
	 */
	public String getDtStatus23() {
		String strDtStatus23 = "";
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (dtStatus23 != null && UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			strDtStatus23 = "○";
		} else {
			strDtStatus23 = "－";
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end
		return strDtStatus23;
	}

	/**
	 * dtStatus23を設定する。
	 * @param dtStatus23 アムス
	 */
	public void setDtStatus23(Date dtStatus23) {
		this.dtStatus23 = dtStatus23;
	}

	/**
	 * dtStatus25を取得する。
	 * @return dtStatus25 写真撮影
	 */
	public String getDtStatus25() {
		String strDtStatus25 = "";
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (dtStatus25 != null && UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			strDtStatus25 = "○";
		} else {
			strDtStatus25 = "－";
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end
		return strDtStatus25;
	}

	/**
	 * dtStatus25を設定する。
	 * @param dtStatus25 写真撮影
	 */
	public void setDtStatus25(Date dtStatus25) {
		this.dtStatus25 = dtStatus25;
	}

	/**
	 * mjSgyoktを取得する。
	 * @return mjSgyokt 作業仕分
	 */
	public String getMjSgyokt() {
		return mjSgyokt;
	}

	/**
	 * mjSgyoktを設定する。
	 * @param mjSgyokt 作業仕分
	 */
	public void setMjSgyokt(String mjSgyokt) {
		this.mjSgyokt = mjSgyokt;
	}

	/**
	 * kjTentanmsを取得する。
	 * @return kjTentanms 店舗
	 */
	public String getKjTentanms() {
		return kjTentanms;
	}

	/**
	 * kjTentanmsを設定する。
	 * @param kjTentanms 店舗
	 */
	public void setKjTentanms(String kjTentanms) {
		this.kjTentanms = kjTentanms;
	}

	/**
	 * mjBikouを取得する。
	 * @return mjBikou 備考
	 */
	public String getMjBikou() {
		return mjBikou;
	}

	/**
	 * mjBikouを設定する。
	 * @param mjBikou 備考
	 */
	public void setMjBikou(String mjBikou) {
		this.mjBikou = mjBikou;
	}

	/**
	 * dtKosinを取得する。
	 * @return dtKosin データ更新日時
	 */
	public Date getDtKosin() {
		return dtKosin;
	}

	/**
	 * dtKosinを設定する。
	 * @param dtKosin データ更新日時
	 */
	public void setDtKosin(Date dtKosin) {
		this.dtKosin = dtKosin;
	}

	/**
	 * dtStatus26を取得する。
	 * @return dtStatus26 ステータス26:店舗受取日
	 */
	public Date getDtStatus26() {
		return dtStatus26;
	}

	/**
	 * dtStatus26を取得する。
	 * @return dtStatus26 ステータス26:店舗受取日
	 * 受取が完了か未完了かの判断
	 */
	public String getDecisionDtStatus26() {
		String decisionDtStatus26 = "";
		if (dtStatus26 == null) {
			decisionDtStatus26 = "false";
		} else {
			decisionDtStatus26 = "true";
		}
		return decisionDtStatus26;
	}

	/**
	 * dtStatus26を設定する。
	 * @param dtStatus26 ステータス26:店舗受取日
	 */
	public void setDtStatus26(Date dtStatus26) {
		this.dtStatus26 = dtStatus26;
	}

	// 2012.04.05 A.Yoshinami 追加 受取欄表示の条件追加のため start
	/**
	 * dtStatus21を取得する。
	 * @return dtStatus21 ステータス21:搬出日
	 */
	public Date getDtStatus21() {
		return dtStatus21;
	}

	/**
	 * dtStatus21を取得する。
	 * @return dtStatus21 ステータス21:搬出日
	 * 受取が完了か未完了かの判断
	 */
	public String getDecisionDtStatus21() {
		String decisionDtStatus21 = "";
		if (dtStatus21 == null) {
			decisionDtStatus21 = "false";
		} else {
			decisionDtStatus21 = "true";
		}
		return decisionDtStatus21;
	}

	/**
	 * dtStatus21を設定する。
	 * @param dtStatus21 ステータス21:搬出日
	 */
	public void setDtStatus21(Date dtStatus21) {
		this.dtStatus21 = dtStatus21;
	}
	// 2012.04.05 A.Yoshinami 追加 受取欄表示の条件追加のため end

	/**
	 * kbDataを取得する。
	 * @return kbData データ区分
	 */
	public String getKbData() {
		return kbData;
	}

	/**
	 * kbDataを設定する。
	 * @param kbData データ区分
	 */
	public void setKbData(String kbData) {
		this.kbData = kbData;
	}

	/**
	 * cdHantenpoを取得する。
	 * @return cdHantenpo 搬入店舗コード・受取店舗コード
	 */
	public String getCdHantenpo() {
		return cdHantenpo;
	}

	/**
	 * cdHantenpoを設定する。
	 * @param cdHantenpo 搬入店舗コード・受取店舗コード
	 */
	public void setCdHantenpo(String cdHantenpo) {
		this.cdHantenpo = cdHantenpo;
	}

}
