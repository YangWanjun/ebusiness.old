package com.toyotec_jp.ucar.workflow.adjustment.common;


/**
 * <strong>精算関連共通処理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[精算(共通)]]
 */
public class AdjustmentUtils {

	/** インスタンス生成しない */
	private AdjustmentUtils(){
	}

}
