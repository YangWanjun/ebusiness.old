package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>作業者マスタDB操作用イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/07/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SagyousyaMasterEvent extends UcarEvent {

	private static final long serialVersionUID = -8975344836334571960L;

	/**	会社コード */
	private String cdKaisya;
	/**	事業所コード */
	private String cdJigyosyo;
	/**	職種コード */
	private String cdSyokusyu;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdJigyosyoを取得する。
	 * @return cdJigyosyo 事業所コード
	 */
	public String getCdJigyosyo() {
		return cdJigyosyo;
	}

	/**
	 * cdJigyosyoを設定する。
	 * @param cdJigyosyo 事業所コード
	 */
	public void setCdJigyosyo(String cdJigyosyo) {
		this.cdJigyosyo = cdJigyosyo;
	}

	/**
	 * cdSyokusyuを取得する。
	 * @return cdSyokusyu 職種コード
	 */
	public String getCdSyokusyu() {
		return cdSyokusyu;
	}

	/**
	 * cdSyokusyuを設定する。
	 * @param cdSyokusyu 職種コード
	 */
	public void setCdSyokusyu(String cdSyokusyu) {
		this.cdSyokusyu = cdSyokusyu;
	}
}
