/*
 * 【システム名】
 * 【ファイル名】DMResult.java
 * 【  説  明  】結果返却用クラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import com.toyotec_jp.im_common.system.exception.TecSystemException;

/**
 * <strong>DMResult</strong>
 * <p>
 * 結果返却用クラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMResult {

	/**
	 * コンストラクタ
	 */
	public DMResult(){
		this.error = false;
	}

	private boolean error;

	private String errorMessage;

	private String errorMessageDetail;

	private String messageID;

	private String byteStringForJs;

	@SuppressWarnings("rawtypes")
	private DMResultColumn[] customProps;

	private DMResultSheet[] sheetList;

	/**
	 * 文書エンジン実行例外発生時結果設定
	 * @param e 例外
	 * @since 1.00
	 */
	public void setDMException(TecSystemException e){
		error = true;
		//messageID = e.getMessageID();
		errorMessage = e.getMessage();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		e.printStackTrace(new PrintStream(baos));
		errorMessageDetail = baos.toString();
	}

	/**
	 * 例外発生時結果設定
	 * @param e 例外
	 * @since 1.00
	 */
	public void setException(Exception e){
		error = true;
		errorMessage = e.getMessage();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		e.printStackTrace(new PrintStream(baos));
		errorMessageDetail = baos.toString();
	}

	/**
	 * エラー取得
	 * @return エラー
	 * @since 1.00
	 */
	public boolean isError() {
		return error;
	}

	/**
	 * エラーメッセージ取得
	 * @return エラーメッセージ
	 * @since 1.00
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * エラーメッセージ詳細取得
	 * @return エラーメッセージ詳細
	 * @since 1.00
	 */
	public String getErrorMessageDetail() {
		return errorMessageDetail;
	}

	/**
	 * メッセージID取得
	 * @return メッセージID
	 * @since 1.00
	 */
	public String getMessageID() {
		return messageID;
	}

	/**
	 * Js用バイト文字列取得
	 * @return Js用バイト文字列
	 * @since 1.00
	 */
	public String getByteStringForJs() {
		return byteStringForJs;
	}

	/**
	 * Js用バイト文字列設定
	 * @param byteStringForJs Js用バイト文字列
	 * @since 1.00
	 */
	public void setByteStringForJs(String byteStringForJs) {
		this.byteStringForJs = byteStringForJs;
	}

	/**
	 * 結果返却用シートリスト取得
	 * @return 結果返却用シートリスト
	 * @since 1.00
	 */
	public DMResultSheet[] getSheetList() {
		return sheetList;
	}

	/**
	 * 結果返却用シートリスト設定
	 * @param sheetList 結果返却用シートリスト
	 * @since 1.00
	 */
	public void setSheetList(DMResultSheet[] sheetList) {
		this.sheetList = sheetList;
	}

	/**
	 * カスタムプロパティ取得
	 * @return カスタムプロパティ
	 * @since 1.00
	 */
	@SuppressWarnings("rawtypes")
	public DMResultColumn[] getCustomProps() {
		return customProps;
	}

	/**
	 * カスタムプロパティ設定
	 * @param customProps カスタムプロパティ
	 * @since 1.00
	 */
	@SuppressWarnings("rawtypes")
	public void setCustomProps(DMResultColumn[] customProps) {
		this.customProps = customProps;
	}

}
