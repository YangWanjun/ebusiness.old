/**
 * システム共通データビーン関連パッケージ
 * @version 1.00 2010/06/02 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.im_common.system.model.object;
