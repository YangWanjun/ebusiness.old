/*
 * 【システム名】リース管理システム
 * 【ファイル名】ResultObject.java
 * 【  説  明  】
 * 【  作  成  】2010/07/23 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.model.event;


/**
 * <strong>ResultObjectクラス。</strong>
 * <p>
 * イベント処理結果として使用可能なオブジェクト。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/23 新規作成<br>
 * @since 1.00
 */
public class ResultObject implements UcarEventResult {

	private static final long serialVersionUID = 8861300117877143850L;

	private Object value;

	/**
	 * コンストラクタ。
	 */
	public ResultObject() {
	}

	/**
	 * コンストラクタ。
	 * @param value
	 */
	public ResultObject(Object value) {
		this.value = value;
	}

	/**
	 * 値を文字列で取得。
	 * @return 値(文字列表現)
	 */
	public String getStringValue(){
		if(value != null){
			return value.toString();
		} else {
			return null;
		}
	}

	/**
	 * valueを取得する。
	 * @return value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * valueを設定する。
	 * @param value
	 */
	public void setValue(Object value) {
		this.value = value;
	}

}
