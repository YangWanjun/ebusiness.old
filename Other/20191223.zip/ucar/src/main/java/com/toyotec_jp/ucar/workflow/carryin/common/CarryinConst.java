package com.toyotec_jp.ucar.workflow.carryin.common;

import com.toyotec_jp.im_common.TecApplicationManager.TecApplicationIdIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecServiceIdIF;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;

/**
 * <strong>車両搬入関連共通定数管理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 * @category [[車両搬入(共通)]]
 */
public class CarryinConst {

	/** パッケージカテゴリ:車両搬入 */
	public static final String PKG_CAT_CARRYIN = ".carryin";

	/** 車両搬入関連パッケージルート */
	public static final String CARRYIN_ROOT
		= UcarApplicationManager.WF_ROOT + PKG_CAT_CARRYIN;

	/** 車両搬入登録パッケージルート */
	public static final String REGISTER_ROOT
		= CARRYIN_ROOT + ".register";
	/** 車両搬入一覧パッケージルート */
	public static final String LIST_ROOT
		= CARRYIN_ROOT + ".list";
	/** 展示店舗受取処理パッケージルート */
	public static final String STORELIST_ROOT
		= CARRYIN_ROOT + ".storelist";

	/** アプリID:車両搬入-車両搬入登録 */
	public static final String APPID_CARRYIN_REGISTER =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.carryin.Register");
	/** アプリID:車両搬入-車両搬入一覧 */
	public static final String APPID_CARRYIN_LIST =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.carryin.List");
	/** アプリID:車両搬入-展示店舗受取処理 */
	public static final String APPID_CARRYIN_STORELIST =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.carryin.StoreList");

	/** 仕入種別:下取 */
	public static final String KBSIIRE_SITADORI =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".KbSiire.Sitadori");
	/** 仕入種別:買取 */
	public static final String KBSIIRE_KAITORI =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".KbSiire.Kaitori");
	/** 仕入種別:オークション */
	public static final String KBSIIRE_AUCTION =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".KbSiire.Auction");

	/** チェック内容区分:下取 */
	public static final String KBCHECK_SITADORI =
		UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".KbCheck.Sitadori");

	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
	/** 搬入書類チェック：書類完備 */
	public static final String DOCUMENTCHECK_COMPLETE 	= UcarConst.RDO_KUBUN_COMPLETE;
	/** 搬入書類チェック：保留 */
	public static final String DOCUMENTCHECK_RESERVE 		= UcarConst.RDO_KUBUN_RESERVE;

	/** 印鑑証明有効期限：OK */
	public static final String DDINKANKGN_OK = "OK";
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

	// 2012.01.30 T.Hayato 追加 車両搬入一覧・搬入書類チェック 共通化 start
	/** 工程チェックボックスの値 */
	public static final String CHECKVALUES_SYORUIKANBI = "01|書類確認未完了,02|保留";
	// 2012.01.30 T.Hayato 追加 車両搬入一覧・搬入書類チェック 共通化 end

	// 2012.04.04 Y.Aya 追加 展示店舗受取一覧 受取チェックボックス追加のため start
	/** 受取チェックボックスの値 */
	public static final String UKETORI_MIKANRYOU = "01";
	public static final String UKETORI_KANRYOU = "02";

	public static final String CHECKBALUES_UKETORI = UKETORI_MIKANRYOU + "|未完了," + UKETORI_KANRYOU + "|完了";
	// 2012.04.04 Y.Aya 追加 展示店舗受取一覧 受取チェックボックス追加のため end

	/** インスタンスを生成しない。 */
	private CarryinConst(){
	}

	/** 車両搬入関連タイトル */
	public enum CarryinTitle {
		/** 車両搬入登録 */
		Register(".Register"),
		/** 車両搬入一覧 */
		List(".List"),
		/** 搬入書類チェック  2011.10.20 H.Yamashita add */
		DocumentCheck(".DocumentCheck"),
		/** 展示店舗受取処理 */
		StoreList(".StoreList"),
		;
		private String titleLabel;
		private CarryinTitle(String key){
			this.titleLabel = UcarApplicationManager.getConstantValue(
					UcarApplicationManager.WF_ROOT + ".title" + PKG_CAT_CARRYIN + key);
		}
		public String toString(){
			return titleLabel;
		}
		/**
		 * 画面タイトルを取得する。
		 * @return titleLabel 画面タイトル
		 */
		public String getTitleLabel() {
			return titleLabel;
		}
	}

	/** 車両搬入関連メニューID */
	public enum CarryinMenuId {
		/** バーコード登録 */
		Barcode(".Register.QR"),
		/** 新規登録 */
		Register(".Register.NEW"),
		/** 搬入一覧 2011.10.20 H.Yamashita add */
		List(".List.LIST"),
		/** 書類チェック 2011.10.20 H.Yamashita add */
		DocumentCheck(".List.DOCUMENTCHECK"),
		;
		private String menuId;
		private CarryinMenuId(String key){
			this.menuId = UcarApplicationManager.getConfigValue(
					UcarApplicationManager.WF_ROOT + ".menuid" + PKG_CAT_CARRYIN + key);
		}
		public String toString(){
			return menuId;
		}
		/**
		 * メニューIDを取得する。
		 * @return menuId メニューID
		 */
		public String getMenuId() {
			return menuId;
		}
	}

	/** 車両搬入関連アプリケーションID */
	public enum CarryinApplicationId implements TecApplicationIdIF {
		/** 車両搬入登録 */
		REGISTER(REGISTER_ROOT + ".Register"),
		/** 車両搬入一覧 */
		LIST(LIST_ROOT + ".List"),
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
		/** 搬入書類チェック */
		DOCUMENT_CHECK(LIST_ROOT + ".DocumentCheck"),
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
		/** 展示店舗受取処理 */
		STORELIST(STORELIST_ROOT + ".StoreList"),
		;
		private String applicationId;
		private CarryinApplicationId(String applicationId){
			this.applicationId = applicationId;
		}
		public String toString(){
			return applicationId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
	}

	/** 車両搬入関連AjaxサービスID */
	public enum CarryinAjaxServiceId {
		/** 車検満了日(日)セレクトボックス取得 */
		GET_DD_SYKNMANR_DD("getDdSyknmanrDd"),
		/** 下取担当者名取得 */
		GET_KJ_SYAINMEI("getKjSyainmei"),
		/** 型式指定類別NO取得 */
		GET_NO_KATARUIB("getNoKataruib"),

		;
		private String ajaxServiceId;
		private CarryinAjaxServiceId(String ajaxServiceId) {
			this.ajaxServiceId = ajaxServiceId;
		}
		public String toString(){
			return ajaxServiceId;
		}
		/**
		 * ajaxServiceIdを取得する。
		 * @return ajaxServiceId
		 */
		public String getAjaxServiceId() {
			return ajaxServiceId;
		}
	}

	/** 車両搬入関連サービスID */
	public enum CarryinServiceId implements TecServiceIdIF {
		/** 初期処理 */
		INIT(CarryinApplicationId.REGISTER, "Init"),
		/** 登録(帳票印刷)処理 */
		REGISTER_AND_DOWNLOAD(CarryinApplicationId.REGISTER, "RegisterAndDownload"),
		/** 登録処理 */
		REGISTER(CarryinApplicationId.REGISTER, "Register"),
		/** 更新登録(帳票印刷)処理 */
		UPDATE_REGISTER_AND_DOWNLOAD(CarryinApplicationId.REGISTER, "UpdateRegisterAndDownload"),
		/** 更新登録処理 */
		UPDATE_REGISTER(CarryinApplicationId.REGISTER, "UpdateRegister"),
		/** 詳細確認・修正処理 */
		EDIT(CarryinApplicationId.REGISTER, "Edit"),
		/** 削除処理 */
		DELETE(CarryinApplicationId.REGISTER, "Delete"),
		/** Ajax処理 */
		AJAX(CarryinApplicationId.REGISTER, "Ajax"),
		/** 車両搬入一覧への遷移 */
		TRANS_LIST(CarryinApplicationId.REGISTER, "TransList"),
		/** 車両チェック(入庫検査／作業仕分)への遷移 */
		TRANS_CAR_CHECK(CarryinApplicationId.REGISTER, "TransCarCheck"),
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
		/** 搬入書類チェックへの遷移 */
		TRANS_DOCUMENT_CHECK(CarryinApplicationId.REGISTER, "TransDocumentCheck"),
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

		/** 初期処理 */
		DUMMY_INIT(CarryinApplicationId.REGISTER, "DummyInit"),
		/** 印刷テスト */
		DUMMY_PRINT_TEST(CarryinApplicationId.REGISTER, "DummyPrintTest"),
		/** 印刷テスト(売上精算) */
		DUMMY_PRINT_TEST_URIAGE(CarryinApplicationId.REGISTER, "DummyPrintTestUriage"),

		/** 初期処理 */
		LIST_INIT(CarryinApplicationId.LIST, "ListInit"),
		/** 検索 */
		LIST_SEARCH(CarryinApplicationId.LIST, "Search"),
		/** ソート */
		LIST_SORT(CarryinApplicationId.LIST, "Sort"),
		/** 搬入登録画面への遷移 */
		TRANS_REGISTER(CarryinApplicationId.LIST, "TransRegister"),
		/** 搬入登録画面からの遷移 */
		RETURN_REGISTER(CarryinApplicationId.LIST, "ReturnRegister"),
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		/** 登録処理 */
		LIST_REGISTER(CarryinApplicationId.LIST, "ListRegister"),
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
		/** 初期処理 */
		DOCUMENT_CHECK_INIT(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckInit"),
		/** 検索 */
		DOCUMENT_CHECK_SEARCH(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckSearch"),
		/** ソート */
		DOCUMENT_CHECK_SORT(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckSort"),
		/** 登録処理 */
		DOCUMENT_CHECK_REGISTER(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckRegister"),
		/** 取消処理 */
		DOCUMENT_CHECK_CANCEL(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckCancel"),

		/** 搬入登録画面への遷移 */
		DOCUMENT_CHECK_TRANS_REGISTER(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckTransRegister"),
		/** 搬入登録画面からの遷移 */
		DOCUMENT_CHECK_RETURN_REGISTER(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckReturnRegister"),
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

		/** 在庫カード印刷 */
		ZAIKO_DOWNLOAD(CarryinApplicationId.LIST, "ZaikoDownload"),
		/** 工程管理表印刷 */
		KOUTEI_DOWNLOAD(CarryinApplicationId.LIST, "KouteiDownload"),
		/** 搬入一覧表印刷 */
		HANNYU_DOWNLOAD(CarryinApplicationId.LIST, "HannyuDownload"),
		/** CSVデータ作成 */
		CSV_DOWNLOAD(CarryinApplicationId.LIST, "CSVDownload"),
		// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため start
		/** 車両装備チェックシート印刷 */
		SYARYOSOUBI_DOWNLOAD(CarryinApplicationId.LIST, "SyaryoSoubiDownload"),
		// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため end

		/** 初期処理 */
		STORELIST_INIT(CarryinApplicationId.STORELIST, "StoreListInit"),
		/** 検索処理 */
		STORELIST_SEARCH(CarryinApplicationId.STORELIST, "StoreListSearch"),
		/** ソート処理 */
		STORELIST_SORTING(CarryinApplicationId.STORELIST, "StoreListSorting"),
		/** 更新処理 */
		STORELIST_UPDATE(CarryinApplicationId.STORELIST, "StoreListUpdate"),
		/** 再表示処理 */
		STORELIST_RELORD(CarryinApplicationId.STORELIST, "StoreListRelord"),
		;
		private String applicationId;
		private String serviceId;
		private CarryinServiceId(TecApplicationIdIF appId, String serviceId){
			this.applicationId = appId.getApplicationId();
			this.serviceId = serviceId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
		@Override
		public String getServiceId() {
			return serviceId;
		}
		/**
		 * 車両搬入関連サービスID取得。
		 * <pre>
		 * 車両搬入関連サービスIDを返却する。<br>
		 * 値として認められない場合はnullを返却する。
		 * </pre>
		 * @param serviceId サービスID
		 * @return 車両搬入関連サービスID
		 */
		public static CarryinServiceId getTargetCarryinServiceId(String serviceId){
			CarryinServiceId target = null;
			for(CarryinServiceId enumElement : CarryinServiceId.values()){
				if(enumElement.getServiceId().equals(serviceId)){
					target = enumElement;
					break;
				}
			}
			return target;
		}
	}

	/** 車両搬入関連イベントキー */
	public enum CarryinEventKey implements TecEventKeyIF {
		/** 車両搬入情報取得イベント */
		GET_REGISTER_DATA(CarryinApplicationId.REGISTER, "GetRegisterDataEvent"),
		/** 登録処理イベント */
		REGISTER_DATA(CarryinApplicationId.REGISTER, "RegisterDataEvent"),
		/** 更新登録処理イベント */
		UPDATE_REGISTER_DATA(CarryinApplicationId.REGISTER, "UpdateRegisterDataEvent"),
		/** 削除処理イベント */
		DELETE_REGISTER_DATA(CarryinApplicationId.REGISTER, "DeleteRegisterDataEvent"),

		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため start
		/** 車両搬入一覧：検索処理 */
		LIST_SELECT(CarryinApplicationId.LIST, "ListSelect"),
		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため end
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		/** 車両搬入一覧：登録処理 */
		LIST_REGISTER(CarryinApplicationId.LIST, "RegisterListDataEvent"),
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
		/** 書類チェック：登録処理 */
		DOCUMENT_CHECK_REGISTER(CarryinApplicationId.DOCUMENT_CHECK, "RegisterDocumentCheckDataEvent"),
		/** 取消処理 */
		DOCUMENT_CHECK_CANCEL(CarryinApplicationId.DOCUMENT_CHECK, "CancelDocumentCheckDataEvent"),
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

		/** 展示店舗受取処理情報取得イベント */
		GET_STORELIST_DATA(CarryinApplicationId.STORELIST, "GetStoreListDataEvent"),
		/** 更新処理 */
		UPDATE_STORELIST_DATA(CarryinApplicationId.STORELIST, "UpdateStoreListDataEvent"),
		;
		private String applicationId;
		private String eventKey;
		private CarryinEventKey(TecApplicationIdIF appId, String eventKey){
			this.applicationId = appId.getApplicationId();
			this.eventKey = eventKey;
		}
		public String toString(){
			return eventKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getEventKey(){
			return eventKey;
		}
	}

	/** 車両搬入関連DAOキー */
	public enum CarryinDAOKey implements TecDAOKeyIF {
		/** 車両搬入登録DAO */
		REGISTER_DAO(CarryinApplicationId.REGISTER, "RegisterDAO"),

		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		/** 車両搬入一覧DAO */
		LIST_DAO(CarryinApplicationId.LIST, "ListDAO"),
		/** 車両搬入一覧DAO */
		LIST_SYSTEMDB_DAO(CarryinApplicationId.LIST, "ListSystemDBDAO"),
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
		/** 車両搬入登録DAO */
		DOCUMENT_CHECK_DAO(CarryinApplicationId.DOCUMENT_CHECK, "DocumentCheckDAO"),
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

		/** 展示店舗受取処理DAO */
		STORELIST_DAO(CarryinApplicationId.STORELIST, "StoreListDAO"),
		;
		private String applicationId;
		private String daoKey;
		private CarryinDAOKey(TecApplicationIdIF appId, String daoKey){
			this.applicationId = appId.getApplicationId();
			this.daoKey = daoKey;
		}
		public String toString(){
			return daoKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getDAOKey(){
			return daoKey;
		}
	}

}
