package com.toyotec_jp.ucar.workflow.carryin.list.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>書類チェック登録イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/01/18 新規作成<br>
 * @since 1.00
 * @category [[搬入書類チェック]]
 */
public class RegisterDocumentCheckDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 処理実行件数 */
	private int countExecute;

	/**
	 * countExecuteを取得する。
	 * @return countExecute 処理実行件数
	 */
	public int getCountExecute() {
		return countExecute;
	}

	/**
	 * countExecuteを設定する。
	 * @param countExecute 処理実行件数
	 */
	public void setCountExecute(int countExecute) {
		this.countExecute = countExecute;
	}

}
