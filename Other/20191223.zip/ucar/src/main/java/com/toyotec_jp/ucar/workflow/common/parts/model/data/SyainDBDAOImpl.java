package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;

/**
 * <strong>社員DB操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/17 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SyainDBDAOImpl extends UcarSharedDBDAO implements SyainDBDAOIF {

	private static final String SELECT_SYAIN_DB_LIST_SQL
		= "SELECT "
		+ "    KJ_SYAINMEI "
		+ "FROM "
		;

	private static final String SELECT_SYAIN_DB_WHERE_SQL
		= " WHERE "
		+ "      CD_KAISYA = ? "
		+ "  AND CD_SYAIN  = ? ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.SyainDBDAOIF#getSyainDBList()
	 */
	@Override
	public ResultArrayList<SyainDBBean> getSyainDBList(String cdKaisya, String cdHanbaitn, String cdSyain) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder(SELECT_SYAIN_DB_LIST_SQL);

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		selectSql.append(AddonTableManager.getSyain(cdHanbaitn));
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		selectSql.append(SELECT_SYAIN_DB_WHERE_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(cdSyain);	// 社員コード

		paramBean.setSql(selectSql.toString());

		ResultArrayList<SyainDBBean> resList
			= executeSimpleSelectQuery(paramBean, SyainDBBean.class);

		return resList;
	}

}
