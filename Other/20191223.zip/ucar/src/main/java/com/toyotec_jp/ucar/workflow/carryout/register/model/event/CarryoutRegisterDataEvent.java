package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出情報登録イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/05 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 車両搬出情報Bean */
//	private T220013gBean t220013gBean;
	private Uccb009gBean t220013gBean;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
	/** 車両搬出情報：データ更新日時(排他チェック用) */
	private String t220013gDtKosin;

	/**
	 * t220013gBeanを取得する。
	 * @return t220013gBean
	 */
//	public T220013gBean getT220013gBean() {
	public Uccb009gBean getT220013gBean() {		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		return t220013gBean;
	}

	/**
	 * t220013gBeanを設定する。
	 * @param t220013gBean
	 */
//	public void setT220013gBean(T220013gBean t220013gBean) {
	public void setT220013gBean(Uccb009gBean t220013gBean) {		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		this.t220013gBean = t220013gBean;
	}

	/**
	 * t220013gDtKosinを取得する。
	 * @return t220013gDtKosin
	 */
	public String getT220013gDtKosin() {
		return t220013gDtKosin;
	}

	/**
	 * t220013gDtKosinを設定する。
	 * @param t220013gDtKosin
	 */
	public void setT220013gDtKosin(String t220013gDtKosin) {
		this.t220013gDtKosin = t220013gDtKosin;
	}

}