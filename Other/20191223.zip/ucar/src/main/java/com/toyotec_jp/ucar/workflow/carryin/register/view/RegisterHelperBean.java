package com.toyotec_jp.ucar.workflow.carryin.register.view;

import java.util.ArrayList;
import java.util.HashMap;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinAjaxServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinEventKey;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinTitle;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.register.model.event.GetRegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.register.model.event.GetRegisterDataEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarButton;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean;

/**
 * <strong>車両搬入登録ヘルパービーン。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 8584928315609391060L;

	/** 和暦年最大値(2桁) */
	private static final int	END_OF_YEAR 	= 99;
	private static final int	END_OF_MONTH 	= 12;
	private static final int	END_OF_DAY 		= 31;

	/** チェック内容区分：下取書類 */
	private static final String KB_CHECK_SITADORI = UcarConst.KB_CHECK_SITADORI;

	private String serviceUrlInit;
	private String	serviceUrlRegisterAndDownload;
	private String	serviceUrlRegister;
	private String	serviceUrlDelete;
	private String	serviceUrlAjax;
	private String	serviceUrlList;
	private String	serviceUrlTransList;

	/** 塗色セレクトボックスデータ */
	private ArrayList<HashMap<String, String>> codeKubunDBSelectList;
	/** 年セレクトボックスデータ */
	private ArrayList<HashMap<String, String>> yyList;
	/** 月セレクトボックスデータ */
	private ArrayList<HashMap<String, String>>	mmList;
	/** 日セレクトボックスデータ */
	private ArrayList<HashMap<String, String>>	ddList;
	/** 年号セレクトボックスデータ */
	private ArrayList<HashMap<String, String>>	eraList;
	/** 個人情報セレクトボックスデータ */
	private ArrayList<HashMap<String, String>>	cdKozinzyhoList;
	/** 搬入日 */
	private String	ddHannyu = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT);

	/** 車両搬入セッションBean */
	private CarryinSessionBean	sessionBean;

	/** 車両搬入情報Bean */
	private Ucaa001gBean t220001gBean = new Ucaa001gBean();
	/** 仕入種別情報Beanリスト */
	private ResultArrayList<Ucaa002gBean> t220002gList;
	/** チェック内容情報Beanリスト */
	private ResultArrayList<Ucaa003gBean> t220003gList;

	/** 書類完備情報Bean 2011.10.13 H.Yamashita add*/
	private Ucab002gBean t220007gBean = new Ucab002gBean();


	/**書類完備日 2011.10.13 H.Yamashita add*/
	private String ddSrk;

	/**書類完備日チェック 2011.10.14 H.Yamashita add */
	private String checkDdSrk = "";

	/** 社員DBBean */
	private SyainDBBean syainDBBean = new SyainDBBean();

	private CarryinServiceId targetServiceId;

	/** 仕入種別(カンマ区切り) */
	private String	kbSiireCSVData;
	/** チェック内容区分(カンマ区切り) */
	private String kbCheckCSVData;
	/** サービスID：EDIT(実行サービスがEDITの場合は"true") */
	private String serviceIdEdit = "false";

	/** 仕入種別checkvalues */
	private String	kbSiireCheckvalues = "";
	/** チェック内容checkvalues */
	private String	kbCheckCheckvalues = "";

	/** ダウンロードファイルパス */
	private String downloadFilePath = "";
	/** 戻るアイコン表示制御(表示する場合は"true") */
	private String showReturnPageIcon = "";
	
	
	/** デフォルトコンストラクタ。 */
	public RegisterHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.base.view.TlsHelperBean#init()
	 */
	@Override
	public void init() throws HelperBeanException {

		// セッションの取得

		sessionBean = getApplicationSessionBean(CarryinSessionBean.class);

		String serviceId = sessionBean.getServiceId();
		targetServiceId = CarryinServiceId.getTargetCarryinServiceId(serviceId);

		// サービス呼び出し用URL設定

		setServiceURLs();

		try {

			// サービスごとの処理

			if(targetServiceId != null){
				switch (targetServiceId) {

					case EDIT:
						// 修正処理(搬入情報一覧画面からの遷移)
						Ucaa001gPKBean t220001gPkBean = sessionBean.getT220001gPkBean();

						GetRegisterDataEvent getEvent = createEvent(
								CarryinEventKey.GET_REGISTER_DATA, GetRegisterDataEvent.class);
						getEvent.setT220001gPkBean(t220001gPkBean);

						GetRegisterDataEventResult getResult
							= (GetRegisterDataEventResult)dispatchEvent(getEvent);

						t220001gBean = getResult.getUcaa001gBean();
						t220002gList = getResult.getT220002gList();
						t220003gList = getResult.getT220003gList();
						syainDBBean = getResult.getSyainDBBean();

						// 書類完備情報 2011.10.13 H.Yamashita add start
						t220007gBean = getResult.getUcab002gBean();

						// 書類完備保留日が空白の場合　書類完備日
						if(t220007gBean.getDdSrkhr() == null && t220007gBean.getDdSrknb() != null){

							setDdSrk(t220007gBean.getDdSrknb() );

						// 以外、書類完備保留日
						}else if(t220007gBean.getDdSrkhr() != null){

							setDdSrk(t220007gBean.getDdSrkhr() );

						}else{
							setDdSrk("");

						}

						// 書類完備日保留：書類完備保留日が空白ならチェックオフ

						if(t220007gBean.getDdSrkhr() == null){
							setCheckDdSrk("");
						// 以外、チェックオン
						}else{
							setCheckDdSrk("checked");

						}
						// 書類完備情報 2011.10.13 H.Yamashita add end

						// 排他制御時に使用する更新日時をセッションにセット
						sessionBean.setT220001gDtKosin(DateUtils.dateToString(getResult.getUcaa001gBean().getDtKosin(),
																				DateUtils.DB_FORMAT_LONG_M));

						// 仕入種別のチェック状態をカンマ区切りのデータに変換
						for (Ucaa002gBean t220002gBean : t220002gList) {
							if (kbSiireCSVData == null) {
								kbSiireCSVData = t220002gBean.getKbSiire();
							} else {
								kbSiireCSVData += "," + t220002gBean.getKbSiire();
							}
						}
						// チェック内容のチェック状態をカンマ区切りのデータに変換
						for (Ucaa003gBean t220003gBean : t220003gList) {
							if (kbCheckCSVData == null) {
								kbCheckCSVData = t220003gBean.getKbCheck();
							} else {
								kbCheckCSVData += "," + t220003gBean.getKbCheck();
							}
						}

						/* 2011.10.13 H.Yamashita 和暦表示＋カレンダー表示に伴い削除
						int dd = 0;
						// 車検満了日の日部分を取得

						if (StringCheckUtils.isEmpty(t220001gBean.getDdSyknmanr())) {
							dd = END_OF_DAY;
						} else {
							// 車検満了日がある場合

							int yyyy = Integer.valueOf(t220001gBean.getDdSyknmanr().substring(0, 4));
							int mm = Integer.valueOf(t220001gBean.getDdSyknmanr().substring(4, 6));
							Calendar calendar = Calendar.getInstance();
							calendar.set(yyyy, mm - 1, 1);
							// 月の末日を取得

							dd = calendar.getActualMaximum(Calendar.DATE);
						}
						createSelectDateList(END_OF_YEAR, END_OF_MONTH, dd);
						*/
						createSelectDateList(END_OF_YEAR, END_OF_MONTH, END_OF_DAY);

						serviceIdEdit = "true";

						showReturnPageIcon = "true";

						break;
					default:
						createSelectDateList(END_OF_YEAR, END_OF_MONTH, END_OF_DAY);
						setDdSrk("");
						serviceIdEdit = "false";
						break;
				}
				downloadFilePath = sessionBean.getDownloadFilePath();
				// セッションのダウンロードファイルパスはクリア
				sessionBean.setDownloadFilePath(null);
			}

			createSelectList();

			kbSiireCheckvalues = UcarUtils.getT220004mCheckvalues(getRequest(), getResponse());
			kbCheckCheckvalues = UcarUtils.getT220005mCheckvalues(getRequest(), getResponse());

		} catch (SystemException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		} catch (ApplicationException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		}
	}

	/**
	 * セレクトボックスデータ作成
	 * @throws TecSystemException
	 */
	private void createSelectList() throws TecSystemException {

		codeKubunDBSelectList = UcarUtils.getCodeKubunDBSelectList(getRequest(), getResponse());

		cdKozinzyhoList = UcarUtils.getSelectList(UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.select.value.CdKozinzyho"),
													UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.select.text.CdKozinzyho"));
	}

	/**
	 * 年号・年・月・日セレクトボックスデータ作成
	 * @param yy 年(和暦)
	 * @param mm 月

	 * @param dd 日
	 * @throws TecSystemException
	 */
	private void createSelectDateList(int yy, int mm, int dd) throws TecSystemException {

		eraList = UcarUtils.getSelectList(UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.select.era"),
											UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.select.era"));
		yyList = UcarUtils.getDateList(yy);
		mmList = UcarUtils.getDateList(mm);
		ddList = UcarUtils.getDateList(dd);

	}

	/** サービス呼び出し用URL設定 */
	private void setServiceURLs() throws HelperBeanException {

		serviceUrlInit 		= getServiceUrl(CarryinServiceId.INIT);
		serviceUrlDelete 	= getServiceUrl(CarryinServiceId.DELETE);
		serviceUrlAjax 		= getServiceUrl(CarryinServiceId.AJAX);
		serviceUrlList 		= getServiceUrl(CarryinServiceId.LIST_INIT);

		if (sessionBean.isTransCarCheck()) {
			// 車両チェック(入庫検査／作業仕分)から画面遷移の場合

			serviceUrlTransList	= getServiceUrl(CarryinServiceId.TRANS_CAR_CHECK);
		} else if (sessionBean.isTransDocumentCheck()) {
			// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
			// 搬入書類チェックから画面遷移の場合

			serviceUrlTransList	= getServiceUrl(CarryinServiceId.TRANS_DOCUMENT_CHECK);
			// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
		} else {
			serviceUrlTransList	= getServiceUrl(CarryinServiceId.TRANS_LIST);
		}

		// サービスごとの処理

		if(targetServiceId != null){
			switch (targetServiceId) {
				case EDIT:
					serviceUrlRegisterAndDownload 	= getServiceUrl(CarryinServiceId.UPDATE_REGISTER_AND_DOWNLOAD);
					serviceUrlRegister 				= getServiceUrl(CarryinServiceId.UPDATE_REGISTER);
					break;
				default:
					serviceUrlRegisterAndDownload 	= getServiceUrl(CarryinServiceId.REGISTER_AND_DOWNLOAD);
					serviceUrlRegister 				= getServiceUrl(CarryinServiceId.REGISTER);
					break;
			}
		}
	}

	/** 画面タイトル取得 */
	public String getTitleLabel(){
		return CarryinTitle.Register.getTitleLabel();
	}

	/** 登録（帳票印刷）ボタンラベル取得 */
	public String getButtonLabelRegisterDownload(){
		return UcarButton.REGISTER_DOWNLOAD.getButtonLabel();
	}

	/** 登録ボタンラベル取得 */
	public String getButtonLabelRegister(){
		return UcarButton.REGISTER.getButtonLabel();
	}

	/** 取消ボタンラベル取得 */
	public String getButtonLabelCancel(){
		return UcarButton.CANCEL.getButtonLabel();
	}

	/** 削除ボタンラベル取得 */
	public String getButtonLabelDelete(){
		return UcarButton.DELETE.getButtonLabel();
	}

	/**
	 * serviceUrlInitを取得する。

	 * @return serviceUrlInit
	 */
	public String getServiceUrlInit() {
		return serviceUrlInit;
	}

	/**
	 * serviceUrlRegisterAndDownloadを取得する。

	 * @return serviceUrlRegisterAndDownload
	 */
	public String getServiceUrlRegisterAndDownload() {
		return serviceUrlRegisterAndDownload;
	}

	/**
	 * serviceUrlRegisterを取得する。

	 * @return serviceUrlRegister
	 */
	public String getServiceUrlRegister() {
		return serviceUrlRegister;
	}

	/**
	 * serviceUrlDeleteを取得する。

	 * @return serviceUrlDelete
	 */
	public String getServiceUrlDelete() {
		return serviceUrlDelete;
	}

	/**
	 * serviceUrlAjaxを取得する。

	 * @return serviceUrlAjax
	 */
	public String getServiceUrlAjax() {
		return serviceUrlAjax;
	}

	/**
	 * serviceUrlListを取得する。

	 * @return serviceUrlList
	 */
	public String getServiceUrlList() {
		return serviceUrlList;
	}

	/**
	 * serviceUrlTransListを取得する。

	 * @return serviceUrlTransList
	 */
	public String getServiceUrlTransList() {
		return serviceUrlTransList;
	}

	/**
	 * codeKubunDBSelectListを取得する。

	 * @return codeKubunDBSelectList
	 */
	public ArrayList<HashMap<String, String>> getCodeKubunDBSelectList() {
		return codeKubunDBSelectList;
	}

	/**
	 * yyListを取得する。

	 * @return yyList
	 */
	public ArrayList<HashMap<String, String>> getYyList() {
		return yyList;
	}

	/**
	 * mmListを取得する。

	 * @return mmList
	 */
	public ArrayList<HashMap<String, String>> getMmList() {
		return mmList;
	}

	/**
	 * ddListを取得する。

	 * @return ddList
	 */
	public ArrayList<HashMap<String, String>> getDdList() {
		return ddList;
	}

	/**
	 * eraListを取得する。

	 * @return eraList
	 */
	public ArrayList<HashMap<String, String>> getEraList() {
		return eraList;
	}

	/**
	 * cdKozinzyhoListを取得する。

	 * @return cdKozinzyhoList
	 */
	public ArrayList<HashMap<String, String>> getCdKozinzyhoList() {
		return cdKozinzyhoList;
	}

	/**
	 * ddHannyuを取得する。

	 * @return ddHannyu
	 */
	public String getDdHannyu() {
		return ddHannyu;
	}

	/**
	 * sessionBeanを取得する。

	 * @return sessionBean
	 */
	public CarryinSessionBean getSessionBean() {
		return sessionBean;
	}

	/**
	 * t220001gBeanを取得する。

	 * @return t220001gBean
	 */
	public Ucaa001gBean getUcaa001gBean() {
		return t220001gBean;
	}

	/**
	 * t220007gBeanを取得する。

	 * @return t220001gBean
	 */
	public Ucab002gBean getUcab002gBean() {
		return t220007gBean;
	}
	/**
	 * targetServiceIdを取得する。

	 * @return targetServiceId
	 */
	public CarryinServiceId getTargetServiceId() {
		return targetServiceId;
	}

	/**
	 * t220002gListを取得する。

	 * @return t220002gList
	 */
	public ResultArrayList<Ucaa002gBean> getT220002gList() {
		return t220002gList;
	}

	/**
	 * t220003gListを取得する。

	 * @return t220003gList
	 */
	public ResultArrayList<Ucaa003gBean> getT220003gList() {
		return t220003gList;
	}

	/**
	 * kbSiireCSVDataを取得する。

	 * @return kbSiireCSVData
	 */
	public String getKbSiireCSVData() {
		return kbSiireCSVData;
	}

	/**
	 * kbCheckCSVDataを取得する。

	 * @return kbCheckCSVData
	 */
	public String getKbCheckCSVData() {
		return kbCheckCSVData;
	}

	/**
	 * serviceIdEditを取得する。

	 * @return serviceIdEdit
	 */
	public String getServiceIdEdit() {
		return serviceIdEdit;
	}

	/**
	 * syainDBBeanを取得する。

	 * @return syainDBBean
	 */
	public SyainDBBean getSyainDBBean() {
		return syainDBBean;
	}

	/**
	 * kbSiireCheckvaluesを取得する。

	 * @return kbSiireCheckvalues
	 */
	public String getKbSiireCheckvalues() {
		return kbSiireCheckvalues;
	}

	/**
	 * kbCheckCheckvaluesを取得する。

	 * @return kbCheckCheckvalues
	 */
	public String getKbCheckCheckvalues() {
		return kbCheckCheckvalues;
	}

	/**
	 * 車両搬入関連AjaxサービスID
	 * CarryinAjaxServiceId.GET_DD_SYKNMANR_DDを取得する。

	 * @return CarryinAjaxServiceId.GET_DD_SYKNMANR_DD
	 */
	public String getDdSyknmanrDd() {
		return CarryinAjaxServiceId.GET_DD_SYKNMANR_DD.toString();
	}

	/**
	 * 車両搬入関連AjaxサービスID
	 * CarryinAjaxServiceId.GET_KJ_SYAINMEIを取得する。

	 * @return CarryinAjaxServiceId.GET_KJ_SYAINMEI
	 */
	public String getKjSyainmei() {
		return CarryinAjaxServiceId.GET_KJ_SYAINMEI.toString();
	}

	/**
	 * 車両搬入関連AjaxサービスID
	 * CarryinAjaxServiceId.GET_NO_KATARUIBを取得する。

	 * @return CarryinAjaxServiceId.GET_NO_KATARUIB
	 */
	public String getNoKataruib() {
		return CarryinAjaxServiceId.GET_NO_KATARUIB.toString();
	}

	/**
	 * downloadFilePathを取得する。

	 * @return downloadFilePath
	 */
	public String getDownloadFilePath() {
		return downloadFilePath;
	}

	/**
	 * showReturnPageIconを取得する。

	 * @return showReturnPageIcon
	 */
	public String getShowReturnPageIcon() {
		return showReturnPageIcon;
	}

	public String getDdSrk() {
		return ddSrk;
	}

	public void setDdSrk(String ddSrk) {
		this.ddSrk = ddSrk;
	}

	public String getCheckDdSrk() {
		return checkDdSrk;
	}

	public void setCheckDdSrk(String checkDdSrk) {
		this.checkDdSrk = checkDdSrk;
	}

	/**
	 * kB_CHECK_SITADORIを取得する。

	 * @return kB_CHECK_SITADORI
	 */
	public String getKB_CHECK_SITADORI() {
		return KB_CHECK_SITADORI;
	}

}
