/*
 * 【システム名】
 * 【ファイル名】DMSheetMap.java
 * 【  説  明  】シート情報格納用マップクラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

import java.util.HashMap;

/**
 * <strong>DMSheetMap</strong>
 * <p>
 * シート情報格納用マップクラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMSheetMap<K, V> extends HashMap<K, V> {

	/** シリアルバージョン */
	private static final long serialVersionUID = 1738094602390669155L;

	protected DMSheetInfo sheetInfo;

	/**
	 * コンストラクタ
	 * @param fileMapData
	 * @param initialCapacity
	 * @param loadFactor
	 */
	public DMSheetMap(DMFilesMapData fileMapData, int initialCapacity, float loadFactor) {
		super(initialCapacity, loadFactor);
		setSheetInfo(fileMapData);
	}

	/**
	 * コンストラクタ
	 * @param fileMapData
	 * @param initialCapacity
	 */
	public DMSheetMap(DMFilesMapData fileMapData, int initialCapacity) {
		super(initialCapacity);
		setSheetInfo(fileMapData);
	}

	/**
	 * コンストラクタ
	 * @param fileMapData
	 */
	public DMSheetMap(DMFilesMapData fileMapData){
		super();
		setSheetInfo(fileMapData);
	}

	/**
	 * シート情報設定
	 * @param fileMapData
	 * @since 1.00
	 */
	private void setSheetInfo(DMFilesMapData fileMapData){
		sheetInfo = new DMSheetInfo(fileMapData);
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getKaiPageKbn()
	 */
	public int getKaiPageKbn() {
		return sheetInfo.getKaiPageKbn();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getSheetIdx()
	 */
	public int getSheetIdx() {
		return sheetInfo.getSheetIdx();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getSheetKbn()
	 */
	public int getSheetKbn() {
		return sheetInfo.getSheetKbn();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getSheetNm()
	 */
	public String getSheetNm() {
		return sheetInfo.getSheetNm();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiFilePath()
	 */
	public String getShokiFilePath() {
		return sheetInfo.getShokiFilePath();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiSaishugyo()
	 */
	public int getShokiSaishugyo() {
		return sheetInfo.getShokiSaishugyo();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiSaishuretsu()
	 */
	public int getShokiSaishuretsu() {
		return sheetInfo.getShokiSaishuretsu();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiSheetNm()
	 */
	public String getShokiSheetNm() {
		return sheetInfo.getShokiSheetNm();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaFilePath()
	 */
	public String getTsuikaFilePath() {
		return sheetInfo.getTsuikaFilePath();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaGyoHoseichi()
	 */
	public int getTsuikaGyoHoseichi() {
		return sheetInfo.getTsuikaGyoHoseichi();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaKaishigyo()
	 */
	public int getTsuikaKaishigyo() {
		return sheetInfo.getTsuikaKaishigyo();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaRetsuHoseichi()
	 */
	public int getTsuikaRetsuHoseichi() {
		return sheetInfo.getTsuikaRetsuHoseichi();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaSheetNm()
	 */
	public String getTsuikaSheetNm() {
		return sheetInfo.getTsuikaSheetNm();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaShuryogyo()
	 */
	public int getTsuikaShuryogyo() {
		return sheetInfo.getTsuikaShuryogyo();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getYoshikiId()
	 */
	public String getYoshikiId() {
		return sheetInfo.getYoshikiId();
	}

}
