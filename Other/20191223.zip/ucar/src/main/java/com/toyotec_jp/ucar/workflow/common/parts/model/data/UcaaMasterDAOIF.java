package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;

/**
 * <strong>U-Car商品化システム マスタ操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/17 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface UcaaMasterDAOIF {

	/**
	 * 仕入種別マスタリスト取得。
	 * @param  cdKaisya 会社コード
	 * @param  cdHanbaitn 販売店コード
	 * @return 仕入種別マスタリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucaa004mBean> getT220004mList(String cdKaisya, String cdHanbaitn) throws TecDAOException;

	/**
	 * チェック内容マスタリスト取得。
	 * @param  cdKaisya 会社コード
	 * @param  cdHanbaitn 販売店コード
	 * @return チェック内容マスタリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucaa005mBean> getT220005mList(String cdKaisya, String cdHanbaitn) throws TecDAOException;

	/**
	 * 作業工程マスタリスト取得。
	 * @param  cdKaisya 会社コード
	 * @param  cdHanbaitn 販売店コード
	 * @param  kbKasyu 加修フラグ
	 * @param  kbTenposk 店舗識別区分
	 * @return 作業工程マスタリスト
	 * @throws TecDAOException
	 */
//	public ResultArrayList<Ucac002mBean> getT220014mList(String cdKaisya, String cdHanbaitn, String kbKasyu) throws TecDAOException;
	public ResultArrayList<Ucac002mBean> getT220014mList(String cdKaisya, String cdHanbaitn, String kbKasyu, String kbTenposk) throws TecDAOException;		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

}
