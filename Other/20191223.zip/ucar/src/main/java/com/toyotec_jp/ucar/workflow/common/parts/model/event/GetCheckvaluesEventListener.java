package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaMasterDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;

/**
 * <strong>checkvalues用データ取得操作用イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/17 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetCheckvaluesEventListener extends UcarEventListener {

	/** 加修なし */
	private static final String	KB_KASYU_NOT_REPAIR	= "0";
	/** 加修あり */
	private static final String	KB_KASYU_REPAIR	= "1";

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetCheckvaluesEvent targetEvent = (GetCheckvaluesEvent)event;

		UcaaMasterDAOIF dao
			= getDAO(UcarDAOKey.UCAA_MASTER_DAO, event, UcaaMasterDAOIF.class);

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<Ucaa004mBean> T220004mList
			= dao.getT220004mList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn());
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		GetCheckvaluesEventResult getResult = new GetCheckvaluesEventResult();

		StringBuilder t220004mCheckvalues = new StringBuilder();

		if (T220004mList.size() > 0) {
			for (Ucaa004mBean t220004mBean : T220004mList) {
				if (t220004mCheckvalues.length() != 0) {
					t220004mCheckvalues.append(",");
				}
				t220004mCheckvalues.append(t220004mBean.getKbSiire());
				t220004mCheckvalues.append("|");
				t220004mCheckvalues.append(t220004mBean.getMjSiire().trim());
			}
		}

		getResult.setT220004mCheckvalues(t220004mCheckvalues.toString());

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<Ucaa005mBean> T220005mList
			= dao.getT220005mList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn());
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		StringBuilder t220005mCheckvalues = new StringBuilder();

		if (T220005mList.size() > 0) {
			for (Ucaa005mBean t220005mBean : T220005mList) {
				if (t220005mCheckvalues.length() != 0) {
					t220005mCheckvalues.append(",");
				}
				t220005mCheckvalues.append(t220005mBean.getKbCheck());
				t220005mCheckvalues.append("|");
				t220005mCheckvalues.append(t220005mBean.getMjCheck().trim());
			}
		}

		getResult.setT220005mCheckvalues(t220005mCheckvalues.toString());

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		// 商品化センター区分取得 
		String kbTenposk = "2";
		if (targetEvent.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			kbTenposk = UcarConst.KB_SCENTER_SCENTER;
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<Ucac002mBean> t220014mNotRepairList
//			= dao.getT220014mList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn(), KB_KASYU_NOT_REPAIR);
			= dao.getT220014mList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn(), KB_KASYU_NOT_REPAIR, kbTenposk);	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		StringBuilder t220014mNotRepairCheckvalues = new StringBuilder();

		if (t220014mNotRepairList.size() > 0) {
			for (Ucac002mBean t220014mBean : t220014mNotRepairList) {
				if (t220014mNotRepairCheckvalues.length() != 0) {
					t220014mNotRepairCheckvalues.append(",");
				}
				t220014mNotRepairCheckvalues.append(t220014mBean.getKbSgyokt());
				t220014mNotRepairCheckvalues.append("|");
				t220014mNotRepairCheckvalues.append(t220014mBean.getMjSgyokt().trim());
			}
		}

		getResult.setT220014mNotRepairCheckvalues(t220014mNotRepairCheckvalues.toString());

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<Ucac002mBean> t220014mRepairList
//			= dao.getT220014mList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn(), KB_KASYU_REPAIR);
			= dao.getT220014mList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn(), KB_KASYU_REPAIR, kbTenposk);	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		StringBuilder t220014mRepairCheckvalues = new StringBuilder();

		if (t220014mRepairList.size() > 0) {
			for (Ucac002mBean t220014mBean : t220014mRepairList) {
				if (t220014mRepairCheckvalues.length() != 0) {
					t220014mRepairCheckvalues.append(",");
				}
				t220014mRepairCheckvalues.append(t220014mBean.getKbSgyokt());
				t220014mRepairCheckvalues.append("|");
				t220014mRepairCheckvalues.append(t220014mBean.getMjSgyokt().trim());
			}
		}

		getResult.setT220014mRepairCheckvalues(t220014mRepairCheckvalues.toString());
		return getResult;
	}

}
