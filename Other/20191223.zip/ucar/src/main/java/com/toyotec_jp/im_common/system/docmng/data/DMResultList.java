/*
 * 【システム名】
 * 【ファイル名】DMResultList.java
 * 【  説  明  】結果返却用項目リストクラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

/**
 * <strong>DMResultList</strong>
 * <p>
 * 結果返却用項目リストクラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMResultList {

	/**
	 * コンストラクタ
	 * @param sheetIdx シートインデックス
	 * @param shoriShosaiKbn 処理詳細区分
	 * @param listId リストID
	 */
	public DMResultList(int sheetIdx, String shoriShosaiKbn, String listId){
		this.sheetIdx = sheetIdx;
		this.shoriShosaiKbn = shoriShosaiKbn;
		this.listId = listId;
	}

	private int sheetIdx;
	private String shoriShosaiKbn;
	private String listId;

	@SuppressWarnings("rawtypes")
	private DMResultColumn[] listColumns;

	/**
	 * リスト項目取得
	 * @return リスト項目
	 * @since 1.00
	 */
	@SuppressWarnings("rawtypes")
	public DMResultColumn[] getListColumns() {
		return listColumns;
	}

	/**
	 * リスト項目設定
	 * @param listColumns リスト項目
	 * @since 1.00
	 */
	@SuppressWarnings("rawtypes")
	public void setListColumns(DMResultColumn[] listColumns) {
		this.listColumns = listColumns;
	}

	/**
	 * 様式項目定義-リストID取得
	 * @return 様式項目定義-リストID
	 * @since 1.00
	 */
	public String getListId() {
		return listId;
	}
	/**
	 * 様式シート定義-シートインデックス取得
	 * @return 様式シート定義-シートインデックス
	 * @since 1.00
	 */
	public int getSheetIdx() {
		return sheetIdx;
	}
	/**
	 * 様式項目定義-処理詳細区分取得
	 * @return 様式項目定義-処理詳細区分(0201:通常セット、0211:縦方向リスト、0212:横方向リスト)
	 * @since 1.00
	 */
	public String getShoriShosaiKbn() {
		return shoriShosaiKbn;
	}

}
