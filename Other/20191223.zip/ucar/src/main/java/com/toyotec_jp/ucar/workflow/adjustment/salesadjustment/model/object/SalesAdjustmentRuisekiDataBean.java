package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object;

import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean;

/**
 * <strong>集計累積Bean</strong>
 * <p>
 * 受注明細情報Bean(Ucbb002gBean)を継承している。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SalesAdjustmentRuisekiDataBean extends Ucbb002gBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 合計原価 */
	private int sumKiGenka;
	/** 合計売価 */
	private int sumKiBaika;
	/** 合計消費税 */
	private int sumKiTax;
	/** 合計値引き */
	private int sumKiNebiki;

	/**
	 * コンストラクタ
	 */
	public SalesAdjustmentRuisekiDataBean() {
		super();
	}

	/**
	 * コンストラクタ
	 * @param kbSiwake		仕訳区分
	 * @param kbUrikamo		売上科目区分
	 */
	public SalesAdjustmentRuisekiDataBean(String kbSiwake, String kbUrikamo) {
		super();
		super.setKbSiwake(kbSiwake);
		super.setKbUrikamo(kbUrikamo);
	}

	/**
	 * sumKiGenkaを取得する。
	 * @return sumKiGenka
	 */
	public int getSumKiGenka() {
		return sumKiGenka;
	}

	/**
	 * sumKiGenkaを設定する。
	 * @param sumKiGenka
	 */
	public void setSumKiGenka(int sumKiGenka) {
		this.sumKiGenka = sumKiGenka;
	}

	/**
	 * sumKiBaikaを取得する。
	 * @return sumKiBaika
	 */
	public int getSumKiBaika() {
		return sumKiBaika;
	}

	/**
	 * sumKiBaikaを設定する。
	 * @param sumKiBaika
	 */
	public void setSumKiBaika(int sumKiBaika) {
		this.sumKiBaika = sumKiBaika;
	}

	/**
	 * sumKiTaxを取得する。
	 * @return sumKiTax
	 */
	public int getSumKiTax() {
		return sumKiTax;
	}

	/**
	 * sumKiTaxを設定する。
	 * @param sumKiTax
	 */
	public void setSumKiTax(int sumKiTax) {
		this.sumKiTax = sumKiTax;
	}

	/**
	 * getKiBaikaZeinukiを取得する。
	 * <p>
	 * 売価－値引き－消費税
	 * </p>
	 * @return getKiBaikaZeinuki 売価(税抜)
	 */
	public int getKiBaikaZeinuki() {
		return sumKiBaika - sumKiNebiki - sumKiTax;
	}

	/**
	 * sumKiNebikiを取得する。
	 * @return sumKiNebiki
	 */
	public int getSumKiNebiki() {
		return sumKiNebiki;
	}

	/**
	 * sumKiNebikiを設定する。
	 * @param sumKiNebiki
	 */
	public void setSumKiNebiki(int sumKiNebiki) {
		this.sumKiNebiki = sumKiNebiki;
	}

}
