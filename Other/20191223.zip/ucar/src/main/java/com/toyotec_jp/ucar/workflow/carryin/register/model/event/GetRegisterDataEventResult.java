package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean;

/**
 * <strong>車両搬入情報取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/10 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class GetRegisterDataEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 車両搬入情報Bean */
	private Ucaa001gBean t220001gBean;
	/** 仕入種別情報Beanリスト */
	private ResultArrayList<Ucaa002gBean> t220002gList;
	/** チェック内容情報Beanリスト */
	private ResultArrayList<Ucaa003gBean> t220003gList;
	/** 社員DBBean */
	private SyainDBBean syainDBBean;
	
	/** 書類完備情報Bean 2011.10.14 H.Yamashita add*/
	private Ucab002gBean t220007gBean;


	/**
	 * t220001gBeanを取得する。
	 * @return t220001gBean
	 */
	public Ucaa001gBean getUcaa001gBean() {
		return t220001gBean;
	}

	/**
	 * t220001gBeanを設定する。
	 * @param t220001gBean
	 */
	public void setUcaa001gBean(Ucaa001gBean t220001gBean) {
		this.t220001gBean = t220001gBean;
	}

	/**
	 * t220002gListを取得する。
	 * @return t220002gList
	 */
	public ResultArrayList<Ucaa002gBean> getT220002gList() {
		return t220002gList;
	}

	/**
	 * t220002gListを設定する。
	 * @param t220002gList
	 */
	public void setT220002gList(ResultArrayList<Ucaa002gBean> t220002gList) {
		this.t220002gList = t220002gList;
	}

	/**
	 * t220003gListを取得する。
	 * @return t220003gList
	 */
	public ResultArrayList<Ucaa003gBean> getT220003gList() {
		return t220003gList;
	}

	/**
	 * t220003gListを設定する。
	 * @param t220003gList
	 */
	public void setT220003gList(ResultArrayList<Ucaa003gBean> t220003gList) {
		this.t220003gList = t220003gList;
	}

	/**
	 * syainDBBeanを取得する。
	 * @return syainDBBean
	 */
	public SyainDBBean getSyainDBBean() {
		return syainDBBean;
	}

	/**
	 * syainDBBeanを設定する。
	 * @param syainDBBean
	 */
	public void setSyainDBBean(SyainDBBean syainDBBean) {
		this.syainDBBean = syainDBBean;
	}


	public Ucab002gBean getUcab002gBean() {
		return t220007gBean;
	}

	public void setUcab002gBean(Ucab002gBean t220007gBean) {
		this.t220007gBean = t220007gBean;
	}
}
