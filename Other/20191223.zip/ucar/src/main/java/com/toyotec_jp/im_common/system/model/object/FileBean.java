/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】FileBean.java
 * 【  説  明  】
 * 【  作  成  】2010/06/30 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.model.object;

import java.io.ByteArrayInputStream;
import java.io.InputStream;


/**
 * <strong>ファイル用ビーン。</strong>
 * <p>
 * リクエスト等から取得したファイルの情報を格納するビーン。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/30 新規作成<br>
 * @since 1.00
 */
public class FileBean extends TecBean {

	private static final long serialVersionUID = 994074770293474989L;

	private byte[] fileByte;

	private String fileName;

	/**
	 * コンストラクタ。
	 */
	public FileBean() {
	}

	/**
	 * バイト配列をByteArrayInputStreamとして取得する。
	 * @return
	 */
	public InputStream getInputStream(){
		return new ByteArrayInputStream(fileByte);
	}

	/**
	 * fileByteを取得する。
	 * @return fileByte
	 */
	public byte[] getFileByte() {
		return fileByte;
	}

	/**
	 * fileByteを設定する。
	 * @param fileByte
	 */
	public void setFileByte(byte[] fileByte) {
		this.fileByte = fileByte;
	}

	/**
	 * fileNameを取得する。
	 * @return fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * fileNameを設定する。
	 * @param fileName
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
