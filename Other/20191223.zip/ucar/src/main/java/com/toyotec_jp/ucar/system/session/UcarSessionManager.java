/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarSessionManager.java
 * 【  説  明  】
 * 【  作  成  】2010/06/23 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.system.session;

import java.lang.reflect.Constructor;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.co.intra_mart.framework.base.event.EventManager;
import jp.co.intra_mart.framework.base.util.UserInfo;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.exception.TecUnsupportedDataTypeException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageKey;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.UserInformationGetEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>セッション管理クラス。</strong>
 * <p>
 * アプリケーションで使用するセッションを管理する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/23 新規作成<br>
 * @since 1.00
 */
public class UcarSessionManager {

	private static final UcarSessionManager instance = new UcarSessionManager();

	/**
	 * コンストラクタ。
	 */
	private UcarSessionManager(){
	}

	/**
	 * インスタンス取得。
	 * @return セッション管理インスタンス
	 */
	public static UcarSessionManager getInstance(){
		return instance;
	}

	/**
	 * ログインセッションビーン取得。
	 * <pre>
	 * ログインユーザの情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、ログインセッションビーンを生成しセッションに設定した後、返却する。
	 * </pre>
	 * @param request リクエスト
	 * @param userInfo ユーザ情報
	 * @return ログインセッションビーン
	 * @throws TecSystemException
	 */
	public LoginSessionBean getLoginSessionBean(HttpServletRequest request, UserInfo userInfo) throws TecSystemException {
		LoginSessionBean ret = null;
		Object val = request.getSession().getAttribute(LoginSessionBean.class.getName());
		// 対象のキーにログインセッションビーンが存在する場合
		if(val != null && (val instanceof LoginSessionBean)){
			ret = (LoginSessionBean)val;
		// 対象のキーにログインセッションビーンが存在しない場合
		} else {
			TecLogger.trace("--- new LoginSessionBean ---");
			// ログインセッションビーンを生成
			ret = new LoginSessionBean();
			// ユーザ情報設定
			ret.setUserInfoBean(getNewLoginUserInfoBean(userInfo));
			// セッションに設定
			request.getSession().setAttribute(LoginSessionBean.class.getName(), ret);
		}
		return ret;
	}

	/**
	 * 新規アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * セッションキーはクラス名を使用する。<br>
	 * 既存の値をセッションから削除し、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	public <E extends ApplicationSessionBeanIF> E getNewApplicationSessionBean(
			HttpServletRequest request, Class<E> cls) throws TecSystemException{
		return getApplicationSessionBean(request, cls.getName(), cls, true, true);
	}

	/**
	 * 新規アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * 既存の値をセッションから削除し、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	public <E extends ApplicationSessionBeanIF> E getNewApplicationSessionBean(
			HttpServletRequest request, String key, Class<E> cls) throws TecSystemException{
		return getApplicationSessionBean(request, key, cls, true, true);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * セッションキーはクラス名を使用する。<br>
	 * 存在しない場合、または存在しているがそのクラスが引数として設定されたクラスと異なる場合、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	public <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			HttpServletRequest request, Class<E> cls) throws TecSystemException{
		return getApplicationSessionBean(request, cls.getName(), cls, true, false);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、または存在しているがそのクラスが引数として設定されたクラスと異なる場合、
	 * 引数として設定されたクラスをデフォルトコンストラクタを使用してインスタンス化し、
	 * セッションに設定した後、返却する。<br>
	 * ただし、引数として指定するクラスは{@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装していること。<br>
	 * (スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。)
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	public <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			HttpServletRequest request, String key, Class<E> cls) throws TecSystemException{
		return getApplicationSessionBean(request, key, cls, true, false);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	public <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			HttpServletRequest request, Class<E> cls, boolean doCreate) throws TecSystemException{
		return getApplicationSessionBean(request, cls.getName(), cls, doCreate, false);
	}

	/**
	 * アプリケーションセッションビーン取得。
	 * <pre>
	 * 画面の情報が格納されているビーンをセッションから返却する。
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param key セッションキー
	 * @param cls 取得するアプリケーションセッションビーンのクラス
	 * @param doCreate true:対象が存在しなければ作成する。false:Nullを返却する。
	 * @return アプリケーションセッションビーン
	 * @throws TecSystemException
	 */
	public <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			HttpServletRequest request, String key, Class<E> cls, boolean doCreate) throws TecSystemException{
		return getApplicationSessionBean(request, key, cls, doCreate, false);
	}

	// アプリケーションセッションビーン取得
	private <E extends ApplicationSessionBeanIF> E getApplicationSessionBean(
			HttpServletRequest request, String key, Class<E> cls, boolean doCreate, boolean doReNew) throws TecSystemException{
		// アプリケーションセッションビーンではないものはサポート対象外
		if(!isAppSessionBean(cls)){
			String clsName = null;
			if(cls != null){
				clsName = cls.getName();
			}
			TecUnsupportedDataTypeException usdte = new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
			TecLogger.error(usdte);
			TecLogger.debug("--- UnSupportedDataType[" + key + "][" + clsName + "] ---");
			throw usdte;
		}
		E ret = null;
		// セッションが無ければ生成
		HttpSession session = request.getSession(true);
		Object val = session.getAttribute(key);
		// 対象のキーに対応する値が存在しており、doReNewフラグがfalse、セッションに格納されているクラスも正しい場合
		if(val != null && !doReNew && cls.isAssignableFrom(val.getClass())){
			ret = cls.cast(val);
		// doCreateフラグがtrueの場合、新規作成して返却
		} else if(doCreate){
			// 既存の値をセッションから削除
			session.removeAttribute(key);
			TecLogger.trace("--- new ApplicationSessionBean[" + key + "][" + cls.getName() + "] ---");
			// デフォルトコンストラクタを使用してインスタンスを生成
			Constructor<E> constructor = null;
			try {
				constructor = cls.getConstructor();
				ret = constructor.newInstance();
			} catch (Exception e) {
				TecLogger.error(e);
				TecLogger.debug("[" + e.getMessage() + "][" + cls.getName() + "]");
				throw new TecSystemException(e);
			}
			// セッションに設定
			session.setAttribute(key, ret);
		}
		return ret;
	}

	/**
	 * アプリケーションセッションビーンをセッションからクリアする。
	 * <pre>
	 * 指定したセッションキーの値を削除する。<br>
	 * セッションキーはクラス名を使用する。
	 * </pre>
	 * @param <E>
	 * @param request リクエスト
	 * @param cls アプリケーションセッションビーンのクラス
	 */
	public <E extends ApplicationSessionBeanIF> void clearApplicationSession(HttpServletRequest request, Class<E> cls){
		clearApplicationSession(request, cls.getName());
	}

	/**
	 * アプリケーションセッションビーンをセッションからクリアする。
	 * <pre>
	 * 指定したセッションキーの値を削除する。
	 * </pre>
	 * @param request リクエスト
	 * @param key セッションキー
	 */
	public void clearApplicationSession(HttpServletRequest request, String key){
		HttpSession session = request.getSession(true);
		// 既存の値をセッションから削除
		session.removeAttribute(key);
	}

	/**
	 * 全てのアプリケーションセッションビーンをセッションからクリアする。
	 * <pre>
	 * {@link ApplicationSessionBean}を継承、
	 * または{@link ApplicationSessionBeanIF}を実装しているものが対象となる。<br>
	 * ただし、スーパークラスのインターフェースに{@link ApplicationSessionBeanIF}を実装しているものは対象外。
	 * </pre>
	 * @param request リクエスト
	 */
	public void clearAllApplicationSession(HttpServletRequest request){
		// セッションが無ければそのまま
		HttpSession session = request.getSession(false);
		if(session != null){
			Enumeration<?> enum_session = session.getAttributeNames();
			if(enum_session != null){
				ArrayList<String> targetKeys = new ArrayList<String>();
				while(enum_session.hasMoreElements()){
					// enum_sessionのループ内で要素の削除はしない
					// (enum_sessionが並行処理での変更を許可していないため、
					// ここでsessionの変更を行うとConcurrentModificationExceptionとなる)
					targetKeys.add(enum_session.nextElement().toString());
				}
				for(String key : targetKeys){
					TecLogger.trace("sessionKey[" + key + "]");
					Object val = session.getAttribute(key);
					if(val != null && isAppSessionBean(val.getClass())){
						TecLogger.trace("--- removeSession[" + key + "][" + val.getClass().getName() + "] ---");
						//ApplicationSessionBeanIF apsIF = (ApplicationSessionBeanIF)val;
						//apsIF.clear();
						session.removeAttribute(key);
					}
				}
			}
		}
	}

	// targetがApplicationSessionBeanを継承している
	// または、ApplicationSessionBeanIF(またはApplicationSessionBeanIFを継承したサブインターフェイス)を実装しているかどうか
	private boolean isAppSessionBean(Class<?> cls){
		boolean ret = false;
		if(isTarget(cls)){
			TecLogger.trace("sessionCheckTargetClass[" + cls.getName() + "]");
			if(ApplicationSessionBean.class.isAssignableFrom(cls)){
				ret = true;
			} else {
				ret = isAppSessionBeanIF(cls);
			}
		}
		return ret;
	}

	// ApplicationSessionBeanIF(またはApplicationSessionBeanIFを継承したサブインターフェイス)を実装しているかどうか
	private boolean isAppSessionBeanIF(Class<?> cls){
		boolean ret = false;
		if(isTarget(cls)){
			for(Class<?> ifcls : cls.getInterfaces()){
				if(ApplicationSessionBeanIF.class.isAssignableFrom(ifcls)){
					ret = true;
					break;
				}
			}
			// スーパークラスのインターフェースは対象外
			//if(!ret){
			//	ret = isAppSessionBeanIF(cls.getSuperclass());
			//}
		}
		return ret;
	}

	// チェック対象とするかどうか
	private boolean isTarget(Class<?> target){
		boolean ret = false;
		if(target != null &&
				!target.isArray() &&
				!target.isPrimitive() &&
				!target.isAssignableFrom(String.class) &&
				!target.isAssignableFrom(Date.class) &&
				!target.isAssignableFrom(Object.class)){
			ret = true;
		}
		return ret;
	}

	// ログインユーザ情報取得
	private UserInformationBean getNewLoginUserInfoBean(UserInfo userInfo) throws TecSystemException {
		UserInformationBean userInfoBean = null;
		try{
			EventManager eventManager = EventManager.getEventManager();
			UserInformationGetEvent event = (UserInformationGetEvent)eventManager.createEvent(
					UcarEventKey.USER_INFO_GET.getApplicationId(), UcarEventKey.USER_INFO_GET.getEventKey(), userInfo);
			event.setEmployeeCd(userInfo.getUserID());
			userInfoBean = (UserInformationBean)eventManager.dispatch(event);
		} catch (SystemException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (ApplicationException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		if(userInfoBean == null){
			userInfoBean = new UserInformationBean();
		}
		return userInfoBean;
	}

}
