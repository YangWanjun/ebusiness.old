package com.toyotec_jp.ucar.batch.daily.datacreate.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb010gBean;

/**
 * <strong>整備売上日報情報作成DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/10/12 新規作成<br>
 * @since 1.00
 * @category [[バッチ：整備売上日報情報作成]]
 */
public interface CreateSeibiUriageNippouDAOIF {

	/**
	 * 処理日付取得処理
	 * @param 	kbBatch   バッチ区分
	 * @throws TecDAOException DAO例外クラス
	 */
	public String selectT220218G(String kbBatch) throws TecDAOException;

	/**
	 * 削除処理（車両搬入情報）
	 * @param 	t220217gBean   整備売上日報情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220217G(Ucbb009gBean t220217gBean) throws TecDAOException;

	/**
	 * 作業区分取得処理
	 * @param 	t220204mBean   コード区分マスタBean
	 * @throws TecDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucba004mBean> selectT220204M(Ucba004mBean t220204mBean) throws TecDAOException;

	/**
	 * 受付車両情報取得処理
	 * @throws TecDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucba001gBean> selectT220201G() throws TecDAOException;

	/**
	 * 新規登録処理（整備売上日報情報）
	 * @param	t220217gBean    整備売上日報情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220217G(Ucbb009gBean t220217gBean) throws TecDAOException;

	/**
	 * 更新処理（整備売上日報情報）
	 * @param	t220217gBean    整備売上日報情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220217G(Ucbb009gBean t220217gBean) throws TecDAOException;

	/**
	 * 作業情報件数取得
	 * <p>
	 * </p>
	 * @param	t220217gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220208GCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg) throws TecDAOException;

	/**
	 * 作業情報件数取得
	 * <p>
	 * </p>
	 * @param	t220217gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220208GSagyoCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg) throws TecDAOException;

	/**
	 * 受注情報件数取得
	 * <p>
	 * </p>
	 * @param	t220217gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220211GCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg) throws TecDAOException;

	/**
	 * 外注仕入情報取得
	 * <p>
	 * </p>
	 * @param	t220217gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectGaityuSiire(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg) throws TecDAOException;

	/**
	 * 売上情報件数取得
	 * <p>
	 * </p>
	 * @param	t220217gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectUriageCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg) throws TecDAOException;

	/**
	 * 売上情報取得
	 * <p>
	 * </p>
	 * @param	t220217gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectUriage(Ucbb009gBean t220217gBean, String ddSyukei) throws TecDAOException;

	/**
	 * 売上作業情報件数取得
	 * <p>
	 * </p>
	 * @param	t220217gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectUriageSagyoCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg, String dataFlg2) throws TecDAOException;

	/**
	 * 更新処理（処理日付情報）
	 * @param	t220218gBean    処理日付情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220218G(Ucbb010gBean t220218gBean) throws TecDAOException;

}
