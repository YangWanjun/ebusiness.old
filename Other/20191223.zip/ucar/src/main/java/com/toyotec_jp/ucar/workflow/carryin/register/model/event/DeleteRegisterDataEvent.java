package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;

/**
 * <strong>登録内容削除イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class DeleteRegisterDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;
	/** 車両搬入情報：データ更新日時(排他チェック用) */
	private String t220001gDtKosin;

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}

	/**
	 * t220001gDtKosinを取得する。
	 * @return t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 */
	public String getT220001gDtKosin() {
		return t220001gDtKosin;
	}

	/**
	 * t220001gDtKosinを設定する。
	 * @param t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 */
	public void setT220001gDtKosin(String t220001gDtKosin) {
		this.t220001gDtKosin = t220001gDtKosin;
	}

}
