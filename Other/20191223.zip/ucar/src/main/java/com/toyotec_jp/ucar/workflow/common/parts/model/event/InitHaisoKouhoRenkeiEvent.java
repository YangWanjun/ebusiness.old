package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>配送候補連携DB操作用イベント(初期表示用)</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/19 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class InitHaisoKouhoRenkeiEvent extends UcarEvent {

	private static final long serialVersionUID = -8975344836334571960L;

	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

	/** 実行アプリID */
	private String executeAppId;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn 販売店コード
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn 販売店コード
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * executeAppIdを取得する。
	 * @return executeAppId
	 */
	public String getExecuteAppId() {
		return executeAppId;
	}

	/**
	 * executeAppIdを設定する。
	 * @param executeAppId
	 */
	public void setExecuteAppId(String executeAppId) {
		this.executeAppId = executeAppId;
	}

}
