package com.toyotec_jp.ucar.batch.monthly;

import java.util.Properties;

import jp.co.intra_mart.foundation.context.Contexts;
import jp.co.intra_mart.foundation.context.model.AccountContext;
import jp.co.intra_mart.foundation.job_scheduler.Job;
import jp.co.intra_mart.foundation.job_scheduler.JobResult;
import jp.co.intra_mart.foundation.job_scheduler.JobSchedulerContext;
import jp.co.intra_mart.foundation.job_scheduler.JobSchedulerManager;
import jp.co.intra_mart.foundation.job_scheduler.JobSchedulerManagerFactory;
import jp.co.intra_mart.foundation.job_scheduler.exception.JobExecuteException;
import jp.co.intra_mart.foundation.job_scheduler.exception.JobSchedulerException;
import jp.co.intra_mart.foundation.job_scheduler.model.job.JobDetail;
import jp.co.intra_mart.foundation.security.exception.AccessSecurityException;
import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventManager;
import jp.co.intra_mart.framework.base.event.EventManagerException;
import jp.co.intra_mart.framework.base.util.ConfigurationUserInfo;

import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.utils.LoginUtils;
import com.toyotec_jp.ucar.batch.common.BatchConst.BatchApplicationId;
import com.toyotec_jp.ucar.batch.common.BatchConst.BatchEventKey;
import com.toyotec_jp.ucar.batch.common.BatchUtils;

/**
 * <strong>月次バッチ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/09/02 新規作成<br>
 * @since 1.00
 * @category [[月次バッチ]]
 */
public class MonthlyBatch implements Job {

	/** バッチ名 データ連携 */
	private static final String BATCH_NAME = "■月次バッチ■";
	/** クラス名 */
	private static final String CLASS_NAME = "MonthlyBatch";
	/** 統合バッチ名：削除処理 */
	private static final String INTEGRATE_DELETE_DATA_BATCH 	= "▼削除処理▼";
	/** 個別バッチ名：データ削除 */
	private static final String DELETE_DATA_BATCH 			= "データ削除処理";
	/** 個別バッチ名：ファイル削除 */
	private static final String DELETE_FILE_BATCH 			= "ファイル削除処理";

	@Override
	public JobResult execute() throws JobExecuteException {
		//========================================================================================
		// ユーザ情報作成
		//========================================================================================
		ConfigurationUserInfo userInfo = new ConfigurationUserInfo();
//		userInfo.setLoginGroupID(arg.getProperty("group"));
        final String tenantId = LoginUtils.getBatchTenantId();
        userInfo.setLoginGroupID(tenantId);
		userInfo.setUserID("SYSTEM");

		boolean monthlyBatchSuccess = true;

		BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 開始");

		try {
			// 削除処理
			if (!deleteBatch(userInfo)) {
				monthlyBatchSuccess = false;
			}
		} catch (Exception e) {
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 異常終了");
			throw new RuntimeException(e.getMessage(),e.getCause());
		}

		// バッチ設定変更処理
		updateBatchManager();

		if(monthlyBatchSuccess){
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 正常終了");
			return JobResult.success(BATCH_NAME + " 正常終了");
		}else{
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 一部処理正常終了");
			return JobResult.waring(BATCH_NAME + " 一部処理正常終了");
		}
	}

	/**
	 * 削除処理
	 * @param userInfo
	 * @throws EventManagerException
	 * @throws TecMessageException
	 */
	private boolean deleteBatch(ConfigurationUserInfo userInfo) throws EventManagerException, TecMessageException {

		BatchUtils.outputInfoLog(CLASS_NAME, INTEGRATE_DELETE_DATA_BATCH + " 開始");

		boolean batchSuccess = true;

		EventManager eventManager = EventManager.getEventManager();
//		try {
//			// データ削除処理
//			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0028", DELETE_DATA_BATCH));
//
//			Event event = eventManager.createEvent(BatchApplicationId.DATA_CLEANING.getApplicationId(),
//													BatchEventKey.DELETE_DATA_CLEANING.getEventKey(),
//													userInfo);
//			eventManager.dispatch(event);
//
//			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0029", DELETE_DATA_BATCH));
//
//		} catch (Exception e) {
//			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0030", DELETE_DATA_BATCH));
//			batchSuccess = false;
//		}

		try {
			// ファイル削除処理
			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0028", DELETE_FILE_BATCH));

			Event event = eventManager.createEvent(BatchApplicationId.FILE_CLEANING.getApplicationId(),
													BatchEventKey.DELETE_FILE_CLEANING.getEventKey(),
													userInfo);
			eventManager.dispatch(event);

			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0029", DELETE_FILE_BATCH));

		} catch (Exception e) {
			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0030", DELETE_FILE_BATCH));
			batchSuccess = false;
		}

		if (batchSuccess) {
			BatchUtils.outputInfoLog(CLASS_NAME, INTEGRATE_DELETE_DATA_BATCH + " 正常終了");
		} else {
			BatchUtils.outputInfoLog(CLASS_NAME, INTEGRATE_DELETE_DATA_BATCH + " 一部処理正常終了");
		}

		return batchSuccess;
	}

	/**
	 * バッチ設定変更処理
	 * @param arg
	 */
	private void updateBatchManager() {

		try {
			JobSchedulerManager batchMng = JobSchedulerManagerFactory.getJobSchedulerManager();
			// バッチ情報取得
			JobDetail batchInfo = batchMng.findJob("MonthlyBatch");	// バッチID
			// バッチ実行を無効に設定
//			batchInfo.setValidate(false);

			// バッチ情報更新
			batchMng.updateJob(batchInfo);

		} catch (JobSchedulerException e) {
			// 処理なし
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " バッチ設定変更 異常終了");
		}
	}
}