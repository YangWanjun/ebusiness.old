package com.toyotec_jp.ucar.workflow.common.parts;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.intra_mart.framework.base.event.EventManager;
import jp.co.intra_mart.framework.base.util.UserInfo;
import jp.co.intra_mart.framework.base.util.UserInfoException;
import jp.co.intra_mart.framework.base.util.UserInfoUtil;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarEventKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.KyoutuTenpoDBEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.KyoutuTenpoDBBean;

/**
 * <strong>共通店舗リスト管理</strong>
 * <p>
 * 共通店舗をリスト化し管理する。
 * </p>
 * @author H.T(TEC)
 * @version 1.00 2011/09/12 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class KyoutuTenpoListManager {

	/** データのキャッシュ時間（ミリ秒）：5秒 */
	private static final long CACHE_TIME = 5000;

	private static List<KyoutuTenpoDBBean> kyoutuTenpoList = new ArrayList<KyoutuTenpoDBBean>();
	/** 現在日時（共通店舗リスト取得日時） */
	private static Date currentDate;

	/**
	 * 共通店舗リスト取得
	 * <pre>
	 * 共通店舗リストを取得する。<br>
	 * </pre>
	 * @param req リクエスト
	 * @param res レスポンス
	 * @return 共通店舗リスト
	 * @throws TecSystemException
	 */
	public static List<KyoutuTenpoDBBean> getKyoutuTenpoList(HttpServletRequest req, HttpServletResponse res) throws TecSystemException {
		UserInfo userInfo = null;
		try {
			userInfo = UserInfoUtil.createUserInfo(req, res);
		} catch (UserInfoException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}

		long differentTime = 0;
		if (currentDate != null) {
			// 既にデータを取得している場合は、経過時間を算出
			differentTime = new Date().getTime() - currentDate.getTime();
		}

		// 2013.11.25 T.Hayato 修正 キャッシュ機能削除 start
		//if (differentTime > CACHE_TIME || currentDate == null) {

			// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
			UcarSessionManager sessionMng = UcarSessionManager.getInstance();
			LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(req, userInfo);
			String cdKaisya 	= loginSessionBean.getUserInfoBean().getCdKaisya();
			String cdHanbaitn 	= loginSessionBean.getUserInfoBean().getCdHanbaitn();

			// データキャッシュ時間を超えている、あるいは新規取得の場合実行
			kyoutuTenpoList = getKyoutuTenpoList(userInfo, cdKaisya, cdHanbaitn);
			// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end
			currentDate = DateUtils.getCurrentDate();
		//}
		// 2013.11.25 T.Hayato 修正 キャッシュ機能削除 end

		return kyoutuTenpoList;
	}

	/**
	 * 共通店舗リスト取得
	 * <pre>
	 * 共通店舗リストを取得する。<br>
	 * </pre>
	 * @param userInfo ユーザ情報
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @return 共通店舗リスト
	 * @throws TecSystemException
 	 */
	@SuppressWarnings("unchecked")
	private static List<KyoutuTenpoDBBean> getKyoutuTenpoList(UserInfo userInfo, String cdKaisya, String cdHanbaitn) throws TecSystemException {

		ResultArrayList<KyoutuTenpoDBBean> result;

		try {
			EventManager eventManager = EventManager.getEventManager();
			KyoutuTenpoDBEvent event = (KyoutuTenpoDBEvent)eventManager.createEvent(UcarEventKey.KYOUTU_TENPO_LIST.getApplicationId(),
																					UcarEventKey.KYOUTU_TENPO_LIST.getEventKey(),
																					userInfo);

			event.setCdKaisya(cdKaisya);
			event.setCdHanbaitn(cdHanbaitn);

			result = (ResultArrayList<KyoutuTenpoDBBean>)eventManager.dispatch(event);

		} catch (ApplicationException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (SystemException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		return result;
	}

}
