package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckParamBean;

/**
 * <strong>作業仕分取得イベント。</strong>
 * <p>
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/24 新規作成<br>
 * @since 1.00
 * @category [[作業仕分]]
 */
public class GetWorkSortDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;

	/** ページ番号 */
	private String pageNo;
	/** 一覧の最大表示件数 */
	private String pageSize;
	/** ソート順(asc/desc) */
	private String sortOrder;
	/** ソートキー */
	private String sortParam;

	/** 絞り込み検索
	 * <pre>
	 * true:絞り込み検索実行
	 * false:絞り込み検索未実行
	 * </pre>
	 * */
	private boolean isNarrowSearch;

	/** 入庫検査／作業仕分画面検索情報Bean */
	private CarCheckParamBean carCheckParamBean;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo
	 */
	public String getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @param pageNo
	 */
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize
	 */
	public String getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize
	 */
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * sortOrderを取得する。
	 * @return sortOrder
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * sortOrderを設定する。
	 * @param sortOrder
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * sortParamを取得する。
	 * @return sortParam
	 */
	public String getSortParam() {
		return sortParam;
	}

	/**
	 * sortParamを設定する。
	 * @param sortParam
	 */
	public void setSortParam(String sortParam) {
		this.sortParam = sortParam;
	}

	/**
	 * isNarrowSearchを取得する。
	 * @return isNarrowSearch
	 */
	public boolean isNarrowSearch() {
		return isNarrowSearch;
	}

	/**
	 * isNarrowSearchを設定する。
	 * @param isNarrowSearch
	 */
	public void setNarrowSearch(boolean isNarrowSearch) {
		this.isNarrowSearch = isNarrowSearch;
	}

	/**
	 * carCheckParamBeanを取得する。
	 * @return carCheckParamBean
	 */
	public CarCheckParamBean getCarCheckParamBean() {
		return carCheckParamBean;
	}

	/**
	 * carCheckParamBeanを設定する。
	 * @param carCheckParamBean
	 */
	public void setCarCheckParamBean(CarCheckParamBean carCheckParamBean) {
		this.carCheckParamBean = carCheckParamBean;
	}

}
