package com.toyotec_jp.ucar.batch.monthly.filecleaning.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.batch.common.BatchUtils;
import com.toyotec_jp.ucar.workflow.report.common.ReportUtils;

/**
 * <strong>ファイル削除イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/08 新規作成<br>
 * @since 1.00
 * @category [[バッチ：ファイル削除]]
 */
public class FileCleaningEventListener extends UcarEventListener {

	/** クラス名 */
	private static final String CLASS_NAME = "FileCleaningEventListener";

	/**
	 * イベントに対する処理です。
	 *
	 * @param event イベント
	 * @return イベント処理結果
	 * @throws SystemException システム例外が発生
	 * @throws ApplicationException アプリケーション例外が発生
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		ReportUtils.deleteFileDirectory(ReportUtils.OUTPUT_DIR_DIRECT_PDF);
		BatchUtils.outputInfoLog(CLASS_NAME, "帳票出力：PDF直接印刷用フォルダ削除");

		ReportUtils.deleteFileDirectory(ReportUtils.OUTPUT_DIR_EXCEL);
		BatchUtils.outputInfoLog(CLASS_NAME, "帳票出力：Excel用フォルダ削除");

		ReportUtils.deleteFileDirectory(ReportUtils.OUTPUT_DIR_CSV);
		BatchUtils.outputInfoLog(CLASS_NAME, "帳票出力：CSV用フォルダ削除");

		return null;
	}

}