/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】MethodInfoBean.java
 * 【  説  明  】
 * 【  作  成  】2010/08/11 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.model.object;

import java.lang.reflect.Method;

/**
 * <strong>メソッド情報ビーン。</strong>
 * <p>
 * ReflectionUtils用。<br>
 * シリアライズ不可のため注意。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/08/11 新規作成<br>
 * @since 1.00
 */
public class MethodInfoBean {

	private Class<?> fieldType;

	private String fieldName;

	private String columnName;

	private Method method;

	/**
	 * fieldTypeを取得する。
	 * @return fieldType
	 */
	public Class<?> getFieldType() {
		return fieldType;
	}

	/**
	 * fieldTypeを設定する。
	 * @param fieldType
	 */
	public void setFieldType(Class<?> fieldType) {
		this.fieldType = fieldType;
	}

	/**
	 * fieldNameを取得する。
	 * @return fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * fieldNameを設定する。
	 * @param fieldName
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * columnNameを取得する。
	 * @return columnName
	 */
	public String getColumnName() {
		return columnName;
	}

	/**
	 * columnNameを設定する。
	 * @param columnName
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * methodを取得する。
	 * @return method
	 */
	public Method getMethod() {
		return method;
	}

	/**
	 * methodを設定する。
	 * @param method
	 */
	public void setMethod(Method method) {
		this.method = method;
	}

}
