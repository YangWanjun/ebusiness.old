/**
 * 車両搬出登録データビーン関連パッケージ
 * @version 1.00 2011/08/02 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.carryout.register.model.object;
