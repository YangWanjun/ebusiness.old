package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentRuisekiDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb004gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb005gBean;

/**
 * <strong>売上精算DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public interface SalesAdjustmentDAOIF {

	/**
	 * 受注情報取得
	 * @param	t220211gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public SalesAdjustmentDataBean selectT220211G(Ucbb001gBean t220211gBean) throws TecDAOException;

	/**
	 * 外注仕入情報取得
	 * <p>
	 * 外注仕入情報に仕入日がセットされていないものが存在する件数を取得する
	 * </p>
	 * @param	t220211gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220213GCount(Ucbb001gBean t220211gBean) throws TecDAOException;

	/**
	 * 受注明細情報取得
	 * <p>
	 * 受注明細情報に売上科目区分がセットされてないものが存在する件数を取得する
	 * </p>
	 * @param	t220211gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220212GCount(Ucbb001gBean t220211gBean) throws TecDAOException;

	/**
	 * 外注仕入情報取得
	 * <p>
	 * 外注仕入情報の伝票NOのリストを取得する
	 * </p>
	 * @param	t220212gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucbb003gBean> selectT220213GNoDenpyo(Ucbb002gBean t220212gBean) throws TecDAOException;

	/**
	 * 外注仕入情報取得
	 * <p>
	 * 外注仕入情報の仕入金額、消費税を取得する
	 * </p>
	 * @param	t220212gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public Ucbb003gBean selectT220213GKingaku(Ucbb003gBean t220213gBean) throws TecDAOException;

	/**
	 * 売上科目別金額取得
	 * <p>
	 * 受注明細情報の売価、原価を取得する
	 * </p>
	 * @param	t220212gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public Ucbb002gBean selectT220212GSumKingaku(Ucbb002gBean t220212gBean, boolean addWhereKbSyanai) throws TecDAOException;

	/**
	 * 消費税取得
	 * <p>
	 * </p>
	 * @param	t220211gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public Ucbb002gBean selectT220212GSumKiTax(Ucbb001gBean t220211gBean) throws TecDAOException;

	/**
	 * 売上精算情報取得
	 * <p>
	 * 受注情報の精算日が入力されている場合に使用する
	 * </p>
	 * @param	t220211gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public SalesAdjustmentDataBean selectT220214G(Ucbb001gBean t220211gBean) throws TecDAOException;

	/**
	 * 更新処理（受注明細情報）
	 * @param	t220212gBean    受注明細情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220212GKbUrikamo(Ucbb002gBean t220212gBean) throws TecDAOException;

	/**
	 * 新規登録処理（売上精算情報）
	 * @param	t220214gBean    売上精算情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220214g(Ucbb004gBean t220214gBean) throws TecDAOException;

	/**
	 * 連番 最大値取得
	 * <pre>
	 * データが存在しない場合はnullを返す
	 * </pre>
	 * @param	t220214gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public String selectT220214GMaxNoRenban(Ucbb004gBean t220214gBean) throws TecDAOException;

	/**
	 * コード区分マスタ取得
	 * <pre>
	 * 売掛金管理区分を取得する
	 * </pre>
	 * @param	t220214gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public String selectUcba004GKbUrikake(Ucba004mBean ucba004gBean) throws TecDAOException;

	/**
	 * 更新処理（受注情報）
	 * @param	t220211gBean    受注情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220211GDdSeisan(Ucbb001gBean t220211gBean) throws TecDAOException;

	/**
	 * 売上精算情報取得
	 * <p>
	 * 件数を取得する
	 * </p>
	 * @param	t220211gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectT220214GCount(Ucbb001gBean t220211gBean) throws TecDAOException;

	/**
	 * 売上精算情報 仕訳区分/売上科目区分 売価算出取得
	 * <p>
	 * </p>
	 * @param	t220212gBean
	 * @param	kbSyanaiIsNull	true:社内区分がnullのデータを検索する場合/false:社内区分に対する追加条件を付加しない
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<SalesAdjustmentRuisekiDataBean> selectT220212GSumKiBaika(Ucbb002gBean t220212gBean,
																					boolean kbSyanaiIsNull) throws TecDAOException;

	/**
	 * コード区分マスタ取得
	 * <p>
	 * 仕訳区分を取得する
	 * </p>
	 * @param	t220214gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucba004mBean> selectT220204MCdKubun(Ucbb002gBean t220212gBean) throws TecDAOException;

	/**
	 * 新規登録処理（売上集計累積情報）
	 * @param	t220215gBean    売上集計累積情報Bean
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220215g(Ucbb005gBean t220215gBean) throws TecDAOException;

	/**
	 * 連番 最大値取得
	 * <pre>
	 * データが存在しない場合はnullを返す
	 * </pre>
	 * @param	t220215gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public String selectT220215GMaxNoRenban(Ucbb005gBean t220215gBean) throws TecDAOException;

	/**
	 * 売上精算情報 売上集計累積情報対象データ取得
	 * <p>
	 * </p>
	 * @param	t220212gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<SalesAdjustmentRuisekiDataBean> selectT220212G(Ucbb002gBean t220212gBean) throws TecDAOException;

	/**
	 * 売上集計累積情報 キャンセル対象データ取得
	 * <p>
	 * </p>
	 * @param	t220212gBean
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucbb005gBean> selectT220215GCancel(Ucbb005gBean t220215gBean) throws TecDAOException;

}