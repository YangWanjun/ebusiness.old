package com.toyotec_jp.ucar.workflow.carryin.list.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>車両搬入一覧登録イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/04 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class RegisterListDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 会社コード */
	private String[] cdKaisya;
	/** 販売店コード */
	private String[] cdHanbaitn;
	/** 搬入日 */
	private String[] ddHannyu;
	/** 管理番号 */
	private String[] noKanri;
	/** ai21車両№ */
	private String[] noSyaryou;
	/** ai21車両№(変更前) */
	private String[] beforeNoSyaryou;


	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya
	 */
	public String[] getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya
	 */
	public void setCdKaisya(String[] cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn
	 */
	public String[] getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn
	 */
	public void setCdHanbaitn(String[] cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * ddHannyuを取得する。
	 * @return ddHannyu
	 */
	public String[] getDdHannyu() {
		return ddHannyu;
	}

	/**
	 * ddHannyuを設定する。
	 * @param ddHannyu
	 */
	public void setDdHannyu(String[] ddHannyu) {
		this.ddHannyu = ddHannyu;
	}

	/**
	 * noKanriを取得する。
	 * @return noKanri
	 */
	public String[] getNoKanri() {
		return noKanri;
	}

	/**
	 * noKanriを設定する。
	 * @param noKanri
	 */
	public void setNoKanri(String[] noKanri) {
		this.noKanri = noKanri;
	}

	/**
	 * noSyaryouを取得する。
	 * @return noSyaryou
	 */
	public String[] getNoSyaryou() {
		return noSyaryou;
	}

	/**
	 * noSyaryouを設定する。
	 * @param noSyaryou
	 */
	public void setNoSyaryou(String[] noSyaryou) {
		this.noSyaryou = noSyaryou;
	}

	/**
	 * beforeNoSyaryouを取得する。
	 * @return beforeNoSyaryou
	 */
	public String[] getBeforeNoSyaryou() {
		return beforeNoSyaryou;
	}

	/**
	 * beforeNoSyaryouを設定する。
	 * @param beforeNoSyaryou
	 */
	public void setBeforeNoSyaryou(String[] beforeNoSyaryou) {
		this.beforeNoSyaryou = beforeNoSyaryou;
	}

}