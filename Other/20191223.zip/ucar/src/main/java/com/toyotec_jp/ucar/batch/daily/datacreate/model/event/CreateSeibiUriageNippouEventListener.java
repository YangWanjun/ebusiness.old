package com.toyotec_jp.ucar.batch.daily.datacreate.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.TecApplicationManager.TecConfigKey;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.batch.common.BatchConst;
import com.toyotec_jp.ucar.batch.common.BatchUtils;
import com.toyotec_jp.ucar.batch.common.BatchConst.BatchDAOKey;
import com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb010gBean;

/**
 * <strong>整備売上日報情報作成イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/10/12 新規作成<br>
 * @since 1.00
 * @category [[バッチ：整備売上日報情報作成]]
 */
public class CreateSeibiUriageNippouEventListener extends UcarEventListener {

	/** 区分ID：作業区分 */
	private static final String KB_ID_KB_SAGYO = "01";
	/** バッチ区分：J1 */
	private static final String KB_BATCH_J1 = "J1";
	/** クラス名 */
	private static final String CLASS_NAME = "CreateSeibiUriageNippouEventListener";

	/**
	 * イベントに対する処理です。
	 *
	 * @param event イベント
	 * @return イベント処理結果
	 * @throws SystemException システム例外が発生
	 * @throws ApplicationException アプリケーション例外が発生
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = "J1_BATCH";
		String updateAppId 	= "UCBB105P";

		// DAOの取得
		CreateSeibiUriageNippouDAOIF executeDao
			= (CreateSeibiUriageNippouDAOIF) getDAO(BatchDAOKey.DATA_SEIBIURIAGENIPPOU_DAO.getApplicationId(),
													BatchDAOKey.DATA_SEIBIURIAGENIPPOU_DAO.getDAOKey(),
													TecApplicationManager.getConfigValue(TecConfigKey.SHAREE_DB_SCHEMA));

		String ddSyukei = executeDao.selectT220218G(KB_BATCH_J1);
		BatchUtils.outputInfoLog(CLASS_NAME,  "集計対象は『" + UcarUtils.getStringDateFormatShort(ddSyukei) + "』です。");

		SimpleExecuteResultBean resultBean = null;

		Ucbb009gBean deleteUcbb009gBean = new Ucbb009gBean();
		// 集計日
		deleteUcbb009gBean.setDdSyukei(ddSyukei);

		// 削除処理(整備売上日報情報)
		resultBean = executeDao.deleteT220217G(deleteUcbb009gBean);
		BatchUtils.outputInfoLog(CLASS_NAME, "整備売上日報情報(T220217G)", "削除", resultBean.getExecuteCount());


		ResultArrayList<Ucba001gBean> t220201gList = executeDao.selectT220201G();

		Ucbb009gBean insertUcbb009gBean = new Ucbb009gBean();
		// 集計日
		insertUcbb009gBean.setDdSyukei(ddSyukei);

		for (Ucba001gBean t220201gBean : t220201gList) {

			// 会社コード
			insertUcbb009gBean.setCdKaisya(t220201gBean.getCdKaisya());
			// 事業所コード
			insertUcbb009gBean.setCdJigyosyo(t220201gBean.getCdJigyosyo());
			// 販売店コード
			insertUcbb009gBean.setCdHanbaitn(t220201gBean.getCdHanbaitn());

			// データ作成日時
			insertUcbb009gBean.setDtSakusei(executeDate);
			// データ更新日時
			insertUcbb009gBean.setDtKosin(executeDate);
			// 作成ユーザID
			insertUcbb009gBean.setCdSksisya(updateUserId);
			// 更新ユーザID
			insertUcbb009gBean.setCdKsnsya(updateUserId);
			// 作成アプリID
			insertUcbb009gBean.setCdSksiapp(updateAppId);
			// 更新アプリID
			insertUcbb009gBean.setCdKsnapp(updateAppId);

			Ucba004mBean t220204mBean = new Ucba004mBean(t220201gBean.getCdKaisya(),
														t220201gBean.getCdJigyosyo(),
														KB_ID_KB_SAGYO);
			ResultArrayList<Ucba004mBean> cdKubunList = executeDao.selectT220204M(t220204mBean);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
			Ucba004mBean t220204mBeanCdKubun = new Ucba004mBean();
			t220204mBeanCdKubun.setCdKubun("10");
			cdKubunList.add(t220204mBeanCdKubun);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end			
			for (Ucba004mBean cdKubunBean : cdKubunList) {
				// 作業区分
				insertUcbb009gBean.setKbSagyo(cdKubunBean.getCdKubun());

				executeDao.insertT220217G(insertUcbb009gBean);
			}
		}

		Ucbb009gBean updateUcbb009gBean = new Ucbb009gBean();
		// 集計日
		updateUcbb009gBean.setDdSyukei(ddSyukei);
		int executeCount = 0;
		for (Ucba001gBean t220201gBean : t220201gList) {
			// 会社コード
			updateUcbb009gBean.setCdKaisya(t220201gBean.getCdKaisya());
			// 事業所コード
			updateUcbb009gBean.setCdJigyosyo(t220201gBean.getCdJigyosyo());
			// 販売店コード
			updateUcbb009gBean.setCdHanbaitn(t220201gBean.getCdHanbaitn());

			Ucba004mBean t220204mBean = new Ucba004mBean(t220201gBean.getCdKaisya(),
														t220201gBean.getCdJigyosyo(),
														KB_ID_KB_SAGYO);
			ResultArrayList<Ucba004mBean> cdKubunList = executeDao.selectT220204M(t220204mBean);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
			Ucba004mBean t220204mBeanCdKubun = new Ucba004mBean();
			t220204mBeanCdKubun.setCdKubun("10");
			cdKubunList.add(t220204mBeanCdKubun);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end			

			for (Ucba004mBean cdKubunBean : cdKubunList) {
				// 作業区分
				updateUcbb009gBean.setKbSagyo(cdKubunBean.getCdKubun());

				// 作業受付台数
				updateUcbb009gBean.setSuSagyouke(executeDao.selectT220208GCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_SAGYOUKE));

				// 作業仕掛台数
				updateUcbb009gBean.setSuSagyosika(executeDao.selectT220208GCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_SAGYOSIKA));

				// 作業完成台数
				updateUcbb009gBean.setSuSagyokan(executeDao.selectT220208GCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_SAGYOKAN));

				// ヘッドライトクリーニング台数
				updateUcbb009gBean.setSuHeadlight(executeDao.selectT220208GSagyoCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_HEADLIGHT));

				// BP簡易台数
				updateUcbb009gBean.setSuBpkani(executeDao.selectT220208GSagyoCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_BPKANI));

				// 手直し件数
				updateUcbb009gBean.setSuTenaosi(executeDao.selectT220208GCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_TENAOSI));

				// 受注件数
				int suJucyu = executeDao.selectT220211GCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_JUCYU);
				int suJucyuCancel = executeDao.selectT220211GCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_JUCYU_CANCEL);
				updateUcbb009gBean.setSuJucyu(suJucyu - suJucyuCancel);

				// 外注仕入金額
				updateUcbb009gBean.setKiGaisiire(executeDao.selectGaityuSiire(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_KI_GAISIIRE));

				// 外注仕掛金額
				updateUcbb009gBean.setKiGaisika(executeDao.selectGaityuSiire(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_KI_GAISIKA));

				// 仕掛件数
				updateUcbb009gBean.setSuSikakari(executeDao.selectT220211GCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_SIKAKARI));

				// 売上件数
				int suUriage = executeDao.selectUriageCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_URIAGE);
				int suUriageCancel = executeDao.selectUriageCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_URIAGE_CANCEL);
				updateUcbb009gBean.setSuUriage(suUriage - suUriageCancel);

				// 売上金額
				updateUcbb009gBean.setKiUriage(executeDao.selectUriage(updateUcbb009gBean, ddSyukei));

				// 売上ヘッドライトクリーニング台数
				int suUrihead = executeDao.selectUriageSagyoCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_URIAGE , BatchConst.DATA_FLG_SU_HEADLIGHT);
				int suUriheadCancel = executeDao.selectUriageSagyoCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_URIAGE_CANCEL, BatchConst.DATA_FLG_SU_HEADLIGHT);
				updateUcbb009gBean.setSuUrihead(suUrihead - suUriheadCancel);

				// 売上BP簡易台数
				int suUribpkn = executeDao.selectUriageSagyoCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_URIAGE , BatchConst.DATA_FLG_SU_BPKANI);
				int suUribpknCancel = executeDao.selectUriageSagyoCount(updateUcbb009gBean, ddSyukei, BatchConst.DATA_FLG_SU_URIAGE_CANCEL, BatchConst.DATA_FLG_SU_BPKANI);
				updateUcbb009gBean.setSuUribpkn(suUribpkn - suUribpknCancel);

				executeDao.updateT220217G(updateUcbb009gBean);
				executeCount++;
			}
		}
		BatchUtils.outputInfoLog(CLASS_NAME, "整備売上日報情報(T220217G)", "追加", executeCount);

		Ucbb010gBean t220218gBean = new Ucbb010gBean();
		// バッチ区分
		t220218gBean.setKbBatch(KB_BATCH_J1);
		// 日付1
		t220218gBean.setDdDate1(UcarUtils.getAdjustDate(ddSyukei, 1));
		// 日付2
		t220218gBean.setDdDate2(ddSyukei);

		// データ更新日時
		t220218gBean.setDtKosin(executeDate);
		// 更新ユーザID
		t220218gBean.setCdKsnsya(updateUserId);
		// 更新アプリID
		t220218gBean.setCdKsnapp(updateAppId);

		SimpleExecuteResultBean executeResultBean = executeDao.updateT220218G(t220218gBean);
		BatchUtils.outputInfoLog(CLASS_NAME, "処理日付情報(T220218G)", "更新", executeResultBean.getExecuteCount());

		return null;
	}

}