package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinUtils;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetDdSiireEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetDdSiireEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;

/**
 * <strong>登録イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterDataEventListener extends UcarEventListener {

	private String InitialParam = "com.toyotec_jp.ucar.workflow.carryin.InitialNumber";
	private String LimitParam = "com.toyotec_jp.ucar.workflow.carryin.LimitNumber";
	
	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		TecLogger.trace("insert registerData start");

		RegisterDataEvent targetEvent = (RegisterDataEvent) event;

		// DAOIF取得
		RegisterDAOIF dao = getDAO(CarryinDAOKey.REGISTER_DAO, targetEvent, RegisterDAOIF.class);

		RegisterInputBean registerInputBean = targetEvent.getRegisterInputBean();

		// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　start
		// フレーム№存在チェック
		ResultArrayList<Ucaa001gBean> t220001gList = null;

		// 2014.10.20 H.Yamashita 障害票278対応 販売店コードを条件に追加 start
		t220001gList = dao.selectCdHantenpo(registerInputBean.getNoSyadai(),
//													targetEvent.getUserInfoBean().getKbScenter());
													targetEvent.getUserInfoBean().getKbScenter(),
/*--2019.3.20 from
													targetEvent.getUserInfoBean().getCdHanbaitn());
*/
													registerInputBean.getCdTenpoHanbaitnSel());
//--2019.3.20 to
		// 2014.10.20 H.Yamashita 障害票278対応 販売店コードを条件に追加 end
				

		if (t220001gList.size() != 0) {
			// 存在する場合、エラー
			String kjTentanms = dao.selectKjTentanms(registerInputBean.getCdKaisya(),
													registerInputBean.getCdHanbaitn(),
													t220001gList.get(0).getCdHantenpo());
			throw new TecExclusionException("この車両は（" + kjTentanms + "）での搬出処理が完了していません。搬出処理を行うよう、連絡してください。");	
		}
		// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　end

		String noKanri = dao.selectNoKanriMax(registerInputBean.getCdKaisya(),
/*--2019.3.20 from				
											registerInputBean.getCdHanbaitn(),
*/
											registerInputBean.getCdTenpoHanbaitnSel(),
//--2019.3.20 to
											registerInputBean.getDdHannyu()
// 2014.7.18 H.Yamashita add start P相模原 連番対応								
											,targetEvent.getUserInfoBean().getKbScenter()
// 2014.7.18 H.Yamashita add end P相模原 連番対応
//--2019.3.20 from
											,targetEvent.getUserInfoBean().getKbGyohan()
											,targetEvent.getUserInfoBean().getCdTenpo()
//--2019.3.20 to											
		);

// 2014.7.18 H.Yamashita add start P相模原 連番対応	
		
		String nextNoKanri = createNoKanri(noKanri,
/*--2019.3.20 from				
											registerInputBean.getCdHanbaitn()
*/
											registerInputBean.getCdTenpoHanbaitnSel()
//--2019.3.20 to
											,targetEvent.getUserInfoBean().getKbScenter()
//--2019.3.20 from											
											,targetEvent.getUserInfoBean().getKbGyohan()
											,targetEvent.getUserInfoBean().getCdTenpo()
//--2019.3.20 to											
							);
		
		// String nextNoKanri = createNoKanri(noKanri);
		
// 2014.7.18 H.Yamashita add start P相模原 連番対応	
// 2015.03.17 Y.Negishi U-Car帳票改善 add start
		String kbScenter = targetEvent.getUserInfoBean().getKbScenter();
/*--2019.3.20 from
		int noKanriHantenStartInt = Integer.parseInt(UcarConst.NO_KANRI_HANTEN_START);
*/
		String kbGyohan = targetEvent.getUserInfoBean().getKbGyohan();
		
		String limitVal = "";
		
		if (UcarConst.WCOROLLA.equals(registerInputBean.getCdTenpoHanbaitnSel())) {
			LimitParam += ".CW";
			limitVal = UcarApplicationManager.getConfigValue(LimitParam+".shop");
			
		}else{
			LimitParam += ".TMT";
			if (UcarConst.KB_SCENTER_SCENTER.equals(kbScenter)) {
				// ログインユーザが商品化センターの場合
				switch(HannyuTenpoEtc.getEnumName(targetEvent.getUserInfoBean().getCdTenpo()))
				{
					case SagamiAG:
						limitVal = UcarApplicationManager.getConfigValue(LimitParam+".SagamiAG");
						break;
					case SagamiBG:
						limitVal = UcarApplicationManager.getConfigValue(LimitParam+".SagamiBG");
						break;
					case KatushimaG:
						limitVal = UcarApplicationManager.getConfigValue(LimitParam+".KatushimaG");
						break;
					case FuchuuG:
						limitVal = UcarApplicationManager.getConfigValue(LimitParam+".FuchuuG");
						break;
					case AdachiG:
						limitVal = UcarApplicationManager.getConfigValue(LimitParam+".AdachiG");
						break;
					case Others:
						throw new TecExclusionException("所定の搬入店舗以外は不可です");
				}

			} else if(UcarConst.KB_GYOHAN.equals(kbGyohan)){
				// ログインユーザが業販店舗の場合
				limitVal = UcarApplicationManager.getConfigValue(LimitParam+".gyohan");
			} else {
				// ログインユーザがU-Car店舗の場合
				limitVal = UcarApplicationManager.getConfigValue(LimitParam+".shop");
			}
			
		}
		
		int noKanriHantenStartInt = Integer.parseInt(limitVal);

//--2019.3.20 to		
		int nextNoKanriInt = Integer.parseInt(nextNoKanri);
/*--2019.3.22 from		
		if(UcarConst.TOYOPET.equals(registerInputBean.getCdHanbaitn()) && UcarConst.KB_SCENTER_SCENTER.equals(kbScenter)){
*/
			if(noKanriHantenStartInt <= nextNoKanriInt){
				throw new TecExclusionException("1日の搬入車両の許容台数を超えました。搬入できません。");	
			}
/*--2019.3.20
   		}
 */
// 2015.03.17 Y.Negishi U-Car帳票改善 add end		
		registerInputBean.setNoKanri(nextNoKanri);

		RegisterDataEventResult eventResult = new RegisterDataEventResult();
		// 帳票出力時に管理番号を使用するためリザルトで戻す
		eventResult.setNoKanri(nextNoKanri);

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarryinConst.APPID_CARRYIN_REGISTER;

		registerInputBean.setCdSksisya(updateUserId);
		registerInputBean.setCdKsnsya(updateUserId);
		registerInputBean.setCdSksiapp(updateAppId);
		registerInputBean.setCdKsnapp(updateAppId);

		// 2013.05.20 T.Hayato 追加 ai21仕入日取得のため start
		// ai21仕入日取得
		GetDdSiireEvent executeEvent = createEvent(UcarEventKey.GET_DD_SIIRE,
													targetEvent.getUserInfo(),
													GetDdSiireEvent.class);

		executeEvent.setCdKaisya(registerInputBean.getCdKaisya());
		executeEvent.setCdHanbaitn(registerInputBean.getCdHanbaitn());
		executeEvent.setNoSyaryou(registerInputBean.getNoSyaryou());

		GetDdSiireEventResult executeResult = (GetDdSiireEventResult)dispatchEvent(executeEvent);
		registerInputBean.setDdSiire(executeResult.getDdSiire());
		// 2013.05.20 T.Hayato 追加 ai21仕入日取得のため end

		try {
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			dao.insertSyaryoHannyu(registerInputBean,
									targetEvent.getUserInfoBean().getKbScenter(),
									executeDate);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		} catch (TecDAOException e) {
			if (e.getMessage().indexOf("ORA-00001") != -1) {
				// 一意キー制約の場合は排他制御としてエラーをthrow
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
			} else {
				throw e;
			}
		}

		if (registerInputBean.getArrayKbSiire() != null) {
			// 仕入種別のチェック数だけ処理を実行
			for (String kbSiire : registerInputBean.getArrayKbSiire()) {
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
				dao.insertT220002G(registerInputBean,
									targetEvent.getUserInfoBean().getKbScenter(),
									kbSiire,
									executeDate);
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
			}
		}

		if (registerInputBean.getArrayKbCheck() != null) {
			String ddCheck = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
			// チェック内容のチェック数だけ処理を実行
			for (String kbCheck : registerInputBean.getArrayKbCheck()) {
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
				dao.insertT220003G(registerInputBean,
									targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
									targetEvent.getUserInfoBean().getKbScenter(),
									kbCheck,
									ddCheck,
									executeDate);
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
			}
		}

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		if (UcarConst.KB_SCENTER_SCENTER.equals(targetEvent.getUserInfoBean().getKbScenter())) {
			// 商品化センターの場合は実行する

			// 書類チェックDB作成処理
			insertT220007G(targetEvent, dao, executeDate);
		}
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// ステータスDB作成処理
		insertT220012G(targetEvent, dao, executeDate);
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		TecLogger.trace("insert registerData end");
		return eventResult;
	}

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/**
	 * ステータスDB作成処理
	 * @param targetEvent
	 * @param dao
	 * @param executeDate
	 * @throws TecDAOException
	 */
	private void insertT220012G(RegisterDataEvent targetEvent,
									RegisterDAOIF dao,
									Timestamp executeDate) throws TecDAOException {

//		T220012gInputDataBean t220012gInputDataBean = new T220012gInputDataBean(targetEvent.getRegisterInputBean().getCdKaisya(),
		Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(targetEvent.getRegisterInputBean().getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
/*--2019.3.20 from				
																				  targetEvent.getRegisterInputBean().getCdHanbaitn(),
*/
																				  targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
//--2019.3.20 to
																				  targetEvent.getRegisterInputBean().getDdHannyu(),
																				  targetEvent.getRegisterInputBean().getNoKanri(),
																				  // 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																				  targetEvent.getUserInfoBean().getCdTenpo(),
																				  targetEvent.getUserInfoBean().getKbScenter(),
																				  // 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																				  targetEvent.getRegisterInputBean().getCdSksisya(),
																				  targetEvent.getRegisterInputBean().getCdKsnsya(),
																				  targetEvent.getRegisterInputBean().getCdSksiapp(),
																				  targetEvent.getRegisterInputBean().getCdKsnapp());

		boolean existKbSiire[] = CarryinUtils.existKbSiire(targetEvent.getRegisterInputBean());
		boolean existSitadori 	= existKbSiire[0];
		boolean existKaitori 	= existKbSiire[1];
		boolean existAuction 	= existKbSiire[2];

		String strDtStatus = UcarUtils.getCurrentDateFormatLongSpace(targetEvent.getRegisterInputBean().getDdHannyu());

		t220012gInputDataBean.setStrDtStatus01(strDtStatus);

		if (existSitadori || !UcarConst.KB_SCENTER_SCENTER.equals(targetEvent.getUserInfoBean().getKbScenter())) {
			// 下取、ログインユーザーが商品化センターではない場合⇒特になし
		} else if (existKaitori || existAuction) {
			// 買取・オークションの場合⇒ステータス04に日付を設定
			t220012gInputDataBean.setStrDtStatus04(strDtStatus);
		} else {
			// それ以外の場合⇒ステータス03に日付を設定
			t220012gInputDataBean.setStrDtStatus03(strDtStatus);
		}

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// ステータスＤＢ 2011.10.29 H.Yamashita add
		dao.insertT220012G(t220012gInputDataBean,
				            targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),  // 2019.04.04 T.Osada 
							targetEvent.getUserInfoBean().getKbScenter(),
							targetEvent.getMenuId(),
							executeDate);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
	}
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	/**
	 * 書類チェックDB作成処理
	 * <pre>
	 * 入庫区分(仕入種別)の状況によって処理を変える
	 * </pre>
	 * @param targetEvent
	 * @param dao
	 * @param executeDate
	 * @throws TecDAOException
	 */
	private void insertT220007G(RegisterDataEvent targetEvent,
			RegisterDAOIF dao, Timestamp executeDate) throws TecDAOException {

		boolean existKbSiire[] = CarryinUtils.existKbSiire(targetEvent.getRegisterInputBean());
		boolean existSitadori = existKbSiire[0];
		boolean existKaitori = existKbSiire[1];
		boolean existAuction = existKbSiire[2];

		// 書類チェックDB：会社コード・販売店コード・搬入日・管理番号
		//			   	   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
		Ucab002gBean t220007gBean = new Ucab002gBean(targetEvent.getRegisterInputBean().getCdKaisya(),
/*--2019.3.20 from				
													targetEvent.getRegisterInputBean().getCdHanbaitn(),
*/
													targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
//--2019.3.20 to
													targetEvent.getRegisterInputBean().getDdHannyu(),
													targetEvent.getRegisterInputBean().getNoKanri(),
													targetEvent.getRegisterInputBean().getCdSksisya(),
													targetEvent.getRegisterInputBean().getCdKsnsya(),
													targetEvent.getRegisterInputBean().getCdSksiapp(),
													targetEvent.getRegisterInputBean().getCdKsnapp());

		String currentDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
		boolean executeT220003g = false;

		if (existSitadori) {
			// 下取にチェックがある場合：処理なし
			return;
		} else if (existKaitori || existAuction) {
			// 買取またはオークションにチェックがある場合：書類完備保留日をセット
			// 書類完備日
			t220007gBean.setDdSrknb("");
			// 書類完備保留日
			t220007gBean.setDdSrkhr(currentDate);
		} else {
			// それ以外の場合：書類完備日をセット
			// 書類完備日
			t220007gBean.setDdSrknb(currentDate);
			// 書類完備保留日
			t220007gBean.setDdSrkhr("");

			// チェック内容情報にINSERT処理をする
			executeT220003g = true;
		}
		dao.insertT220007G(t220007gBean,
							// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
							targetEvent.getUserInfoBean().getCdTenpo(),
							targetEvent.getUserInfoBean().getKbScenter(),
							// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
							executeDate);

		if (executeT220003g) {
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			// チェック内容情報に下取書類のデータをINSERT処理をする
			dao.insertT220003G(targetEvent.getRegisterInputBean(),
								targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
								targetEvent.getUserInfoBean().getKbScenter(),
								CarryinConst.KBCHECK_SITADORI,
								DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE),
								executeDate);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
		}
	}

	/**
	 * 管理番号生成
	 * @param noKanri
	 * @throws NumberFormatException
	 */
// 2014.7.18 H.Yamashita add start P相模原 連番対応
	private String createNoKanri(String noKanri
								, String cdHanbaitn
								, String loginKbScenter
//--2019.3.20 FROM
								, String loginKbGyohan
								, String cdHantenpo
//--2019.3.20 TO								
	) throws NumberFormatException {
	//private String createNoKanri(String noKanri) throws NumberFormatException {

// 2014.7.18 H.Yamashita end start P相模原 連番対応

		String nextNoKanri = "";

		if (StringCheckUtils.isEmpty(noKanri)) {

			// 2014.7.18 H.Yamashita add start P相模原 連番対応
/*--2019.3.20 from
			if (UcarConst.TOYOPET.equals(cdHanbaitn)) {
*/			
			
			if (UcarConst.WCOROLLA.equals(cdHanbaitn)) {
				InitialParam += ".CW";
				nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".shop");
				
			}else{
				InitialParam += ".TMT";
				if (UcarConst.KB_SCENTER_SCENTER.equals(loginKbScenter)) {
					// ログインユーザが商品化センターの場合
					switch(HannyuTenpoEtc.getEnumName(cdHantenpo))
					{
						case SagamiAG:
							nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".SagamiAG");
							break;
						case SagamiBG:
							nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".SagamiBG");
							break;
						case KatushimaG:
							nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".KatushimaG");
							break;
						case FuchuuG:
							nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".FuchuuG");
							break;
						case AdachiG:
							nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".AdachiG");
							break;
						case Others:
							nextNoKanri = "";
							
						
					}
				} else if(UcarConst.KB_GYOHAN.equals(loginKbGyohan)){
					// ログインユーザが業販店舗の場合
					nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".gyohan");
					
				} else {
					// ログインユーザがU-Car店舗の場合
					nextNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".shop");
				}
			}
/*--				
				} else {
				nextNoKanri = "001";
			}
//--2019.3.30 to  */
					
			// 2014.7.18 H.Yamashita add end P相模原 連番対応
		} else {
			int i = Integer.parseInt(noKanri) + 1;
			nextNoKanri = String.format("%1$03d", i);
		}

		return nextNoKanri;
	}
//--2019.3.20 from
	/**
	 * 東京トヨペット(車両搬入情報より取得できない場合の設定用）
	 */
	public enum HannyuTenpoEtc
	{
	    SagamiAG("49B"),
	    SagamiBG("49C"),
	    KatushimaG("04H"),
	    FuchuuG("34G"),
	    AdachiG("16Q"),
	    Others("***");
	    
	    private final String name;
	    
	    HannyuTenpoEtc(String name)
	    {
	        this.name = name;
	    }
	    
	    String getName()
	    {
	        return this.name;
	    }
	 
	    public static HannyuTenpoEtc getEnumName(String str)
	    {
	        for(HannyuTenpoEtc v : values())
	        {
	            if(v.getName().equals(str))
	            {
	                return v;
	            }
	 
	        }
	        return HannyuTenpoEtc.Others;
	    }
	}
//--2019.3.20 to
}
