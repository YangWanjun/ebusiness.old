package com.toyotec_jp.ucar.workflow.carryin.list.model.object;

import java.util.Date;

import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;

/**
 * <strong>車両搬入一覧 検索レコード用Bean</strong>
 * @author Y.F(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */

public class ListDataBean extends Ucaa001gBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 店舗短縮名 */
	private String kjTentanms;
	/** 登録NO陸支名 */
	private String kjRikusim;
	/** チェック内容 */
	private String kbCheck;
	/** 仕入種別 */
	private String mjSiire;
	/** 書類完備日 */
	private String ddSrknb;
	/** 書類完備保留日 */
	private String ddSrkhr;
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
	/** 書類チェック：データ更新日時
	 * <pre>
	 * 排他制御時に使用する
	 * </pre>
	 *  */
	private Date syoruiDtKosin;
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

	/**
	 *
	 */
	public ListDataBean() {
		super();
	}

	/**
	 * kjTentanmsを取得する。
	 * @return kjTentanms 店舗短縮名
	 */
	public String getKjTentanms() {
		return kjTentanms;
	}

	/**
	 * kjTentanmsを設定する。
	 * @param kjTentanms 店舗短縮名
	 */
	public void setKjTentanms(String kjTentanms) {
		this.kjTentanms = kjTentanms;
	}

	/**
	 * kjRikusimを取得する。
	 * @return kjRikusim 登録NO陸支名
	 */
	public String getKjRikusim() {
		return kjRikusim;
	}

	/**
	 * kjRikusimを設定する。
	 * @param kjRikusim 登録NO陸支名
	 */
	public void setKjRikusim(String kjRikusim) {
		this.kjRikusim = kjRikusim;
	}

	/**
	 * kbCheckを取得する。
	 * @return kbCheck チェック内容
	 */
	public String getKbCheck() {
		return kbCheck;
	}

	/**
	 * kbCheckを設定する。
	 * @param kbCheck チェック内容
	 */
	public void setKbCheck(String kbCheck) {
		this.kbCheck = kbCheck;
	}

	/**
	 * mjSiireを取得する。
	 * @return mjSiire 仕入種別
	 */
	public String getMjSiire() {
		// 仕入種別の最大出力文字数
		final int maxLength = 10;
		return UcarUtils.getMaxLengthSubstring(this.mjSiire, maxLength);
	}

	/**
	 * mjSiireを設定する。
	 * @param mjSiire 仕入種別
	 */
	public void setMjSiire(String mjSiire) {
		this.mjSiire = mjSiire;
	}

	/**
	 * ddSrknbを取得する。
	 * @return ddSrknb 書類完備日
	 */
	public String getDdSrknb() {
		return ddSrknb;
	}

	/**
	 * ddSrknbを設定する。
	 * @param ddSrknb 書類完備日
	 */
	public void setDdSrknb(String ddSrknb) {
		this.ddSrknb = ddSrknb;
	}

	/**
	 * ddSrkhrを取得する。
	 * @return ddSrkhr 書類完備保留日
	 */
	public String getDdSrkhr() {
		return ddSrkhr;
	}

	/**
	 * ddSrkhrを設定する。
	 * @param ddSrkhr 書類完備保留日
	 */
	public void setDdSrkhr(String ddSrkhr) {
		this.ddSrkhr = ddSrkhr;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.object.T220001gBean#getMjBikou()
	 */
	@Override
	public String getMjBikou() {
		// 備考の最大出力文字数
		final int maxLength = 24;
		return UcarUtils.getMaxLengthSubstring(super.getMjBikou(), maxLength);
	}

	// 2012.01.30 T.Hayato 追加 搬入書類チェック一括登録機能追加のため start
	/**
	 * syoruiDtKosinを取得する。
	 * @return syoruiDtKosin 書類チェック：データ更新日時
	 */
	public Date getSyoruiDtKosin() {
		return syoruiDtKosin;
	}

	/**
	 * syoruiDtKosinを設定する。
	 * @param syoruiDtKosin 書類チェック：データ更新日時
	 */
	public void setSyoruiDtKosin(Date syoruiDtKosin) {
		this.syoruiDtKosin = syoruiDtKosin;
	}
	// 2012.01.30 T.Hayato 追加 搬入書類チェック一括登録機能追加のため end
}
