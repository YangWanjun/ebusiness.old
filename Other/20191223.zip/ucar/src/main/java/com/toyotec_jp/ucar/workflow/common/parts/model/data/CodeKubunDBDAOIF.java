package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.CodeKubunDBBean;

/**
 * <strong>コード区分DB操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface CodeKubunDBDAOIF {

	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
	/**
	 * コード区分DBリスト取得
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @return コード区分DBリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<CodeKubunDBBean> getCodeKubunDBList(String cdKaisya, String cdHanbaitn) throws TecDAOException;
	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため start
	/**
	 * コード区分DB取得
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @param mjBlockid ブロックID
	 * @param mjKubunid 区分ID
	 * @param cdKubun 区分コード
	 * @return コード区分DBBean
	 * @throws TecDAOException
	 */
	public CodeKubunDBBean getCodeKubunDB(String cdKaisya,
											String cdHanbaitn,
											String mjBlockid,
											String mjKubunid,
											String cdKubun) throws TecDAOException;
	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため end
	// 2015.03.17 Y.Negishi U-Car帳票改善 add start
	/**
	 * 特別仕様名称取得処理
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @param kbId 区分ID
	 * @return 特別仕様名称
	 * @throws TecDAOException
	 */
	public String getMjSpecailWay(	String cdKaisya,
									String cdHanbaitn,
									String kbId
									) throws TecDAOException;
	
	/**
	 * 塗色名取得処理
	 * @param	中古車塗色コード/内装色
	 * @param	販売店コード
	 * @return	中古車塗色名/内装色名
	 * @throws	TecDAOException
	 */
	public String getKjTosikime(	String cdToshiki,
									String cdHanbaitn) throws TecDAOException;
	// 2015.03.17 Y.Negishi U-Car帳票改善 add end
}
