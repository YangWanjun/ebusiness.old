/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TimeCheckUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/06/08 T.H(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;


/**
 * <strong>時間チェック系ユーティリティクラス</strong>
 * <p>
 * 時間チェック関連支援処理を管理するクラス
 *
 * @author T.H(SCC)
 * @version 1.00 2010/06/08 新規作成<br>
 */
public class TimeCheckUtils {

	/** checkFormatHHMM */
	public static final String RESULT_FORMATHHMM_ER_FORMAT = "0";
	public static final String RESULT_FORMATHHMM_ER_OVER = "1";
	public static final String RESULT_FORMATHHMM_OK = "2";

	/*
     * デフォルトコンストラクタ
     */
	private TimeCheckUtils() {
	}

	/**
	 * 時間形式判定関数(HH:MM形式上限指定版)
	 * <pre>
	 * 引数がHH:MM形式かをチェックする
	 * </pre>
	 * @param time チェック文字列
	 * @param max 時間チェック用マックス値
	 * @return HH:MM形式でなければ0、それ以外で限界値を超えていれば1、超えてなければ2
	 * @see #RESULT_FORMATHHMM_ER_FORMAT
	 * @see #RESULT_FORMATHHMM_ER_OVER
	 * @see #RESULT_FORMATHHMM_OK
	 */
	public static String isHHMMFormat(String time, int max) {
		// 形式チェック
		if (!isHHMMFormat(time)) {
			return RESULT_FORMATHHMM_ER_FORMAT;
		}
		String[] str1 = time.split(":");
		//MM限界値チェック
		if (Integer.parseInt(str1[0]) > max) {
			return RESULT_FORMATHHMM_ER_OVER;
		}
		//MM限界値チェック
		if (Integer.parseInt(str1[1]) > 59) {
			return RESULT_FORMATHHMM_ER_OVER;
		}
		return RESULT_FORMATHHMM_OK;
	}

	/**
	 * 時間形式判定関数(HH:MM形式上限未指定版)
	 * <pre>
	 * 引数がHH:MM形式かをチェックする
	 * </pre>
	 * @param time チェック文字列
	 * @return 判定結果
	 */
	public static boolean isHHMMFormat(String time) {
		//空文字
		if (StringCheckUtils.isEmpty(time)) {
			return false;
		}

		String[] str1 = time.split(":");
		if (str1.length != 2) {
			return false;
		}
		for (int i = 0; i < str1.length; i++) {
			//数値チェック
			if (!NumericCheckUtils.isNumericFormat(str1[i], false, false)) {
				return false;
			}
			//桁数チェック
			if (str1[i].length() != 2) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 最大時間判定関数
	 * <pre>
	 * 対象の時間[hh:mm]が指定された最大時間を越えているか判断する
	 * </pre>
	 * @param time チェック文字列
	 * @param maxHour 最大時間
	 * @return true:指定された時間内、false:指定された時間を超えている
	 */
	public static boolean isRangeHour(String time, int maxHour) {
		int h = Integer.parseInt(time.split(":")[0], 10);
		if (h > maxHour) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 時間整合性判定関数
	 * <pre>
	 * 開始時間と終了時間の整合性をチェックする　
	 * equalFlgがtrueの場合は同じ時間でもtrueを返却する
	 * </pre>
	 * @param startTime 開始時間
	 * @param endTime 終了時間
	 * @param equalFlg true:同値を許可
	 * @return 判定結果
	 */
	public static boolean compareHHMM(String startTime, String endTime, boolean equalFlg) {

		if (StringCheckUtils.isEmpty(startTime) || StringCheckUtils.isEmpty(endTime)) {
			return false;
		}

		if (!isHHMMFormat(startTime) || !isHHMMFormat(endTime)) {
			return false;
		}

		int startM = TimeUtils.getMinfromHM(startTime);
		int endM = TimeUtils.getMinfromHM(endTime);

		if (equalFlg) {
			if ((endM - startM) < 1) {
				return false;
			}
		} else {
			if ((endM - startM) < 0) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 時間包含判定関数
	 * <pre>
	 * 内部時刻が、外部時刻の範囲内か判定する
	 * 各時刻の開始・終了時刻のフォーマット・逆転はチェックしない
	 * </pre>
	 * @param outerStartTime 外部開始時刻[hh:mm]
	 * @param outerEndTime 外部終了時刻[hh:mm]
	 * @param innerStartTime 内部開始時刻[hh:mm]
	 * @param innerEndTime 内部終了時刻[hh:mm]
	 * @return 判定結果
	 */
	public static boolean isRangeOuter(
		String outerStartTime, String outerEndTime,
		String innerStartTime, String innerEndTime) {

		if (TimeUtils.compareHHMM(innerStartTime, outerStartTime) < 0 ) {
			return false;
		}
		if (TimeUtils.compareHHMM(innerEndTime, outerEndTime) > 0 ) {
			return false;
		}

		return true;
	}

	/**
	 * 時間重複判定関数
	 * <pre>
	 * 複数の時刻が重複していないかチェックする
	 * 時刻が未入力の項目があった場合、チェック対象外として処理を続行します。
	 * </pre>
	 * @param times 開始時刻[hh:mm],終了時刻[hh:mm]の各時刻の2次元配列
	 * @return 判定結果
	 */
	public static boolean checkOverlap(String[][] times) {

		for (int i = 0; i < times.length; i++) {

			// 時刻が未入力の場合、チェック対象外として処理をとばす
			if (StringCheckUtils.isEmpty(times[i][0])) continue;
			if (StringCheckUtils.isEmpty(times[i][1])) continue;

			int startMin = TimeUtils.getMinfromHM(times[i][0]);
			int endMin = TimeUtils.getMinfromHM(times[i][1]);

			for (int j = 0; j < times.length; j++) {
				if (j == i) continue;

				int targetStartMin = TimeUtils.getMinfromHM(times[j][0]);
				int targetEndMin = TimeUtils.getMinfromHM(times[j][1]);

				boolean startIn = (startMin > targetStartMin) && (startMin < targetEndMin);
				boolean endIn = (endMin > targetStartMin) && (endMin < targetEndMin);

				if (startIn || endIn) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * 時間重複判定関数（判定対象時間指定版）
	 * <PRE>
	 * 該当インデックスの時刻が、他の複数の時刻と重複していないかチェックする
	 * 時刻が未入力の項目があった場合、チェック対象外として処理を続行する
	 * </PRE>
	 * @param times 開始時刻[hh:mm],終了時刻[hh:mm]の各時刻の2次元配列
	 * @param targetIndex 判定対象時間
	 * @return true:時間帯が重なり合っている
	 */
	public static boolean checkOverlap(String[][] times, int targetIndex) {

		// 時刻が未入力の場合、チェック対象外としてtrueを返却
		if (StringCheckUtils.isEmpty(times[targetIndex][0])) return true;
		if (StringCheckUtils.isEmpty(times[targetIndex][1])) return true;

		int startMin = TimeUtils.getMinfromHM(times[targetIndex][0]);
		int endMin = TimeUtils.getMinfromHM(times[targetIndex][1]);

		for (int i = 0; i < times.length; i++) {
			if (i == targetIndex) continue;

			// 時刻が未入力の場合、チェック対象外として処理をとばす
			if (StringCheckUtils.isEmpty(times[i][0])) continue;
			if (StringCheckUtils.isEmpty(times[i][1])) continue;

			int targetStartMin = TimeUtils.getMinfromHM(times[i][0]);
			int targetEndMin = TimeUtils.getMinfromHM(times[i][1]);

			boolean startIn = (startMin >= targetStartMin) && (startMin < targetEndMin);
			boolean endIn = (endMin > targetStartMin) && (endMin <= targetEndMin);

			if (startIn || endIn) {
				return false;
			}
		}
		return true;
	}

}
