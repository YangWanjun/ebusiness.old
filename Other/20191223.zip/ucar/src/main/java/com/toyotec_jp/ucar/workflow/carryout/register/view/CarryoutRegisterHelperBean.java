package com.toyotec_jp.ucar.workflow.carryout.register.view;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinAjaxServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutSessionBean;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutEventKey;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutServiceId;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutTitle;
import com.toyotec_jp.ucar.workflow.carryout.register.model.event.GetCarryoutRegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryout.register.model.event.GetCarryoutRegisterDataEventResult;
import com.toyotec_jp.ucar.workflow.carryout.register.model.object.CarryoutRegisterDataBean;
import com.toyotec_jp.ucar.workflow.carryout.register.model.object.CarryoutRegisterSessionBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarButton;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarRadioButton;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出登録ヘルパービーン。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 8584928315609391060L;

	/** 搬出日 */
	private String	ddHansyt = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT);
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
	private String	ddOutpln;
	private String	dtStatus25;
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end
	
	/** 車両搬出セッションBean */
	private CarryoutSessionBean carryoutSession;
	/** 車両搬出登録セッションBean */
	private CarryoutRegisterSessionBean carryoutRegisterSession;

	/** 車両搬出登録 画面出力値Bean */
	private CarryoutRegisterDataBean carryoutRegisterDataBean = new CarryoutRegisterDataBean();
	/** 仕入種別情報Beanリスト */
	private ResultArrayList<Ucaa002gBean> t220002gList;
	/** チェック内容情報Beanリスト */
	private ResultArrayList<Ucaa003gBean> t220003gList;
	/** 車両搬出情報Bean */
//	private T220013gBean t220013gBean = new T220013gBean();
	private Uccb009gBean t220013gBean = new Uccb009gBean();	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

	/** 車両搬出関連サービスID */
	private CarryoutServiceId targetServiceId;

	/** 仕入種別(カンマ区切り) */
	private String	kbSiireCSVData;
	/** チェック内容区分(カンマ区切り) */
	private String kbCheckCSVData;

	/** 仕入種別checkvalues */
	private String	kbSiireCheckvalues = "";
	/** チェック内容checkvalues */
	private String	kbCheckCheckvalues = "";
	/** 作業工程(加修なし)checkvalues */
	private String	kbSgyoktNotRepairCheckvalues;
	/** 作業工程(加修あり)checkvalues */
	private String	kbSgyoktRepairCheckvalues;

	/** 車両搬出登録 画面出力値有無フラグ
	 * (true：有／false：無) */
	private boolean existCarryoutRegisterData;
	/** 車両搬出情報(T220013G) 有無フラグ
	 * (true：有／false：無) */
	private boolean existT220013gData;

	private String serviceUrlInit;
	private String	serviceUrlSearch;
	private String	serviceUrlRegister;
	// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため start
	private String	serviceUrlRegisterAndDownload;
	// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため end
	private String	serviceUrlDelete;
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
	private String	serviceUrlPlanRegister;
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end
	
	// 2014.08.11 00496_990215 追加 社員名称取得のため start
	private String	serviceUrlAjax;
	// 2014.08.11 00496_990215 追加 社員名称取得のため end
	
	/** サービスID：EDIT(実行サービスがEDITの場合は"true") */
	private String serviceIdEdit = "false";	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

	/** デフォルトコンストラクタ。 */
	public CarryoutRegisterHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.base.view.TlsHelperBean#init()
	 */
	@Override
	public void init() throws HelperBeanException {

		// セッションの取得
		carryoutSession = getApplicationSessionBean(CarryoutSessionBean.class);
		carryoutRegisterSession = getApplicationSessionBean(CarryoutRegisterSessionBean.class);

		String serviceId = carryoutSession.getServiceId();
		targetServiceId = CarryoutServiceId.getTargetCarryoutServiceId(serviceId);

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		// 店舗の場合、他店貸出を表示
		if (!getLoginSessionBean().getUserInfoBean().getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)){
			serviceIdEdit = "true";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start

		// サービス呼び出し用URL設定
		setServiceURLs();

		try {

			// サービスごとの処理
			if(targetServiceId != null){
				switch (targetServiceId) {
					case REGISTER_SEARCH:

						// インスタンスを複製する
						Ucaa001gPKBean t220001gPkBean = carryoutSession.getT220001gPkBean().clone();

						GetCarryoutRegisterDataEvent getEvent = createEvent(
								CarryoutEventKey.GET_REGISTER_DATA, GetCarryoutRegisterDataEvent.class);

						//新環境構築疎通テストの一時修正 2019-09-01 Add Satrt
						if (getEvent.getUserInfoBean() == null) {
							LoginSessionBean se = getLoginSessionBean();
							getEvent.setUserInfoBean(se.getUserInfoBean());							
						}
						//新環境構築疎通テストの一時修正 2019-09-01 Add   End
						
						// yyyy/MM/ddからyyyyMMddに変換
						String ddHannyu = UcarUtils.getStringDateFormatShortSimple(t220001gPkBean.getDdHannyu());
						t220001gPkBean.setDdHannyu(ddHannyu);

						getEvent.setT220001gPkBean(t220001gPkBean);

						GetCarryoutRegisterDataEventResult getResult
							= (GetCarryoutRegisterDataEventResult)dispatchEvent(getEvent);

						existCarryoutRegisterData = getResult.isExistCarryoutRegisterData();

						if (existCarryoutRegisterData) {
							// データが存在する場合
							carryoutRegisterDataBean = getResult.getCarryoutRegisterDataBean();
							t220002gList = getResult.getT220002gList();
							t220003gList = getResult.getT220003gList();

							// 仕入種別のチェック状態をカンマ区切りのデータに変換
							for (Ucaa002gBean t220002gBean : t220002gList) {
								if (kbSiireCSVData == null) {
									kbSiireCSVData = t220002gBean.getKbSiire();
								} else {
									kbSiireCSVData += "," + t220002gBean.getKbSiire();
								}
							}
							// チェック内容のチェック状態をカンマ区切りのデータに変換
							for (Ucaa003gBean t220003gBean : t220003gList) {
								if (kbCheckCSVData == null) {
									kbCheckCSVData = t220003gBean.getKbCheck();
								} else {
									kbCheckCSVData += "," + t220003gBean.getKbCheck();
								}
							}

							t220013gBean = getResult.getT220013gBean();
							if (t220013gBean.getDdHansyt() != null) {
								// yyyyMMddからyyyy/MM/ddに変換
								ddHansyt = UcarUtils.getStringDateFormatShort(t220013gBean.getDdHansyt());
							}
							if (t220013gBean.getDtKosin() != null) {
								// 排他制御時に使用する更新日時をセッションにセット
								carryoutRegisterSession.setT220013gDtKosin(DateUtils.dateToString(t220013gBean.getDtKosin(),
																								  DateUtils.DB_FORMAT_LONG_M));
							}
							
							// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
							if (carryoutRegisterDataBean.getDdOutpln() != null) {
								// Date型から文字列yyyy/MM/ddに変換
								ddOutpln =  UcarUtils.dateToStringAsFormatShort(carryoutRegisterDataBean.getDdOutpln());
							}
							if (carryoutRegisterDataBean.getDtStatus25() != null) {
								// Date型から文字列yyyy/MM/ddに変換
								dtStatus25 =  UcarUtils.dateToStringAsFormatShort(carryoutRegisterDataBean.getDtStatus25());
							}
							// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end
							
							existT220013gData = getResult.isExistT220013gData();

						} else {
							// データが存在しない場合

							// 搬入日をクリア
							carryoutSession.getT220001gPkBean().setDdHannyu("");
							// 管理番号をクリア
							carryoutSession.getT220001gPkBean().setNoKanri("");
						}
						break;
					default:
						break;
				}
			}

			kbSiireCheckvalues 				= UcarUtils.getT220004mCheckvalues(getRequest(), getResponse());
			kbCheckCheckvalues 				= UcarUtils.getT220005mCheckvalues(getRequest(), getResponse());
			kbSgyoktNotRepairCheckvalues 	= UcarUtils.getT220014mNotRepairCheckvalues(getRequest(), getResponse());
			kbSgyoktRepairCheckvalues 		= UcarUtils.getT220014mRepairCheckvalues(getRequest(), getResponse());

		} catch (SystemException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		} catch (ApplicationException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		}
	}

	/** サービス呼び出し用URL設定 */
	private void setServiceURLs() throws HelperBeanException {

		serviceUrlInit		= getServiceUrl(CarryoutServiceId.REGISTER_INIT);
		serviceUrlSearch	= getServiceUrl(CarryoutServiceId.REGISTER_SEARCH);
		// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため start
		serviceUrlRegisterAndDownload = getServiceUrl(CarryoutServiceId.REGISTER_EXECUTE_AND_DOWNLOAD);
		// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため end
		serviceUrlRegister	= getServiceUrl(CarryoutServiceId.REGISTER_EXECUTE);
		serviceUrlDelete	= getServiceUrl(CarryoutServiceId.REGISTER_DELETE);
		// 2014.08.08 00496_990215 追加 搬出予定情報登録処理追加のため start
		serviceUrlPlanRegister	= getServiceUrl(CarryoutServiceId.REGISTER_PLAN_EXECUTE);
		// 2014.08.08 00496_990215 追加 搬出予定情報登録処理追加のため end
		// 2014.08.08 00496_990215 追加 社員名取得のため start
		serviceUrlAjax 		= getServiceUrl(CarryinServiceId.AJAX);
		// 2014.08.08 00496_990215 追加 社員名取得のため end
	}

	/** 画面タイトル取得 */
	public String getTitleLabel(){
		return CarryoutTitle.CARRYOUT_REGISTER.getTitleLabel();
	}

	/** 登録ボタンラベル取得 */
	public String getButtonLabelRegister(){
		return UcarButton.REGISTER.getButtonLabel();
	}

	// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 登録(帳票印刷)ボタンラベル取得 */
	public String getButtonLabelRegisterDownload(){
		return UcarButton.REGISTER_DOWNLOAD.getButtonLabel();
	}
	// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため end

	/** 取消ボタンラベル取得 */
	public String getButtonLabelCancel(){
		return UcarButton.CANCEL.getButtonLabel();
	}

	/** 削除ボタンラベル取得 */
	public String getButtonLabelDelete(){
		return UcarButton.DELETE.getButtonLabel();
	}

	/** 検索ボタンラベル取得 */
	public String getButtonLabelSearch(){
		return UcarButton.SEARCH.getButtonLabel();
	}
	
	// 2014.08.08 00496_990215 追加 搬出予定情報登録処理追加のため start
	/** 搬出予定登録ボタンラベル取得 */
	public String getButtonLabelOutplanRegister(){
		return UcarButton.OUTPLAN_REGISTER.getButtonLabel();
	}
	// 2014.08.08 00496_990215 追加 搬出予定情報登録処理追加のため end

	/** 操作方法ラジオボタン出力値取得 */
	public String getRadiovalues(){
		return UcarRadioButton.operate_input.getRadiovalues();
	}
	
	

	/**
	 * serviceUrlInitを取得する。
	 * @return serviceUrlInit
	 */
	public String getServiceUrlInit() {
		return serviceUrlInit;
	}

	/**
	 * serviceUrlRegisterAndDownloadを取得する。
	 * @return serviceUrlRegisterAndDownload
	 */
	public String getServiceUrlRegisterAndDownload() {
		return serviceUrlRegisterAndDownload;
	}

	/**
	 * serviceUrlRegisterを取得する。
	 * @return serviceUrlRegister
	 */
	public String getServiceUrlRegister() {
		return serviceUrlRegister;
	}

	/**
	 * serviceUrlDeleteを取得する。
	 * @return serviceUrlDelete
	 */
	public String getServiceUrlDelete() {
		return serviceUrlDelete;
	}

	/**
	 * serviceUrlSearchを取得する。
	 * @return serviceUrlSearch
	 */
	public String getServiceUrlSearch() {
		return serviceUrlSearch;
	}

	// 2014.08.08 00496_990215 追加 搬出予定情報登録処理追加のため start
	/**
	 * serviceUrlPlanRegisterを取得する。
	 * @return serviceUrlPlanRegister
	 */
	public String getServiceUrlPlanRegister() {
		return serviceUrlPlanRegister;
	}
	// 2014.08.08 00496_990215 追加 搬出予定情報登録処理追加のため end
	
	/**
	 * ddHansytを取得する。
	 * @return ddHansyt
	 */
	public String getDdHansyt() {
		return ddHansyt;
	}
	
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため start
	/**
	 * ddOutplnを取得する。
	 * @return ddOutpln
	 */
	public String getDdOutpln() {
		return ddOutpln;
	}

	/**
	 * dtStatus25を取得する。
	 * @return dtStatus25
	 */
	public String getDtStatus25() {
		return dtStatus25;
	}
	// 2014.08.11 00496_990215 追加 搬出予定情報取得のため end

	/**
	 * carryoutSessionを取得する。
	 * @return carryoutSession
	 */
	public CarryoutSessionBean getCarryoutSession() {
		return carryoutSession;
	}

	/**
	 * carryoutRegisterSessionを取得する。
	 * @return carryoutRegisterSession
	 */
	public CarryoutRegisterSessionBean getCarryoutRegisterSession() {
		return carryoutRegisterSession;
	}

	/**
	 * carryoutRegisterDataBeanを取得する。
	 * @return carryoutRegisterDataBean
	 */
	public CarryoutRegisterDataBean getCarryoutRegisterDataBean() {
		return carryoutRegisterDataBean;
	}

	/**
	 * targetServiceIdを取得する。
	 * @return targetServiceId
	 */
	public CarryoutServiceId getTargetServiceId() {
		return targetServiceId;
	}

	/**
	 * t220002gListを取得する。
	 * @return t220002gList
	 */
	public ResultArrayList<Ucaa002gBean> getT220002gList() {
		return t220002gList;
	}

	/**
	 * t220003gListを取得する。
	 * @return t220003gList
	 */
	public ResultArrayList<Ucaa003gBean> getT220003gList() {
		return t220003gList;
	}

	/**
	 * kbSiireCSVDataを取得する。
	 * @return kbSiireCSVData
	 */
	public String getKbSiireCSVData() {
		return kbSiireCSVData;
	}

	/**
	 * kbCheckCSVDataを取得する。
	 * @return kbCheckCSVData
	 */
	public String getKbCheckCSVData() {
		return kbCheckCSVData;
	}

	/**
	 * kbSiireCheckvaluesを取得する。
	 * @return kbSiireCheckvalues
	 */
	public String getKbSiireCheckvalues() {
		return kbSiireCheckvalues;
	}

	/**
	 * kbCheckCheckvaluesを取得する。
	 * @return kbCheckCheckvalues
	 */
	public String getKbCheckCheckvalues() {
		return kbCheckCheckvalues;
	}

	/**
	 * kbSgyoktNotRepairCheckvaluesを取得する。
	 * @return kbSgyoktNotRepairCheckvalues
	 */
	public String getKbSgyoktNotRepairCheckvalues() {
		return kbSgyoktNotRepairCheckvalues;
	}

	/**
	 * kbSgyoktRepairCheckvaluesを取得する。
	 * @return kbSgyoktRepairCheckvalues
	 */
	public String getKbSgyoktRepairCheckvalues() {
		return kbSgyoktRepairCheckvalues;
	}

	/**
	 * t220013gBeanを取得する。
	 * @return t220013gBean
	 */
//	public T220013gBean getT220013gBean() {
	public Uccb009gBean getT220013gBean() {		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		return t220013gBean;
	}

	/**
	 * existCarryoutRegisterDataを取得する。
	 * @return existCarryoutRegisterData
	 */
	public boolean isExistCarryoutRegisterData() {
		return existCarryoutRegisterData;
	}

	/**
	 * existT220013gDataを取得する。
	 * @return existT220013gData
	 */
	public boolean isExistT220013gData() {
		return existT220013gData;
	}

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * serviceIdEditを取得する。
	 * @return serviceIdEdit
	 */
	public String getServiceIdEdit() {
		return serviceIdEdit;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	// 2014.08.08 00496_990215 追加 社員名取得のため start
	/**
	 * serviceUrlAjaxを取得する。
	 * @return serviceUrlAjax
	 */
	public String getServiceUrlAjax() {
		return serviceUrlAjax;
	}
	
	/**
	 * 車両搬入関連AjaxサービスID
	 * CarryinAjaxServiceId.GET_KJ_SYAINMEIを取得する。
	 * @return CarryinAjaxServiceId.GET_KJ_SYAINMEI
	 */
	public String getKjSyainmei() {
		return CarryinAjaxServiceId.GET_KJ_SYAINMEI.toString();
	}
	// 2014.08.08 00496_990215 追加 社員名取得のため end
	
}
