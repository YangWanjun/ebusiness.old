package com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;

/**
 * <strong>データ削除DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/07 新規作成<br>
 * @since 1.00
 * @category [[バッチ：データ削除]]
 */
public interface DataCleaningDAOIF {

	/**
	 * 削除処理（車両搬入情報）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220001G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（仕入種別情報）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220002G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（チェック内容情報）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220003G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（書類チェックDB）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220007G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（入庫検査チェックDB）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220008G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（仕分作業DB）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220009G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（完成検査DB）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220010G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（ステータスDB）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220012G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

	/**
	 * 削除処理（車両搬出情報）
	 * @param 	cdKaisya   会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHansyt   搬出日
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220013G(String cdKaisya,
													String cdHanbaitn,
													String ddHansyt) throws TecDAOException;

}
