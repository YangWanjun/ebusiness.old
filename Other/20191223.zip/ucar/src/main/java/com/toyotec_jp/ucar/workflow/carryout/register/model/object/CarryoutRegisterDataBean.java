package com.toyotec_jp.ucar.workflow.carryout.register.model.object;

import java.util.Date;

import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;

/**
 * <strong>車両搬出登録 画面出力値Bean</strong>
 * <p>
 * 車両搬入情報Bean(Ucaa001gBean)を継承している。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/04 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterDataBean extends Ucaa001gBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 陸支名 */
	private String kjRikusim;
	/** 区分内容(塗色) */
	private String mjKubunnai;
	/** 店舗短縮名称 */
	private String kjTentanms;
	/** 社員名 */
	private String kjSyainmei;
	
	// 2014.08.08 00496_990215 追加 搬出予定情報取得のため start
	/** 車両搬出予定日 */
	private Date ddOutpln;
	/** 写真撮影日 */
	private Date dtStatus25;
	/** 商談担当者名 */
	private String kjShtan;
	// 2014.08.08 00496_990215 追加 搬出予定情報取得のため end
	

	/**
	 *
	 */
	public CarryoutRegisterDataBean() {
		super();
	}

	/**
	 * kjRikusimを取得する。
	 * @return kjRikusim
	 */
	public String getKjRikusim() {
		return kjRikusim;
	}

	/**
	 * kjRikusimを設定する。
	 * @param kjRikusim
	 */
	public void setKjRikusim(String kjRikusim) {
		this.kjRikusim = kjRikusim;
	}

	/**
	 * mjKubunnaiを取得する。
	 * @return mjKubunnai
	 */
	public String getMjKubunnai() {
		return mjKubunnai;
	}

	/**
	 * mjKubunnaiを設定する。
	 * @param mjKubunnai
	 */
	public void setMjKubunnai(String mjKubunnai) {
		this.mjKubunnai = mjKubunnai;
	}

	/**
	 * kjTentanmsを取得する。
	 * @return kjTentanms
	 */
	public String getKjTentanms() {
		return kjTentanms;
	}

	/**
	 * kjTentanmsを設定する。
	 * @param kjTentanms
	 */
	public void setKjTentanms(String kjTentanms) {
		this.kjTentanms = kjTentanms;
	}

	/**
	 * kjSyainmeiを取得する。
	 * @return kjSyainmei
	 */
	public String getKjSyainmei() {
		return kjSyainmei;
	}

	/**
	 * kjSyainmeiを設定する。
	 * @param kjSyainmei
	 */
	public void setKjSyainmei(String kjSyainmei) {
		this.kjSyainmei = kjSyainmei;
	}

	/**
	 * 塗色を取得する。
	 * @return cdTosyoku + mjKubunnai
	 */
	public String getTosyoku() {
		return StringUtils.defaultValue(super.getCdTosyoku()) + " " + StringUtils.defaultValue(mjKubunnai);
	}

	/**
	 * 搬入拠点を取得する。
	 * @return cdSirtenpo + kjTentanms
	 */
	public String getSirtenpo() {
		return StringUtils.defaultValue(super.getCdSirtenpo()) + " " + StringUtils.defaultValue(kjTentanms);
	}

	
	// 2014.08.08 00496_990215 追加 搬出予定情報取得のため start
	/**
	 * ddOutplnを取得する。
	 * @param ddOutpln
	 */
	public Date getDdOutpln() {
		return ddOutpln;
	}

	/**
	 * ddOutplnを設定する。
	 * @param ddOutpln
	 */
	public void setDdOutpln(Date ddOutpln) {
		this.ddOutpln = ddOutpln;
	}

	/**
	 * dtStatus25を取得する。
	 * @param dtStatus25
	 */
	public Date getDtStatus25() {
		return dtStatus25;
	}

	/**
	 * dtStatus25を設定する。
	 * @param dtStatus25
	 */
	public void setDtStatus25(Date dtStatus25) {
		this.dtStatus25 = dtStatus25;
	}

	/**
	 * dtStatus25を取得する。
	 * @param dtStatus25
	 */
	public String getKjShtan() {
		return kjShtan;
	}

	/**
	 * dtStatus25を設定する。
	 * @param dtStatus25
	 */
	public void setKjShtan(String kjShtan) {
		this.kjShtan = kjShtan;
	}
	// 2014.08.08 00496_990215 追加 搬出予定情報取得のため end
	
}
