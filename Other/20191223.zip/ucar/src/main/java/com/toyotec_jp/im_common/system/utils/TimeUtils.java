/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TimeUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/05/06 T.H(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.math.BigDecimal;

/**
 * <strong>時間系ユーティリティクラス</strong>
 * <p>
 * 時間関連支援処理を管理するクラス
 *
 * @author T.H(SCC)
 * @version 1.00 2010/05/17 新規作成<br>
 */
public class TimeUtils {

	/** 1時間内の分数. */
	public static final int ONE_HOUR = 60;
	/** 1日内の時間数. */
	public static final int ONE_DAY = 24;
	/** 30分の時間数. */
	public static final double HALF_HOUR = 0.5;
	/** 15分の時間数. */
	public static final double QUARTER_HOUR = 0.25;
	/** HH:MMがNULLであった場合のデフォルト値 */
	public static final String HHMM_FOR_NULL = "00:00";

	/*
     * デフォルトコンストラクタ
     */
	private TimeUtils() {
	}

	/**
	 * 分変換関数(HH:MM形式)
	 * <pre>
	 * 24時間を超えても0時間に戻さない
	 * 延べ時間数とする
	 * 2400分は40:00となり、16:00とはならない
	 * </pre>
	 * @param i 分数
	 * @return HH:MM
	 */
	public static String getHMfromMin(int i) {
		String hh = "00" + i / ONE_HOUR;
		String mm = "00" + i % ONE_HOUR;
		String hhmm =
			hh.substring(hh.length() - 2) + ":" + mm.substring(mm.length() - 2);
		return hhmm;
	}

	/**
	 * 分変換関数(H:MM形式)
	 * <pre>
	 * 24時間を超えても0時間に戻さない
	 * 延べ時間数とする
	 * 240分は4:00となり、04:00とはならない
	 * 2400分は40:00となり、16:00とはならない
	 * また、24000分は400:00となる
	 * </pre>
	 * @param i 分数
	 * @return H:MM
	 */
	public static String getHMMfromMin(int i) {

		String hh = "" + Math.abs(i) / ONE_HOUR;
		String mm = "00" + Math.abs(i % ONE_HOUR);
		String hhmm = hh + ":" + mm.substring(mm.length() - 2);
		if (0 > i) {
			hhmm = "-" + hhmm;
		}
		return hhmm;
	}

	/**
	 * 分変換関数(NNN.N端数切り捨て形式)
	 * <pre>
	 * 分を時間換算に変換する
	 * 0分は0.00、90分は1.50となる
	 * 25分の場合、	0.41となり、小数点第3位以降は切り捨てられる
	 * </pre>
	 * @param i 分数
	 * @return NNN.N
	 */
	public static String getNNNNfromMin(int i) {

		double hh = (double)i / (double) ONE_HOUR;
		BigDecimal bd = new BigDecimal(String.valueOf(hh));
		double time = bd.setScale(2, BigDecimal.ROUND_DOWN).doubleValue();

		String strTime = String.valueOf(time);

		if ((strTime.length() - strTime.indexOf(".")) != 3) {
			strTime += "0";
		}

		return strTime;
	}

	/**
	 * 分変換関数(NNN.N30分単位切り上げ形式)
	 * <pre>
	 * 分を時間換算に変換する
	 * 0分は0.0、90分は1.5となる
	 * 25分の場合、	0.5となり、小数点第2位以降は切り捨てられる
	 * </pre>
	 * @param i 分数
	 * @return NNN.N
	 */
	public static double getNNNNfromMinRoundUpForHalfHour(int i) {

		double hh = (double)i / (double) ONE_HOUR;
		BigDecimal bd = new BigDecimal(String.valueOf(hh));
		BigDecimal bdhh = new BigDecimal(String.valueOf(HALF_HOUR));

		double time = 0;
		while (bd.doubleValue() > 0) {
			bd = bd.subtract(bdhh);
			time += HALF_HOUR;
		}

		return time;

	}

	/**
	 * 分変換関数(NNN.N15分単位切り上げ形式)
	 * <pre>
	 * 分を時間換算に変換する
	 * 0分は0.0、90分は1.5となる
	 * 35分の場合、	0.75となり、小数点第3位以降は切り捨てられる
	 * </pre>
	 * @param i to convert
	 * @return NNN.N
	 */
	public static double getNNNNfromMinRoundUpForQuarterHour(int i) {

		double hh = (double)i / (double) ONE_HOUR;
		BigDecimal bd = new BigDecimal(String.valueOf(hh));
		BigDecimal bdhh = new BigDecimal(String.valueOf(QUARTER_HOUR));

		double time = 0;
		while (bd.doubleValue() > 0) {
			bd = bd.subtract(bdhh);
			time += QUARTER_HOUR;
		}

		return time;

	}

	/**
	 * 時刻変換関数
	 * <pre>
	 * HH:MM形式を分（MINUTE）に変換する
	 * </pre>
	 * @param hhmm 時刻(HH:MM)
	 * @return 分数
	 */
	public static int getMinfromHM(String hhmm) {
		String[] hhmmHairetsu = hhmm.split(":");
		int i =
			(Integer.parseInt(hhmmHairetsu[0]) * ONE_HOUR)
				+ Integer.parseInt(hhmmHairetsu[1]);
		return i;
	}

	/**
	 * 開始・終了時刻調整関数
	 * <pre>
	 * 所定の開始・終了の配列を取得し、開始・終了の時刻が逆転している場合、終了に24時間付加して返却する
	 * </pre>
	 * @param shotei 0:開始時刻[hh:MM]、1:終了時刻[hh:MM]
	 * @return 変換した所定配列
	 */
	public static String[] convertSyoteiForShinya(String[] shotei) {

		if (shotei == null || shotei.length != 2) {
			return shotei;
		}

		String[] rsult;

		String startSyotei = shotei[0];
		String endSyotei = shotei[1];

		//開始時刻と終了時刻が逆転している場合
		if (endSyotei.compareTo(startSyotei) < 0) {
			String[] aryHM = endSyotei.split(":");
			String hour = String.valueOf(Integer.parseInt(aryHM[0]) + ONE_DAY);
			String endCnvSyotei = hour + ":" + aryHM[1];

			rsult = new String[] { startSyotei, endCnvSyotei };
		} else {
			rsult = shotei;
		}

		return rsult;
	}

	/**
	 * 時間比較関数
	 * <pre>
	 * 時間の大小判別を行う
	 * hhmm1がhhmm2より大きい場合：1
	 * hhmm1がhhmm2と同じ場合：0
	 * hhmm1がhhmm2より小さい場合：-1
	 * </pre>
	 * @param hhmm1
	 * @param hhmm2
	 * @return 1(hhmm1 > hhmm2)、0(hhmm1 = hhmm2)、-1(hhmm1 < hhmm2)
	 */
	public static int compareHHMM(String hhmm1, String hhmm2) {
		int min1 = getMinfromHM(hhmm1);
		int min2 = getMinfromHM(hhmm2);
		if (min1 > min2) {
			return 1;
		} else if (min1 == min2) {
			return 0;
		} else {
			return -1;
		}
	}

	/**
	 * 時間加減算関数
	 * <pre>
	 * 時刻[HH:MM]に時間[h]を追加する（マイナス可）
	 * </pre>
	 * @param hhmm
	 * @param addHour
	 * @return 結果時間
	 */
	public static String addTime(String hhmm, int addHour) {
		return getHMfromMin(getMinfromHM(hhmm) + (addHour * 60));
	}

}
