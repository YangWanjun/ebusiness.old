package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;

/**
 * <strong>精算イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/25 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SaveSalesAdjustmentDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/** 売上精算 画面出力値Bean */
	private SalesAdjustmentDataBean salesAdjustmentDataBean;
	/**
	 * 精算処理
	 * <p>
	 * true:精算処理／false:精算取消処理
	 * </p>
	 *  */
	private boolean executeAdjustment;
	/** 売上担当者(精算取消時) */
	private String cdUritanCancel;

	/**
	 * salesAdjustmentDataBeanを取得する。
	 * @return salesAdjustmentDataBean
	 */
	public SalesAdjustmentDataBean getSalesAdjustmentDataBean() {
		return salesAdjustmentDataBean;
	}

	/**
	 * salesAdjustmentDataBeanを設定する。
	 * @param salesAdjustmentDataBean
	 */
	public void setSalesAdjustmentDataBean(
			SalesAdjustmentDataBean salesAdjustmentDataBean) {
		this.salesAdjustmentDataBean = salesAdjustmentDataBean;
	}

	/**
	 * executeAdjustmentを取得する。
	 * @return executeAdjustment
	 */
	public boolean isExecuteAdjustment() {
		return executeAdjustment;
	}

	/**
	 * executeAdjustmentを設定する。
	 * @param executeAdjustment
	 */
	public void setExecuteAdjustment(boolean executeAdjustment) {
		this.executeAdjustment = executeAdjustment;
	}

	/**
	 * cdUritanCancelを取得する。
	 * @return cdUritanCancel
	 */
	public String getCdUritanCancel() {
		return cdUritanCancel;
	}

	/**
	 * cdUritanCancelを設定する。
	 * @param cdUritanCancel
	 */
	public void setCdUritanCancel(String cdUritanCancel) {
		this.cdUritanCancel = cdUritanCancel;
	}

}
