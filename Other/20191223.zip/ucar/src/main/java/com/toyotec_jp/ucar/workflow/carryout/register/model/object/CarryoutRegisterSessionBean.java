package com.toyotec_jp.ucar.workflow.carryout.register.model.object;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst;

/**
 * <strong>車両搬出登録セッションビーン。</strong>
 * <p>
 * セッションに格納する車両搬出登録画面用のビーン。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/05 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** 検索方法 */
	private String rdoSearch;

	/** センタ、店舗区分 */
	private String kbCenterTenpo;
	
	/** 車両搬出情報：データ更新日時(排他チェック用) */
	private String t220013gDtKosin;

	/**
	 * デフォルトコンストラクタ。
	 */
	public CarryoutRegisterSessionBean() {
		setDefaultParams();
	}

	/**
	 * デフォルトパラメータ設定。
	 * <pre>
	 * </pre>
	 */
	public void setDefaultParams(){
		rdoSearch = CarryoutConst.SEARCH_VALUE_BARCODE;
	}

	/**
	 * rdoSearchを取得する。
	 * @return rdoSearch
	 */
	public String getRdoSearch() {
		return rdoSearch;
	}

	/**
	 * rdoSearchを設定する。
	 * @param rdoSearch
	 */
	public void setRdoSearch(String rdoSearch) {
		this.rdoSearch = rdoSearch;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getKbCenterTenpo() {
		return kbCenterTenpo;
	}
	/**
	 * 
	 * @param kbCenterTenpo
	 */
	public void setKbCenterTenpo(String kbCenterTenpo) {
		this.kbCenterTenpo = kbCenterTenpo;
	}

	/**
	 * t220013gDtKosinを取得する。
	 * @return t220013gDtKosin
	 */
	public String getT220013gDtKosin() {
		return t220013gDtKosin;
	}

	/**
	 * t220013gDtKosinを設定する。
	 * @param t220013gDtKosin
	 */
	public void setT220013gDtKosin(String t220013gDtKosin) {
		this.t220013gDtKosin = t220013gDtKosin;
	}

}
