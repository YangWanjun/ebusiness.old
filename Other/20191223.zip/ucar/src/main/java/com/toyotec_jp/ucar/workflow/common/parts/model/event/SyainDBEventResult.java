package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>社員DB操作用イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SyainDBEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 社員名 */
	private String kjSyainmei;

	/**
	 * kjSyainmeiを取得する。
	 * @return kjSyainmei
	 */
	public String getKjSyainmei() {
		return kjSyainmei;
	}

	/**
	 * kjSyainmeiを設定する。
	 * @param kjSyainmei
	 */
	public void setKjSyainmei(String kjSyainmei) {
		this.kjSyainmei = kjSyainmei;
	}
	
}
