/*
 * 【システム名】リース管理システム
 * 【ファイル名】MassageHelperBean.java
 * 【  説  明  】共通メッセージ画面ヘルパービーン
 * 【  作  成  】2010/06/28 T.H(SCC)
 */
package com.toyotec_jp.ucar.workflow.common.message.view;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;

import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.view.UcarErrorHelperBean;

/**
 * <strong>共通メッセージ画面ヘルパービーン。</strong>
 * <p>
 * 共通メッセージ画面の表示を補助する。
 * </p>
 * @author T.H(SCC)
 * @version 1.00 2010/06/28 新規作成<br>
 * @since 1.00
 */
public class MessageHelperBean extends UcarErrorHelperBean {

	private static final long serialVersionUID = -8469945833527722090L;

	private MessageBean messageBean;

	private boolean isExistMessageBean = false;

	private boolean returnFlg = false;

	private String message;

	private String iconPath;

	/**
	 * コンストラクタ
	 */
	public MessageHelperBean() throws HelperBeanException{
		super();
	}

	/**
	 * 初期処理
	 */
	public void init() throws HelperBeanException{
		// 例外系パラメータ設定
		setupExceptionParams();
		// メッセージ用ビーンがリクエストに設定されているか
		Object bean = getRequest().getAttribute(UcarApplicationManager.REQ_ATTR_KEY_MESSAGE_BEAN);
		if(bean != null && MessageBean.class.isAssignableFrom(bean.getClass())){
			isExistMessageBean = true;
			messageBean = (MessageBean)bean;
			returnFlg = Boolean.valueOf(messageBean.getReturnFlg());
		}
		// 例外発生時の場合
		if(isException()){
			message = getExceptionDispMessage();
			switch (getLevel()) {
				case ERROR:
					iconPath = MessageBean.ICON_ERROR;
					break;
				case WARN:
					iconPath = MessageBean.ICON_WARNING;
					break;
				case INFO:
					iconPath = MessageBean.ICON_INFORMATION;
					break;
				default:
					iconPath = MessageBean.ICON_ERROR;
					break;
			}
			// システム例外の場合は戻らない
			if(isSystemException()){
				returnFlg = false;
			}
		// 正常系
		} else {
			if(isExistMessageBean){
				message = messageBean.getMessage();
				iconPath = messageBean.getIcon();
			} else {
				// TODO 正常系だが、メッセージ用ビーン無しで遷移した場合・・・
				message = "XXXXX";
				iconPath = MessageBean.ICON_INFORMATION;
			}
		}
	}

	/**
	 * messageBeanを取得する。
	 * @return messageBean
	 */
	public MessageBean getMessageBean() {
		return messageBean;
	}

	/**
	 * isExistMessageBeanを取得する。
	 * @return isExistMessageBean
	 */
	public boolean isExistMessageBean() {
		return isExistMessageBean;
	}

	/**
	 * isExistMessageBeanを取得する。
	 * @return isExistMessageBean
	 */
	public String isExistMessageBeanStr() {
		return Boolean.toString(isExistMessageBean);
	}

	/**
	 * returnFlgを取得する。
	 * @return returnFlg
	 */
	public boolean isReturnFlg() {
		return returnFlg;
	}

	/**
	 * returnFlgを取得する。
	 * @return returnFlg
	 */
	public String isReturnFlgStr() {
		return Boolean.toString(returnFlg);
	}

	/**
	 * messageを取得する。
	 * @return message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * iconPathを取得する。
	 * @return iconPath
	 */
	public String getIconPath() {
		return iconPath;
	}

}