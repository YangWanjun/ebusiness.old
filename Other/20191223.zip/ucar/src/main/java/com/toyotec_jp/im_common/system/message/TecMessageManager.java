/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecMessageManager.java
 * 【  説  明  】
 * 【  作  成  】2010/05/10 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.message;

import java.util.ArrayList;

import jp.co.intra_mart.foundation.security.exception.AccessSecurityException;
import jp.co.intra_mart.foundation.security.message.MessageManager;

import com.toyotec_jp.im_common.system.exception.TecMessageException;

/**
 * <strong>メッセージ管理クラス。</strong>
 * <p>
 * アプリケーションで使用するメッセージを管理する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/17 新規作成<br>
 * @since 1.00
 */
public class TecMessageManager {

	/**
	 * メッセージキーに対応するメッセージの取得。
	 * @param messageKey メッセージキー
	 * @return メッセージ
	 * @throws TecMessageException
	 */
	public static String getMessage(TecMessageKeyIF messageKey) throws TecMessageException {
		return getMessage(messageKey.getMessageKey(), "");
	}

	/**
	 * キーに対応するメッセージの取得。
	 * @param key キー名
	 * @return メッセージ
	 * @throws TecMessageException
	 */
	public static String getMessage(String key) throws TecMessageException {
		return getMessage(key, "");
	}

	/**
	 * メッセージキーに対応するメッセージの取得。
	 * @param messageKey メッセージキー
	 * @param args 置換文字列の配列
	 * @return 置換文字列をを挿入したメッセージ
	 * @throws TecMessageException
	 */
	public static String getMessage(TecMessageKeyIF messageKey, ArrayList<Object> args) throws TecMessageException {
		return getMessage(messageKey.getMessageKey(), args);
	}

	/**
	 * キーに対応するメッセージの取得。
	 * @param key キー名
	 * @param args 置換文字列の配列
	 * @return 置換文字列をを挿入したメッセージ
	 * @throws TecMessageException
	 */
	public static String getMessage(String key, ArrayList<Object> args) throws TecMessageException {
		ArrayList<String> strArgs = new ArrayList<String>();
		if(args != null){
			for(Object arg : args){
				if(arg != null){
					strArgs.add(arg.toString());
				} else {
					strArgs.add("");
				}
			}
		}
		return getMessage(key, strArgs.toArray(new String[strArgs.size()]));
	}

	/**
	 * メッセージキーに対応するメッセージの取得。
	 * @param messageKey メッセージキー
	 * @param args 置換文字列の配列
	 * @return 置換文字列をを挿入したメッセージ
	 * @throws TecMessageException
	 */
	public static String getMessage(TecMessageKeyIF messageKey, String ... args) throws TecMessageException {
		return getMessage(messageKey.getMessageKey(), args);
	}

	/**
	 * キーに対応するメッセージの取得。
	 * @param key キー名
	 * @param args 置換文字列の配列
	 * @return 置換文字列をを挿入したメッセージ
	 * @throws TecMessageException
	 */
	public static String getMessage(String key, String ... args) throws TecMessageException {
		String msg = null;
		MessageManager msgMng = MessageManager.getInstance();
		try {
			msg = msgMng.getMessage(key, args);
		} catch (AccessSecurityException e) {
			throw new TecMessageException(key, e);
		}
		return msg;
	}

	/**
	 * メッセージの再取得。
	 * <pre>
	 * IMのメッセージ管理クラスを初期化、メッセージ再取得を行う。
	 * </pre>
	 */
	public static void refreshMessage(){
		MessageManager.clearInstance();
	}

}
