/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】IMStorageServiceManager.java
 * 【  説  明  】
 * 【  作  成  】2010/07/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.io.IOException;
import java.util.Collection;

import jp.co.intra_mart.foundation.service.client.file.PublicStorage;

import com.toyotec_jp.im_common.system.exception.TecFileMngException;
import com.toyotec_jp.im_common.system.log.TecLogger;

/**
 * <strong>IMStorageService操作クラス。</strong>
 * <p>
 * IMのストレージサービスにおいてファイルを操作する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/01 新規作成<br>
 * @since 1.00
 */
public class IMStorageServiceManager implements IMFileManagerIF {

	/** コンストラクタ。 */
	private IMStorageServiceManager(){
	}

	private static final IMStorageServiceManager instance = new IMStorageServiceManager();

	/** エラーメッセージ:対象ファイルNull */
	private static final String MSG_ERR_NULL_FILE = "対象ファイルがNullになっています";
	/** エラーメッセージ:パスNull */
	private static final String MSG_ERR_NULL_PATH = "パスが未指定です";

	/** エラーメッセージ:フォルダ作成失敗 */
	private static final String MSG_ERR_CREATE_FOLDER = "フォルダ作成に失敗しました";
	/** エラーメッセージ:フォルダコピー失敗 */
	private static final String MSG_ERR_COPY_FOLDER = "フォルダコピーに失敗しました";
	/** エラーメッセージ:フォルダ削除失敗 */
	private static final String MSG_ERR_DELETE_FOLDER = "フォルダ削除に失敗しました";

	/** エラーメッセージ:ファイル保存失敗 */
	private static final String MSG_ERR_SAVE_FILE = "ファイル保存に失敗しました";
	/** エラーメッセージ:ファイル読込失敗 */
	private static final String MSG_ERR_LOAD_FILE = "ファイル読込に失敗しました";
	/** エラーメッセージ:ファイルコピー失敗 */
	private static final String MSG_ERR_COPY_FILE = "ファイルコピーに失敗しました";
	/** エラーメッセージ:ファイル移動失敗 */
	private static final String MSG_ERR_MOVE_FILE = "ファイル移動に失敗しました";
	/** エラーメッセージ:ファイル削除失敗 */
	private static final String MSG_ERR_DELETE_FILE = "ファイル削除に失敗しました";

	/** エラーメッセージ:NotFound */
	private static final String MSG_ERR_NOT_FOUND = "対象が存在しません";
	/** エラーメッセージ:上書き不可 */
	private static final String MSG_ERR_IS_EXIST = "既に同名のファイルまたはフォルダが存在しているため処理できません";

	/**
	 * インスタンス取得
	 * @return IMStorageService操作インスタンス
	 */
	public static IMStorageServiceManager getInstance(){
		return instance;
	}

	/**
	 * フォルダ作成<BR>
	 * 既にフォルダが存在している場合も作成成功とする
	 * @param path パス
	 * @throws TecFileMngException
	 */
	public void createFolder(String path) throws TecFileMngException {
		String funcName = "createFolder";
		boolean ret = false;
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		// 処理開始
		try{
			imnf = new PublicStorage(path);
			if(!imnf.exists()){
				ret = imnf.makeDirectories();
			} else {
				if(imnf.isDirectory()){
					// 既にフォルダが存在する場合
					ret = true;
				} else {
					// 同名のファイルが存在する場合
					TecLogger.error(funcName + ":isExist_error(file)");
					TecLogger.debug("[" + path + "]");
					throw new TecFileMngException(MSG_ERR_IS_EXIST);
				}
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_CREATE_FOLDER, e);
		} finally {
		}
		// 結果
		if(!ret){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + path + "]");
			throw new TecFileMngException(MSG_ERR_CREATE_FOLDER);
		}
	}

	/**
	 * フォルダコピー
	 * @param fromPath コピー元パス(フォルダ)
	 * @param toPath コピー先パス(フォルダ)
	 * @param doOverWrite true:上書き
	 * @throws TecFileMngException
	 */
	public void copyFolder(String fromPath, String toPath, boolean doOverWrite) throws TecFileMngException {
		String funcName = "copyFolder";
		boolean ret = false;
		PublicStorage imnfFrom = null;
		PublicStorage imnfTo = null;
		if(fromPath == null || toPath == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		String fromDirPath = StringUtils.getFolderPath(fromPath);
		String toDirPath = StringUtils.getFolderPath(toPath);
		TecLogger.trace("[" + fromDirPath + "][" + toDirPath + "]");
		// 処理開始
		try{
			imnfFrom = new PublicStorage(fromDirPath);
			imnfTo = new PublicStorage(toDirPath);
			// コピー元フォルダなし
			if(!(imnfFrom.exists() && imnfFrom.isDirectory())){
				TecLogger.error(funcName + ":not_found_error");
				TecLogger.debug("[" + fromDirPath + "]");
				throw new TecFileMngException(MSG_ERR_NOT_FOUND);
			}
			// コピー先
			if(!imnfTo.exists()){
				// 存在しない場合はコピー先フォルダ作成
				createFolder(toDirPath);
			} else {
				// 同名ファイルが存在する場合はエラー
				if(imnfTo.isFile()){
					TecLogger.error(funcName + ":isExist_error(file)");
					TecLogger.debug("[" + toDirPath + "]");
					throw new TecFileMngException(MSG_ERR_IS_EXIST);
				}
			}
			// ファイルコピー
			Collection<?> filePathList = imnfFrom.directories();
			for(Object filePath : filePathList){
				String filePathStr = filePath.toString();
				copyFile(fromDirPath + filePathStr, toDirPath + filePathStr, doOverWrite);
			}
			ret = true;
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + fromDirPath + "][" + toDirPath + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_COPY_FOLDER, e);
		} finally {}
		// 結果
		if(!ret){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + fromDirPath + "][" + toDirPath + "]");
			throw new TecFileMngException(MSG_ERR_COPY_FOLDER);
		}
	}

	/**
	 * フォルダ削除<BR>
	 * 対象が存在しない場合も削除成功とする
	 * @param path パス
	 * @throws TecFileMngException
	 */
	public void deleteFolder(String path) throws TecFileMngException {
		String funcName = "deleteFolder";
		boolean ret = false;
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		String targetPath = StringUtils.getFolderPath(path);
		TecLogger.trace("start[" + targetPath + "]");
		// 処理開始
		try{
			imnf = new PublicStorage(targetPath);
			if(imnf.exists()){
				// フォルダが存在する場合
				if(imnf.isDirectory()){
					// フォルダ直下のファイルを削除
					Collection<?> filePathList = imnf.files();
					for(Object filePath : filePathList){
						String filePathStr = filePath.toString();
						TecLogger.trace("[" + filePathStr + "]");
						deleteFile(targetPath + filePathStr);
					}
					// フォルダ直下のサブフォルダを削除
					Collection<?> dirPathList = imnf.directories();
					for(Object dirPath : dirPathList){
						String dirPathStr = dirPath.toString();
						TecLogger.trace("[" + dirPathStr + "]");
						deleteFolder(targetPath + dirPathStr);
					}
					// フォルダを削除
					ret = imnf.remove();
				// 同名ファイルが存在する場合
				} else {
					TecLogger.error(funcName + ":isExist_error(file)");
					TecLogger.debug("[" + targetPath + "]");
					throw new TecFileMngException(MSG_ERR_IS_EXIST);
				}
				TecLogger.trace("exist[" + targetPath + "]");
			// 対象が存在しない場合
			} else {
				TecLogger.trace("notexist[" + targetPath + "]");
				ret = true;
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + targetPath + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_DELETE_FOLDER, e);
		} finally {}
		// 結果
		if(!ret){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + targetPath + "]");
			throw new TecFileMngException(MSG_ERR_DELETE_FOLDER);
		}
		TecLogger.trace("end[" + targetPath + "]");
	}

	/**
	 * ファイル保存
	 * @param path パス
	 * @param byteStream 保存バイト配列
	 * @param doOverWrite true:上書き
	 * @throws TecFileMngException
	 */
	public void saveFile(String path, byte[] byteStream, boolean doOverWrite) throws TecFileMngException {
		String funcName = "saveFile";
		boolean ret = false;
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		if(byteStream == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_FILE);
		}
		// 処理開始
		try{
			imnf = new PublicStorage(path);
			initBeforeFileSave(imnf, path, doOverWrite, funcName);
			imnf.save(byteStream);
			
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_SAVE_FILE, e);
		} finally {}
		// 結果
		// TODO
		if(!ret){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + path + "]");
			throw new TecFileMngException(MSG_ERR_SAVE_FILE);
		}
	}

	/**
	 * ファイル読込
	 * @param path パス
	 * @return 読込バイト配列
	 * @throws TecFileMngException
	 */
	public byte[] loadFile(String path) throws TecFileMngException {
		String funcName = "loadFile";
		byte[] ret;
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		// 処理開始
		try{
			imnf = new PublicStorage(path);
			if(imnf.exists() && imnf.isFile()){
				ret = imnf.load();
			} else {
				TecLogger.error(funcName + ":not_found_error");
				TecLogger.debug("[" + path + "]");
				throw new TecFileMngException(MSG_ERR_NOT_FOUND);
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_LOAD_FILE, e);
		} finally {}
		// 結果
		if(ret == null){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + path + "]");
			throw new TecFileMngException(MSG_ERR_LOAD_FILE);
		}
		return ret;
	}

	/**
	 * ファイル削除<BR>
	 * 対象が存在しない場合も削除成功とする
	 * @param path パス
	 * @throws TecFileMngException
	 */
	public void deleteFile(String path) throws TecFileMngException {
		String funcName = "deleteFile";
		boolean ret = false;
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		// 処理開始
		try{
			imnf = new PublicStorage(path);
			if(imnf.exists()){
				// ファイルが存在する場合
				if(imnf.isFile()){
					ret = imnf.remove();
				// 同名フォルダが存在する場合
				} else {
					TecLogger.error(funcName + ":isExist_error(folder)");
					TecLogger.debug("[" + path + "]");
					throw new TecFileMngException(MSG_ERR_IS_EXIST);
				}
			// ファイルが存在しない場合
			} else {
				ret = true;
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_DELETE_FILE, e);
		} finally {}
		// 結果
		if(!ret){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + path + "]");
			throw new TecFileMngException(MSG_ERR_DELETE_FILE);
		}
	}

	/**
	 * ファイル移動
	 * @param fromPath 移動元パス
	 * @param toPath 移動先パス
	 * @param doOverWrite true:上書き
	 * @throws TecFileMngException
	 */
	public void moveFile(String fromPath, String toPath, boolean doOverWrite) throws TecFileMngException {
		String funcName = "moveFile";
		boolean ret = false;
		PublicStorage imnfFrom = null;
		PublicStorage imnfTo = null;
		if(fromPath == null || toPath == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		// 処理開始
		try{
			imnfFrom = new PublicStorage(fromPath);
			imnfTo = new PublicStorage(toPath);
			if(!(imnfFrom.exists() && imnfFrom.isFile())){
				TecLogger.error(funcName + ":not_found_error");
				TecLogger.debug("[" + fromPath + "]");
				throw new TecFileMngException(MSG_ERR_NOT_FOUND);
			} else {
				initBeforeFileSave(imnfTo, toPath, doOverWrite, funcName);
			}
			ret = imnfFrom.move(toPath);
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + fromPath + "][" + toPath + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_MOVE_FILE, e);
		} finally {}
		// 結果
		if(!ret){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + fromPath + "][" + toPath + "]");
			throw new TecFileMngException(MSG_ERR_MOVE_FILE);
		}
	}

	/**
	 * ファイルコピー
	 * @param fromPath コピー元パス
	 * @param toPath コピー先パス
	 * @param doOverWrite true:上書き
	 * @throws TecFileMngException
	 */
	public void copyFile(String fromPath, String toPath, boolean doOverWrite) throws TecFileMngException {
		String funcName = "copyFile";
		boolean ret = false;
		PublicStorage imnfFrom = null;
		PublicStorage imnfTo = null;
		if(fromPath == null || toPath == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		// 処理開始
		try{
			imnfFrom = new PublicStorage(fromPath);
			imnfTo = new PublicStorage(toPath);
			if(!(imnfFrom.exists() && imnfFrom.isFile())){
				TecLogger.error(funcName + ":not_found_error");
				TecLogger.debug("[" + fromPath + "]");
				throw new TecFileMngException(MSG_ERR_NOT_FOUND);
			} else {
				initBeforeFileSave(imnfTo, toPath, doOverWrite, funcName);
			}
			imnfTo.save(imnfFrom.load());
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + fromPath + "][" + toPath + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_COPY_FILE, e);
		} finally {}
		// 結果
		if(!ret){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + fromPath + "][" + toPath + "]");
			throw new TecFileMngException(MSG_ERR_COPY_FILE);
		}
	}

	/**
	 * フォルダ直下のファイル数取得。
	 * @param path パス
	 * @return ファイル数
	 * @throws TecFileMngException
	 */
	public int getFileCnt(String path) throws TecFileMngException {
		String funcName = "getFileCnt";
		int ret = 0;
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		// 処理開始
		try{
			imnf = new PublicStorage(path);
			if(imnf.exists() && imnf.isDirectory()){
				// フォルダ直下のファイル数取得
				ret = imnf.files().size();
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_LOAD_FILE, e);
		} finally {}
		return ret;
	}

	/**
	 * フォルダ直下のファイルを削除。
	 * @param path パス
	 * @throws TecFileMngException
	 */
	public void deleteChildFiles(String path) throws TecFileMngException {
		String funcName = "deleteChildFiles";
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		String targetPath = StringUtils.getFolderPath(path);
		TecLogger.trace("start[" + targetPath + "]");
		// 処理開始
		try{
			imnf = new PublicStorage(targetPath);
			if(imnf.exists() && imnf.isDirectory()){
				// フォルダ直下のファイルを削除
				Collection<?> filePathList = imnf.files();
				for(Object filePath : filePathList){
					String filePathStr = filePath.toString();
					TecLogger.trace("[" + filePathStr + "]");
					deleteFile(targetPath + filePathStr);
				}
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + targetPath + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_DELETE_FILE, e);
		} finally {}
		TecLogger.trace("end[" + targetPath + "]");
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.im_common.system.utils.IMFileManagerIF#getFileByteLength(java.lang.String)
	 */
	public long getFileByteLength(String path) throws TecFileMngException {
		String funcName = "getFileByteLength";
		long ret = 0;
		PublicStorage imnf = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH);
		}
		// 処理開始
		try{
			imnf = new PublicStorage(path);
			if(imnf.exists() && imnf.isFile()){
				ret = imnf.length();
			} else {
				TecLogger.error(funcName + ":not_found_error");
				TecLogger.debug("[" + path + "]");
				throw new TecFileMngException(MSG_ERR_NOT_FOUND);
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_LOAD_FILE, e);
		} finally {}
		return ret;
	}

	/**
	 * ファイル保存前処理
	 * @param imnf
	 * @param path
	 * @param doOverWrite
	 * @param funcName
	 * @throws TecFileMngException
	 * @throws IOException
	 */
	private void initBeforeFileSave(PublicStorage imnf, String path, boolean doOverWrite, String funcName) throws TecFileMngException, IOException {
		if(imnf.exists() && imnf.isFile()){
			// 同名ファイルあり
			if(doOverWrite){
				if(!imnf.remove()){
					// 削除失敗
					TecLogger.error(funcName + ":delete_error");
					TecLogger.debug("[" + path + "]");
					throw new TecFileMngException(MSG_ERR_DELETE_FILE);
				}
			} else {
				// 上書き不可
				TecLogger.error(funcName + ":isExist_error");
				TecLogger.debug("[" + path + "]");
				throw new TecFileMngException(MSG_ERR_IS_EXIST);
			}
		} else if(imnf.exists() && imnf.isDirectory()){
			// 同名フォルダあり
			TecLogger.error(funcName + ":isExist_error(folder)");
			TecLogger.debug("[" + path + "]");
			throw new TecFileMngException(MSG_ERR_IS_EXIST);
		} else {
			String parentPath = getParentFolderPath(path);
			createFolder(parentPath);
		}
	}

	/**
	 * 親フォルダパス取得
	 * @param path パス
	 * @return 親フォルダパス
	 */
	private String getParentFolderPath(String path){
		String pathSep = "/";
		StringBuffer sb = new StringBuffer();
		// 「\」変換後、最初と最後の「/」を削除
		String[] splitPath = path.replaceAll("\\\\", pathSep).replaceAll(
				pathSep + "$", "").replaceAll("^" + pathSep, "").split(pathSep);
		// 最後の要素を除く
		for(int i = 0; i < splitPath.length - 1; i++){
			sb.append(splitPath[i] + pathSep);
		}
		return new String(sb);
	}

}
