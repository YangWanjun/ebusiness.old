/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecPreparedStatement.java
 * 【  説  明  】
 * 【  作  成  】2010/05/19 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.db;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;

import com.toyotec_jp.im_common.system.model.object.SimplePrepareParamBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;


/**
 * <strong>共通プリペアドステートメントクラス。</strong>
 * <p>
 * 簡易パラメータ設定処理を実装したプリペアドステートメントクラス。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/19 新規作成<br>
 * @since 1.00
 */
public class TecPreparedStatement {

	private PreparedStatement pstmt = null;

	/**
	 * コンストラクタ。
	 * @param pstmt
	 */
	public TecPreparedStatement(PreparedStatement pstmt){
		this.pstmt = pstmt;
	}

	/**
	 * 簡易パラメータ設定。
	 * <pre>
	 * ビーンの値をプリペアドステートメントのパラメータとして設定する。
	 * </pre>
	 * @param paramBean 簡易クエリ実行用クエリパラメータビーン
	 * @throws SQLException
	 */
	public void setParameters(SimpleQueryParamBean paramBean) throws SQLException{
		if(paramBean != null){
			ArrayList<SimplePrepareParamBean> paramList = paramBean.getParamList();
			if(paramList != null){
				pstmt.clearParameters();
				int paramIdx = 1;
				for(SimplePrepareParamBean param : paramList){
					if(param.getValue() == null){
						pstmt.setObject(paramIdx++, param.getValue(), param.getSqlType());
					} else {
						switch (param.getSqlType()) {
						case Types.VARCHAR:
						case Types.NVARCHAR:
							pstmt.setString(paramIdx++, param.getValue().toString());
							break;
						default:
							pstmt.setObject(paramIdx++, param.getValue(), param.getSqlType());
							break;
						}
					}
				}
			}
		}
	}

	/**
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#addBatch()
	 */
	public void addBatch() throws SQLException {
		pstmt.addBatch();
	}

	/**
	 * @param arg0
	 * @throws SQLException
	 * @see java.sql.Statement#addBatch(java.lang.String)
	 */
	public void addBatch(String arg0) throws SQLException {
		pstmt.addBatch(arg0);
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Statement#cancel()
	 */
	public void cancel() throws SQLException {
		pstmt.cancel();
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Statement#clearBatch()
	 */
	public void clearBatch() throws SQLException {
		pstmt.clearBatch();
	}

	/**
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#clearParameters()
	 */
	public void clearParameters() throws SQLException {
		pstmt.clearParameters();
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Statement#clearWarnings()
	 */
	public void clearWarnings() throws SQLException {
		pstmt.clearWarnings();
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Statement#close()
	 */
	public void close() throws SQLException {
		pstmt.close();
	}

	/**
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#execute()
	 */
	public boolean execute() throws SQLException {
		return pstmt.execute();
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#execute(java.lang.String, int)
	 */
	public boolean execute(String arg0, int arg1) throws SQLException {
		return pstmt.execute(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#execute(java.lang.String, int[])
	 */
	public boolean execute(String arg0, int[] arg1) throws SQLException {
		return pstmt.execute(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#execute(java.lang.String, java.lang.String[])
	 */
	public boolean execute(String arg0, String[] arg1) throws SQLException {
		return pstmt.execute(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#execute(java.lang.String)
	 */
	public boolean execute(String arg0) throws SQLException {
		return pstmt.execute(arg0);
	}

	/**
	 * @return int[]
	 * @throws SQLException
	 * @see java.sql.Statement#executeBatch()
	 */
	public int[] executeBatch() throws SQLException {
		return pstmt.executeBatch();
	}

	/**
	 * 設定されたプリペアドステートメントを実行する。
	 * @return 共通リザルトセット
	 * @throws SQLException
	 */
	public TecResultSet executeQuery() throws SQLException {
		return new TecResultSet(pstmt.executeQuery());
	}

	/**
	 * 指定されたSQLを実行する。
	 * @param sql SQL
	 * @return 共通リザルトセット
	 * @throws SQLException
	 */
	public TecResultSet executeQuery(String sql) throws SQLException {
		return new TecResultSet(pstmt.executeQuery(sql));
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#executeUpdate()
	 */
	public int executeUpdate() throws SQLException {
		return pstmt.executeUpdate();
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#executeUpdate(java.lang.String, int)
	 */
	public int executeUpdate(String arg0, int arg1) throws SQLException {
		return pstmt.executeUpdate(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#executeUpdate(java.lang.String, int[])
	 */
	public int executeUpdate(String arg0, int[] arg1) throws SQLException {
		return pstmt.executeUpdate(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#executeUpdate(java.lang.String, java.lang.String[])
	 */
	public int executeUpdate(String arg0, String[] arg1) throws SQLException {
		return pstmt.executeUpdate(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#executeUpdate(java.lang.String)
	 */
	public int executeUpdate(String arg0) throws SQLException {
		return pstmt.executeUpdate(arg0);
	}

	/**
	 * @return Connection
	 * @throws SQLException
	 * @see java.sql.Statement#getConnection()
	 */
	public Connection getConnection() throws SQLException {
		return pstmt.getConnection();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getFetchDirection()
	 */
	public int getFetchDirection() throws SQLException {
		return pstmt.getFetchDirection();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getFetchSize()
	 */
	public int getFetchSize() throws SQLException {
		return pstmt.getFetchSize();
	}

	/**
	 * @return ResultSet
	 * @throws SQLException
	 * @see java.sql.Statement#getGeneratedKeys()
	 */
	public ResultSet getGeneratedKeys() throws SQLException {
		return pstmt.getGeneratedKeys();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getMaxFieldSize()
	 */
	public int getMaxFieldSize() throws SQLException {
		return pstmt.getMaxFieldSize();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getMaxRows()
	 */
	public int getMaxRows() throws SQLException {
		return pstmt.getMaxRows();
	}

	/**
	 * @return ResultSetMetaData
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#getMetaData()
	 */
	public ResultSetMetaData getMetaData() throws SQLException {
		return pstmt.getMetaData();
	}

	/**
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#getMoreResults()
	 */
	public boolean getMoreResults() throws SQLException {
		return pstmt.getMoreResults();
	}

	/**
	 * @param arg0
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#getMoreResults(int)
	 */
	public boolean getMoreResults(int arg0) throws SQLException {
		return pstmt.getMoreResults(arg0);
	}

	/**
	 * @return ParameterMetaData
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#getParameterMetaData()
	 */
	public ParameterMetaData getParameterMetaData() throws SQLException {
		return pstmt.getParameterMetaData();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getQueryTimeout()
	 */
	public int getQueryTimeout() throws SQLException {
		return pstmt.getQueryTimeout();
	}

	/**
	 * @return ResultSet
	 * @throws SQLException
	 * @see java.sql.Statement#getResultSet()
	 */
	public ResultSet getResultSet() throws SQLException {
		return pstmt.getResultSet();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getResultSetConcurrency()
	 */
	public int getResultSetConcurrency() throws SQLException {
		return pstmt.getResultSetConcurrency();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getResultSetHoldability()
	 */
	public int getResultSetHoldability() throws SQLException {
		return pstmt.getResultSetHoldability();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getResultSetType()
	 */
	public int getResultSetType() throws SQLException {
		return pstmt.getResultSetType();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Statement#getUpdateCount()
	 */
	public int getUpdateCount() throws SQLException {
		return pstmt.getUpdateCount();
	}

	/**
	 * @return SQLWarning
	 * @throws SQLException
	 * @see java.sql.Statement#getWarnings()
	 */
	public SQLWarning getWarnings() throws SQLException {
		return pstmt.getWarnings();
	}

	/**
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#isClosed()
	 */
	public boolean isClosed() throws SQLException {
		return pstmt.isClosed();
	}

	/**
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Statement#isPoolable()
	 */
	public boolean isPoolable() throws SQLException {
		return pstmt.isPoolable();
	}

	/**
	 * @param iface
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
	 */
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return pstmt.isWrapperFor(iface);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setArray(int, java.sql.Array)
	 */
	public void setArray(int arg0, Array arg1) throws SQLException {
		pstmt.setArray(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setAsciiStream(int, java.io.InputStream, int)
	 */
	public void setAsciiStream(int arg0, InputStream arg1, int arg2)
			throws SQLException {
		pstmt.setAsciiStream(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setAsciiStream(int, java.io.InputStream, long)
	 */
	public void setAsciiStream(int arg0, InputStream arg1, long arg2)
			throws SQLException {
		pstmt.setAsciiStream(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setAsciiStream(int, java.io.InputStream)
	 */
	public void setAsciiStream(int arg0, InputStream arg1) throws SQLException {
		pstmt.setAsciiStream(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBigDecimal(int, java.math.BigDecimal)
	 */
	public void setBigDecimal(int arg0, BigDecimal arg1) throws SQLException {
		pstmt.setBigDecimal(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBinaryStream(int, java.io.InputStream, int)
	 */
	public void setBinaryStream(int arg0, InputStream arg1, int arg2)
			throws SQLException {
		pstmt.setBinaryStream(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBinaryStream(int, java.io.InputStream, long)
	 */
	public void setBinaryStream(int arg0, InputStream arg1, long arg2)
			throws SQLException {
		pstmt.setBinaryStream(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBinaryStream(int, java.io.InputStream)
	 */
	public void setBinaryStream(int arg0, InputStream arg1) throws SQLException {
		pstmt.setBinaryStream(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBlob(int, java.sql.Blob)
	 */
	public void setBlob(int arg0, Blob arg1) throws SQLException {
		pstmt.setBlob(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBlob(int, java.io.InputStream, long)
	 */
	public void setBlob(int arg0, InputStream arg1, long arg2)
			throws SQLException {
		pstmt.setBlob(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBlob(int, java.io.InputStream)
	 */
	public void setBlob(int arg0, InputStream arg1) throws SQLException {
		pstmt.setBlob(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBoolean(int, boolean)
	 */
	public void setBoolean(int arg0, boolean arg1) throws SQLException {
		pstmt.setBoolean(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setByte(int, byte)
	 */
	public void setByte(int arg0, byte arg1) throws SQLException {
		pstmt.setByte(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setBytes(int, byte[])
	 */
	public void setBytes(int arg0, byte[] arg1) throws SQLException {
		pstmt.setBytes(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setCharacterStream(int, java.io.Reader, int)
	 */
	public void setCharacterStream(int arg0, Reader arg1, int arg2)
			throws SQLException {
		pstmt.setCharacterStream(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setCharacterStream(int, java.io.Reader, long)
	 */
	public void setCharacterStream(int arg0, Reader arg1, long arg2)
			throws SQLException {
		pstmt.setCharacterStream(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setCharacterStream(int, java.io.Reader)
	 */
	public void setCharacterStream(int arg0, Reader arg1) throws SQLException {
		pstmt.setCharacterStream(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setClob(int, java.sql.Clob)
	 */
	public void setClob(int arg0, Clob arg1) throws SQLException {
		pstmt.setClob(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setClob(int, java.io.Reader, long)
	 */
	public void setClob(int arg0, Reader arg1, long arg2) throws SQLException {
		pstmt.setClob(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setClob(int, java.io.Reader)
	 */
	public void setClob(int arg0, Reader arg1) throws SQLException {
		pstmt.setClob(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @throws SQLException
	 * @see java.sql.Statement#setCursorName(java.lang.String)
	 */
	public void setCursorName(String arg0) throws SQLException {
		pstmt.setCursorName(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setDate(int, java.sql.Date, java.util.Calendar)
	 */
	public void setDate(int arg0, Date arg1, Calendar arg2) throws SQLException {
		pstmt.setDate(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setDate(int, java.sql.Date)
	 */
	public void setDate(int arg0, Date arg1) throws SQLException {
		pstmt.setDate(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setDouble(int, double)
	 */
	public void setDouble(int arg0, double arg1) throws SQLException {
		pstmt.setDouble(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @throws SQLException
	 * @see java.sql.Statement#setEscapeProcessing(boolean)
	 */
	public void setEscapeProcessing(boolean arg0) throws SQLException {
		pstmt.setEscapeProcessing(arg0);
	}

	/**
	 * @param arg0
	 * @throws SQLException
	 * @see java.sql.Statement#setFetchDirection(int)
	 */
	public void setFetchDirection(int arg0) throws SQLException {
		pstmt.setFetchDirection(arg0);
	}

	/**
	 * @param arg0
	 * @throws SQLException
	 * @see java.sql.Statement#setFetchSize(int)
	 */
	public void setFetchSize(int arg0) throws SQLException {
		pstmt.setFetchSize(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setFloat(int, float)
	 */
	public void setFloat(int arg0, float arg1) throws SQLException {
		pstmt.setFloat(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setInt(int, int)
	 */
	public void setInt(int arg0, int arg1) throws SQLException {
		pstmt.setInt(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setLong(int, long)
	 */
	public void setLong(int arg0, long arg1) throws SQLException {
		pstmt.setLong(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @throws SQLException
	 * @see java.sql.Statement#setMaxFieldSize(int)
	 */
	public void setMaxFieldSize(int arg0) throws SQLException {
		pstmt.setMaxFieldSize(arg0);
	}

	/**
	 * @param arg0
	 * @throws SQLException
	 * @see java.sql.Statement#setMaxRows(int)
	 */
	public void setMaxRows(int arg0) throws SQLException {
		pstmt.setMaxRows(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNCharacterStream(int, java.io.Reader, long)
	 */
	public void setNCharacterStream(int arg0, Reader arg1, long arg2)
			throws SQLException {
		pstmt.setNCharacterStream(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNCharacterStream(int, java.io.Reader)
	 */
	public void setNCharacterStream(int arg0, Reader arg1) throws SQLException {
		pstmt.setNCharacterStream(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNClob(int, java.sql.NClob)
	 */
	public void setNClob(int arg0, NClob arg1) throws SQLException {
		pstmt.setNClob(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNClob(int, java.io.Reader, long)
	 */
	public void setNClob(int arg0, Reader arg1, long arg2) throws SQLException {
		pstmt.setNClob(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNClob(int, java.io.Reader)
	 */
	public void setNClob(int arg0, Reader arg1) throws SQLException {
		pstmt.setNClob(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNString(int, java.lang.String)
	 */
	public void setNString(int arg0, String arg1) throws SQLException {
		pstmt.setNString(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNull(int, int, java.lang.String)
	 */
	public void setNull(int arg0, int arg1, String arg2) throws SQLException {
		pstmt.setNull(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setNull(int, int)
	 */
	public void setNull(int arg0, int arg1) throws SQLException {
		pstmt.setNull(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setObject(int, java.lang.Object, int, int)
	 */
	public void setObject(int arg0, Object arg1, int arg2, int arg3)
			throws SQLException {
		pstmt.setObject(arg0, arg1, arg2, arg3);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setObject(int, java.lang.Object, int)
	 */
	public void setObject(int arg0, Object arg1, int arg2) throws SQLException {
		pstmt.setObject(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setObject(int, java.lang.Object)
	 */
	public void setObject(int arg0, Object arg1) throws SQLException {
		pstmt.setObject(arg0, arg1);
	}

	/**
	 * @param poolable
	 * @throws SQLException
	 * @see java.sql.Statement#setPoolable(boolean)
	 */
	public void setPoolable(boolean poolable) throws SQLException {
		pstmt.setPoolable(poolable);
	}

	/**
	 * @param seconds
	 * @throws SQLException
	 * @see java.sql.Statement#setQueryTimeout(int)
	 */
	public void setQueryTimeout(int seconds) throws SQLException {
		pstmt.setQueryTimeout(seconds);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setRef(int, java.sql.Ref)
	 */
	public void setRef(int arg0, Ref arg1) throws SQLException {
		pstmt.setRef(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setRowId(int, java.sql.RowId)
	 */
	public void setRowId(int arg0, RowId arg1) throws SQLException {
		pstmt.setRowId(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setShort(int, short)
	 */
	public void setShort(int arg0, short arg1) throws SQLException {
		pstmt.setShort(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setSQLXML(int, java.sql.SQLXML)
	 */
	public void setSQLXML(int arg0, SQLXML arg1) throws SQLException {
		pstmt.setSQLXML(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setString(int, java.lang.String)
	 */
	public void setString(int arg0, String arg1) throws SQLException {
		pstmt.setString(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setTime(int, java.sql.Time, java.util.Calendar)
	 */
	public void setTime(int arg0, Time arg1, Calendar arg2) throws SQLException {
		pstmt.setTime(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setTime(int, java.sql.Time)
	 */
	public void setTime(int arg0, Time arg1) throws SQLException {
		pstmt.setTime(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setTimestamp(int, java.sql.Timestamp, java.util.Calendar)
	 */
	public void setTimestamp(int arg0, Timestamp arg1, Calendar arg2)
			throws SQLException {
		pstmt.setTimestamp(arg0, arg1, arg2);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setTimestamp(int, java.sql.Timestamp)
	 */
	public void setTimestamp(int arg0, Timestamp arg1) throws SQLException {
		pstmt.setTimestamp(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @throws SQLException
	 * @see java.sql.PreparedStatement#setURL(int, java.net.URL)
	 */
	public void setURL(int arg0, URL arg1) throws SQLException {
		pstmt.setURL(arg0, arg1);
	}

	/**
	 * @param <T>
	 * @param iface
	 * @return Class
	 * @throws SQLException
	 * @see java.sql.Wrapper#unwrap(java.lang.Class)
	 */
	public <T> T unwrap(Class<T> iface) throws SQLException {
		return pstmt.unwrap(iface);
	}

}
