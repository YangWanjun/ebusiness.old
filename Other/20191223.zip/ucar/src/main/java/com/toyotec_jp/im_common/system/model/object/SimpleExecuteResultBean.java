/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】SimpleExecuteResultBean.java
 * 【  説  明  】
 * 【  作  成  】2010/07/02 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.model.object;

import jp.co.intra_mart.framework.base.event.EventResult;


/**
 * <strong>簡易更新クエリ実行結果ビーン。</strong>
 * <p>
 * 簡易更新クエリ実行の実行結果として返却されるビーン。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/02 新規作成<br>
 * @since 1.00
 */
public class SimpleExecuteResultBean extends TecBean implements EventResult {

	private static final long serialVersionUID = 3880799218626937193L;

	private int executeCount;

	private String generatedKey;

	/**
	 * コンストラクタ。
	 */
	public SimpleExecuteResultBean() {
		super();
		init();
	}

	private void init(){
		executeCount = 0;
		generatedKey = null;
	}

	/**
	 * executeCountを取得する。
	 * @return executeCount
	 */
	public int getExecuteCount() {
		return executeCount;
	}

	/**
	 * executeCountを設定する。
	 * @param executeCount
	 */
	public void setExecuteCount(int executeCount) {
		this.executeCount = executeCount;
	}

	/**
	 * generatedKeyを取得する。
	 * @return generatedKey
	 */
	public String getGeneratedKey() {
		return generatedKey;
	}

	/**
	 * generatedKeyを設定する。
	 * @param generatedKey
	 */
	public void setGeneratedKey(String generatedKey) {
		this.generatedKey = generatedKey;
	}

}
