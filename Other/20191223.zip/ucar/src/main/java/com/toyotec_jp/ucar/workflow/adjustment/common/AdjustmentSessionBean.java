package com.toyotec_jp.ucar.workflow.adjustment.common;

import java.util.ArrayList;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;

/**
 * <strong>精算セッションBean。</strong>
 * <p>
 * セッションに格納する精算パッケージ共通セッションBean。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[精算(共通)]]
 */
public class AdjustmentSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** サービスID */
	private String serviceId;
	/** メニューID */
	private String menuId;

	/** 会社コード */
	private String cdKaisya;
	/** 事業所コード */
	private String cdJigyosyo;

	/** 受注NO */
	private String noJucyu;

	/** 売上精算 画面出力値Bean */
	private SalesAdjustmentDataBean salesAdjustmentDataBean;
	/** 確認メッセージ表示 */
	private boolean confirmMessage;

	/** 処理モード */
	private String rdoSearch;
	/** 再発行ボタン使用可否フラグ */
	private boolean disabledBtnReissue;

	/** ダウンロードファイルパス */
	private ArrayList<String> arrayDownloadFilePath;

	/**
	 * デフォルトコンストラクタ。
	 */
	public AdjustmentSessionBean() {
		setDefaultParams();
	}

	/**
	 * デフォルトパラメータ設定。
	 * <pre>
	 * </pre>
	 */
	public void setDefaultParams(){

	}

	/**
	 * serviceIdを取得する。
	 * @return serviceId サービスID
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * serviceIdを設定する。
	 * @param serviceId サービスID
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * menuIdを取得する。
	 * @return menuId メニューID
	 */
	public String getMenuId() {
		return menuId;
	}

	/**
	 * menuIdを設定する。
	 * @param menuId メニューID
	 */
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdJigyosyoを取得する。
	 * @return cdJigyosyo 事業所コード
	 */
	public String getCdJigyosyo() {
		return cdJigyosyo;
	}

	/**
	 * cdJigyosyoを設定する。
	 * @param cdJigyosyo 事業所コード
	 */
	public void setCdJigyosyo(String cdJigyosyo) {
		this.cdJigyosyo = cdJigyosyo;
	}

	/**
	 * noJucyuを取得する。
	 * @return noJucyu 受注NO
	 */
	public String getNoJucyu() {
		return noJucyu;
	}

	/**
	 * noJucyuを設定する。
	 * @param noJucyu 受注NO
	 */
	public void setNoJucyu(String noJucyu) {
		this.noJucyu = noJucyu;
	}

	/**
	 * salesAdjustmentDataBeanを取得する。
	 * @return salesAdjustmentDataBean
	 */
	public SalesAdjustmentDataBean getSalesAdjustmentDataBean() {
		return salesAdjustmentDataBean;
	}

	/**
	 * salesAdjustmentDataBeanを設定する。
	 * @param salesAdjustmentDataBean
	 */
	public void setSalesAdjustmentDataBean(
			SalesAdjustmentDataBean salesAdjustmentDataBean) {
		this.salesAdjustmentDataBean = salesAdjustmentDataBean;
	}

	/**
	 * confirmMessageを取得する。
	 * @return confirmMessage
	 */
	public boolean isConfirmMessage() {
		return confirmMessage;
	}

	/**
	 * confirmMessageを設定する。
	 * @param confirmMessage
	 */
	public void setConfirmMessage(boolean confirmMessage) {
		this.confirmMessage = confirmMessage;
	}

	/**
	 * rdoSearchを取得する。
	 * @return rdoSearch
	 */
	public String getRdoSearch() {
		return rdoSearch;
	}

	/**
	 * rdoSearchを設定する。
	 * @param rdoSearch
	 */
	public void setRdoSearch(String rdoSearch) {
		this.rdoSearch = rdoSearch;
	}

	/**
	 * disabledBtnReissueを取得する。
	 * @return disabledBtnReissue
	 */
	public boolean isDisabledBtnReissue() {
		return disabledBtnReissue;
	}

	/**
	 * disabledBtnReissueを設定する。
	 * @param disabledBtnReissue
	 */
	public void setDisabledBtnReissue(boolean disabledBtnReissue) {
		this.disabledBtnReissue = disabledBtnReissue;
	}

	/**
	 * arrayDownloadFilePathを取得する。
	 * @return arrayDownloadFilePath
	 */
	public ArrayList<String> getArrayDownloadFilePath() {
		return arrayDownloadFilePath;
	}

	/**
	 * arrayDownloadFilePathを設定する。
	 * @param arrayDownloadFilePath
	 */
	public void setArrayDownloadFilePath(ArrayList<String> arrayDownloadFilePath) {
		this.arrayDownloadFilePath = arrayDownloadFilePath;
	}

}
