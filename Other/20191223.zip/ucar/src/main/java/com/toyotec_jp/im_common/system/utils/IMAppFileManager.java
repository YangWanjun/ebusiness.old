/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】IMAppFileManager.java
 * 【  説  明  】
 * 【  作  成  】2010/07/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Iterator;

import jp.co.intra_mart.common.aid.jdk.java.io.file.ExtendedDirectory;
import jp.co.intra_mart.common.aid.jdk.java.io.file.ExtendedFile;
import com.toyotec_jp.im_common.system.utils.HomeDirectory;

import com.toyotec_jp.im_common.system.exception.TecFileMngException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.StringUtils.CharSet;

/**
 * <strong>IMAppRuntimeファイル操作クラス。</strong>
 * <p>
 * IMのAppRuntimeにおいてファイルを操作する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/01 新規作成<br>
 * @since 1.00
 */
public class IMAppFileManager implements IMFileManagerIF {

	/** コンストラクタ。 */
	private IMAppFileManager(){
	}

	private static final IMAppFileManager instance = new IMAppFileManager();

	/** Application Runtime 一時ディレクトリ(固定(スクリプト開発モデルFileオブジェクトと同等に扱うため)) */
	private static final String APP_TEMP_DIR = "dealerspt/p220_ucar/work/";
	/** Application Runtime HOMEディレクトリ */
	private static final HomeDirectory APP_HOME_DIR = HomeDirectory.instance();

	/** エラーメッセージ:パスNull */
	private static final String MSG_ERR_NULL_PATH = "パスが未指定です";

	/** エラーメッセージ:ファイルオブジェクト取得失敗 */
	private static final String MSG_ERR_NEW_FILE = "ファイルオブジェクト取得に失敗しました";

	/** エラーメッセージ:フォルダ作成失敗 */
	private static final String MSG_ERR_CREATE_FOLDER = "フォルダ作成に失敗しました";

	/** エラーメッセージ:ファイル保存失敗 */
	private static final String MSG_ERR_SAVE_FILE = "ファイル保存に失敗しました";
	/** エラーメッセージ:ファイル読込失敗 */
	private static final String MSG_ERR_LOAD_FILE = "ファイル読込に失敗しました";
	/** エラーメッセージ:ファイル削除失敗 */
	private static final String MSG_ERR_DELETE_FILE = "ファイル削除に失敗しました";

	/** エラーメッセージ:上書き不可 */
	private static final String MSG_ERR_IS_EXIST = "既に同名のファイルまたはフォルダが存在しているため処理できません";

	/**
	 * インスタンス取得。
	 * @return IMAppRuntimeファイル操作インスタンス
	 */
	public static IMAppFileManager getInstance(){
		return instance;
	}

	/**
	 * ファイル保存。
	 * @param path パス
	 * @param byteStream 保存バイト配列
	 * @param doOverWrite true:上書き
	 * @throws TecFileMngException
	 */
	public void saveFile(String path, byte[] byteStream, boolean doOverWrite) throws TecFileMngException {
		String funcName = "saveFile";
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		ExtendedFile imaf = getAppFileObject(path);
		saveFile(path, imaf, byteStream, doOverWrite);
	}

	/**
	 * ファイル保存。
	 * @param absPath パス(絶対パス)
	 * @param byteStream 保存バイト配列
	 * @param doOverWrite true:上書き
	 * @throws TecFileMngException
	 */
	public void saveAbsFile(String absPath, byte[] byteStream, boolean doOverWrite) throws TecFileMngException {
		String funcName = "saveAbsFile";
		if(absPath == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		ExtendedFile imaf = new ExtendedFile(absPath);
		saveFile(absPath, imaf, byteStream, doOverWrite);
	}

	/** ファイル保存。 */
	private void saveFile(
			String path, ExtendedFile imaf, byte[] byteStream, boolean doOverWrite) throws TecFileMngException {
		String funcName = "saveFile";
		// 処理開始
		try{
			// 同名ファイルが存在する場合
			if(imaf.exists() && imaf.isFile()){
				if(doOverWrite){
					imaf.write(byteStream);
					return;
				}
				TecLogger.error(funcName + ":isExist_error");
				TecLogger.debug("[" + path + "]");
				throw new TecFileMngException(MSG_ERR_IS_EXIST);
			// 同名フォルダが存在する場合
			} else if(imaf.exists() && imaf.isDirectory()){
				TecLogger.error(funcName + ":isExist_error(folder)");
				TecLogger.debug("[" + path + "]");
				throw new TecFileMngException(MSG_ERR_IS_EXIST);
			// ファイルが存在しない場合
			} else {
				if(!imaf.getParentFile().exists()){
					if(!imaf.getParentFile().mkdirs()){
						TecLogger.error(funcName + ":mkdirs_error");
						TecLogger.debug("[" + imaf.getParent() + "]");
						throw new TecFileMngException(MSG_ERR_CREATE_FOLDER);
					}
				}
				if(imaf.createNewFile()){
					imaf.write(byteStream);
					return;
				}
				TecLogger.error(funcName + ":exec_error");
				TecLogger.debug("[" + imaf.getPath() + "]");
				throw new TecFileMngException(MSG_ERR_SAVE_FILE);
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_SAVE_FILE, e);
		}
	}

	/**
	 * ファイル追記(文字列)。
	 * <pre>
	 * デフォルト文字コードで追記。
	 * </pre>
	 * @param path パス
	 * @param appendString 追記する文字列
	 * @throws TecFileMngException
	 */
	public void appendStrFile(String path, String appendString) throws TecFileMngException {
		appendStrFile(path, appendString, null);
	}

	/**
	 * ファイル追記(文字列)。
	 * @param path パス
	 * @param appendString 追記する文字列
	 * @param encodeCharSetName エンコード文字コード名(Null時はデフォルト文字コードを使用)
	 * @throws TecFileMngException
	 */
	public void appendStrFile(String path, String appendString, String encodeCharSetName) throws TecFileMngException {
		String funcName = "appendStrFile";
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		ExtendedFile imaf = getAppFileObject(path);
		try{
			// 同名ファイルが存在する場合
			if(imaf.exists() && imaf.isFile()){
				// 追記
				if(encodeCharSetName == null){
					imaf.append(appendString);
				} else {
					imaf.append(appendString, encodeCharSetName);
				}
			// 同名フォルダが存在する場合
			} else if(imaf.exists() && imaf.isDirectory()){
				TecLogger.error(funcName + ":isExist_error(folder)");
				TecLogger.debug("[" + path + "]");
				throw new TecFileMngException(MSG_ERR_IS_EXIST);
			// ファイルが存在しない場合
			} else {
				if(!imaf.getParentFile().exists()){
					if(!imaf.getParentFile().mkdirs()){
						TecLogger.error(funcName + ":mkdirs_error");
						TecLogger.debug("[" + imaf.getParent() + "]");
						throw new TecFileMngException(MSG_ERR_CREATE_FOLDER);
					}
				}
				if(imaf.createNewFile()){
					if(encodeCharSetName == null){
						imaf.write(appendString);
					} else {
						imaf.write(appendString, encodeCharSetName);
					}
					return;
				}
				TecLogger.error(funcName + ":exec_error");
				TecLogger.debug("[" + imaf.getPath() + "]");
				throw new TecFileMngException(MSG_ERR_SAVE_FILE);
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_SAVE_FILE, e);
		}
	}

	/**
	 * ファイル読込。
	 * @param path パス
	 * @return 読込バイト配列
	 * @throws TecFileMngException
	 */
	public byte[] loadFile(String path) throws TecFileMngException {
		String funcName = "loadFile";
		byte[] ret;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		try{
			ExtendedFile imaf = getAppFileObject(path);
			if(imaf.exists() && imaf.isFile()){
				ret = imaf.getBytes();
			} else {
				TecLogger.error(funcName + ":isExist_error");
				TecLogger.debug("[" + imaf.getPath() + "]");
				throw new TecFileMngException(MSG_ERR_IS_EXIST);
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_LOAD_FILE, e);
		}
		if(ret == null){
			TecLogger.error(funcName + ":exec_error");
			TecLogger.debug("[" + path + "]");
			throw new TecFileMngException(MSG_ERR_LOAD_FILE);
		}
		return ret;
	}

	/**
	 * ファイル削除。
	 * @param path パス
	 * @throws TecFileMngException
	 */
	public void deleteFile(String path) throws TecFileMngException{
		String funcName = "deleteFile";
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		ExtendedFile imaf = getAppFileObject(path);
		if(imaf.exists() && imaf.isFile()){
			if(!imaf.delete()){
				TecLogger.error(funcName + ":exec_error");
				TecLogger.debug("[" + imaf.getPath() + "]");
				throw new TecFileMngException(MSG_ERR_DELETE_FILE);
			}
		// 同名フォルダが存在する場合
		} else if(imaf.exists() && imaf.isDirectory()){
			TecLogger.error(funcName + ":isExist_error(folder)");
			TecLogger.debug("[" + path + "]");
			throw new TecFileMngException(MSG_ERR_IS_EXIST);
		}
		return;
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.im_common.system.utils.IMFileManagerIF#getFileByteLength(java.lang.String)
	 */
	public long getFileByteLength(String path) throws TecFileMngException {
		String funcName = "getFileByteLength";
		long ret = 0;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		ExtendedFile imaf = getAppFileObject(path);
		if(imaf.exists() && imaf.isFile()){
			ret = imaf.length();
		} else {
			TecLogger.error(funcName + ":isExist_error");
			TecLogger.debug("[" + imaf.getPath() + "]");
			throw new TecFileMngException(MSG_ERR_IS_EXIST);
		}
		return ret;
	}

	/**
	 * ファイルの行を繰り返し処理する反復子を作成。
	 * <pre>
	 * デフォルトの文字エンコーディングを使用する。
	 * </pre>
	 * @param path パス
	 * @return ファイルの行を繰り返し処理する反復子
	 * @throws TecFileMngException
	 */
	public Iterator<String> readLines(String path) throws TecFileMngException {
		return readLines(path, null);
	}

	/**
	 * ファイルの行を繰り返し処理する反復子を作成。
	 * @param path パス
	 * @param encChar ファイルの文字エンコーディング名
	 * @return ファイルの行を繰り返し処理する反復子
	 * @throws TecFileMngException
	 */
	@SuppressWarnings("unchecked")
	public Iterator<String> readLines(String path, CharSet encChar) throws TecFileMngException {
		String funcName = "readLines";
		Iterator<String> ret = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		ExtendedFile imaf = getAppFileObject(path);
		try{
			if(encChar == null){
				ret = (Iterator<String>)imaf.readLines();
			} else {
				ret = (Iterator<String>)imaf.readLines(encChar.toString());
			}
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + path + "][" + e.getMessage() + "]");
			throw new TecFileMngException(MSG_ERR_LOAD_FILE, e);
		}
		return ret;
	}

	/**
	 * 絶対パス返却。
	 * @param path パス
	 * @return 絶対パス
	 * @throws TecFileMngException
	 */
	public String getAbsPath(String path) throws TecFileMngException {
		String funcName = "getAbsPath";
		String ret = null;
		if(path == null){
			TecLogger.error(funcName + ":call_error");
			throw new TecFileMngException(MSG_ERR_NULL_PATH, new IllegalAccessException());
		}
		// 処理開始
		ExtendedFile imaf = getAppFileObject(path);
		ret = imaf.getAbsolutePath();
		return ret;
	}

	/**
	 * IMAppRuntime用拡張ファイルオブジェクト取得。
	 * @param path パス
	 * @return ファイルオブジェクト
	 * @throws TecFileMngException
	 */
	public ExtendedFile getAppFileObject(String path) throws TecFileMngException {
		ExtendedFile imaf = null;
		String appPath = APP_TEMP_DIR + path;
		imaf = APP_HOME_DIR.childFile(appPath);
		if(imaf == null){
			TecLogger.error("--- file_object_error ---");
			TecLogger.debug("[" + appPath + "]");
			throw new TecFileMngException(MSG_ERR_NEW_FILE);
		}
		return imaf;
	}

	/**
	 * 古いファイルの削除。
	 * <pre>
	 * 親ディレクトリ以下の古いファイルを削除する。<br>
	 * calendarFieldに「Calendar.HOUR」、amountに「3」を設定した場合、
	 * 最終更新日時が3時間前よりも古いファイルを削除する。
	 * </pre>
	 * @param parentPath 親ディレクトリのパス
	 * @param calendarField カレンダフィールド
	 * @param amount フィールドから減算される日付または時刻の量
	 */
	public void deleteOldFile(String parentPath, int calendarField, int amount){
		String appPath = APP_TEMP_DIR + parentPath;
		ExtendedDirectory parentDir = APP_HOME_DIR.childDirectory(appPath);
		Calendar baseDate = getExecBaseDate(calendarField, amount);
		if(parentDir.childFiles() != null){
			for(Object child : parentDir.childFiles()){
				if(child instanceof File){
					File childFile = (File)child;
					// 基準日よりも古いファイルを削除
					if(childFile.lastModified() < baseDate.getTimeInMillis()){
						if(!childFile.delete()){
							TecLogger.warn(MSG_ERR_DELETE_FILE + "[" + childFile.getPath() + "]");
						}
					}
				}
			}
		}
	}

	/** 基準日を返却 */
	private Calendar getExecBaseDate(int calendarField, int amount){
		Calendar cal = Calendar.getInstance();
		if(amount != 0){
			int subamount = amount;
			if(subamount > 0){
				subamount = -subamount;
			}
			switch (calendarField) {
				case Calendar.YEAR:
				case Calendar.MONTH:
				case Calendar.DATE:
				case Calendar.HOUR:
				case Calendar.HOUR_OF_DAY:
				case Calendar.MINUTE:
				case Calendar.SECOND:
				case Calendar.MILLISECOND:
					cal.add(calendarField, subamount);
					break;
				default:
					// amount日前を返却
					cal.add(Calendar.DATE, subamount);
					break;
			}
		}
		return cal;
	}

}
