/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】SimplePagingResultBean.java
 * 【  説  明  】
 * 【  作  成  】2010/05/24 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.model.object;

import java.util.ArrayList;

import jp.co.intra_mart.framework.base.event.EventResult;


/**
 * <strong>簡易ページング用クエリ実行結果ビーン。</strong>
 * <p>
 * 簡易SELECTクエリ実行(ページング)の実行結果として返却されるビーン。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/07 新規作成<br>
 * @since 1.00
 */
public abstract class SimplePagingResultBean<E> extends TecBean implements EventResult {

	private static final long serialVersionUID = -1290452216195764944L;

	private boolean isOverRecLimit = false;

	private int totalRecordCount;

	private int recordCount;

	private int pageNo;

	private int pageSize;

	private int recLimit;

	private ArrayList<E> resultRecordList;

	public SimplePagingResultBean() {
		super();
	}

	/**
	 * isOverRecLimitを取得する。
	 * @return isOverRecLimit true:レコード出力制限値を超えている
	 */
	public boolean isOverRecLimit() {
		return isOverRecLimit;
	}

	/**
	 * isOverRecLimitを設定する。
	 * @param isOverRecLimit
	 */
	public void setOverRecLimit(boolean isOverRecLimit) {
		this.isOverRecLimit = isOverRecLimit;
	}

	/**
	 * totalRecordCountを取得する。
	 * @return totalRecordCount 総件数
	 * @since 1.00
	 */
	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	/**
	 * totalRecordCountを設定する。
	 * @param totalRecordCount
	 * @since 1.00
	 */
	public void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	/**
	 * recordCountを取得する。
	 * @return recordCount
	 * @since 1.00
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * recordCountを設定する。
	 * @param recordCount
	 * @since 1.00
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo
	 * @since 1.00
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @param pageNo
	 * @since 1.00
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize
	 * @since 1.00
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize
	 * @since 1.00
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * resultRecordListを取得する。
	 * @return resultRecordList
	 * @since 1.00
	 */
	public ArrayList<E> getResultRecordList() {
		return resultRecordList;
	}

	/**
	 * resultRecordListを設定する。
	 * @param resultRecordList
	 * @since 1.00
	 */
	public void setResultRecordList(ArrayList<E> resultRecordList) {
		this.resultRecordList = resultRecordList;
	}

	/**
	 * recLimitを取得する。
	 * @return recLimit
	 */
	public int getRecLimit() {
		return recLimit;
	}

	/**
	 * recLimitを設定する。
	 * @param recLimit
	 */
	public void setRecLimit(int recLimit) {
		this.recLimit = recLimit;
	}

}
