/*
 * 【システム名】リース管理システム
 * 【ファイル名】CalendarSessionBean.java
 * 【  説  明  】カレンダー情報セッション保持用Bean
 * 【  作  成  】2010/06/25 T.H(SCC)
 */
package com.toyotec_jp.ucar.workflow.common.calendar.model.object;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;

/**
 * カレンダー情報セッション保持用Bean
 */
public class CalendarSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = 1L;
	private String form;			// フォーム
	private String name;			// エレメント名
	private String year;			// 年
	private String month;			// 月
	private String dateformat;		// 日付書式
//2015.4.22 前後追加 START
	private String yearBefore;		// 前年
	private String monthBefore;	// 前月
	private String yearAfter;		// 翌年
	private String monthAfter;		// 翌月
//2015.4.22 前後追加 END
	
	/**
	 * コンストラクタ
	 */
	public CalendarSessionBean() {
		super();
		this.form		= "";
		this.name		= "";
		this.year		= "";
		this.month		= "";
		this.dateformat	= "";
//2015.4.22 前後追加 START
		this.yearBefore		= "";
		this.monthBefore	= "";
		this.yearAfter		= "";
		this.monthAfter		= "";
//2015.4.22 前後追加 END
		
	}

	/**
	 * フォームを設定します
	 * @return フォーム
	 */
	public String getForm() {
		return form;
	}

	/**
	 * フォームを返却します
	 * @param フォーム
	 */
	public void setForm(String form) {
		this.form = form;
	}

	/**
	 * エレメント名を設定します
	 * @return エレメント名
	 */
	public String getName() {
		return name;
	}

	/**
	 * エレメント名を返却します
	 * @param エレメント名
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 年を設定します
	 * @return 年
	 */
	public String getYear() {
		return year;
	}

	/**
	 * 年を返却します
	 * @param 年
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * 月を設定します
	 * @return 月
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * 月を返却します
	 * @param 月
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * dateformatを取得する。
	 * @return dateformat 日付書式
	 */
	public String getDateformat() {
		return dateformat;
	}

	/**
	 * dateformatを設定する。
	 * @param dateformat 日付書式
	 */
	public void setDateformat(String dateformat) {
		this.dateformat = dateformat;
	}
	
//2015.4.22 前後追加 START
	public String getYearBefore() {
		return yearBefore;
	}

	public void setYearBefore(String yearBefore) {
		this.yearBefore = yearBefore;
	}

	public String getMonthBefore() {
		return monthBefore;
	}

	public void setMonthBefore(String monthBefore) {
		this.monthBefore = monthBefore;
	}

	public String getYearAfter() {
		return yearAfter;
	}

	public void setYearAfter(String yearAfter) {
		this.yearAfter = yearAfter;
	}

	public String getMonthAfter() {
		return monthAfter;
	}

	public void setMonthAfter(String monthAfter) {
		this.monthAfter = monthAfter;
	}
//2015.4.22 前後追加 END

}
