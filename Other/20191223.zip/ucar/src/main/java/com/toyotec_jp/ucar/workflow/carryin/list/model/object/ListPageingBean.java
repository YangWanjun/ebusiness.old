package com.toyotec_jp.ucar.workflow.carryin.list.model.object;

import com.toyotec_jp.im_common.system.model.object.SimplePagingResultBean;

/**
 * <strong>車両搬入一覧 検索結果Bean</strong>
 * @author Y.F(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class ListPageingBean extends SimplePagingResultBean<ListDataBean>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ListPageingBean() {
		
	}

}
