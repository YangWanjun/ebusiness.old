package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;

/**
 * <strong>入庫検査選択イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/21 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class GetEnterCheckSelectDataEventResult implements UcarEventResult {

	/**  */
	private static final long serialVersionUID = 5660570503669216103L;

	/** 入庫検査Beanリスト */
	private List<CarCheckDataBean> carCheckDataList;
	/** 検査完了日(存在する:true／存在しない:false) */
	private boolean existDdNkkns;

	/**
	 * carCheckDataListを取得する。
	 * @return carCheckDataList
	 */
	public List<CarCheckDataBean> getCarCheckDataList() {
		return carCheckDataList;
	}

	/**
	 * carCheckDataListを設定する。
	 * @param carCheckDataList
	 */
	public void setCarCheckDataList(List<CarCheckDataBean> carCheckDataList) {
		this.carCheckDataList = carCheckDataList;
	}

	/**
	 * existDdNkknsを取得する。
	 * @return existDdNkkns
	 */
	public boolean isExistDdNkkns() {
		return existDdNkkns;
	}

	/**
	 * existDdNkknsを設定する。
	 * @param existDdNkkns
	 */
	public void setExistDdNkkns(boolean existDdNkkns) {
		this.existDdNkkns = existDdNkkns;
	}

}
