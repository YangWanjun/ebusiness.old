package com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.object;

import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba001gBean;

/**
 * <strong>未計画情報 画面出力値Bean</strong>
 * <p>
 * 受付車両情報Bean(Ucba001gBean)を継承している。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/24 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public class CleanPlanUnPlanDataBean extends Ucba001gBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 色コード */
	private String cdColor;

	/**
	 *
	 */
	public CleanPlanUnPlanDataBean() {
		super();
	}

	/**
	 * cdColorを取得する。
	 * @return cdColor 色コード
	 */
	public String getCdColor() {
		return cdColor;
	}

	/**
	 * cdColorを設定する。
	 * @param cdColor 色コード
	 */
	public void setCdColor(String cdColor) {
		this.cdColor = cdColor;
	}

}
