/*
 * 【システム名】リース管理システム
 * 【ファイル名】ApplicationSessionBeanIF.java
 * 【  説  明  】
 * 【  作  成  】2010/06/23 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.system.session;

/**
 * <strong>アプリケーションセッションビーンインターフェース。</strong>
 * <p>
 * アプリケーションセッションビーン共通のインターフェース。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/23 新規作成<br>
 * @since 1.00
 */
public interface ApplicationSessionBeanIF extends SessionBeanIF {

}
