package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.KyoutuTenpoDBDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.KyoutuTenpoDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa006mBean;

/**
 * <strong>共通店舗DB操作用イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class KyoutuTenpoDBEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		KyoutuTenpoDBEvent targetEvent = (KyoutuTenpoDBEvent)event;

		KyoutuTenpoDBDAOIF dao
			= getDAO(UcarDAOKey.KYOUTU_TENPO_DB_DAO, event, KyoutuTenpoDBDAOIF.class);

		// 共通店舗DB取得
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<KyoutuTenpoDBBean> kyoutuTenpoList
			= dao.getKyoutuTenpoDBList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn());
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		// 店舗付加マスタ取得
		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
		ResultArrayList<Ucaa006mBean> T220006mList
			= dao.selectT220006m(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn());
		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

		for (Ucaa006mBean t220006mBean : T220006mList) {
			KyoutuTenpoDBBean kyoutuTenpoDBBean = new KyoutuTenpoDBBean();

			kyoutuTenpoDBBean.setCdTenpo(t220006mBean.getCdTenpo());
			kyoutuTenpoDBBean.setKjTenpomei(t220006mBean.getKjTenpomei());
			kyoutuTenpoDBBean.setKjTentanms(t220006mBean.getKjTentanms());
			kyoutuTenpoDBBean.setKbTenpo(t220006mBean.getKbTenpo());	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
//2019.3.22 from
			kyoutuTenpoDBBean.setKbDuotenpo(" ");
			kyoutuTenpoDBBean.setCdHanbaitn(t220006mBean.getCdHanbaitn());
//2019.3.22 to			
			// 共通店舗DBの後に店舗付加マスタのデータを追加
			kyoutuTenpoList.add(kyoutuTenpoDBBean);
		}

		return kyoutuTenpoList;
	}

}
