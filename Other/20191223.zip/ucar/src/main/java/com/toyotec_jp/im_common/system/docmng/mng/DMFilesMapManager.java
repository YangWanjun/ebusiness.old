/*
 * 【システム名】
 * 【ファイル名】DMFilesMapManager.java
 * 【  説  明  】ファイル設定パラメータマップ操作クラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.mng;

import java.util.ArrayList;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapKey;
import com.toyotec_jp.im_common.system.docmng.data.DMSheetMap;
import com.toyotec_jp.im_common.system.docmng.data.DMYoshikiMap;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData.ShoriKbn;


/**
 * <strong>DMFilesMapManager</strong>
 * <p>
 * ファイル設定パラメータマップ操作クラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMFilesMapManager {

	/** コンストラクタ */
	private DMFilesMapManager() {
	}

	/** インスタンス */
	private static final DMFilesMapManager instance = new DMFilesMapManager();

	/**
	 * インスタンス取得
	 * @return ファイル設定パラメータマップ操作インスタンス
	 * @since 1.00
	 */
	public static DMFilesMapManager getInstance(){
		return instance;
	}

	/**
	 * マッピング用データリスト変換<br>
	 * マッピング用データリストを様式情報格納用マップに変換
	 * @param fileMapList マッピング用データリスト
	 * @param filter 処理区分
	 * @return 様式情報格納用マップ
	 * @since 1.00
	 */
	public DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> convMapListToYoshikiMap(
			DMFilesMapData[] fileMapList, ShoriKbn filter){

		DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> retMap =
			new DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>>();
		if(fileMapList != null && fileMapList.length > 0){
			retMap.setYoshikiInfo(fileMapList[0]);
		}

		if(fileMapList != null){
			for(DMFilesMapData fileMapRec : fileMapList){
				if(fileMapRec != null && (filter == null || filter.toString().equals(fileMapRec.getShoriKbn()))){
					int sheetKey = fileMapRec.getSheetIdx();
					DMFilesMapKey key = new DMFilesMapKey(
							fileMapRec.getSheetIdx(), fileMapRec.getShoriShosaiKbn(), fileMapRec.getListId());

					if(!retMap.containsKey(sheetKey)){
						retMap.put(sheetKey, new DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>(fileMapRec));
					}

					DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> sheetMap = retMap.get(sheetKey);
					if(!sheetMap.containsKey(key)){
						sheetMap.put(key, new ArrayList<DMFilesMapData>());
					}
					sheetMap.get(key).add(fileMapRec);
				}
			}
		}

		return retMap;
	}

}
