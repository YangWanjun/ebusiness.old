package com.toyotec_jp.ucar.workflow.carryin.list.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>車両搬入一覧 検索パラメータBean</strong>
 * @author Y.F(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class ListParamBean extends TecBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	/** 搬入日From */
	private String ddHannyuFrom;
	/** 搬入日To */
	private String ddHannyuTo;
	/** 登録NO陸支コード */
	private String	cdNorikusi;
	/** 登録NO車種区分 */
	private String	kbNosyasyu;
	/** 登録NO業態コード */
	private String	cdNogyotai;
	/** 登録NO整理番号 */
	private String	noNoseiri;
	/** 型式 */
	private String	mjSitkata;
	/** 車名 */
	private String	mjSyamei;
	/** 型式指定類別NO */
	private String	noKataruib;
	/** ai21車両NO */
	private String	noSyaryou;
	/** 仕入店舗コード */
	private String	cdSirtenpo;
	/** チェック内容 */
	private String[] arrayKbCheck;
	/** 印刷チェック */
	private String[] arrayKbCheckPrint;

	/** 状態チェック 2011.10.19 H.Yamashita add */
	private String[] arrayCheckSrk;

	/** 車台番号 2011.10.19 H.Yamashita add */
	private String noSyadai;

	/** 書類完備日From  2011.10.19 H.Yamashita add */
	private String ddSrknbFrom;
	/** 書類完備日To  2011.10.19 H.Yamashita add */
	private String ddSrknbTo;

	/** 保留日From  2011.10.19 H.Yamashita add */
	private String ddSrkhrFrom;
	/** 保留日To  2011.10.19 H.Yamashita add */
	private String ddSrkhrTo;

	/** 仕入種別チェック */
	private String[] arrayKbSiire;

	/** menuId */
	private String menuId;

	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 店舗コード */
	private String cdTenpo;
	/** 商品化センター区分 */
	private String kbScenter;
	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

	public ListParamBean(){
		this.cdKaisya = "";
		this.cdHanbaitn = "";

		this.ddHannyuFrom = "";
		this.ddHannyuTo = "";
		/* 2011.10.20 H.Yamashita 書類チェックモード追加に伴う対応
		this.ddHannyuFrom = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT);
		this.ddHannyuTo = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT);
		*/
		this.cdNorikusi = "";
		this.kbNosyasyu = "";
		this.cdNogyotai = "";
		this.noNoseiri = "";
		this.mjSitkata = "";
		this.mjSyamei = "";
		this.noKataruib = "";
		this.noSyaryou = "";
		this.cdSirtenpo = "";
		this.noSyadai = "";
		this.ddSrknbFrom = "";
		this.ddSrknbTo = "";
		this.ddSrkhrFrom = "";
		this.ddSrkhrTo = "";
		this.cdTenpo = "";
		this.kbScenter = "";
	}

	public String getCdKaisya() {
		return cdKaisya;
	}

	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	public String getDdHannyuFrom() {
		return ddHannyuFrom;
	}

	public void setDdHannyuFrom(String ddHannyuFrom) {
		this.ddHannyuFrom = ddHannyuFrom;
	}

	public String getDdHannyuTo() {
		return ddHannyuTo;
	}

	public void setDdHannyuTo(String ddHannyuTo) {
		this.ddHannyuTo = ddHannyuTo;
	}

	public String getCdNorikusi() {
		return cdNorikusi;
	}

	public void setCdNorikusi(String cdNorikusi) {
		this.cdNorikusi = cdNorikusi;
	}

	public String getKbNosyasyu() {
		return kbNosyasyu;
	}

	public void setKbNosyasyu(String kbNosyasyu) {
		this.kbNosyasyu = kbNosyasyu;
	}

	public String getCdNogyotai() {
		return cdNogyotai;
	}

	public void setCdNogyotai(String cdNogyotai) {
		this.cdNogyotai = cdNogyotai;
	}

	public String getNoNoseiri() {
		return noNoseiri;
	}

	public void setNoNoseiri(String noNoseiri) {
		this.noNoseiri = noNoseiri;
	}

	public String getMjSitkata() {
		return mjSitkata;
	}

	public void setMjSitkata(String mjSitkata) {
		this.mjSitkata = mjSitkata;
	}

	public String getMjSyamei() {
		return mjSyamei;
	}

	public void setMjSyamei(String mjSyamei) {
		this.mjSyamei = mjSyamei;
	}

	public String getNoKataruib() {
		return noKataruib;
	}

	public void setNoKataruib(String noKataruib) {
		this.noKataruib = noKataruib;
	}

	/**
	 * noSyaryouを取得する。
	 * @return noSyaryou
	 */
	public String getNoSyaryou() {
		return noSyaryou;
	}

	/**
	 * noSyaryouを設定する。
	 * @param noSyaryou
	 */
	public void setNoSyaryou(String noSyaryou) {
		this.noSyaryou = noSyaryou;
	}

	public String getCdSirtenpo() {
		return cdSirtenpo;
	}

	public void setCdSirtenpo(String cdSirtenpo) {
		this.cdSirtenpo = cdSirtenpo;
	}

	/**
	 * arrayKbCheckを取得する。
	 * @return arrayKbCheck
	 */
	public String[] getArrayKbCheck() {
		return arrayKbCheck;
	}

	/**
	 * arrayKbCheckを設定する。
	 * @param arrayKbCheck
	 */
	public void setArrayKbCheck(String[] arrayKbCheck) {
		this.arrayKbCheck = arrayKbCheck;
	}
	/**
	 * arrayKbCheckPrintを取得する。
	 * @return arrayKbCheckPrint
	 */
	public String[] getArrayKbCheckPrint() {
		return arrayKbCheckPrint;
	}

	/**
	 * arrayKbCheckPrintを設定する。
	 * @param arrayKbCheckPrint
	 */
	public void setArrayKbCheckPrint(String[] arrayKbCheckPrint) {
		this.arrayKbCheckPrint = arrayKbCheckPrint;
	}

	/**
	 *
	 * @return
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public String[] getArrayCheckSrk() {
		return arrayCheckSrk;
	}

	public void setArrayCheckSrk(String[] arrayCheckSrk) {
		this.arrayCheckSrk = arrayCheckSrk;
	}


	public String getNoSyadai() {
		return noSyadai;
	}

	public void setNoSyadai(String noSyadai) {
		this.noSyadai = noSyadai;
	}


	public String getDdSrknbFrom() {
		return ddSrknbFrom;
	}

	public void setDdSrknbFrom(String ddSrknbFrom) {
		this.ddSrknbFrom = ddSrknbFrom;
	}

	public String getDdSrknbTo() {
		return ddSrknbTo;
	}

	public void setDdSrknbTo(String ddSrknbTo) {
		this.ddSrknbTo = ddSrknbTo;
	}

	public String getDdSrkhrFrom() {
		return ddSrkhrFrom;
	}

	public void setDdSrkhrFrom(String ddSrkhrFrom) {
		this.ddSrkhrFrom = ddSrkhrFrom;
	}

	public String getDdSrkhrTo() {
		return ddSrkhrTo;
	}

	public void setDdSrkhrTo(String ddSrkhrTo) {
		this.ddSrkhrTo = ddSrkhrTo;
	}

	public String[] getArrayKbSiire() {
		return arrayKbSiire;
	}

	public void setArrayKbSiire(String[] arrayKbSiire) {
		this.arrayKbSiire = arrayKbSiire;
	}


	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	/**
	 * cdTenpoを取得する。
	 * @return cdTenpo
	 */
	public String getCdTenpo() {
		return cdTenpo;
	}

	/**
	 * cdTenpoを設定する。
	 * @param cdTenpo
	 */
	public void setCdTenpo(String cdTenpo) {
		this.cdTenpo = cdTenpo;
	}

	/**
	 * kbScenterを取得する。
	 * @return kbScenter
	 */
	public String getKbScenter() {
		return kbScenter;
	}

	/**
	 * kbScenterを設定する。
	 * @param kbScenter
	 */
	public void setKbScenter(String kbScenter) {
		this.kbScenter = kbScenter;
	}

}
