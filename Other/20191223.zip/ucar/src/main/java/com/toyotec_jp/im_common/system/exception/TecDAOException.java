/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecDAOException.java
 * 【  説  明  】
 * 【  作  成  】2010/06/15 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import java.util.ArrayList;

import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;


/**
 * <strong>DAO例外クラス。</strong>
 * <p>
 * DAOで発生したシステム例外。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/15 新規作成<br>
 * @since 1.00
 */
public class TecDAOException extends TecSystemException {

	private static final long serialVersionUID = -2435026514634750812L;

	/**
	 * コンストラクタ。
	 */
	public TecDAOException() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 * @param cause
	 */
	public TecDAOException(TecMessageKeyIF messageKey, ArrayList<Object> args,
			Throwable cause) {
		super(messageKey, args, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 */
	public TecDAOException(TecMessageKeyIF messageKey, ArrayList<Object> args) {
		super(messageKey, args);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param cause
	 */
	public TecDAOException(TecMessageKeyIF messageKey, Throwable cause) {
		super(messageKey, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 */
	public TecDAOException(TecMessageKeyIF messageKey) {
		super(messageKey);
	}

	/**
	 * コンストラクタ。
	 * @param message
	 * @param cause
	 */
	public TecDAOException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * コンストラクタ。
	 * @param message
	 */
	public TecDAOException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * @param cause
	 */
	public TecDAOException(Throwable cause) {
		super(cause);
	}

}
