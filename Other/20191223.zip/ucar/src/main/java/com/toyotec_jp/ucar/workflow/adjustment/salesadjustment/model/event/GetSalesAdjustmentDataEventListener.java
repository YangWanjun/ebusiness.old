package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event;

import java.math.BigDecimal;
import java.util.Date;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst.AdjustmentDAOKey;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetSyouhizeirituEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetSyouhizeirituEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb003gBean;
import com.toyotec_jp.ucar.workflow.receipt.common.ReceiptConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst.ReportDAOKey;
import com.toyotec_jp.ucar.workflow.report.model.data.MitumoriDAOIF;

/**
 * <strong>売上精算取得イベントリスナ</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class GetSalesAdjustmentDataEventListener extends UcarEventListener {

	/** 社内区分がブランクかつ、売上科目区分が'4'(外注)の原価合計 */
	private int sumUrikamoGaichu;
	/** 社内区分が'1'かつ、売上科目区分が'4'(外注)の原価合計 */
	private int sumSyanaiUrikamoGaichu;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetSalesAdjustmentDataEvent targetEvent = (GetSalesAdjustmentDataEvent)event;

		// DAOIF取得
		SalesAdjustmentDAOIF getDao = getDAO(AdjustmentDAOKey.SALESADJUSTMENT_DAO, targetEvent, SalesAdjustmentDAOIF.class);

		SalesAdjustmentDataBean salesAdjustmentDataBean = null;
		boolean confirmMessage = false;

		// 再発行ボタン：押下不可をデフォルトで設定
		boolean disabledBtnReissue = true;

		// 受注情報
		Ucbb001gBean t220211gBean = new Ucbb001gBean(targetEvent.getCdKaisya(),
													targetEvent.getCdJigyosyo(),
													targetEvent.getNoJucyu());

		salesAdjustmentDataBean = getDao.selectT220211G(t220211gBean);

		if (salesAdjustmentDataBean == null) {
			// 「該当データがありません」を表示する
			throw new TecApplicationException(TecMessageManager.getMessage(UcarMessage.NOT_FOUND));
		} else {

			if (salesAdjustmentDataBean.getKbCancel() != null) {
				// 受注情報のキャンセル区分がセットされている
				throw new TecApplicationException("受注№[" + targetEvent.getNoJucyu() + "]は取消されています。");
			}

			int t220213GCount = getDao.selectT220213GCount(t220211gBean);
			if (t220213GCount > 0) {
				// 外注仕入情報に仕入日がセットされていないものが存在するとき
				throw new TecApplicationException("外注業者の仕入処理が完了していません。");
			}

			int t220212GCount = getDao.selectT220212GCount(t220211gBean);
			if (t220212GCount > 0) {
				// 受注明細情報に売上科目区分がセットされていないものが存在するとき
				// ワーニングメッセージを表示する
				confirmMessage = true;
			}

			if (salesAdjustmentDataBean.getDdSeisan() == null) {
				// 受注情報の精算日がセットされていない

				// 原価額
				createGenka(getDao, t220211gBean, salesAdjustmentDataBean);
				// 売価額
				int kiUriage = createBaika(getDao, t220211gBean, salesAdjustmentDataBean);

				String kbNebiki = "";
				boolean executeConfirm = targetEvent.isExecuteConfirm();
				if (executeConfirm) {
					// 確認の場合
					kbNebiki = targetEvent.getKbNebiki();
					salesAdjustmentDataBean.setKbNebiki(kbNebiki);
				} else {
					// 検索の場合
					kbNebiki = salesAdjustmentDataBean.getKbNebiki();
				}

				// 得意先値引き
				int KiTnebiki = 0;
				if (ReceiptConst.KB_NEBIKI_TEKIYOU.equals(kbNebiki)) {
					// 見積書用DAO取得
					MitumoriDAOIF reportDao = getDAO(ReportDAOKey.MITUMORI_DAO,
													 targetEvent,
													 MitumoriDAOIF.class);

					Ucbb001gBean result001gBean = reportDao.selectT220211G(t220211gBean);

					Ucbb002gBean t220212gBean = new Ucbb002gBean(t220211gBean.getCdKaisya(),
																  t220211gBean.getCdJigyosyo(),
																  t220211gBean.getNoJucyu());

					KiTnebiki = createTotalKingaku(true, reportDao, result001gBean, t220212gBean);
				}
				salesAdjustmentDataBean.setKiTnebiki(KiTnebiki);

				// 値引き
				int kiNebiki = 0;
				if (executeConfirm) {
					// 確認の場合
					kiNebiki = targetEvent.getKiNebiki();
				}
				salesAdjustmentDataBean.setKiNebiki(kiNebiki);

				// 精算金額
				int kiSeikyu = kiUriage - KiTnebiki - kiNebiki;
				salesAdjustmentDataBean.setKiSeikyu(kiSeikyu);

				// 内消費税
				int kiTax = 0;
				
				// 2013/08/28 要望対応start
				// 共通処理実施(消費税率抽出方法、端数処理)
				GetSyouhizeirituEvent syouhizeirituEvent = 
								createEvent(UcarEventKey.GET_SYOUHIZEIRITU,
								targetEvent.getUserInfo(),
								GetSyouhizeirituEvent.class);
				syouhizeirituEvent.setCdKaisya(t220211gBean.getCdKaisya());
				syouhizeirituEvent.setCdJigyosyo(t220211gBean.getCdJigyosyo());
				syouhizeirituEvent.setTargetDate(new Date());

				GetSyouhizeirituEventResult syouhizeirituResult = (GetSyouhizeirituEventResult)dispatchEvent(syouhizeirituEvent);

				// 受注情報から消費税率を取得
				BigDecimal bdSyouhizeiPercent = new BigDecimal(salesAdjustmentDataBean.getSuTaxritu());

				if ((executeConfirm == false && ReceiptConst.KB_NEBIKI_TEKIYOUGAI.equals(kbNebiki))
					|| (executeConfirm == true && ReceiptConst.KB_NEBIKI_TEKIYOUGAI.equals(kbNebiki) && kiNebiki == 0)) {
					// 検索ボタン押下時で、値引適用外の場合
					// あるいは、確認ボタン押下時で、値引適用外、値引金額が0の場合

					// 消費税率が同じ場合
					if (bdSyouhizeiPercent.compareTo(syouhizeirituResult.getBdSyouhizeiPercent()) == 0) {
						kiTax = getDao.selectT220212GSumKiTax(t220211gBean).getKiTax();
					} else {
						// 受注時と本日で消費税率が違う場合
						kiTax = syouhizeirituResult.getUchiSyouhizei(getDao.selectT220212GSumKiTax(t220211gBean).getKiBaika());
					}
				} else {
					
					// 精算金額で内消費税を取得
					kiTax = syouhizeirituResult.getUchiSyouhizei(kiSeikyu);

				}
				
				boolean sameTax = false;
				// 消費税率が同じ場合
				if (bdSyouhizeiPercent.compareTo(syouhizeirituResult.getBdSyouhizeiPercent()) == 0) {
					sameTax = true;
				}
				// 消費税率が受注情報のデータと本日の消費税率と同一かの判定結果を設定
				salesAdjustmentDataBean.setSameTax(sameTax);
				// 2013/08/28 要望対応 end

				salesAdjustmentDataBean.setKiTax(kiTax);

				// 社内振替
				createSyanai(getDao, t220211gBean, salesAdjustmentDataBean);

			} else {
				// 受注情報の精算日がセットされている

				// 精算後のデータを再取得する
				salesAdjustmentDataBean = getDao.selectT220214G(t220211gBean);
				if (salesAdjustmentDataBean == null) {
					throw new TecApplicationException("売上精算情報がありません");
				}
			}

			int t220214GCount = getDao.selectT220214GCount(t220211gBean);

			if (t220214GCount > 0) {
				// 再発行ボタンが使用できる
				disabledBtnReissue = false;
			}

		}

		GetSalesAdjustmentDataEventResult getEventResult = new GetSalesAdjustmentDataEventResult();
		getEventResult.setSalesAdjustmentDataBean(salesAdjustmentDataBean);
		getEventResult.setConfirmMessage(confirmMessage);
		getEventResult.setDisabledBtnReissue(disabledBtnReissue);

		return getEventResult;
	}

	/**
	 * 合計金額作成処理
	 * @param returnNebiki true:値引き金額を返却する場合／false:値引後の売上金額を返却する場合
	 * @param reportDao
	 * @param result001gBean
	 * @param t220212gBean
	 * @return
	 * @throws TecDAOException
	 */
	private int createTotalKingaku(boolean returnNebiki,
									MitumoriDAOIF reportDao,
									Ucbb001gBean result001gBean,
									Ucbb002gBean t220212gBean) throws TecDAOException {

		Ucba004mBean t220204mBean = reportDao.selectNebikiRitu(result001gBean);

		// 技術料売上金額
		int gijyutu = reportDao.selectKiBaika(t220212gBean, ReceiptConst.KB_URIKIN_GIJYUTU).getKiBaika();
		// 技術料
		int gijyutuTotal = createKingaku(returnNebiki, gijyutu, Integer.parseInt(t220204mBean.getMjInfo2()));

		// 部品売上金額
		int buhin 	= reportDao.selectKiBaika(t220212gBean, ReceiptConst.KB_URIKIN_BUHIN).getKiBaika();
		// 部品
		int buhinTotal = createKingaku(returnNebiki, buhin, Integer.parseInt(t220204mBean.getMjInfo3()));

		// 油脂売上金額
		int yusi 	= reportDao.selectKiBaika(t220212gBean, ReceiptConst.KB_URIKIN_YUSI).getKiBaika();
		// 油脂
		int yusiTotal = createKingaku(returnNebiki, yusi, Integer.parseInt(t220204mBean.getMjInfo4()));

		int total = gijyutuTotal + buhinTotal + yusiTotal;
		return total;
	}

	/**
	 * 金額作成処理
	 * @param returnNebiki true:値引き金額を返却する場合／false:値引後の売上金額を返却する場合
	 * @param uriage
	 * @param nebiki
	 * @return
	 */
	private int createKingaku(boolean returnNebiki, int uriage, int nebiki) {

		BigDecimal bdOnehundred = new BigDecimal(100);

		// 値引÷100
		BigDecimal nebikiRate = new BigDecimal(nebiki).divide(bdOnehundred);
		// 値引金額(小数点以下四捨五入する)＝売上金額×値引率
		BigDecimal bdNebiki = new BigDecimal(uriage).multiply(nebikiRate).setScale(0, BigDecimal.ROUND_HALF_UP);

		int kingaku = 0;
		if (returnNebiki) {
			kingaku = bdNebiki.intValue();
		} else {
			// 売上金額－値引金額
			kingaku = new BigDecimal(uriage).subtract(bdNebiki).intValue();
		}
		return kingaku;
	}

	/**
	 * 原価作成
	 * @param getDao
	 * @param t220211gBean
	 * @param salesAdjustmentDataBean
	 * @throws TecDAOException
	 */
	private void createGenka(SalesAdjustmentDAOIF getDao,
								Ucbb001gBean t220211gBean,
								SalesAdjustmentDataBean salesAdjustmentDataBean) throws TecDAOException {

		// 原価額
		Ucbb002gBean t220212gBean = new Ucbb002gBean(t220211gBean.getCdKaisya(),
													t220211gBean.getCdJigyosyo(),
													t220211gBean.getNoJucyu());

		// 原価額工賃
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_KOUTIN);
		int sumKoutin = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();
		salesAdjustmentDataBean.setKiGenkou(sumKoutin);
		// 原価額部品
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_BUHIN);
		int sumBuhin = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();
		salesAdjustmentDataBean.setKiGenbuhin(sumBuhin);
		// 原価額油脂
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_YUSI);
		int sumYusi = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();
		salesAdjustmentDataBean.setKiGenyusi(sumYusi);
		// 原価額外注
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_GAICHU);
		sumUrikamoGaichu = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();
		int sumGaichu = 0;

		// 原価額調整
		if (sumUrikamoGaichu == 0) {
			sumGaichu = sumUrikamoGaichu;
		} else {
			// 原価額外注

			// (外注仕入情報.仕入金額 - 外注仕入情報.消費税)の合計
			int sumGaichuGoukeiZeinuki = createGaichuGoukeiZeinuki(getDao, t220212gBean);

			// 社内区分をセットする
			t220212gBean.setKbSyanai(ReceiptConst.KB_SYANAI_SYANAI);
			sumSyanaiUrikamoGaichu = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();

			sumGaichu = sumGaichuGoukeiZeinuki - sumSyanaiUrikamoGaichu;
		}
		salesAdjustmentDataBean.setKiGengai(sumGaichu);

		int sumKiGenka = sumKoutin + sumBuhin + sumYusi + sumGaichu;
		salesAdjustmentDataBean.setKiGenka(sumKiGenka);
	}

	/**
	 * 外注合計税抜作成
	 * @param getDao
	 * @param t220212gBean
	 * @throws TecDAOException
	 */
	private int createGaichuGoukeiZeinuki(SalesAdjustmentDAOIF getDao,
											Ucbb002gBean t220212gBean) throws TecDAOException {

		// 伝票NOを取得する
		ResultArrayList<Ucbb003gBean> noDenpyoList = getDao.selectT220213GNoDenpyo(t220212gBean);

		// 仕入金額、消費税を取得する
		int kiSiire = 0;
		int kiTax = 0;
		for (Ucbb003gBean t220213gBean : noDenpyoList) {
			Ucbb003gBean kingakuBean = getDao.selectT220213GKingaku(t220213gBean);
			if (kingakuBean != null) {
				kiSiire += kingakuBean.getKiSiire();
				kiTax 	+= kingakuBean.getKiTax();
			}
		}

		return kiSiire - kiTax;
	}

	/**
	 * 売価作成
	 * @param getDao
	 * @param t220211gBean
	 * @param salesAdjustmentDataBean
	 * @throws TecDAOException
	 */
	private int createBaika(SalesAdjustmentDAOIF getDao,
			Ucbb001gBean t220211gBean,
			SalesAdjustmentDataBean salesAdjustmentDataBean)
			throws TecDAOException {

		// 売価額
		Ucbb002gBean t220212gBean = new Ucbb002gBean(t220211gBean.getCdKaisya(),
													t220211gBean.getCdJigyosyo(),
													t220211gBean.getNoJucyu());


		// 売価額工賃
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_KOUTIN);
		int sumKoutin = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiBaika();
		salesAdjustmentDataBean.setKiUrikou(sumKoutin);
		// 売価額部品
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_BUHIN);
		int sumBuhin = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiBaika();
		salesAdjustmentDataBean.setKiUribuhin(sumBuhin);
		// 売価額油脂
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_YUSI);
		int sumYusi = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiBaika();
		salesAdjustmentDataBean.setKiUriyusi(sumYusi);
		// 売価額外注
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_GAICHU);
		int sumGaichu = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiBaika();
		salesAdjustmentDataBean.setKiUrigai(sumGaichu);

		int sumKiUriage = sumKoutin + sumBuhin + sumYusi + sumGaichu;
		salesAdjustmentDataBean.setKiUriage(sumKiUriage);

		return sumKiUriage;
	}

	/**
	 * 社内振替作成
	 * @param getDao
	 * @param t220211gBean
	 * @param salesAdjustmentDataBean
	 * @throws TecDAOException
	 */
	private void createSyanai(SalesAdjustmentDAOIF getDao,
			Ucbb001gBean t220211gBean,
			SalesAdjustmentDataBean salesAdjustmentDataBean)
			throws TecDAOException {

		// 社内振替
		Ucbb002gBean t220212gBean = new Ucbb002gBean(t220211gBean.getCdKaisya(),
													t220211gBean.getCdJigyosyo(),
													t220211gBean.getNoJucyu());

		// 社内区分をセットする
		t220212gBean.setKbSyanai(ReceiptConst.KB_SYANAI_SYANAI);

		// 社内振替工賃
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_KOUTIN);
		int sumKoutin = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();
		salesAdjustmentDataBean.setKiSyafkou(sumKoutin);
		// 社内振替部品
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_BUHIN);
		int sumBuhin = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();
		salesAdjustmentDataBean.setKiSyafbuhin(sumBuhin);
		// 社内振替油脂
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_YUSI);
		int sumYusi = getDao.selectT220212GSumKingaku(t220212gBean, true).getKiGenka();
		salesAdjustmentDataBean.setKiSyafyusi(sumYusi);

		int sumGaichu = 0;

		// 社内振替外注
		if (sumUrikamoGaichu == 0) {
			// (外注仕入情報.仕入金額 - 外注仕入情報.消費税)の合計
			sumGaichu = createGaichuGoukeiZeinuki(getDao, t220212gBean);
		} else {
			// 社内振替外注
			sumGaichu = sumSyanaiUrikamoGaichu;

		}
		salesAdjustmentDataBean.setKiSyafgai(sumGaichu);

		int sumKiSyanai = sumKoutin + sumBuhin + sumYusi + sumGaichu;
		salesAdjustmentDataBean.setKiSyanai(sumKiSyanai);
	}

}
