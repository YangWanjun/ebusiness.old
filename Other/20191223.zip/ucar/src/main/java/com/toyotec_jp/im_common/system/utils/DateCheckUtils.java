/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】DateCheckUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/06/08 T.H(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.regex.Pattern;

/**
 * <strong>日付チェック系ユーティリティクラス</strong>
 * <p>
 * 日付チェック関連支援処理を管理するクラス
 *
 * @author T.H(SCC)
 * @version 1.00 2010/06/08 新規作成<br>
 */
public class DateCheckUtils {

	/*
     * デフォルトコンストラクタ
     */
	private DateCheckUtils() {
		super();
	}

	/**
	 * 日付形式判定関数
	 * <pre>
	 * 対象の文字列が指定した形式かどうか判別する
	 * </pre>
	 * @param date 日付
	 * @param format 形式指定 DateUtilの各フォーマット定数を指定してください
	 * @return true:形式が正しい
	 * @see DateUtils#FORMAT_SHORT
	 * @see DateUtils#FORMAT_SHORT_SIMPLE
	 */
	public static boolean isDateFormat(String date, String format) {

		boolean isCreectForm = false;
		String formatedString = null;

		// 形式チェック
		if (DateUtils.FORMAT_SHORT.equals(format)) {
			isCreectForm = Pattern.matches("[\\d]{4}\\/[\\d]{2}\\/[\\d]{2}", date);
			if (isCreectForm) {
				formatedString = date;
			}
		} else if (DateUtils.FORMAT_SHORT_SIMPLE.equals(format)) {
			isCreectForm = Pattern.matches("[\\d]{8}", date);
			if (isCreectForm) {
				formatedString =
					date.substring(0, 4) + "/" + date.substring(4, 6) + "/" + date.substring(6, 8);
			}
		}

		if (!isCreectForm) return false;

		// 整合性チェック
		try {
			DateFormat df = DateFormat.getDateInstance();
			df.setLenient(false);
			df.parse(formatedString);
		} catch (ParseException e) {
			return false;
		}

		// 有効年チェック
		if (!compareDate(DateUtils.FORMAT_SHORT_VALID_START, formatedString, true)) {
			return false;
		}
		if (!compareDate(formatedString, DateUtils.FORMAT_SHORT_VALID_END, true)) {
			return false;
		}

		return true;
	}

	/**
	 * 指定年月チェック
	 * <pre>
	 * 対象の年月日が、指定された年月かどうかチェックする
	 * </pre>
	 * @param ymd yyyy/mm/ddまたはyyyymmdd（年月の形式に揃える）
	 * @param ym yyyy/mmまたはyyyymm（年月日の形式に揃える）
	 * @return 判定結果
	 */
	public static boolean matchYm(String ymd, String ym) {
		return ymd.startsWith(ym);
	}

	/**
	 * 日付存在チェック
	 * <pre>
	 * 対象の年月日が実在する日付であるかどうかチェックする
	 * (内部で形式チェックも行う)
	 * </pre>
	 * @param date 日付
	 * @param format 形式指定 DateUtilの各フォーマット定数を指定してください
	 * @return 判定結果
	 */
	public static boolean isExistDate(String date, String format) {

		//形式チェック
		if (!isDateFormat(date, format)) return false;

		//実在日チェック
		if (!date.equals(DateUtils.dateToString(DateUtils.getDate(date, format), format))) return false;

		return true;
	}

	/**
	 * 日付整合性判定関数
	 * <pre>
	 * 開始日と終了日の整合性をチェックする　
	 * equalFlgがtrueの場合は同じ年月日でもtrueを返却する
	 * </pre>
	 * @param startYmd 開始日付
	 * @param endYmd 終了日付
	 * @param equalFlg 同日許可
	 * @return 判定結果
	 */
	public static boolean compareDate(String startYmd, String endYmd, boolean equalFlg) {

		if (startYmd == null || startYmd.equals("") || endYmd == null || endYmd.equals("")) {
			return false;
		}
		String[] start = startYmd.split("/");
		String startY = start[0];
		String startM = start[1];
		String startD = start[2];

		String[] end = endYmd.split("/");
		String endY = end[0];
		String endM = end[1];
		String endD = end[2];

		if (Integer.parseInt(startY) < Integer.parseInt(endY)) {
			return true;
		} else if (Integer.parseInt(startY) > Integer.parseInt(endY)) {
			return false;
		}

		if (Integer.parseInt(startM) < Integer.parseInt(endM)) {
			return true;
		} else if (Integer.parseInt(startM) > Integer.parseInt(endM)) {
			return false;
		}
		if (Integer.parseInt(startD) < Integer.parseInt(endD)) {
			return true;
		} else if (Integer.parseInt(startD) > Integer.parseInt(endD)) {
			return false;
		}

		if (equalFlg) {
			return true;
		}
		return false;
	}

}
