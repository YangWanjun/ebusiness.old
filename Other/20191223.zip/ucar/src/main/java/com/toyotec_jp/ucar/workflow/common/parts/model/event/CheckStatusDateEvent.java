package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;


/**
 * <strong>ステータスDB日付比較チェックイベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/25 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CheckStatusDateEvent extends UcarEvent {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;
	/** ステータスDB(店舗用) プライマリーキーBean */
	private Uccb007gPKBean t220107gPkBean;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
	/** チェック対象ステータス番号
	 * <pre>
	 * 指定範囲：1～24
	 * </pre>
	 *  */
	private int checkStatusNo;
	/** チェック日付 */
	private String dtStatus;

	public CheckStatusDateEvent() {
		super();
	}

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * t220107gPkBeanを取得する。
	 * @return t220107gPkBean
	 */
	public Uccb007gPKBean getT220107gPkBean() {
		return t220107gPkBean;
	}

	/**
	 * t220107gPkBeanを設定する。
	 * @param t220107gPkBean
	 */
	public void setT220107gPkBean(Uccb007gPKBean t220107gPkBean) {
		this.t220107gPkBean = t220107gPkBean;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	/**
	 * checkStatusNoを取得する。
	 * @return checkStatusNo
	 */
	public int getCheckStatusNo() {
		return checkStatusNo;
	}

	/**
	 * checkStatusNoを設定する。
	 * @param checkStatusNo
	 */
	public void setCheckStatusNo(int checkStatusNo) {
		this.checkStatusNo = checkStatusNo;
	}

	/**
	 * dtStatusを取得する。
	 * @return dtStatus
	 */
	public String getDtStatus() {
		return dtStatus;
	}

	/**
	 * dtStatusを設定する。
	 * @param dtStatus
	 */
	public void setDtStatus(String dtStatus) {
		this.dtStatus = dtStatus;
	}

}
