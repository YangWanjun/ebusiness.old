package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.util.Date;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucca002mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb011vBean;

/**
 * <strong>U-Car商品化システム(共通)用DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/30 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface UcarCommonDAOIF {

	/**
	 * 消費税率取得（コード区分マスタ 区分ID='29'）
	 * @param	t220204mBean
	 * 会社コード、事業所コードがセットされているBeanを引数とする
	 * @throws LcmDAOException DAO例外クラス
	 * @return t220204mBean
	 * MJ_KUBUN（区分名称）に消費税率、MJ_INFO3（情報3）に端数処理区分がセットされているBeanを返却する
	 */
	public Ucba004mBean selectSyouhizei(Ucba004mBean t220204mBean,
										Date targetDate) throws TecDAOException;

	/**
	 * 端数処理取得（コード区分マスタ 区分ID='30'）
	 * @param	t220204mBean
	 * 会社コード、事業所コード、区分コードがセットされているBeanを引数とする
	 * @throws LcmDAOException DAO例外クラス
	 * @return t220204mBean
	 * MJ_KUBUN（区分名称）に端数処理区分がセットされているBeanを返却する
	 */
	public Ucba004mBean selectHasuu(Ucba004mBean t220204mBean) throws TecDAOException;

	/**
	 * コード区分マスタ取得
	 * @param	t220204mBean
	 * 会社コード、事業所コード、区分IDがセットされているBeanを引数とする<br>
	 * 区分コード、区分略名を更にセットすることでデータを絞り込むことが可能
	 * @throws LcmDAOException DAO例外クラス
	 * @return ResultArrayList<Ucba004mBean>
	 */
	public ResultArrayList<Ucba004mBean> selectT220204M(Ucba004mBean t220204mBean) throws TecDAOException;

	/**
	 * コード区分マスタ取得処理
	 * @param cdKaisya
	 * @param cdHanbaitn
	 * @param kbId
	 * @param cdKubun
	 * @return
	 * @throws TecDAOException
	 */
	public Ucca002mBean selectT220018m(String cdKaisya,
										String cdHanbaitn,
										String kbId,
										String cdKubun) throws TecDAOException;

	// 2013.04.22 T.Hayato 追加 搬入拠点分散対応2のため start
	/**
	 * 車両搬入受取情報ビュー取得処理
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @param 	ddHannyu 搬入日
	 * @param 	noKanri 管理番号
	 * @param 	cdHantenpo 搬入店舗コード・受取店舗コード
	 * @return
	 * @throws LcmDAOException DAO例外クラス
	 */
	public Uccb011vBean selectT220902v(String cdKaisya,
										String cdHanbaitn,
										String ddHannyu,
										String noKanri,
										String cdHantenpo) throws TecDAOException;
	// 2013.04.22 T.Hayato 追加 搬入拠点分散対応2のため end
}
