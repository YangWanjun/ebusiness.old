/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecMessageKey.java
 * 【  説  明  】
 * 【  作  成  】2010/12/24 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.message;

import com.toyotec_jp.im_common.TecApplicationManager;

/**
 * <strong>メッセージキー。</strong>
 * @author H.O(SCC)
 * @version 1.00 2010/12/24 新規作成<br>
 * @since 1.00
 */
public enum TecMessageKey implements TecMessageKeyIF {

	/** システム内部エラーメッセージ:呼出パラメータが不正です。 */
	SYS_E_ILLEGAL_ARGUMENT(TecApplicationManager.SYSTEM_COMMON_ROOT + ".E1001"),
	/** システム内部エラーメッセージ:データベースコネクション取得に失敗しました。 */
	SYS_E_FAILED_GET_CONNECTION(TecApplicationManager.SYSTEM_COMMON_ROOT + ".E1002"),
	/** システム内部エラーメッセージ:プリペアドステートメント取得に失敗しました。 */
	SYS_E_FAILED_GET_PSTMT(TecApplicationManager.SYSTEM_COMMON_ROOT + ".E1003"),
	/** システム内部エラーメッセージ:データベース操作に失敗しました。 */
	SYS_E_FAILED_EXECUTE_QUERY(TecApplicationManager.SYSTEM_COMMON_ROOT + ".E1004"),
	/** システム内部エラーメッセージ:サポートしていないデータタイプです。 */
	SYS_E_UNSUPPORTED_DATA_TYPE(TecApplicationManager.SYSTEM_COMMON_ROOT + ".E1005"),
	/** システム内部エラーメッセージ:リクエストのマッピングに失敗しました。 */
	SYS_E_FAILED_REQUEST_MAPPING(TecApplicationManager.SYSTEM_COMMON_ROOT + ".E1006"),
	/** システム内部エラーメッセージ:DB取得結果のマッピングに失敗しました。 */
	SYS_E_FAILED_DB_RESULT_MAPPING(TecApplicationManager.SYSTEM_COMMON_ROOT + ".E1007"),
	;
	private String messageKey;

	private TecMessageKey(String messageKey){
		this.messageKey = messageKey;
	}
	public String toString(){
		return messageKey;
	}
	@Override
	public String getMessageKey() {
		return messageKey;
	}

}
