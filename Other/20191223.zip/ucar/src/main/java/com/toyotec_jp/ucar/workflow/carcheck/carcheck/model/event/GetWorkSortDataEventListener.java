package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataListPagingBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.CodeKubunDBDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.CodeKubunDBBean;

/**
 * <strong>作業仕分取得イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/24 新規作成<br>
 * @since 1.00
 * @category [[作業仕分]]
 */
public class GetWorkSortDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetWorkSortDataEvent targetEvent = (GetWorkSortDataEvent)event;

		// DAOIF取得
		CarCheckDAOIF getDao = getDAO(CarCheckDAOKey.CAR_CHECK_DAO, targetEvent, CarCheckDAOIF.class);

		// 作業仕分 画面出力値取得
		CarCheckDataListPagingBean carCheckDataListPagingBean
			= getDao.selectWorkSortListPaging(targetEvent.getCdKaisya(),
											targetEvent.getCdHanbaitn(),
											// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
											targetEvent.getUserInfoBean().getCdTenpo(),	
											targetEvent.getUserInfoBean().getKbScenter(),
											// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
											targetEvent.getCarCheckParamBean(),
											targetEvent.isNarrowSearch(),
											targetEvent.getSortOrder(),
											targetEvent.getSortParam(),
											targetEvent.getPageNo(),
											targetEvent.getPageSize());

		CodeKubunDBDAOIF dao
			= getDAO(UcarDAOKey.CODE_KUBUN_DB_DAO, event, CodeKubunDBDAOIF.class);
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<CodeKubunDBBean> codeKubunList = dao.getCodeKubunDBList(targetEvent.getCdKaisya(),
																				targetEvent.getCdHanbaitn());
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		GetWorkSortDataEventResult getEventResult = new GetWorkSortDataEventResult();

		// 2012.03.20 T.Hayato 追加 ページング表示上限超過時 エラー発生のため start
		if (carCheckDataListPagingBean.getResultRecordList() != null
			&& carCheckDataListPagingBean.getResultRecordList().size() > 0)  {
		// 2012.03.20 T.Hayato 追加 ページング表示上限超過時 エラー発生のため end
			// 検索対象が1件以上の場合
			List<CarCheckDataBean> carCheckDataListPaging = new ArrayList<CarCheckDataBean>();

			for (CarCheckDataBean carCheckDataBean : carCheckDataListPagingBean.getResultRecordList()) {

				if (StringCheckUtils.isEmpty(carCheckDataBean.getCdTosyoku())) {
					// 塗色コードがnull/空文字の場合はそのままリストに追加
					carCheckDataListPaging.add(carCheckDataBean);
					continue;
				}
				boolean isAdd = false;
				for (CodeKubunDBBean codeKubunDBBean : codeKubunList) {
					if (carCheckDataBean.getCdTosyoku().equals(codeKubunDBBean.getCdKubun())) {
						// コード区分DBリストに該当するコードが存在した場合
						carCheckDataBean.setMjKubunnai(codeKubunDBBean.getMjKubunnai());
						carCheckDataListPaging.add(carCheckDataBean);
						isAdd = true;
						break;
					}
				}
				if (!isAdd) {
					// 存在しなかった場合はそのままリストに追加
					carCheckDataListPaging.add(carCheckDataBean);
				}
			}
			getEventResult.setCarCheckDataList(carCheckDataListPaging);
			getEventResult.setTotalRecordCount(carCheckDataListPagingBean.getTotalRecordCount());
		}

		return getEventResult;
	}

}
