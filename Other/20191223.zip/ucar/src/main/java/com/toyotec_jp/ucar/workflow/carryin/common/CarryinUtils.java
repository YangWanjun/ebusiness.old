package com.toyotec_jp.ucar.workflow.carryin.common;

import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;

/**
 * <strong>U-Car商品化システムユーティリティクラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/07 新規作成<br>
 * @since 1.00
 * @category [[車両搬入(共通)]]
 */
public class CarryinUtils {

	/** インスタンス生成しない */
	private CarryinUtils(){
	}

	/**
	 * 更新時の下取書類チェック状態取得
	 * @param registerInputBean
	 * @return
	 */
	public static boolean getNowKbCheckSitadori(RegisterInputBean registerInputBean) {
		boolean nowKbCheckSitadori = false;
		if (registerInputBean.getArrayKbCheck() != null) {
			// チェック内容のチェック数だけ処理を実行
			for (String kbCheck : registerInputBean.getArrayKbCheck()) {
				if (UcarConst.KB_CHECK_SITADORI.equals(kbCheck)) {
					nowKbCheckSitadori = true;
					break;
				}
			}
		}
		return nowKbCheckSitadori;
	}

	/**
	 * 更新時の保留チェック状態取得
	 * @param registerInputBean
	 * @return
	 */
	public static boolean getNowCheckSrk(RegisterInputBean registerInputBean) {
		boolean nowCheckSrk = false;
		if (registerInputBean.getArrayCheckSrk() != null) {
			for (String checkSrk : registerInputBean.getArrayCheckSrk()) {
				if ("on".equals(checkSrk)) {
					nowCheckSrk = true;
					break;
				}
			}
		}
		return nowCheckSrk;
	}

	/**
	 * 入庫区分チェック状態取得
	 * @param registerInputBean
	 * @return boolean配列[下取, 買取, オークション]
	 */
	public static boolean[] existKbSiire(RegisterInputBean registerInputBean) {
		boolean existKbSiire[] = {false, false, false};
		for (String kbSiire : registerInputBean.getArrayKbSiire()) {
			if (CarryinConst.KBSIIRE_SITADORI.equals(kbSiire)) {
				existKbSiire[0] = true;
			}
			if (CarryinConst.KBSIIRE_KAITORI.equals(kbSiire)) {
				existKbSiire[1] = true;
			}
			if (CarryinConst.KBSIIRE_AUCTION.equals(kbSiire)) {
				existKbSiire[2] = true;
			}
		}
		return existKbSiire;
	}

}
