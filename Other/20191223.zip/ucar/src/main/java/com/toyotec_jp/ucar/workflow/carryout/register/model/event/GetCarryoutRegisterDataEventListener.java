package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutDAOKey;
import com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF;
import com.toyotec_jp.ucar.workflow.carryout.register.model.object.CarryoutRegisterDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出情報取得イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/10 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class GetCarryoutRegisterDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetCarryoutRegisterDataEvent targetEvent = (GetCarryoutRegisterDataEvent)event;

		Ucaa001gPKBean t220001gPkBean = targetEvent.getT220001gPkBean();

		// DAOIF取得
		CarryoutRegisterDAOIF getDao = getDAO(CarryoutDAOKey.REGISTER_DAO, targetEvent, CarryoutRegisterDAOIF.class);

		// 車両搬出登録 画面出力値取得
		ResultArrayList<CarryoutRegisterDataBean> carryoutRegisterDataList = getDao.selectT220001G(t220001gPkBean,
																									// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
																									targetEvent.getUserInfoBean().getCdTenpo(),
																									targetEvent.getUserInfoBean().getKbScenter());
																									// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		GetCarryoutRegisterDataEventResult getEventResult = new GetCarryoutRegisterDataEventResult();

		// 検索対象が0件の場合
		if (carryoutRegisterDataList.size() == 0) {
			getEventResult.setExistCarryoutRegisterData(false);
		} else {
			getEventResult.setExistCarryoutRegisterData(true);
			
			//2019.04.03 T.Osada Start
			t220001gPkBean.setCdKaisya(carryoutRegisterDataList.get(0).getCdKaisya());
			t220001gPkBean.setCdHanbaitn(carryoutRegisterDataList.get(0).getCdHanbaitn());
			//2019.04.03 T.Osada End
			
			
			// 仕入種別情報取得
			ResultArrayList<Ucaa002gBean> t220002gList = getDao.selectT220002G(t220001gPkBean);

			// チェック内容情報取得
			ResultArrayList<Ucaa003gBean> t220003gList = getDao.selectT220003G(t220001gPkBean,
																				// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
																				targetEvent.getUserInfoBean().getCdTenpo(),
																				targetEvent.getUserInfoBean().getKbScenter());
																				// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			// 車両搬出情報取得
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//			ResultArrayList<T220013gBean> t220013gList = getDao.selectT220013G(t220001gPkBean);
			ResultArrayList<Uccb009gBean> t220013gList = getDao.selectT220013G(t220001gPkBean,
																				targetEvent.getUserInfoBean().getCdTenpo(),
																				targetEvent.getUserInfoBean().getKbScenter());
																				// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			getEventResult.setCarryoutRegisterDataBean(carryoutRegisterDataList.get(0));
			getEventResult.setT220002gList(t220002gList);
			getEventResult.setT220003gList(t220003gList);

			if (t220013gList.size() == 0) {
//				getEventResult.setT220013gBean(new T220013gBean());
				getEventResult.setT220013gBean(new Uccb009gBean());		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
				getEventResult.setExistT220013gData(false);
			} else {
				getEventResult.setT220013gBean(t220013gList.get(0));
				getEventResult.setExistT220013gData(true);
			}
		}

		return getEventResult;
	}

}
