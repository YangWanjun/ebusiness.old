package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.util.HashMap;

import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.ucar.base.model.event.UcarEvent;


/**
 * <strong>Excel読み込みイベント。</strong>
 * <p>
 * ・パラメータ詳細<br>
 * docFormatID・・・書式ID(DOC_FORMAT_ID)を設定。(必須)<br>
 * filePath・・・読み込むExcelファイルのパスを設定。(必須)<br>
 * isAppFilePath・・・
 * trueの場合アプリケーションサーバ、falseの場合ストレージサービスを対象とする。
 * デフォルトはfalse。<br>
 * singleParamBeanClass・・・通常GET項目を格納するビーンのクラス。<br>
 * listParamBeanClassMap・・・
 * キー：リストID(LIST_ID)、値：リストGET項目を格納するビーンのクラス。<br>
 * putListParamBeanClassMapを使用して設定する。<br>
 * ・返却<br>
 * ResultArrayList&lt;ExcelSheetInfoBean&gt;の形式で返却される。<br>
 * ・システム例外<br>
 * TDAOException・・・DBに設定した定義情報の取得に失敗した場合の例外。<br>
 * TFileMngException・・・ファイルが存在しないなどの理由でファイル読み込みに失敗した場合の例外。<br>
 * TExcelMngException・・・文書エンジンにおいて例外が発生した場合の例外。<br>
 * TUnsupportedDataTypeException・・・GET項目をマッピングするビーンが
 * マッピングサポート対象外である型のフィールドをもつ場合の例外。<br>
 * TSystemException・・・その他システム例外。<br>
 * ・アプリケーション例外<br>
 * なし。<br>
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/13 新規作成<br>
 * @since 1.00
 */
public class ExcelFormatReadEvent extends UcarEvent {

	private static final long serialVersionUID = 6987088558211022576L;

	private String docFormatID;

	private String filePath;

	private boolean isAppFilePath = false;

	private Class<? extends TecBean> singleParamBeanClass;

	private HashMap<String, Class<? extends TecBean>> listParamBeanClassMap = new HashMap<String, Class<? extends TecBean>>();

	/**
	 * docFormatIDを取得する。
	 * @return docFormatID
	 */
	public String getDocFormatID() {
		return docFormatID;
	}

	/**
	 * docFormatIDを設定する。
	 * @param docFormatID
	 */
	public void setDocFormatID(String docFormatID) {
		this.docFormatID = docFormatID;
	}

	/**
	 * filePathを取得する。
	 * @return filePath
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * filePathを設定する。
	 * @param filePath
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * isAppFilePathを取得する。
	 * @return isAppFilePath
	 */
	public boolean isAppFilePath() {
		return isAppFilePath;
	}

	/**
	 * isAppFilePathを設定する。
	 * @param isAppFilePath
	 */
	public void setAppFilePath(boolean isAppFilePath) {
		this.isAppFilePath = isAppFilePath;
	}

	/**
	 * singleParamBeanClassを取得する。
	 * @return singleParamBeanClass
	 */
	public Class<? extends TecBean> getSingleParamBeanClass() {
		return singleParamBeanClass;
	}

	/**
	 * singleParamBeanClassを設定する。
	 * @param singleParamBeanClass
	 */
	public void setSingleParamBeanClass(Class<? extends TecBean> singleParamBeanClass) {
		this.singleParamBeanClass = singleParamBeanClass;
	}

	/**
	 * listParamBeanClassMapを取得する。
	 * @return listParamBeanClassMap
	 */
	public HashMap<String, Class<? extends TecBean>> getListParamBeanClassMap() {
		return listParamBeanClassMap;
	}

	/**
	 *
	 * @see java.util.HashMap#clear()
	 */
	public void clearListParamBeanClassMap() {
		listParamBeanClassMap.clear();
	}

	/**
	 * @param key
	 * @param value
	 * @return
	 * @see java.util.HashMap#put(java.lang.Object, java.lang.Object)
	 */
	public Class<? extends TecBean> putListParamBeanClassMap(String key, Class<? extends TecBean> value) {
		return listParamBeanClassMap.put(key, value);
	}

}
