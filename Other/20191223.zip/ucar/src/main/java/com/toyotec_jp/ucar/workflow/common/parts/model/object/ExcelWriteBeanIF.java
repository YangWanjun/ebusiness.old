/*
 * 【システム名】リース管理システム
 * 【ファイル名】ExcelWriteBeanIF.java
 * 【  説  明  】
 * 【  作  成  】2010/07/13 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import java.util.ArrayList;

/**
 * <strong>Excel書き込み用インターフェース。</strong>
 * <p>
 * Excel書き込みに使用するビーンはこのインターフェースを実装する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/13 新規作成<br>
 * @since 1.00
 */
public interface ExcelWriteBeanIF {

	/**
	 * Excel書き込み用ArrayList取得。
	 * <pre>
	 * ArrayListの順序が書き込み順序(ARRAY_IDX)に対応する。
	 * </pre>
	 * @return Excel書き込み用ArrayList
	 */
	public ArrayList<String> getExcelWriteList();

}
