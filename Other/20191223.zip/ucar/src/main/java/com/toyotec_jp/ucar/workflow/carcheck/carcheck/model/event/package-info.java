/**
 * 入庫検査/作業仕分イベント関連パッケージ
 * @version 1.00 2011/10/03 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;
