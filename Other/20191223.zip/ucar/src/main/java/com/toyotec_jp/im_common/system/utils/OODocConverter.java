/*
 * 【システム名】リース管理システム
 * 【ファイル名】OODocConverter.java
 * 【  説  明  】
 * 【  作  成  】2011/01/12 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.net.ConnectException;

import com.artofsolving.jodconverter.openoffice.converter.StreamOpenOfficeDocumentConverter;
import jp.co.intra_mart.common.aid.jdk.java.io.file.ExtendedFile;

import com.artofsolving.jodconverter.DocumentConverter;
import com.artofsolving.jodconverter.openoffice.connection.OpenOfficeConnection;
import com.artofsolving.jodconverter.openoffice.connection.SocketOpenOfficeConnection;
import com.artofsolving.jodconverter.openoffice.converter.OpenOfficeDocumentConverter;
import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.TecApplicationManager.TecConfigKey;
import com.toyotec_jp.im_common.system.exception.TecSystemException;

/**
 * <strong>ドキュメントコンバータ(OpenOffice連携)。</strong>
 * <p>
 * OpenOfficeと連携し、各種ドキュメントを変換する。<br>
 * 連携にはJODConverter(ver2.2.2)を使用。<br>
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2011/01/12 新規作成<br>
 * @since 1.00
 */
public class OODocConverter {

	/** コンストラクタ。 */
	private OODocConverter(){
	}

	private static final OODocConverter instance = new OODocConverter();

	/** OpenOfficeデフォルトホスト名 */
	private static final String DEFAULT_OO_HOST =
		TecApplicationManager.getConfigValue(TecConfigKey.DOC_CONV_DEFAULT_HOST);
	/** OpenOfficeデフォルトポート番号 */
	private static final int DEFAULT_OO_PORT =
		TecApplicationManager.getConfigInt(TecConfigKey.DOC_CONV_DEFAULT_PORT);

	/**
	 * インスタンス取得。
	 * @return ドキュメントコンバータインスタンス
	 */
	public static OODocConverter getInstance(){
		return instance;
	}

	/**
	 * ファイルの形式をPDFに変換する。
	 * @param docFilePath 変換元ファイルパス(「AppRuntimeルート/work/」相対)
	 * @return 変換後のファイルパス(「AppRuntimeルート/work/」相対)
	 * @throws TecSystemException
	 * @see {@link com.toyotec_jp.im_common.system.utils.OODocConverter#convert(String, String, String, int)}
	 */
	public String convertToPdf(String docFilePath) throws TecSystemException {
		String pdfFilePath = StringUtils.replaceFileExtension(docFilePath, "pdf");
		convert(docFilePath, pdfFilePath);
		return pdfFilePath;
	}

	/**
	 * ファイルの形式をPDFに変換する。
	 * @param docFilePath 変換元ファイルパス(「AppRuntimeルート/work/」相対)
	 * @param ooHost OpenOfficeホスト名
	 * @param ooPort OpenOfficeポート番号
	 * @return 変換後のファイルパス(「AppRuntimeルート/work/」相対)
	 * @throws TecSystemException
	 * @see {@link com.toyotec_jp.im_common.system.utils.OODocConverter#convert(String, String, String, int)}
	 */
	public String convertToPdf(String docFilePath, String ooHost, int ooPort) throws TecSystemException {
		String pdfFilePath = StringUtils.replaceFileExtension(docFilePath, "pdf");
		convert(docFilePath, pdfFilePath, ooHost, ooPort);
		return pdfFilePath;
	}

	/**
	 * ファイルの形式を変換する。
	 * @param fromFilePath 変換元ファイルパス(「AppRuntimeルート/work/」相対)
	 * @param toFilePath 変換先ファイルパス(「AppRuntimeルート/work/」相対)
	 * @throws TecSystemException
	 * @see {@link com.toyotec_jp.im_common.system.utils.OODocConverter#convert(String, String, String, int)}
	 */
	public void convert(String fromFilePath, String toFilePath) throws TecSystemException {
		convert(fromFilePath, toFilePath, DEFAULT_OO_HOST, DEFAULT_OO_PORT);
	}

	/**
	 * ファイルの形式を変換する。
	 * <pre>
	 * 以下を変換する。<br>
	 * ・TEXT系<br>
	 * HTML(.html)、OpenDocument Text(.odt)、OpenOffice.org 1.0 Text Document(.sxw)、<br>
	 * Microsoft Word(.doc)、Microsoft Word 2007 XML(.docx)、Rich Text Format(.rtf)、<br>
	 * WordPerfect(.wpd)、Plain Text(.txt)<br>
	 * ・SPREADSHEET系<br>
	 * OpenDocument Spreadsheet(.ods)、OpenOffice.org 1.0 Spreadsheet(.sxc)、<br>
	 * Microsoft Excel(.xls)、Microsoft Excel 2007 XML(.xlsx)、CSV(.csv)、Tab-separated Values(.tsv)<br>
	 * ・PRESENTATION系<br>
	 * OpenDocument Presentation(.odp)、OpenOffice.org 1.0 Presentation(.sxi)、<br>
	 * Microsoft PowerPoint(.ppt)、Microsoft PowerPoint 2007 XML(.pptx)<br>
	 * ・DRAWING系<br>
	 * OpenDocument Drawing(.odg)<br>
	 * <br>
	 * 変換先となるファイル形式は以下。
	 * ・TEXT系(変換先)<br>
	 * Portable Document Format(.pdf)、XHTML(.xhtml)、HTML(.html)、<br>
	 * OpenDocument Text(.odt)、OpenOffice.org 1.0 Text Document(.sxw)、Microsoft Word(.doc)、<br>
	 * Rich Text Format(.rtf)、Plain Text(.txt)、MediaWiki wikitext(.wiki)<br>
	 * ・SPREADSHEET系(変換先)<br>
	 * Portable Document Format(.pdf)、XHTML(.xhtml)、HTML(.html)、<br>
	 * OpenDocument Spreadsheet(.ods)、OpenOffice.org 1.0 Spreadsheet(.sxc)、<br>
	 * Microsoft Excel(.xls)、CSV(.csv)、Tab-separated Values(.tsv)<br>
	 * ・PRESENTATION系(変換先)<br>
	 * Portable Document Format(.pdf)、Macromedia Flash(.swf)、XHTML(.xhtml)、HTML(.html)、<br>
	 * OpenDocument Presentation(.odp)、OpenOffice.org 1.0 Presentation(.sxi)、<br>
	 * Microsoft PowerPoint(.ppt)<br>
	 * ・DRAWING系(変換先)<br>
	 * Portable Document Format(.pdf)、Macromedia Flash(.swf)、<br>
	 * OpenDocument Drawing(.odg)、Scalable Vector Graphics(.svg)<br>
	 * </pre>
	 * @param fromFilePath 変換元ファイルパス(「AppRuntimeルート/work/」相対)
	 * @param toFilePath 変換先ファイルパス(「AppRuntimeルート/work/」相対)
	 * @param ooHost OpenOfficeホスト名
	 * @param ooPort OpenOfficeポート番号
	 * @throws TecSystemException
	 */
	public void convert(String fromFilePath, String toFilePath, String ooHost, int ooPort) throws TecSystemException {
		IMAppFileManager imap = IMAppFileManager.getInstance();
		ExtendedFile fromFile = imap.getAppFileObject(fromFilePath);
		ExtendedFile toFile = imap.getAppFileObject(toFilePath);
		// OpenOfficeとのコネクション
		OpenOfficeConnection connection = new SocketOpenOfficeConnection(ooHost, ooPort);
		try {
			connection.connect();
			// 変換
			DocumentConverter converter = new StreamOpenOfficeDocumentConverter(connection);
			converter.convert(fromFile, toFile);
		} catch (ConnectException e) {
			// 接続失敗
			throw new TecSystemException("OpenOffice接続失敗", e);
		} catch (Exception e) {
			// 変換失敗
			throw new TecSystemException("変換失敗", e);
		} finally {
			if(connection != null && connection.isConnected()){
				connection.disconnect();
			}
		}
	}

}
