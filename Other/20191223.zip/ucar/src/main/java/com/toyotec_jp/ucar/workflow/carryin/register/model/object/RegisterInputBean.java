package com.toyotec_jp.ucar.workflow.carryin.register.model.object;

import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;

/**
 * <strong>車両搬入登録 画面入力値Bean</strong>
 * <p>
 * 車両搬入情報Bean(Ucaa001gBean)を継承している。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterInputBean extends Ucaa001gBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 仕入種別 */
	private String[] arrayKbSiire;
	/** チェック内容 */
	private String[] arrayKbCheck;

	/** 書類完備日チェック内容 */
	private String[] arrayCheckSrk;

	/** 書類完備日 テキストボックス*/
	private String ddSrk;

//--2019.3.20 from
	/** 搬入拠点が属する販社コード**/
	private String cdTenpoHanbaitnSel;
	
//--2019.3.20 to	
	/** 下取書類(チェックボックス)の画面初期表示状態
	 * <pre>
	 * true：画面初期表示時点でチェックあり
	 * false：画面初期表示時点でチェックなし
	 * </pre>
	 *  */
	private boolean initKbCheckSitadori;
	/** 保留(チェックボックス)の画面初期表示状態
	 * <pre>
	 * true：画面初期表示時点でチェックあり
	 * false：画面初期表示時点でチェックなし
	 * </pre>
	 *  */
	private boolean initCheckSrk;

	/**
	 *
	 */
	public RegisterInputBean() {
		super();
	}

	/**
	 * arrayKbSiireを取得する。
	 * @return arrayKbSiire 仕入種別
	 */
	public String[] getArrayKbSiire() {
		return arrayKbSiire;
	}

	/**
	 * arrayKbSiireを設定する。
	 * @param arrayKbSiire 仕入種別
	 */
	public void setArrayKbSiire(String[] arrayKbSiire) {
		this.arrayKbSiire = arrayKbSiire;
	}

	/**
	 * arrayKbCheckを取得する。
	 * @return arrayKbCheck チェック内容
	 */
	public String[] getArrayKbCheck() {
		return arrayKbCheck;
	}

	/**
	 * arrayKbCheckを設定する。
	 * @param arrayKbCheck チェック内容
	 */
	public void setArrayKbCheck(String[] arrayKbCheck) {
		this.arrayKbCheck = arrayKbCheck;
	}


	public String[] getArrayCheckSrk() {
		return arrayCheckSrk;
	}

	public void setArrayCheckSrk(String[] arrayCheckSrk) {
		this.arrayCheckSrk = arrayCheckSrk;
	}


	public String getDdSrk() {
		return ddSrk;
	}

	public void setDdSrk(String ddSrk) {
		this.ddSrk = ddSrk;
	}

	/**
	 * initKbCheckSitadoriを取得する。
	 * @return initKbCheckSitadori
	 */
	public boolean isInitKbCheckSitadori() {
		return initKbCheckSitadori;
	}

	/**
	 * initKbCheckSitadoriを設定する。
	 * @param initKbCheckSitadori
	 */
	public void setInitKbCheckSitadori(boolean initKbCheckSitadori) {
		this.initKbCheckSitadori = initKbCheckSitadori;
	}

	/**
	 * initCheckSrkを取得する。
	 * @return initCheckSrk
	 */
	public boolean isInitCheckSrk() {
		return initCheckSrk;
	}

	/**
	 * initCheckSrkを設定する。
	 * @param initCheckSrk
	 */
	public void setInitCheckSrk(boolean initCheckSrk) {
		this.initCheckSrk = initCheckSrk;
	}
	
//--2019.3.20 from
	public String getCdTenpoHanbaitnSel() {
		return cdTenpoHanbaitnSel;
	}

	public void setCdTenpoHanbaitnSel(String cdTenpoHanbaitnSel) {
		this.cdTenpoHanbaitnSel = cdTenpoHanbaitnSel;
	}
//--2019.3.20 to

}
