package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutDAOKey;
import com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;

/**
 * <strong>搬出予定車両登録イベントリスナ</strong>
 * @author 00496_990215
 * @version 1.00 2014/08/11 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutPlanRegisterDataEventListener extends UcarEventListener {

	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {
		TecLogger.trace("update registerData start");
		
		CarryoutPlanRegisterDataEvent targetEvent = (CarryoutPlanRegisterDataEvent) event;
		
		// DAOIF取得
		CarryoutRegisterDAOIF dao = getDAO(CarryoutDAOKey.REGISTER_DAO, targetEvent, CarryoutRegisterDAOIF.class);
		
		if(targetEvent.getUcaa001gBean().getCdShtan() != null && !"".equals(targetEvent.getUcaa001gBean().getCdShtan())){
			// 入力値チェック
			ResultArrayList<SyainDBBean> t220107gList = null;
			t220107gList = dao.getSyainDBList(targetEvent.getUcaa001gBean().getCdKaisya(),
												targetEvent.getUcaa001gBean().getCdHanbaitn(),
												targetEvent.getUcaa001gBean().getCdShtan());
			if (t220107gList.size() == 0) {				
					throw new TecExclusionException("「商談担当」に入力された担当者が存在しません。");	
			}		
		}
		
		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarryoutConst.APPID_CARRYOUT_REGISTER;
		
		//2019.04.30 T.Osada start
		if (targetEvent.getUserInfoBean().getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)){
			updateUcaa001gData(targetEvent, dao, executeDate, updateUserId, updateAppId);
			updateUcab007gData(targetEvent, dao, executeDate, updateUserId, updateAppId);
		}
		//2019.04.30 T.Osada end
		
		TecLogger.trace("update registerData end");
		return null;
	}
	
	/**
	 * 車両搬入情報 更新処理
	 * @param targetEvent
	 * @param dao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void updateUcaa001gData(CarryoutPlanRegisterDataEvent targetEvent,
									CarryoutRegisterDAOIF dao,
									Timestamp executeDate,
									String updateUserId,
									String updateAppId) throws TecExclusionException, TecMessageException, TecDAOException {

		targetEvent.getUcaa001gBean().setCdSksisya(updateUserId);
		targetEvent.getUcaa001gBean().setCdKsnsya(updateUserId);
		targetEvent.getUcaa001gBean().setCdSksiapp(updateAppId);
		targetEvent.getUcaa001gBean().setCdKsnapp(updateAppId);

		SimpleExecuteResultBean updateResult = dao.updateT220001G(targetEvent.getUcaa001gBean(),
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																	targetEvent.getUserInfoBean().getKbScenter(),
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																	targetEvent.getUcaa001gDtKosin(),
																	executeDate);

		if (updateResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
		}
	}
	
	/**
	 * 車両搬入情報 更新処理
	 * @param targetEvent
	 * @param dao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void updateUcab007gData(CarryoutPlanRegisterDataEvent targetEvent,
									CarryoutRegisterDAOIF dao,
									Timestamp executeDate,
									String updateUserId,
									String updateAppId) throws TecExclusionException, TecMessageException, TecDAOException {

		targetEvent.getUcab007gBean().setCdSksisya(updateUserId);
		targetEvent.getUcab007gBean().setCdKsnsya(updateUserId);
		targetEvent.getUcab007gBean().setCdSksiapp(updateAppId);
		targetEvent.getUcab007gBean().setCdKsnapp(updateAppId);

		SimpleExecuteResultBean updateResult = dao.updateT220012G(targetEvent.getUcab007gBean(),
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																	targetEvent.getUserInfoBean().getKbScenter(),
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																	targetEvent.getUcaa001gDtKosin(),
																	executeDate);

		if (updateResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
		}
	}

}
