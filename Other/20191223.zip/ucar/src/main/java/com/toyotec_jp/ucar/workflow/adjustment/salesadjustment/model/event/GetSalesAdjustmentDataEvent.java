package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>売上精算取得イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class GetSalesAdjustmentDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/** 会社コード */
	private String cdKaisya;
	/** 事業所コード */
	private String cdJigyosyo;
	/** 受注NO */
	private String noJucyu;

	/** 確認処理
	 * <p>
	 * 確認ボタン押下による再計算の場合はtrue
	 * </p>
	 *  */
	private boolean executeConfirm;
	/** 得意先値引適用 */
	private String kbNebiki;
	/** 値引き */
	private int kiNebiki;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdJigyosyoを取得する。
	 * @return cdJigyosyo 事業所コード
	 */
	public String getCdJigyosyo() {
		return cdJigyosyo;
	}

	/**
	 * cdJigyosyoを設定する。
	 * @param cdJigyosyo 事業所コード
	 */
	public void setCdJigyosyo(String cdJigyosyo) {
		this.cdJigyosyo = cdJigyosyo;
	}

	/**
	 * noJucyuを取得する。
	 * @return noJucyu 受注NO
	 */
	public String getNoJucyu() {
		return noJucyu;
	}

	/**
	 * noJucyuを設定する。
	 * @param noJucyu 受注NO
	 */
	public void setNoJucyu(String noJucyu) {
		this.noJucyu = noJucyu;
	}

	/**
	 * executeConfirmを取得する。
	 * @return executeConfirm
	 */
	public boolean isExecuteConfirm() {
		return executeConfirm;
	}

	/**
	 * executeConfirmを設定する。
	 * @param executeConfirm
	 */
	public void setExecuteConfirm(boolean executeConfirm) {
		this.executeConfirm = executeConfirm;
	}

	/**
	 * kbNebikiを取得する。
	 * @return kbNebiki
	 */
	public String getKbNebiki() {
		return kbNebiki;
	}

	/**
	 * kbNebikiを設定する。
	 * @param kbNebiki
	 */
	public void setKbNebiki(String kbNebiki) {
		this.kbNebiki = kbNebiki;
	}

	/**
	 * kiNebikiを取得する。
	 * @return kiNebiki
	 */
	public int getKiNebiki() {
		return kiNebiki;
	}

	/**
	 * kiNebikiを設定する。
	 * @param kiNebiki
	 */
	public void setKiNebiki(int kiNebiki) {
		this.kiNebiki = kiNebiki;
	}

}
