/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecApplicationManager.java
 * 【  説  明  】
 * 【  作  成  】2010/06/08 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common;

import java.util.ResourceBundle;

import com.toyotec_jp.im_common.system.utils.StringCheckUtils;

/**
 * <strong>アプリケーション管理クラス。</strong>
 * <p>
 * アプリケーションで使用する固定値、初期設定ファイルに定義した値を管理する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/08 新規作成<br>
 * @since 1.00
 */
public class TecApplicationManager {

	/** パッケージのルート */
	public static final String APPLICATION_ROOT = "com.toyotec_jp.im_common";

	/** システム共通パッケージのルート */
	public static final String SYSTEM_COMMON_ROOT = APPLICATION_ROOT + ".system";

	/** ダウンロード用：ファイル名を設定するリクエスト属性のキー名称 */
	public static final String REQ_ATTR_KEY_DOWNLOAD_FILE_NAME = APPLICATION_ROOT + ".download_file_name";
	/** ダウンロード用：ファイルパス(ストレージサービス)を設定するリクエスト属性のキー名称 */
	public static final String REQ_ATTR_KEY_DOWNLOAD_SS_FILE_PATH = APPLICATION_ROOT + ".download_ss_file_path";
	/** ダウンロード用：ファイルパス(APサーバ)を設定するリクエスト属性のキー名称 */
	public static final String REQ_ATTR_KEY_DOWNLOAD_AP_FILE_PATH = APPLICATION_ROOT + ".download_ap_file_path";
	/** ダウンロード用：ファイルのバイト配列を設定するリクエスト属性のキー名称 */
	public static final String REQ_ATTR_KEY_DOWNLOAD_FILE_DATA = APPLICATION_ROOT + ".download_file_data";

	private TecApplicationManager(){
	}

	/** アプリケーションIDIF */
	public interface TecApplicationIdIF {
		/** アプリケーションID取得 */
		public String getApplicationId();
	}

	/** サービスIDIF */
	public interface TecServiceIdIF {
		/** アプリケーションID取得 */
		public String getApplicationId();
		/** サービスID取得 */
		public String getServiceId();
	}

	/** イベントキーIF */
	public interface TecEventKeyIF {
		/** アプリケーションID取得 */
		public String getApplicationId();
		/** イベントキー取得 */
		public String getEventKey();
	}

	/** DAOキーIF */
	public interface TecDAOKeyIF {
		/** アプリケーションID取得 */
		public String getApplicationId();
		/** DAOキー取得 */
		public String getDAOKey();
	}

	/** コンスタントキーIF */
	public interface TecConstantKeyIF {
		/** コンスタントキー取得 */
		public String getConstantKey();
	}

	/** コンフィグキーIF */
	public interface TecConfigKeyIF {
		/** コンフィグキー取得 */
		public String getConfigKey();
	}

	/** コンフィグキー */
	public static enum TecConfigKey implements TecConfigKeyIF {
		/** ページング用デフォルトページ件数 */
		DEFAULT_PAGE_SIZE(SYSTEM_COMMON_ROOT + ".paging.DefaultPageSize"),
		/** ページング用デフォルトページ上限件数 */
		DEFAULT_REC_LIMIT(SYSTEM_COMMON_ROOT + ".paging.DefaultRecLimit"),
		/** CSVパーサ用一時ファイル保存パス */
		TEMP_CSV_PARSER_PATH(SYSTEM_COMMON_ROOT + ".file.temp.CsvParser.Path"),
		/** ドキュメントコンバータ-デフォルトホスト名 */
		DOC_CONV_DEFAULT_HOST(SYSTEM_COMMON_ROOT + ".OODocConverter.DefaultHost"),
		/** ドキュメントコンバータ-デフォルトポート番号 */
		DOC_CONV_DEFAULT_PORT(SYSTEM_COMMON_ROOT + ".OODocConverter.DefaultPort"),
		/** シェアデータスキマ */
		SHAREE_DB_SCHEMA(SYSTEM_COMMON_ROOT + ".sharedDb.schema")
		;
		private String configKey;
		private TecConfigKey(String configKey){
			this.configKey = configKey;
		}
		public String toString(){
			return configKey;
		}
		@Override
		public String getConfigKey() {
			return configKey;
		}
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(TConfig.properties)から指定されたキーに対応する数値を取得する。
	 * </pre>
	 * @param configKey キー
	 * @return キーに対応する数値
	 */
	public static final int getConfigInt(TecConfigKeyIF configKey) {
		return getConfigInt(configKey.getConfigKey());
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(TConfig.properties)から指定されたキーに対応する数値を取得する。
	 * </pre>
	 * @param key キー
	 * @return キーに対応する数値
	 */
	public static final int getConfigInt(String key) {
		String configValue = getConfigValue(key);
		if(StringCheckUtils.isEmpty(configValue)){
			return 0;
		}
		return Integer.parseInt(configValue, 10);
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(TConfig.properties)から指定されたキーに対応する文字列を取得する。
	 * </pre>
	 * @param configKey キー
	 * @return キーに対応する文字列
	 */
	public static final String getConfigValue(TecConfigKeyIF configKey) {
		return getConfigValue(configKey.getConfigKey());
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(TConfig.properties)から指定されたキーに対応する文字列を取得する。
	 * </pre>
	 * @param key キー
	 * @return キーに対応する文字列
	 */
	public static final String getConfigValue(String key) {
		//return StringUtils.encode(RB_CONFIG.getString(key), CharSet.UTF8, CharSet.UTF8);
		//return StringUtil.encode(RB_CONFIG.getString(key), CharSet.ISO_8859_1, CharSet.UTF8);
		return ResourceBundle.getBundle(APPLICATION_ROOT + ".TecConfig").getString(key);
	}

	/**
	 * プロパティファイル再取得。
	 * <pre>
	 * 本システムでは使用しない。<br>
	 * ResourceBundleのキャッシュをクリアすることで
	 * プロパティファイルを再読込させる。<br>
	 * ただし、staticフィールドに取得結果を設定し使用していることがあるため、
	 * 対象のクラスを再読込しなければ意図した結果とはならないため注意。
	 * </pre>
	 */
	public static void refreshProperties(){
		ResourceBundle.clearCache();
	}

}
