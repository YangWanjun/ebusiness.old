package com.toyotec_jp.ucar.workflow.carryin.common;

import java.util.Iterator;

import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListParamBean;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;

/**
 * <strong>車両搬入一覧共通SQL管理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/09 新規作成<br>
 * @since 1.00
 * @category [[車両搬入(共通)]]
 */
public class CarryinUtilsSql {

	/** インスタンス生成しない */
	private CarryinUtilsSql(){
	}

	/**
	 * 抽出ＳＱＬメイン
	 */
	private static final String SELECT_T220001G_MAIN =
		"SELECT"
		+ "    SYARYO_HANNYU1.CD_KAISYA"
		+ "  , SYARYO_HANNYU1.CD_HANBAITN"
		+ "  , SYARYO_HANNYU1.DD_HANNYU"
		+ "  , SYARYO_HANNYU1.NO_KANRI"
		+ "  , CD_OKYAKU"
		+ "  , KJ_OKYAKUM"
		+ "  , CD_NORIKUSI"
		+ "  , TRIM('　' FROM V213M.KJ_RIKUSIM) AS KJ_RIKUSIM"
		+ "  , KB_NOSYASYU"
		+ "  , CD_NOGYOTAI"
		+ "  , NO_NOSEIRI"
		// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため start
		+ "  , SYARYO_HANNYU1.CD_HANTENPO"
		// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため end
		+ "  , MJ_SITKATA"
		+ "  , NO_SYADAI"
		+ "  , MJ_SYAMEI"
		+ "  , DD_SYODOTOR"
		+ "  , DD_SYKNMANR"
		+ "  , NO_KATARUIB"
		+ "  , CD_TOSYOKU"
		+ "  , NU_SOUKUKM"
		+ "  , CD_SIRTENPO"
		+ "  , TRIM('　' FROM NVL(V201M.KJ_TENTANMS, U006M.KJ_TENTANMS)) AS KJ_TENTANMS "
		+ "  , CD_SDTAN"
		+ "  , KI_NYUKOK"
		+ "  , CD_KOZINZYHO"
		+ "  , NO_ZYUTYU"
		+ "  , MJ_UKETAN"
		+ "  , NO_SYARYOU"
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		+ "  , DD_SIIRE"
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

		// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
		+ "  , DD_INKANKGN"
		// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end
		+ "  , MJ_BIKOU"
		+ "  , DT_ZAIKO"
		+ "  , DT_KOUTEI"
		// 2011.10.18 H.Yamashita 結合条件変更に伴う対応 start
		+ "  , SYARYO_HANNYU1.DT_SAKUSEI"
		+ "  , SYARYO_HANNYU1.DT_KOSIN"
		+ "  , SYARYO_HANNYU1.CD_SKSISYA"
		+ "  , SYARYO_HANNYU1.CD_KSNSYA"
		+ "  , SYARYO_HANNYU1.CD_SKSIAPP"
		+ "  , SYARYO_HANNYU1.CD_KSNAPP "
		// 2011.10.18 H.Yamashita 結合条件変更に伴う対応 end

		+ "  , SYORUI_CHECK.DD_SRKNB"
		+ "  , SYORUI_CHECK.DD_SRKHR "
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
		+ "  , SYORUI_CHECK.DT_KOSIN SYORUI_DT_KOSIN "
		// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

		+ "  , ";

	// 2011.10.18 H.Yamashita add
	private static final String SELECT_T220001G_FROM3 =
		 "	,(SELECT "
		+ "		 SYARYO_HANNYU2.CD_KAISYA "
		+ "		,SYARYO_HANNYU2.CD_HANBAITN "
		+ " 	,SYARYO_HANNYU2.DD_HANNYU "
		+ "		,SYARYO_HANNYU2.NO_KANRI ";

	/**
	 * SQL SELECT部分作成
	 * @param prmData
	 * @param t220004mList
	 * @param t220005mList
	 * @param ddTenuktFlg 店舗受取日検索実行フラグ(true:店舗受取日で検索を実行する／false:実行しない)
	 * @return
	 */
	public static StringBuilder createSelectSql(ListParamBean prmData,
												ResultArrayList<Ucaa004mBean> t220004mList,
												ResultArrayList<Ucaa005mBean> t220005mList,
												Boolean ddTenuktFlg) {

		StringBuilder selectSql = new StringBuilder(SELECT_T220001G_MAIN);
		StringBuilder caseSql = new StringBuilder();

		// 仕入種別チェック用 2011.10.18 H.Yamashita add
		StringBuilder caseSql2 = new StringBuilder();

		// 仕入種別マスタ 2011.10.18 H.Yamashita add
		StringBuilder tableSql = new StringBuilder();

		// 仕入種別マスタ結合 2011.10.18 H.Yamashita add
		StringBuilder where004m = new StringBuilder();

		if (t220005mList != null){
			// チェック内容マスタの表示フラグ１のデータ分処理を行う
			for (Iterator<Ucaa005mBean> iterator = t220005mList.iterator(); iterator.hasNext();) {
				Ucaa005mBean t220005m = (Ucaa005mBean) iterator.next();
				// KB_CHECK + "01","02"…の文字列とKB_CHECK="01","02"…の存在チェックのcase文を生成
				selectSql.append("U003GCHK.KB_CHECK" + t220005m.getKbCheck());
				caseSql.append( " ,CASE WHEN SUM(CASE WHEN CHECK_NAIYO.KB_CHECK = '" + t220005m.getKbCheck() +
								"' THEN 1 ELSE NULL END) = 1 " + " THEN '1' ELSE '0' " +
								" END AS KB_CHECK" + t220005m.getKbCheck());
				if (iterator.hasNext()){
					selectSql.append(" || ");
				}
			}
			selectSql.append(" AS KB_CHECK ");
		}

		// 仕入種別チェック 2011.10.18 H.Yamashita add start
		if (t220004mList != null){

			if (t220005mList != null){
				selectSql.append(" , ");
			}
			// 仕入種別マスタの表示フラグ１のデータ分処理を行う
			for (Iterator<Ucaa004mBean> iterator = t220004mList.iterator(); iterator.hasNext();) {
				Ucaa004mBean t220004m = (Ucaa004mBean) iterator.next();
				// KB_CHECK + "01","02"…の文字列とKB_CHECK="01","02"…の存在チェックのcase文を生成
				selectSql.append(" DECODE( U002GCHK.KB_SIIRE" + t220004m.getKbSiire() +
								" , '1' , RTRIM(U004M_" + t220004m.getKbSiire() +
								".MJ_SIIRE, ' ')|| ' ', '') ");
				/*
				selectSql.append(" case when U002GCHK.KB_SIIRE" + t220004m.getKbSiire() +
									" = '1' then RTRIM(U004M_" + t220004m.getKbSiire() +
									".MJ_SIIRE, ' ')|| ' ' ELSE null end");
				*/
				caseSql2.append( " ,CASE WHEN SUM(CASE WHEN SIIRE_SYUBETU.KB_SIIRE = '" + t220004m.getKbSiire() +
								"' THEN 1 ELSE NULL END) = 1 " + " THEN '1' ELSE '0' " +
								" END AS KB_SIIRE" + t220004m.getKbSiire());
				if (iterator.hasNext()){
					selectSql.append(" || ");
				}

				tableSql.append(", (select * FROM T220004M where kb_siire = '" +
								t220004m.getKbSiire()+ "') U004M_" +
								t220004m.getKbSiire() + " ");

				where004m.append(" AND U002GCHK.CD_KAISYA   = U004M_" + t220004m.getKbSiire() + ".CD_KAISYA ");
				where004m.append(" AND U002GCHK.CD_HANBAITN = U004M_" + t220004m.getKbSiire() + ".CD_HANBAITN ");
			}
			selectSql.append(" AS MJ_SIIRE ");

		}
		// 仕入種別チェック 2011.10.18 H.Yamashita add end

		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		String SELECT_T220001G_FROM1
			= "FROM "
			+ UcarTableManager.getSyaryoHannyuSelectOnly(prmData.getKbScenter()) + " SYARYO_HANNYU1 "
			+ "	,(SELECT "
			+ "		 SYARYO_HANNYU2.CD_KAISYA "
			+ "		,SYARYO_HANNYU2.CD_HANBAITN "
			+ " 	,SYARYO_HANNYU2.DD_HANNYU "
			+ "		,SYARYO_HANNYU2.NO_KANRI ";

		String selectT220001gFrom2
			= "	  FROM "
			+ UcarTableManager.getSyaryoHannyuSelectOnly(prmData.getKbScenter()) +" SYARYO_HANNYU2 "
			+ "		," + UcarTableManager.getCheckNaiyo(prmData.getKbScenter()) + " CHECK_NAIYO "
			+ "	  WHERE "
			+ "			SYARYO_HANNYU2.CD_KAISYA   = CHECK_NAIYO.CD_KAISYA(+) "
			+ "		AND SYARYO_HANNYU2.CD_HANBAITN = CHECK_NAIYO.CD_HANBAITN(+) "
			+ "		AND SYARYO_HANNYU2.DD_HANNYU   = CHECK_NAIYO.DD_HANNYU(+) "
			+ " 	AND SYARYO_HANNYU2.NO_KANRI    = CHECK_NAIYO.NO_KANRI(+) ";

		if ("".equals(prmData.getKbScenter())) {
			// 業販・U-Car店舗の場合
			SELECT_T220001G_FROM1
				+= "	,SYARYO_HANNYU2.CD_HANTENPO ";

			selectT220001gFrom2
				+= " 	AND SYARYO_HANNYU2.CD_HANTENPO = CHECK_NAIYO.CD_ZAITENPO(+) "
				+ "  GROUP BY "
				+ "	 	SYARYO_HANNYU2.CD_KAISYA "
				+ "    ,SYARYO_HANNYU2.CD_HANBAITN "
				+ "    ,SYARYO_HANNYU2.DD_HANNYU "
				+ "    ,SYARYO_HANNYU2.NO_KANRI "
				+ "    ,SYARYO_HANNYU2.CD_HANTENPO) U003GCHK ";

		} else {
			selectT220001gFrom2
			+= "  GROUP BY "
			+ "	 	SYARYO_HANNYU2.CD_KAISYA "
			+ "    ,SYARYO_HANNYU2.CD_HANBAITN "
			+ "    ,SYARYO_HANNYU2.DD_HANNYU "
			+ "    ,SYARYO_HANNYU2.NO_KANRI) U003GCHK ";
		}
		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

		selectSql.append(SELECT_T220001G_FROM1);
		selectSql.append(caseSql.toString());
		selectSql.append(selectT220001gFrom2);

		// 仕入種別チェック 2011.10.18 H.Yamashita add
		selectSql.append(SELECT_T220001G_FROM3);
		if ("".equals(prmData.getKbScenter())) {
			// 業販・U-Car店舗の場合
			selectSql.append("  ,SYARYO_HANNYU2.CD_HANTENPO ");
		}
		selectSql.append(caseSql2.toString());

		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
		String SELECT_T220001G_FROM4
			= "	  FROM "
			+ UcarTableManager.getSyaryoHannyuSelectOnly(prmData.getKbScenter()) + " SYARYO_HANNYU2 "
//			+ "		," + UcarTableManager.getSiireSyubetu(prmData.getKbScenter()) + " SIIRE_SYUBETU "
			+ "		,T220903V SIIRE_SYUBETU "
			+ "	  WHERE "
			+ "			SYARYO_HANNYU2.CD_KAISYA   = SIIRE_SYUBETU.CD_KAISYA(+) "
			+ "		AND SYARYO_HANNYU2.CD_HANBAITN = SIIRE_SYUBETU.CD_HANBAITN(+) "
			+ "		AND SYARYO_HANNYU2.DD_HANNYU   = SIIRE_SYUBETU.DD_HANNYU(+) "
			+ " 	AND SYARYO_HANNYU2.NO_KANRI    = SIIRE_SYUBETU.NO_KANRI(+) "
			+ "	  GROUP BY "
			+ "	 	SYARYO_HANNYU2.CD_KAISYA "
			+ "    ,SYARYO_HANNYU2.CD_HANBAITN "
			+ "    ,SYARYO_HANNYU2.DD_HANNYU ";

		if ("".equals(prmData.getKbScenter())) {
			// 業販・U-Car店舗の場合
			SELECT_T220001G_FROM4
				+= "    ,SYARYO_HANNYU2.NO_KANRI "
				+ " ,SYARYO_HANNYU2.CD_HANTENPO) U002GCHK ";
		} else {
			SELECT_T220001G_FROM4
				+= "    ,SYARYO_HANNYU2.NO_KANRI) U002GCHK ";
		}

		SELECT_T220001G_FROM4
			+= "    ," + UcarTableManager.getSyoruiCheck(prmData.getKbScenter()) + " SYORUI_CHECK "
			+ "  , T220006M U006M "
			+ "  , ";

		// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

		selectSql.append(SELECT_T220001G_FROM4);

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		selectSql.append(AddonTableManager.getKyoutuTenpo(prmData.getCdHanbaitn()));
		selectSql.append(" V201M , ");
//2019.4.25 TO
		selectSql.append(AddonTableManager.getRikusiCode(prmData.getCdHanbaitn()));
		selectSql.append(" V213M ");
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		// 仕入れマスタ
		selectSql.append(tableSql.toString());

		// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため start
		if (ddTenuktFlg) {
			// 受取日から該当のデータを取得する場合
			String innterSql
				= "  , ( "
				+ "    SELECT "
				+ "        CD_KAISYA "
				+ "      , CD_HANBAITN "
				+ "      , DD_HANNYU "
				+ "      , NO_KANRI "
				+ "    FROM "
				+ "      T220906V "
				+ "    WHERE "
				/*2019.05.01 T.Osada Start
				+ "      CD_KAISYA = '" + prmData.getCdKaisya() + "' "
				+ "      AND CD_HANBAITN = '" + prmData.getCdHanbaitn() + "' "
				+ "      AND CD_HSTENPO = '" + prmData.getCdTenpo() + "' "
				*/
				+ "      CD_HSTENPO = '" + prmData.getCdTenpo() + "' "
				+ "      AND TO_CHAR(DD_TENUKT, 'YYYYMMDD') BETWEEN '" + prmData.getDdHannyuFrom().replace("/", "")
															+ "' AND '" + prmData.getDdHannyuTo().replace("/", "") + "' "
				+ "    GROUP BY "
				+ "      CD_KAISYA "
				+ "      , CD_HANBAITN "
				+ "      , DD_HANNYU "
				+ "      , NO_KANRI "
				+ "  ) SYARYO_HANSYUTU_UKETORI ";
			selectSql.append(innterSql);
		}
		// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため end
		String selectT220001gWhere
			= "WHERE ";
		// 2019.03.27 T.Osada 修正 会社融合対応 strat
			if (prmData.getCdHanbaitn().equals(UcarConst.TOYOTA) || 
					 prmData.getCdHanbaitn().equals(UcarConst.TOYOPET) ||  
					 prmData.getCdHanbaitn().equals(UcarConst.COROLLA) || 
/*2019.4.26 from					 
					 prmData.getCdHanbaitn().equals(UcarConst.NETZ)){
*/
					 prmData.getCdHanbaitn().equals(UcarConst.NETZ) ||
					 prmData.getCdHanbaitn().equals(UcarConst.LEXUS)){
//0219.4.26 to
				
				selectT220001gWhere
				+= "      SYARYO_HANNYU1.CD_SIRTENPO = V201M.CD_TENPO(+) "
				+ "  AND SYARYO_HANNYU1.CD_SIRTENPO = U006M.CD_TENPO(+) ";
			} else {
				selectT220001gWhere
				/* 2019.04.28 T.Osada Start
				+= "      SYARYO_HANNYU1.CD_KAISYA   = V201M.CD_KAISYA(+) "
				*/
				+= "      SYARYO_HANNYU1.CD_SIRTENPO = V201M.CD_TENPO(+) "
				+ "  AND SYARYO_HANNYU1.CD_KAISYA   = U006M.CD_KAISYA(+) "
				+ "  AND SYARYO_HANNYU1.CD_SIRTENPO = U006M.CD_TENPO(+) ";
			}
			selectT220001gWhere
			+= "  AND SYARYO_HANNYU1.CD_NORIKUSI = V213M.CD_RIKUSI(+) "
			+ "  AND SYARYO_HANNYU1.CD_KAISYA   = U003GCHK.CD_KAISYA "
			+ "  AND SYARYO_HANNYU1.CD_HANBAITN = U003GCHK.CD_HANBAITN "
			+ "  AND SYARYO_HANNYU1.DD_HANNYU   = U003GCHK.DD_HANNYU "
			+ "  AND SYARYO_HANNYU1.NO_KANRI    = U003GCHK.NO_KANRI ";
		if ("".equals(prmData.getKbScenter())) {
			// 業販・U-Car店舗の場合
			selectT220001gWhere
				+= "  AND SYARYO_HANNYU1.CD_HANTENPO = U003GCHK.CD_HANTENPO "
				+ "  AND SYARYO_HANNYU1.CD_HANTENPO = U002GCHK.CD_HANTENPO ";
		}

		selectT220001gWhere
			+= "  AND SYARYO_HANNYU1.CD_KAISYA   = U002GCHK.CD_KAISYA "
			+ "  AND SYARYO_HANNYU1.CD_HANBAITN = U002GCHK.CD_HANBAITN "
			+ "  AND SYARYO_HANNYU1.DD_HANNYU   = U002GCHK.DD_HANNYU "
			+ "  AND SYARYO_HANNYU1.NO_KANRI    = U002GCHK.NO_KANRI "
			// 2011.10.19 H.Yamsahita add start
			+ "  AND SYARYO_HANNYU1.CD_KAISYA   = SYORUI_CHECK.CD_KAISYA(+) "
			+ "  AND SYARYO_HANNYU1.CD_HANBAITN = SYORUI_CHECK.CD_HANBAITN(+) "
			+ "  AND SYARYO_HANNYU1.DD_HANNYU   = SYORUI_CHECK.DD_HANNYU(+) "
			+ "  AND SYARYO_HANNYU1.NO_KANRI    = SYORUI_CHECK.NO_KANRI(+) ";
			// 2011.10.19 H.Yamsahita add end

		if ("".equals(prmData.getKbScenter())) {
			// 業販・U-Car店舗の場合
			selectT220001gWhere
				+= " 	AND SYARYO_HANNYU1.CD_HANTENPO = SYORUI_CHECK.CD_ZAITENPO(+) ";
		}

		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため start
		// 2019.03.27 T.Osada 修正 会社融合対応 start 
		if (prmData.getCdHanbaitn().equals(UcarConst.TOYOTA) || 
				 prmData.getCdHanbaitn().equals(UcarConst.TOYOPET) ||  
				 prmData.getCdHanbaitn().equals(UcarConst.COROLLA) ||
/*2019.4.26 from				 
				 prmData.getCdHanbaitn().equals(UcarConst.NETZ)){
*/
				 prmData.getCdHanbaitn().equals(UcarConst.NETZ) ||
				 prmData.getCdHanbaitn().equals(UcarConst.LEXUS)){
//2019.4.26 to
				selectT220001gWhere
				+= "  AND SYARYO_HANNYU1.CD_HANTENPO = '" + prmData.getCdTenpo() + "' ";
		} else {
				selectT220001gWhere
				+= "  AND SYARYO_HANNYU1.CD_KAISYA = '" + prmData.getCdKaisya() + "' "
				+ "  AND SYARYO_HANNYU1.CD_HANBAITN = '" + prmData.getCdHanbaitn() + "' "
				+ "  AND SYARYO_HANNYU1.CD_HANTENPO = '" + prmData.getCdTenpo() + "' ";				
		}
		// 2019.03.27 T.Osada 修正 会社融合対応 end 

			/*  2011.10.20 H.Yamashita 書類チェックモード追加に伴う対応
			+ "  AND SYARYO_HANNYU1.DD_HANNYU BETWEEN ? AND ? ";
			*/
		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため end

		selectSql.append(selectT220001gWhere);

		// 仕入れマスタ結合条件
		selectSql.append(where004m.toString());
		return selectSql;
	}

	/**
	 * SQL 条件部分作成
	 * @param prmData
	 * @param ddTenuktFlg 店舗受取日検索実行フラグ(true:店舗受取日で検索を実行する／false:実行しない)
	 * @return
	 */
	public static StringBuilder createConditionSql(ListParamBean prmData,
													Boolean ddTenuktFlg) {

		StringBuilder sqlCondition = new StringBuilder();

		if(!prmData.getCdSirtenpo().equals("")){
			sqlCondition.append(" AND CD_SIRTENPO = '" + prmData.getCdSirtenpo() + "'");
		}
		if(!prmData.getCdNorikusi().equals("")){
			sqlCondition.append(" AND CD_NORIKUSI = '" + prmData.getCdNorikusi() + "'");
		}
		if(!prmData.getKbNosyasyu().equals("")){
			sqlCondition.append(" AND KB_NOSYASYU = '" + prmData.getKbNosyasyu() + "'");
		}
		if(!prmData.getCdNogyotai().equals("")){
			sqlCondition.append(" AND CD_NOGYOTAI = '" + prmData.getCdNogyotai() + "'");
		}
		if(!prmData.getNoNoseiri().equals("")){
			sqlCondition.append(" AND NO_NOSEIRI = '" + prmData.getNoNoseiri() + "'");
		}

		// 2011.10.20 H.Yamashita 部分一致に変更
		if(!prmData.getMjSitkata().equals("")){
			sqlCondition.append(" AND MJ_SITKATA LIKE '%" + prmData.getMjSitkata() + "%'");
		}

		// 2011.10.20 H.Yamashita 部分一致に変更
		if(!prmData.getMjSyamei().equals("")){
			sqlCondition.append(" AND MJ_SYAMEI LIKE '%" + prmData.getMjSyamei() + "%'");
		}

		if(!prmData.getNoSyaryou().equals("")){
			sqlCondition.append(" AND RTRIM(NO_SYARYOU) = '" + prmData.getNoSyaryou() + "'");
		}
		if (prmData.getArrayKbCheck() != null) {
			// 画面のKB_CHECKの存在チェック
			for (int i = 0; i < prmData.getArrayKbCheck().length; i++) {
				String kbCheck = prmData.getArrayKbCheck()[i];
				if(!(kbCheck == null)){
					// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
					sqlCondition.append(" AND NOT EXISTS " +
											"(SELECT 'X' FROM " + UcarTableManager.getCheckNaiyo(prmData.getKbScenter()) + " CHECK_NAIYO2 " +
											" WHERE SYARYO_HANNYU1.CD_KAISYA   = CHECK_NAIYO2.CD_KAISYA " +
											" AND   SYARYO_HANNYU1.CD_HANBAITN = CHECK_NAIYO2.CD_HANBAITN " +
											" AND   SYARYO_HANNYU1.DD_HANNYU   = CHECK_NAIYO2.DD_HANNYU " +
											" AND   SYARYO_HANNYU1.NO_KANRI    = CHECK_NAIYO2.NO_KANRI "  +
											" AND   CHECK_NAIYO2.KB_CHECK      = '" + kbCheck + "' ");

					if ("".equals(prmData.getKbScenter())) {
						// 業販・U-Car店舗の場合
						// 結合キーを追加する
						sqlCondition.append(" AND SYARYO_HANNYU1.CD_HANTENPO = CHECK_NAIYO2.CD_ZAITENPO ");
					}
					sqlCondition.append(" ) ");
					// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
				}
			}
		}
		if(prmData.getArrayKbCheckPrint() != null){
			sqlCondition.append(" AND DT_ZAIKO IS NULL ");
		}

		// 状態チェック	2011.10.20 H.Yamashita add
		if (prmData.getArrayCheckSrk() != null) {
			// 画面のcheck_srkの存在チェック
			for (int i = 0; i < prmData.getArrayCheckSrk().length; i++) {
				String checkSrk = prmData.getArrayCheckSrk()[i];

				// 書類確認未完了にチェック→書類完備日未入力を検索
				if(checkSrk.equals("01")){
					sqlCondition.append(" AND   SYORUI_CHECK.DD_SRKNB is null ");
				}

				// 保留にチェック→書類完備保留日入力を検索
				if(checkSrk.equals("02")){
					sqlCondition.append(" AND   SYORUI_CHECK.DD_SRKHR is not null ");
				}
			}
		}

		// フレームNo(部分一致)	2011.10.20 H.Yamashita add
		if(!prmData.getNoSyadai().equals("")){
			sqlCondition.append(" AND NO_SYADAI LIKE '%" + prmData.getNoSyadai() + "%'");
		}

		// 書類完備日 2011.10.20 H.Yamashita add
		if(!prmData.getDdSrknbFrom().equals("") && !prmData.getDdSrknbTo().equals("")){
			sqlCondition.append(" AND SYORUI_CHECK.DD_SRKNB BETWEEN '" +prmData.getDdSrknbFrom().replace("/", "")
										+ "' AND '" + prmData.getDdSrknbTo().replace("/", "") + "'") ;
		}

		// 保留日 2011.10.20 H.Yamashita add
		if(!prmData.getDdSrkhrFrom().equals("") && !prmData.getDdSrkhrTo().equals("")){
			sqlCondition.append(" AND SYORUI_CHECK.DD_SRKHR BETWEEN '" +prmData.getDdSrkhrFrom().replace("/", "")
										+ "' AND '" + prmData.getDdSrkhrTo().replace("/", "") + "'") ;
		}

		// 仕入種別チェック 2011.10.20 H.Yamashita add
		if (prmData.getArrayKbSiire() != null) {
			// 画面のKB_SIIREの存在チェック
			for (int i = 0; i < prmData.getArrayKbSiire().length; i++) {
				String kbSiire = prmData.getArrayKbSiire()[i];
				if(!(kbSiire == null)){
					// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
					sqlCondition.append(" AND EXISTS " +
//											"(SELECT 'X' FROM " + UcarTableManager.getSiireSyubetu(prmData.getKbScenter()) + " SIIRE_SYUBETU2 " +
											"(SELECT 'X' FROM T220903V SIIRE_SYUBETU2 " +
											" WHERE SYARYO_HANNYU1.CD_KAISYA   = SIIRE_SYUBETU2.CD_KAISYA " +
											" AND   SYARYO_HANNYU1.CD_HANBAITN = SIIRE_SYUBETU2.CD_HANBAITN " +
											" AND   SYARYO_HANNYU1.DD_HANNYU   = SIIRE_SYUBETU2.DD_HANNYU " +
											" AND   SYARYO_HANNYU1.NO_KANRI    = SIIRE_SYUBETU2.NO_KANRI "  +
											" AND   SIIRE_SYUBETU2.KB_SIIRE    = '" + kbSiire + "') ");
					// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
				}
			}
		}

		// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため start
		if (ddTenuktFlg) {
			// 受取日から該当のデータを取得する場合
			sqlCondition.append("  AND SYARYO_HANNYU1.CD_KAISYA = SYARYO_HANSYUTU_UKETORI.CD_KAISYA ");
			sqlCondition.append("  AND SYARYO_HANNYU1.CD_HANBAITN = SYARYO_HANSYUTU_UKETORI.CD_HANBAITN ");
			sqlCondition.append("  AND SYARYO_HANNYU1.DD_HANNYU = SYARYO_HANSYUTU_UKETORI.DD_HANNYU ");
			sqlCondition.append("  AND SYARYO_HANNYU1.NO_KANRI = SYARYO_HANSYUTU_UKETORI.NO_KANRI ");
		} else {
			// 搬入日 2011.10.20 H.Yamashita 書類チェックモード追加に伴う対応
			if(!prmData.getDdHannyuFrom().equals("") && !prmData.getDdHannyuTo().equals("")){
				sqlCondition.append(" AND SYARYO_HANNYU1.DD_HANNYU BETWEEN '" + prmData.getDdHannyuFrom().replace("/", "")
						+ "' AND '" + prmData.getDdHannyuTo().replace("/", "") + "'") ;
			}
		}
		// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため end

		return sqlCondition;
	}

}
