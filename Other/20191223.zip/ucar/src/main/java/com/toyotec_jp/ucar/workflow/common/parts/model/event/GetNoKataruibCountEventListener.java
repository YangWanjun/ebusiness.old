package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaTransactionDAOIF;

/**
 * <strong>型式指定類別NO件数取得操作用イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/07/05 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetNoKataruibCountEventListener extends UcarEventListener {

	private static final char PAD_CHAR_HALFSPACE	= ' ';
	/** 型式指定類別NO桁数 */
	private static final int	MAXLENGTH_NO_KATARUIB = 9;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetNoKataruibCountEvent targetEvent = (GetNoKataruibCountEvent)event;

		UcaaTransactionDAOIF dao
			= getDAO(UcarDAOKey.UCAA_TRANSACTION_DAO, targetEvent, UcaaTransactionDAOIF.class);

		// 型式指定類別NO件数
		int countNoKataruib = 0;
		// 型式指定類別NOの桁数調整
		String noKataruib = StringUtils.padRight(targetEvent.getNoKataruib(), PAD_CHAR_HALFSPACE, MAXLENGTH_NO_KATARUIB);

		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
		if (targetEvent.isEditMode()) {
			// 詳細確認・修正モードの場合
			countNoKataruib = dao.selectNoKataruibEditCount(targetEvent.getT220001gPkBean().getCdKaisya(),
															targetEvent.getT220001gPkBean().getCdHanbaitn(),
															targetEvent.getT220001gPkBean().getDdHannyu(),
															targetEvent.getT220001gPkBean().getNoKanri(),
															noKataruib);
		} else {
			// バーコード取り込みモード、新規登録モードの場合
			countNoKataruib = dao.selectNoKataruibCount(targetEvent.getT220001gPkBean().getCdKaisya(),
														targetEvent.getT220001gPkBean().getCdHanbaitn(),
														noKataruib);
		}
		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

		GetNoKataruibCountEventResult getResult = new GetNoKataruibCountEventResult();
		getResult.setCountNoKataruib(countNoKataruib);

		return getResult;
	}
}
