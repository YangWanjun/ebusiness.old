package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.UpdateZoneDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb005gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;

/**
 * <strong>入庫検査登録イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/18 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class RegisterEnterCheckDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		TecLogger.trace("insert/update registerData start");

		RegisterEnterCheckDataEvent targetEvent = (RegisterEnterCheckDataEvent) event;

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarCheckConst.APPID_CARCHECK_ENTERCHECK;

		ArrayList<String> selectDataList = new ArrayList<String>(Arrays.asList(targetEvent.getSelectData()));

		// DAOIF取得
		CarCheckDAOIF dao = getDAO(CarCheckDAOKey.CAR_CHECK_DAO, targetEvent, CarCheckDAOIF.class);

		int resultCount = 0;
		for (String selectData : selectDataList) {

			String[] arraySelectData = selectData.split(",");

			// 入庫チェックDB：会社コード・販売店コード・搬入日・管理番号
			// 				   在庫店舗コード	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			// 				   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
//			T220008gBean t220008gBean = new T220008gBean(targetEvent.getCdKaisya(),
//			Uccb005gBean t220008gBean = new Uccb005gBean(targetEvent.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
//														targetEvent.getCdHanbaitn(),
			//2019.03.31 T.Osada start
			Uccb005gBean t220008gBean = new Uccb005gBean(arraySelectData[0],
			                                            arraySelectData[1],
														arraySelectData[2],
														arraySelectData[3],
														//2019.03.31 T.Osada end
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
														targetEvent.getUserInfoBean().getCdTenpo(),	
														targetEvent.getUserInfoBean().getKbScenter(),
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
														updateUserId,
														updateUserId,
														updateAppId,
														updateAppId);

			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
			// ステータスDB：会社コード・販売店コード・搬入日・管理番号
			//			   在庫店舗コード・商品化センター区分	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			//			   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start	
//			T220012gInputDataBean t220012gInputDataBean = new T220012gInputDataBean(targetEvent.getCdKaisya(),
//			Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(targetEvent.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
//																					targetEvent.getCdHanbaitn(),
																					//2019.03.31 T.Osada start
			Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(arraySelectData[0],
																					arraySelectData[1],
																					arraySelectData[2],
																					arraySelectData[3],
																					//2019.03.31 T.Osada start
																					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																					targetEvent.getUserInfoBean().getCdTenpo(),	
																					targetEvent.getUserInfoBean().getKbScenter(),
																					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																					updateUserId,
																					updateUserId,
																					updateAppId,
																					updateAppId);

//			T220001gPKBean t220001gPKBean = new T220001gPKBean(targetEvent.getCdKaisya(),
//			Uccb007gPKBean t220001gPKBean = new Uccb007gPKBean(targetEvent.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
//																targetEvent.getCdHanbaitn(),
																//2019.03.31 T.Osada start
			Uccb007gPKBean t220001gPKBean = new Uccb007gPKBean(arraySelectData[0],
																arraySelectData[1],
																arraySelectData[2],
																arraySelectData[3],
																//2019.03.31 T.Osada end
																// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																targetEvent.getUserInfoBean().getCdTenpo(),	
																targetEvent.getUserInfoBean().getKbScenter());
																// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			String ddSetDate = UcarUtils.getStringDateFormatShortSimple(targetEvent.getDdSetDate());

			if (UcarConst.RDO_KUBUN_COMPLETE.equals(targetEvent.getRdoKubun())) {
				// 完了
				// 入庫チェックDB：入庫検査日
				t220008gBean.setDdNkkns(ddSetDate);
				// ステータスDB：ステータス05
				CheckStatusDateEventResult csdeResult = checkStatusDate(targetEvent, t220001gPKBean, 5, ddSetDate);
				t220012gInputDataBean.setStrDtStatus05(csdeResult.getDtStatus());
			} else {
				// 保留
				// 入庫チェックDB：入庫検査保留日
				t220008gBean.setDdNkkhr(ddSetDate);
				// ステータスDB:ステータス06
				CheckStatusDateEventResult csdeResult = checkStatusDate(targetEvent, t220001gPKBean, 6, ddSetDate);
				t220012gInputDataBean.setStrDtStatus06(csdeResult.getDtStatus());
			}
			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

			// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
			// 入庫検査担当者コードを設定
			t220008gBean.setCdNkktan(targetEvent.getCdNkktan());
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため end

			int countSelect = dao.selectT220008GCount(t220008gBean);
			if (countSelect > 0) {
				String nyukoDtKosin = getNyukoDtKosin(targetEvent, arraySelectData);
				// 更新処理
				updateT220008gData(dao, t220008gBean, nyukoDtKosin, executeDate);
			} else {
				// 新規登録処理
				insertT220008gData(dao, t220008gBean, executeDate);
			}
			resultCount++;

			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
			// ステータス更新処理
			SimpleExecuteResultBean updateStatusResult = dao.updateT220012GEnterCheck(t220012gInputDataBean, executeDate);
			if (updateStatusResult.getExecuteCount() == 0) {
				// 更新件数が0件の場合はInsert処理

				// Insertの場合はステータス01をセット
				String strDtStatus01 = UcarUtils.getStringDateFormatShort(arraySelectData[0]);
				t220012gInputDataBean.setStrDtStatus01(strDtStatus01);

				dao.insertT220012G(t220012gInputDataBean, executeDate);
			}
			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

			// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
			UpdateZoneDateEvent updateZoneDateEvent
				= createEvent(UcarEventKey.UPDATE_ZONE_DATE, targetEvent.getUserInfo(), UpdateZoneDateEvent.class);

//			updateZoneDateEvent.setT220001gPkBean(t220001gPKBean);
			updateZoneDateEvent.setT220107gPkBean(t220001gPKBean);					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
//			updateZoneDateEvent.setT220012gInputDataBean(t220012gInputDataBean);
			updateZoneDateEvent.setUccb007gInputDataBean(t220012gInputDataBean);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			updateZoneDateEvent.setExecuteDtStatus03(false);
			updateZoneDateEvent.setExecuteDtStatus05(true);
			updateZoneDateEvent.setExecuteDtStatus07(false);

			updateZoneDateEvent.setExecuteDate(executeDate);

			// イベント実行
			dispatchEvent(updateZoneDateEvent);
			// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため end

		}

		RegisterEnterCheckDataEventResult eventResult = new RegisterEnterCheckDataEventResult();
		// 処理件数を返す
		eventResult.setCountExecute(resultCount);

		TecLogger.trace("insert/update registerData end");
		return eventResult;
	}

	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため start
	/**
	 * ステータスDB日付比較チェック
	 * @param targetEvent
	 * @param t220001gPkBean
	 * @param checkStatusNo
	 * @param dtStatus
	 * @return
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	public CheckStatusDateEventResult checkStatusDate(RegisterEnterCheckDataEvent targetEvent,
//														T220001gPKBean t220001gPkBean,
														Uccb007gPKBean t220107gPKBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
														int checkStatusNo,
														String dtStatus) throws SystemException, ApplicationException {

		CheckStatusDateEvent checkStatusDateEvent
			= createEvent(UcarEventKey.CHECK_STATUS_DATE, targetEvent.getUserInfo(), CheckStatusDateEvent.class);

//		checkStatusDateEvent.setT220001gPkBean(t220001gPkBean);
		checkStatusDateEvent.setT220107gPkBean(t220107gPKBean);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		checkStatusDateEvent.setCheckStatusNo(checkStatusNo);
		checkStatusDateEvent.setDtStatus(dtStatus);

		return (CheckStatusDateEventResult)dispatchEvent(checkStatusDateEvent);
	}
	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため end

	/**
	 * 入庫チェックDB データ更新日時取得
	 * <pre>
	 * 取得したデータ更新日時を使用して、排他制御を実行する
	 * </pre>
	 * @param targetEvent
	 * @param carCheckDataList
	 * @param arraySelectData
	 * @return
	 */
	private String getNyukoDtKosin(RegisterEnterCheckDataEvent targetEvent, String[] arraySelectData) {

		String nyukoDtKosin = null;

		for (CarCheckDataBean carCheckDataBean : targetEvent.getCarCheckDataList()) {
			// 画面表示リスト件数分

			// 2019.03.31 T.Osada Start
//			if (targetEvent.getCdKaisya().equals(carCheckDataBean.getCdKaisya())
//				&& targetEvent.getCdHanbaitn().equals(carCheckDataBean.getCdHanbaitn())
//				&& arraySelectData[0].equals(carCheckDataBean.getDdHannyu())
//				&& arraySelectData[1].equals(carCheckDataBean.getNoKanri())) {
			if (arraySelectData[0].equals(carCheckDataBean.getCdKaisya())
					&& arraySelectData[1].equals(carCheckDataBean.getCdHanbaitn())
					&& arraySelectData[2].equals(carCheckDataBean.getDdHannyu())
					&& arraySelectData[3].equals(carCheckDataBean.getNoKanri())) {
				// 更新対象のキーと一致した場合
				// 2019.03.31 T.Osada End

				if (carCheckDataBean.getNyukoDtKosin() != null) {
					// 入庫チェックDBのデータ更新日時がNullでなければ、更新日時を取得
					nyukoDtKosin = DateUtils.dateToString(carCheckDataBean.getNyukoDtKosin(), DateUtils.DB_FORMAT_LONG_M);
				}
				break;
			}
		}
		return nyukoDtKosin;
	}

	/**
	 * 入庫チェックDB 更新処理
	 * @param dao
	 * @param t220008gBean
	 * @param nyukoDtKosin
	 * @param executeDate
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void updateT220008gData(CarCheckDAOIF dao,
//									T220008gBean t220008gBean,
									Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
									String nyukoDtKosin,
									Timestamp executeDate)
									throws TecExclusionException, TecMessageException, TecDAOException {

		SimpleExecuteResultBean updateResult = dao.updateT220008G(t220008gBean,
																	nyukoDtKosin,
																	executeDate);

		if (updateResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
		}
	}

	/**
	 * 入庫チェックDB 新規登録処理
	 * @param dao
	 * @param t220008gBean
	 * @param executeDate
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void insertT220008gData(CarCheckDAOIF dao,
//									T220008gBean t220008gBean,
									Uccb005gBean t220008gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
									Timestamp executeDate)
									throws TecExclusionException, TecMessageException, TecDAOException {

		try {
			dao.insertT220008G(t220008gBean, executeDate);
		} catch (TecDAOException e) {
			if (e.getMessage().indexOf("ORA-00001") != -1) {
				// 一意キー制約の場合は排他制御としてエラーをthrow
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
			} else {
				throw e;
			}
		}
	}

}