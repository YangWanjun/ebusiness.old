package com.toyotec_jp.ucar.batch.daily.datacreate.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.batch.common.BatchConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb004gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb010gBean;

/**
 * <strong>整備売上日報情報作成DAOの実装</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/10/12 新規作成<br>
 * @since 1.00
 * @category [[バッチ：整備売上日報情報作成]]
 */
public class CreateSeibiUriageNippouDAOImpl extends UcarSharedDBDAO implements CreateSeibiUriageNippouDAOIF {

	/** 処理日付情報 */
	private static final String SELECT_T220218G_SQL
		= "SELECT "
		+ "    DD_DATE1 "
		+ "FROM "
		+ "  T220218G "
		+ "WHERE "
		+ "  KB_BATCH = ? "
		+ "ORDER BY "
		+ "  KB_BATCH ";

	/** 新規登録処理（整備売上日報情報）SQL */
	private static final String DELETE_T220217G_SQL
		= "DELETE "
		+ "FROM "
		+ "  T220217G "
		+ "WHERE "
		+ "  DD_SYUKEI   = ? ";

	/** コード区分マスタ SQL */
	private static final String SELECT_T220204M_SQL
		= "SELECT "
		+ "   CD_KUBUN "
		+ "FROM "
		+ "  T220204M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND KB_ID       = ? "
		+ "ORDER BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , KB_ID "
		+ "  , CD_KUBUN ";

	/** 受付車両情報 SQL */
	private static final String SELECT_T220201G_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , CD_HANBAITN "
		+ "FROM "
		+ "  T220201G "
		+ "GROUP BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , CD_HANBAITN "
		+ "ORDER BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , CD_HANBAITN ";

	/** 整備売上日報情報 SQL */
	private static final String INSERT_T220217G_SQL
		= "INSERT "
		+ "INTO T220217G( "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , DD_SYUKEI "
		+ "  , CD_HANBAITN "
		+ "  , KB_SAGYO "
		+ "  , SU_SAGYOUKE "
		+ "  , SU_SAGYOSIKA "
		+ "  , SU_SAGYOKAN "
		+ "  , SU_HEADLIGHT "
		+ "  , SU_BPKANI "
		+ "  , SU_TENAOSI "
		+ "  , SU_JUCYU "
		+ "  , KI_GAISIIRE "
		+ "  , KI_GAISIKA "
		+ "  , SU_SIKAKARI "
		+ "  , SU_URIAGE "
		+ "  , KI_URIAGE "
		+ "  , SU_URIHEAD "
		+ "  , SU_URIBPKN "
		+ "  , MJ_BIKOU "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ ") "
		+ "VALUES ( "
		+ "  ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ "  , ? "
		+ ") ";

	/** 整備売上日報情報 SQL */
	private static final String UPDATE_T220217G_SQL
		= "UPDATE T220217G "
		+ "SET "
		+ "  SU_SAGYOUKE = ? "
		+ "  , SU_SAGYOSIKA = ? "
		+ "  , SU_SAGYOKAN = ? "
		+ "  , SU_HEADLIGHT = ? "
		+ "  , SU_BPKANI = ? "
		+ "  , SU_TENAOSI = ? "
		+ "  , SU_JUCYU = ? "
		+ "  , KI_GAISIIRE = ? "
		+ "  , KI_GAISIKA = ? "
		+ "  , SU_SIKAKARI = ? "
		+ "  , SU_URIAGE = ? "
		+ "  , KI_URIAGE = ? "
		+ "  , SU_URIHEAD = ? "
		+ "  , SU_URIBPKN = ? "
		+ "WHERE "
		+ "      CD_KAISYA = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND DD_SYUKEI = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_SAGYO = ? ";

	private static final String SELECT_T220208G_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , CD_HANBAITN "
		+ "  , DD_HANNYU "
		+ "  , NO_KANRI "
		+ "  , KB_SAGYO "
		+ "FROM "
		+ "  T220208G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_SAGYO    = ? ";

	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
	private static final String LEFT_JOIN_T220212G_SQL
		= "  LEFT JOIN T220212G JYUTYU_MEISAI "
		+ "    ON JYUTYU.CD_KAISYA = JYUTYU_MEISAI.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = JYUTYU_MEISAI.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU = JYUTYU_MEISAI.NO_JUCYU ";	
	
	private static final String SELECT_T220208G_MARUKURI_WHERE_SQL
		= "WHERE "
		+ "      SAGYO.CD_KAISYA   = ? "
		+ "  AND SAGYO.CD_JIGYOSYO = ? "
		+ "  AND SAGYO.CD_HANBAITN = ? "
		+ "  AND SAGYO.KB_SAGYO    = '01' ";
	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end

	private static final String SELECT_T220208G_ORDER_SQL
		= "ORDER BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , CD_HANBAITN "
		+ "  , DD_HANNYU "
		+ "  , NO_KANRI "
		+ "  , KB_SAGYO ";

	private static final String SELECT_T220208G_SAGYO_SQL
		= "SELECT "
		+ "    SAGYO.CD_KAISYA "
		+ "  , SAGYO.CD_JIGYOSYO "
		+ "  , SAGYO.CD_HANBAITN "
		+ "  , SAGYO.DD_HANNYU "
		+ "  , SAGYO.NO_KANRI "
		+ "  , SAGYO.KB_SAGYO "
		+ "FROM "
		+ "  T220208G SAGYO "
		+ "  LEFT JOIN T220211G JYUTYU "
		+ "    ON SAGYO.CD_KAISYA    = JYUTYU.CD_KAISYA "
		+ "    AND SAGYO.CD_JIGYOSYO = JYUTYU.CD_JIGYOSYO "
		+ "    AND SAGYO.CD_HANBAITN = JYUTYU.CD_HANBAITN "
		+ "    AND SAGYO.DD_HANNYU   = JYUTYU.DD_HANNYU "
		+ "    AND SAGYO.NO_KANRI    = JYUTYU.NO_KANRI "
		+ "    AND SAGYO.KB_SAGYO    = JYUTYU.KB_SAGYO ";

	private static final String SELECT_T220208G_SAGYO_WHERE_SQL
		= "WHERE "
		+ "      SAGYO.CD_KAISYA   = ? "
		+ "  AND SAGYO.CD_JIGYOSYO = ? "
		+ "  AND SAGYO.CD_HANBAITN = ? "
		+ "  AND SAGYO.KB_SAGYO    = ? "
		+ "  AND TO_CHAR(SAGYO.DT_END, 'YYYYMMDD') = ? ";

	private static final String SELECT_T220211G_SQL
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU "
		+ "FROM "
		+ "  T220211G "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_SAGYO    = ? ";

	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
	private static final String SELECT_T220211G_MARUKURI_SQL
		= "SELECT "
		+ "    JYUTYU.CD_KAISYA "
		+ "  , JYUTYU.CD_JIGYOSYO "
		+ "  , JYUTYU.NO_JUCYU "
		+ "FROM "
		+ "  T220211G JYUTYU "
		+ "  LEFT  JOIN T220212G JYUTYU_MEISAI "
		+ "    ON  JYUTYU.CD_KAISYA   = JYUTYU_MEISAI.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = JYUTYU_MEISAI.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = JYUTYU_MEISAI.NO_JUCYU ";
		
	private static final String SELECT_T220211G_MARUKURI_WHERE_SQL
		= "WHERE "
		+ "      JYUTYU.CD_KAISYA   = ? "
		+ "  AND JYUTYU.CD_JIGYOSYO = ? "
		+ "  AND JYUTYU.CD_HANBAITN = ? "
		+ "  AND JYUTYU.KB_SAGYO    = '01' "
		+ "  AND JYUTYU_MEISAI.NO_BUHIN = '00' ";
	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end

	private static final String SELECT_T220211G_ORDER_SQL
		= "ORDER BY "
		+ "  CD_KAISYA "
		+ "  , CD_JIGYOSYO "
		+ "  , NO_JUCYU ";

	private static final String SELECT_GAITYU_SQL
		= "SELECT "
		+ "  SUM(GAITYU_SIIRE.KI_SIIRE) KI_SIIRE "
		+ "  , SUM(GAITYU_SIIRE.KI_TAX) KI_TAX "
		+ "FROM "
		+ "  T220211G JYUTYU "
		+ "  INNER JOIN T220213G GAITYU_SIIRE "
		+ "    ON  JYUTYU.CD_KAISYA   = GAITYU_SIIRE.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = GAITYU_SIIRE.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = GAITYU_SIIRE.NO_JUCYU "
		+ "WHERE "
		+ "      JYUTYU.CD_KAISYA      = ? "
		+ "  AND JYUTYU.CD_JIGYOSYO    = ? "
		+ "  AND JYUTYU.CD_HANBAITN    = ? "
		+ "  AND JYUTYU.KB_SAGYO       = ? "
		+ "  AND GAITYU_SIIRE.KB_JISYA = ? ";
	
	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
	private static final String SELECT_GAITYU_MARUKURI_SQL
		= "SELECT "
		+ "  SUM(GAITYU_SIIRE.KI_SIIRE) KI_SIIRE "
		+ "  , SUM(GAITYU_SIIRE.KI_TAX) KI_TAX "
		+ "FROM "
		+ "  T220211G JYUTYU "
		+ "  INNER JOIN T220213G GAITYU_SIIRE "
		+ "    ON  JYUTYU.CD_KAISYA   = GAITYU_SIIRE.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = GAITYU_SIIRE.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = GAITYU_SIIRE.NO_JUCYU "
		+ "  LEFT  JOIN T220212G JYUTYU_MEISAI "
		+ "    ON  JYUTYU.CD_KAISYA   = JYUTYU_MEISAI.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = JYUTYU_MEISAI.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = JYUTYU_MEISAI.NO_JUCYU "
		+ "WHERE "
		+ "      JYUTYU.CD_KAISYA       = ? "
		+ "  AND JYUTYU.CD_JIGYOSYO     = ? "
		+ "  AND JYUTYU.CD_HANBAITN     = ? "
		+ "  AND JYUTYU.KB_SAGYO        = '01' "
		+ "  AND GAITYU_SIIRE.KB_JISYA  = ? "
		+ "  AND JYUTYU_MEISAI.NO_BUHIN = '00' ";
	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end

	private static final String SELECT_URIAGE_SQL
		= "SELECT "
		+ "    URIAGE_SEISAN.CD_KAISYA "
		+ "  , URIAGE_SEISAN.CD_JIGYOSYO "
		+ "  , URIAGE_SEISAN.NO_JUCYU ";

	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
	private static final String SELECT_URIAGE_MARUKURI_FROM_SQL
		= "FROM "
		+ "  T220211G JYUTYU "
		+ "  INNER JOIN T220214G URIAGE_SEISAN "
		+ "    ON  JYUTYU.CD_KAISYA   = URIAGE_SEISAN.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = URIAGE_SEISAN.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = URIAGE_SEISAN.NO_JUCYU "
		+ "  LEFT  JOIN T220212G JYUTYU_MEISAI "
		+ "    ON  JYUTYU.CD_KAISYA   = JYUTYU_MEISAI.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = JYUTYU_MEISAI.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = JYUTYU_MEISAI.NO_JUCYU "
		+ "WHERE "
		+ "      JYUTYU.CD_KAISYA   = ? "
		+ "  AND JYUTYU.CD_JIGYOSYO = ? "
		+ "  AND JYUTYU.CD_HANBAITN = ? "
		+ "  AND JYUTYU.KB_SAGYO    = '01' "
		+ "  AND TO_CHAR(URIAGE_SEISAN.DD_URIAGE, 'YYYYMMDD') = ? "
		+ "  AND JYUTYU_MEISAI.NO_BUHIN = '00' ";	
	// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end

	private static final String SELECT_URIAGE_SUM_SQL
		= "SELECT "
		+ "    SUM(URIAGE_SEISAN.KI_SEIKYU) KI_SEIKYU "
		+ "  , SUM(URIAGE_SEISAN.KI_TAX) KI_TAX ";

	private static final String SELECT_URIAGE_FROM_SQL
		= "FROM "
		+ "  T220211G JYUTYU "
		+ "  INNER JOIN T220214G URIAGE_SEISAN "
		+ "    ON  JYUTYU.CD_KAISYA   = URIAGE_SEISAN.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = URIAGE_SEISAN.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = URIAGE_SEISAN.NO_JUCYU "
		+ "WHERE "
		+ "      JYUTYU.CD_KAISYA   = ? "
		+ "  AND JYUTYU.CD_JIGYOSYO = ? "
		+ "  AND JYUTYU.CD_HANBAITN = ? "
		+ "  AND JYUTYU.KB_SAGYO    = ? "
		+ "  AND TO_CHAR(URIAGE_SEISAN.DD_URIAGE, 'YYYYMMDD') = ? ";

	private static final String SELECT_URIAGE_SAGYO_SQL
		= "SELECT "
		+ "    URIAGE_SEISAN.CD_KAISYA "
		+ "  , URIAGE_SEISAN.CD_JIGYOSYO "
		+ "  , URIAGE_SEISAN.NO_JUCYU "
		+ "FROM "
		+ "  T220211G JYUTYU "
		+ "  INNER JOIN T220214G URIAGE_SEISAN "
		+ "    ON  JYUTYU.CD_KAISYA   = URIAGE_SEISAN.CD_KAISYA "
		+ "    AND JYUTYU.CD_JIGYOSYO = URIAGE_SEISAN.CD_JIGYOSYO "
		+ "    AND JYUTYU.NO_JUCYU    = URIAGE_SEISAN.NO_JUCYU ";

	private static final String SELECT_URIAGE_SAGYO_FROM_SQL
		= "WHERE "
		+ "      JYUTYU.CD_KAISYA   = ? "
		+ "  AND JYUTYU.CD_JIGYOSYO = ? "
		+ "  AND JYUTYU.CD_HANBAITN = ? "
		+ "  AND JYUTYU.KB_SAGYO    = ? "
		+ "  AND TO_CHAR(URIAGE_SEISAN.DD_URIAGE, 'YYYYMMDD') = ? ";

	private static final String SELECT_URIAGE_ORDER_SQL
		= "ORDER BY "
		+ "  JYUTYU.CD_KAISYA "
		+ "  , JYUTYU.CD_JIGYOSYO "
		+ "  , JYUTYU.NO_JUCYU ";

	private static final String UPDATE_T220218G_SQL
		= "UPDATE T220218G "
		+ "SET "
		+ "  DD_DATE1 = ? "
		+ "  , DD_DATE2 = ? "
		+ "  , DT_KOSIN = ? "
		+ "  , CD_KSNSYA = ? "
		+ "  , CD_KSNAPP = ? "
		+ "WHERE "
		+ "  KB_BATCH = ? ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectT220218G(java.lang.String)
	 */
	@Override
	public String selectT220218G(String kbBatch) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220218G_SQL);

		// パラメータセット<条件>
		paramBean.setString(kbBatch);	// バッチ区分

		ResultArrayList<Ucbb010gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb010gBean.class);

		String ddDate1 = null;
		if (resultList.size() > 0) {
			ddDate1 = resultList.get(0).getDdDate1();
		}

		return ddDate1;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF#deleteT220001G(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220217G(Ucbb009gBean t220217gBean) throws TecDAOException {

		StringBuilder targetSql = new StringBuilder(DELETE_T220217G_SQL);

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(targetSql.toString());

		// パラメータセット<条件>
		paramBean.setString(t220217gBean.getDdSyukei());	// 集計日

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);
		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectT220204M(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean)
	 */
	@Override
	public ResultArrayList<Ucba004mBean> selectT220204M(Ucba004mBean t220204mBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220204M_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220204mBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220204mBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220204mBean.getKbId());		// 区分ID

		ResultArrayList<Ucba004mBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucba004mBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectT220201G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba001gBean)
	 */
	@Override
	public ResultArrayList<Ucba001gBean> selectT220201G() throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220201G_SQL);

		ResultArrayList<Ucba001gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucba001gBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#insertT220217g(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean)
	 */
	@Override
	public SimpleExecuteResultBean insertT220217G(Ucbb009gBean t220217gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220217G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220217gBean.getDdSyukei());	// 集計日
		paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220217gBean.getKbSagyo());		// 作業区分

		paramBean.setInt(t220217gBean.getSuSagyouke()); 	// 作業受付台数
		paramBean.setInt(t220217gBean.getSuSagyosika()); 	// 作業仕掛台数
		paramBean.setInt(t220217gBean.getSuSagyokan()); 	// 作業完成台数
		paramBean.setInt(t220217gBean.getSuHeadlight()); 	// ヘッドライトクリーニング台数
		paramBean.setInt(t220217gBean.getSuBpkani()); 		// ＢＰ簡易台数
		paramBean.setInt(t220217gBean.getSuTenaosi()); 		// 手直し件数
		paramBean.setInt(t220217gBean.getSuJucyu()); 		// 受注件数
		paramBean.setInt(t220217gBean.getKiGaisiire()); 	// 外注仕入金額
		paramBean.setInt(t220217gBean.getKiGaisika()); 		// 外注仕掛金額
		paramBean.setInt(t220217gBean.getSuSikakari()); 	// 仕掛件数
		paramBean.setInt(t220217gBean.getSuUriage()); 		// 売上件数
		paramBean.setInt(t220217gBean.getKiUriage()); 		// 売上金額
		paramBean.setInt(t220217gBean.getSuUrihead()); 		// 売上ヘッドライトクリーニング台数
		paramBean.setInt(t220217gBean.getSuUribpkn()); 		// 売上BP簡易台数

		paramBean.setString(null); 							// 備考

		paramBean.setTimestamp(new Timestamp(t220217gBean.getDtSakusei().getTime()));	// データ作成日時
		paramBean.setTimestamp(new Timestamp(t220217gBean.getDtKosin().getTime()));		// データ更新日時

		paramBean.setString(t220217gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220217gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220217gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220217gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#updateT220217g(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean)
	 */
	@Override
	public SimpleExecuteResultBean updateT220217G(Ucbb009gBean t220217gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220217G_SQL);

		// パラメータセット<値>
		paramBean.setInt(t220217gBean.getSuSagyouke()); 	// 作業受付台数
		paramBean.setInt(t220217gBean.getSuSagyosika()); 	// 作業仕掛台数
		paramBean.setInt(t220217gBean.getSuSagyokan()); 	// 作業完成台数
		paramBean.setInt(t220217gBean.getSuHeadlight()); 	// ヘッドライトクリーニング台数
		paramBean.setInt(t220217gBean.getSuBpkani()); 		// ＢＰ簡易台数
		paramBean.setInt(t220217gBean.getSuTenaosi()); 		// 手直し件数
		paramBean.setInt(t220217gBean.getSuJucyu()); 		// 受注件数
		paramBean.setInt(t220217gBean.getKiGaisiire()); 	// 外注仕入金額
		paramBean.setInt(t220217gBean.getKiGaisika()); 		// 外注仕掛金額
		paramBean.setInt(t220217gBean.getSuSikakari()); 	// 仕掛件数
		paramBean.setInt(t220217gBean.getSuUriage()); 		// 売上件数
		paramBean.setInt(t220217gBean.getKiUriage()); 		// 売上金額
		paramBean.setInt(t220217gBean.getSuUrihead()); 		// 売上ヘッドライトクリーニング台数
		paramBean.setInt(t220217gBean.getSuUribpkn()); 		// 売上BP簡易台数

		// パラメータセット<条件>
		paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220217gBean.getDdSyukei());	// 集計日
		paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220217gBean.getKbSagyo());		// 作業区分

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectT220208GCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.T220208gBean)
	 */
	@Override
	public int selectT220208GCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg)
			throws TecDAOException {

		int count = 0;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
//		StringBuilder executeSql = new StringBuilder(SELECT_T220208G_SQL);
		StringBuilder executeSql;

		if (t220217gBean.getKbSagyo().equals("01") || t220217gBean.getKbSagyo().equals("10")) {	
			executeSql = new StringBuilder(SELECT_T220208G_SAGYO_SQL);
			
			executeSql.append(LEFT_JOIN_T220212G_SQL);		
			
			executeSql.append(SELECT_T220208G_MARUKURI_WHERE_SQL);			

			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			
			executeSql.append("  AND JYUTYU_MEISAI.NO_BUHIN = '00' ");
			if (t220217gBean.getKbSagyo().equals("01")) {
				// まるクリ
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO NOT LIKE 'FM05%' ");
			} else {				
				// ルームクリーニング
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO LIKE 'FM05%' ");				
			}

			if (BatchConst.DATA_FLG_SU_SAGYOUKE.equals(dataFlg)) {
				// 作業受付台数
				executeSql.append("  AND TO_CHAR(SAGYO.DT_SAKUSEI, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// データ作成日時
			} else if (BatchConst.DATA_FLG_SU_SAGYOSIKA.equals(dataFlg)) {
				// 作業仕掛台数
				executeSql.append("  AND (SAGYO.DT_END IS NULL OR TO_CHAR(SAGYO.DT_END, 'YYYYMMDD') > ?) ");
				paramBean.setString(ddSyukei);					// 作業完了日時
				executeSql.append("  AND TO_CHAR(SAGYO.DT_SAKUSEI, 'YYYYMMDD') <= ? ");
				paramBean.setString(ddSyukei);					// データ作成日次
			} else if (BatchConst.DATA_FLG_SU_SAGYOKAN.equals(dataFlg)) {
				// 作業完成台数
				executeSql.append("  AND TO_CHAR(SAGYO.DT_END, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 作業完了日時
			} else if (BatchConst.DATA_FLG_SU_TENAOSI.equals(dataFlg)) {
				// 手直し件数
				executeSql.append("  AND TO_CHAR(SAGYO.DT_END, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 作業完了日時
				executeSql.append("  AND SAGYO.KB_TENAOSI = '1' ");	// 手直し区分
			}
			
		} else {	
			executeSql = new StringBuilder(SELECT_T220208G_SQL);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
			
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220217gBean.getKbSagyo());		// 作業区分
		
			if (BatchConst.DATA_FLG_SU_SAGYOUKE.equals(dataFlg)) {
				// 作業受付台数
				executeSql.append("  AND TO_CHAR(DT_SAKUSEI, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// データ作成日時
			} else if (BatchConst.DATA_FLG_SU_SAGYOSIKA.equals(dataFlg)) {
				// 作業仕掛台数
				executeSql.append("  AND (DT_END IS NULL OR TO_CHAR(DT_END, 'YYYYMMDD') > ?) ");
				paramBean.setString(ddSyukei);					// 作業完了日時
				executeSql.append("  AND TO_CHAR(DT_SAKUSEI, 'YYYYMMDD') <= ? ");
				paramBean.setString(ddSyukei);					// データ作成日次
			} else if (BatchConst.DATA_FLG_SU_SAGYOKAN.equals(dataFlg)) {
				// 作業完成台数
				executeSql.append("  AND TO_CHAR(DT_END, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 作業完了日時
			} else if (BatchConst.DATA_FLG_SU_TENAOSI.equals(dataFlg)) {
				// 手直し件数
				executeSql.append("  AND TO_CHAR(DT_END, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 作業完了日時
				executeSql.append("  AND KB_TENAOSI = '1' ");	// 手直し区分
			}
		}

		paramBean.setSql(executeSql.toString());
		paramBean.setOrderSql(SELECT_T220208G_ORDER_SQL);

		// 取得
		count = getRecordCount(paramBean);

		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectT220208GSagyoCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectT220208GSagyoCount(Ucbb009gBean t220217gBean,
			String ddSyukei, String dataFlg) throws TecDAOException {

		int count = 0;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_T220208G_SAGYO_SQL);

		if (BatchConst.DATA_FLG_SU_HEADLIGHT.equals(dataFlg)) {
			// ヘッドライトクリーニング
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
//			executeSql.append("  LEFT JOIN T220212G JYUTYU_MEISAI ");
//			executeSql.append("    ON JYUTYU.CD_KAISYA = JYUTYU_MEISAI.CD_KAISYA ");
//			executeSql.append("    AND JYUTYU.CD_JIGYOSYO = JYUTYU_MEISAI.CD_JIGYOSYO ");
//			executeSql.append("    AND JYUTYU.NO_JUCYU = JYUTYU_MEISAI.NO_JUCYU ");
			executeSql.append(LEFT_JOIN_T220212G_SQL);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end

		} else if (BatchConst.DATA_FLG_SU_BPKANI.equals(dataFlg)) {
			// BP簡易台数
			executeSql.append("  LEFT JOIN T220204M CODE_KUBUN ");
			executeSql.append("    ON JYUTYU.CD_KAISYA = CODE_KUBUN.CD_KAISYA ");
			executeSql.append("    AND JYUTYU.CD_JIGYOSYO = CODE_KUBUN.CD_JIGYOSYO ");
			executeSql.append("    AND JYUTYU.KB_GOYOMEI = CODE_KUBUN.CD_KUBUN ");
		}

		executeSql.append(SELECT_T220208G_SAGYO_WHERE_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
		// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
		if (t220217gBean.getKbSagyo().equals("10")) {
			paramBean.setString("01");						// 作業区分（まるクリ）
		} else {
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
			paramBean.setString(t220217gBean.getKbSagyo());	// 作業区分
		}
		paramBean.setString(ddSyukei);						// 作業完了日時

		if (BatchConst.DATA_FLG_SU_HEADLIGHT.equals(dataFlg)) {
			// ヘッドライトクリーニング
			executeSql.append("  AND JYUTYU_MEISAI.NO_BUHIN = '00' ");
			executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO = 'FM10' ");
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
			if (t220217gBean.getKbSagyo().equals("01") || t220217gBean.getKbSagyo().equals("10")) {	
				executeSql.append("INTERSECT ");
				
				executeSql.append(SELECT_T220208G_SAGYO_SQL);
				
				executeSql.append(LEFT_JOIN_T220212G_SQL);
				
				executeSql.append(SELECT_T220208G_SAGYO_WHERE_SQL);
	
				// パラメータセット<条件>
				paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
				paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
				paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
				paramBean.setString("01");							// 作業区分（まるクリ）
				paramBean.setString(ddSyukei);						// 作業完了日時
				
				executeSql.append("  AND JYUTYU_MEISAI.NO_BUHIN = '00' ");
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO <> 'FM10' ");
				if (t220217gBean.getKbSagyo().equals("01")) {
					// まるクリ
					executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO NOT LIKE 'FM05%' ");
				} else {				
					// ルームクリーニング
					executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO LIKE 'FM05%' ");				
				}
			}
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end			
		} else if (BatchConst.DATA_FLG_SU_BPKANI.equals(dataFlg)) {
			// BP簡易台数
			executeSql.append("  AND CODE_KUBUN.KB_ID = '23' ");
			executeSql.append("  AND CODE_KUBUN.MJ_INFO3 = '1' ");
		}

		paramBean.setSql(executeSql.toString());

		// 取得
		count = getRecordCount(paramBean);

		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectT220211GCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectT220211GCount(Ucbb009gBean t220217gBean, String ddSyukei,
			String dataFlg) throws TecDAOException {

		int count = 0;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
//		StringBuilder executeSql = new StringBuilder(SELECT_T220211G_SQL);
		StringBuilder executeSql;

		if (t220217gBean.getKbSagyo().equals("01") || t220217gBean.getKbSagyo().equals("10")) {	
			executeSql = new StringBuilder(SELECT_T220211G_MARUKURI_SQL);
			
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード

			executeSql.append(SELECT_T220211G_MARUKURI_WHERE_SQL);

			if (t220217gBean.getKbSagyo().equals("01")) {
				// まるクリ
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO NOT LIKE 'FM05%' ");
			} else {				
				// ルームクリーニング
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO LIKE 'FM05%' ");				
			}

			if (BatchConst.DATA_FLG_SU_JUCYU.equals(dataFlg)) {
				// 受注件数：受注日
				executeSql.append("  AND TO_CHAR(JYUTYU.DD_JUCYU, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 受注日
			} else if (BatchConst.DATA_FLG_SU_JUCYU_CANCEL.equals(dataFlg)) {
				// 受注件数：受注取消日
				executeSql.append("  AND TO_CHAR(JYUTYU.DD_JUCYUCAN, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 受注取消日
			} else if (BatchConst.DATA_FLG_SU_SIKAKARI.equals(dataFlg)) {
				// 仕掛件数
				executeSql.append("  AND JYUTYU.KB_CANCEL IS NULL ");
				executeSql.append("  AND (JYUTYU.DD_SEISAN IS NULL OR JYUTYU.DD_SEISAN > ? ) ");
				paramBean.setString(ddSyukei);					// 精算日
				executeSql.append("  AND TO_CHAR(JYUTYU.DD_JUCYU, 'YYYYMMDD') <= ? ");
				paramBean.setString(ddSyukei);					// 受注日
			}
			
		} else {
			executeSql = new StringBuilder(SELECT_T220211G_SQL);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
			
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220217gBean.getKbSagyo());		// 作業区分
	
			if (BatchConst.DATA_FLG_SU_JUCYU.equals(dataFlg)) {
				// 受注件数：受注日
				executeSql.append("  AND TO_CHAR(DD_JUCYU, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 受注日
			} else if (BatchConst.DATA_FLG_SU_JUCYU_CANCEL.equals(dataFlg)) {
				// 受注件数：受注取消日
				executeSql.append("  AND TO_CHAR(DD_JUCYUCAN, 'YYYYMMDD') = ? ");
				paramBean.setString(ddSyukei);					// 受注取消日
			} else if (BatchConst.DATA_FLG_SU_SIKAKARI.equals(dataFlg)) {
				// 仕掛件数
				executeSql.append("  AND KB_CANCEL IS NULL ");
				executeSql.append("  AND (DD_SEISAN IS NULL OR DD_SEISAN > ? ) ");
				paramBean.setString(ddSyukei);					// 精算日
				executeSql.append("  AND TO_CHAR(DD_JUCYU, 'YYYYMMDD') <= ? ");
				paramBean.setString(ddSyukei);					// 受注日
			}
		}

		paramBean.setSql(executeSql.toString());
		paramBean.setOrderSql(SELECT_T220211G_ORDER_SQL);

		// 取得
		count = getRecordCount(paramBean);

		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectGaityuSiire(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean, java.lang.String)
	 */
	@Override
	public int selectGaityuSiire(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
//		StringBuilder executeSql = new StringBuilder(SELECT_GAITYU_SQL);
		StringBuilder executeSql;

		if (t220217gBean.getKbSagyo().equals("01") || t220217gBean.getKbSagyo().equals("10")) {	
			executeSql = new StringBuilder(SELECT_GAITYU_MARUKURI_SQL);
			
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString("0");							// 自社区分（外注業者）

			if (t220217gBean.getKbSagyo().equals("01")) {
				// まるクリ
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO NOT LIKE 'FM05%' ");
			} else {				
				// ルームクリーニング
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO LIKE 'FM05%' ");				
			}
			
		} else {
			executeSql = new StringBuilder(SELECT_GAITYU_SQL);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
			
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220217gBean.getKbSagyo());		// 作業区分
			paramBean.setString("0");							// 自社区分（外注業者）
		}

		if (BatchConst.DATA_FLG_KI_GAISIIRE.equals(dataFlg)) {
			// 外注仕入金額
			executeSql.append("AND TO_CHAR(GAITYU_SIIRE.DD_SIIRE, 'YYYYMMDD') = ? ");
			paramBean.setString(ddSyukei);					// 仕入日
		} else if (BatchConst.DATA_FLG_KI_GAISIKA.equals(dataFlg)) {
			// 外注仕掛金額
			executeSql.append("  AND JYUTYU.KB_CANCEL IS NULL ");
			executeSql.append("  AND (JYUTYU.DD_SEISAN IS NULL OR TO_CHAR(JYUTYU.DD_SEISAN, 'YYYYMMDD') > ?) ");
			paramBean.setString(ddSyukei);					// 精算日
			executeSql.append("  AND TO_CHAR(JYUTYU.DD_JUCYU, 'YYYYMMDD') <= ? ");
			paramBean.setString(ddSyukei);					// 受注日
			executeSql.append("  AND GAITYU_SIIRE.KB_CANCEL IS NULL ");
			executeSql.append("  AND GAITYU_SIIRE.DD_SIIRE IS NOT NULL ");
		}

		paramBean.setSql(executeSql.toString());
		paramBean.setOrderSql(SELECT_URIAGE_ORDER_SQL);

		ResultArrayList<Ucbb003gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb003gBean.class);

		int kiUriage = 0;
		if (resultList.size() > 0) {
			kiUriage = resultList.get(0).getKiSiire() - resultList.get(0).getKiTax();
		}

		return kiUriage;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectUriageCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectUriageCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg) throws TecDAOException {

		int count = 0;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_URIAGE_SQL);

		// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
		if (t220217gBean.getKbSagyo().equals("01") || t220217gBean.getKbSagyo().equals("10")) {	
			executeSql.append(SELECT_URIAGE_MARUKURI_FROM_SQL);
			
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(ddSyukei);						// 受注日

			if (t220217gBean.getKbSagyo().equals("01")) {
				// まるクリ
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO NOT LIKE 'FM05%' ");
			} else {				
				// ルームクリーニング
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO LIKE 'FM05%' ");				
			}
			
		} else {
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
			executeSql.append(SELECT_URIAGE_FROM_SQL);
	
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220217gBean.getKbSagyo());		// 作業区分
			paramBean.setString(ddSyukei);						// 受注日	
		}

		if (BatchConst.DATA_FLG_SU_URIAGE.equals(dataFlg)) {
			// 売上件数：売上
			executeSql.append("  AND URIAGE_SEISAN.KB_CANCEL IS NULL ");
		} else if (BatchConst.DATA_FLG_SU_URIAGE_CANCEL.equals(dataFlg)) {
			// 売上件数：売上取消
			executeSql.append("  AND URIAGE_SEISAN.KB_CANCEL = '1' ");
		}

		paramBean.setSql(executeSql.toString());
		paramBean.setOrderSql(SELECT_URIAGE_ORDER_SQL);

		// 取得
		count = getRecordCount(paramBean);

		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectUriage(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean, java.lang.String)
	 */
	@Override
	public int selectUriage(Ucbb009gBean t220217gBean, String ddSyukei) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_URIAGE_SUM_SQL);
		
		// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
		if (t220217gBean.getKbSagyo().equals("01") || t220217gBean.getKbSagyo().equals("10")) {	
			executeSql.append(SELECT_URIAGE_MARUKURI_FROM_SQL);
			
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(ddSyukei);						// 受注日

			if (t220217gBean.getKbSagyo().equals("01")) {
				// まるクリ
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO NOT LIKE 'FM05%' ");
			} else {				
				// ルームクリーニング
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO LIKE 'FM05%' ");				
			}
			
		} else {
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
			executeSql.append(SELECT_URIAGE_FROM_SQL);
	
			// パラメータセット<条件>
			paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
			paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220217gBean.getKbSagyo());		// 作業区分
			paramBean.setString(ddSyukei);						// 受注日
		}

		paramBean.setSql(executeSql.toString());
		paramBean.setOrderSql(SELECT_URIAGE_ORDER_SQL);

		ResultArrayList<Ucbb004gBean> resultList
			= executeSimpleSelectQuery(paramBean, Ucbb004gBean.class);

		int kiUriage = 0;
		if (resultList.size() > 0) {
			kiUriage = resultList.get(0).getKiSeikyu() - resultList.get(0).getKiTax();
		}

		return kiUriage;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#selectUriageSagyoCount(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb009gBean, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectUriageSagyoCount(Ucbb009gBean t220217gBean, String ddSyukei, String dataFlg, String dataFlg2) throws TecDAOException {

		int count = 0;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder executeSql = new StringBuilder(SELECT_URIAGE_SAGYO_SQL);
		
		if (BatchConst.DATA_FLG_SU_HEADLIGHT.equals(dataFlg2)) {
			// ヘッドライトクリーニング
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
//			executeSql.append("  LEFT JOIN T220212G JYUTYU_MEISAI ");
//			executeSql.append("    ON JYUTYU.CD_KAISYA = JYUTYU_MEISAI.CD_KAISYA ");
//			executeSql.append("    AND JYUTYU.CD_JIGYOSYO = JYUTYU_MEISAI.CD_JIGYOSYO ");
//			executeSql.append("    AND JYUTYU.NO_JUCYU = JYUTYU_MEISAI.NO_JUCYU ");
			executeSql.append(LEFT_JOIN_T220212G_SQL);
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end

		} else if (BatchConst.DATA_FLG_SU_BPKANI.equals(dataFlg2)) {
			// BP簡易台数
			executeSql.append("  LEFT JOIN T220204M CODE_KUBUN ");
			executeSql.append("    ON JYUTYU.CD_KAISYA = CODE_KUBUN.CD_KAISYA ");
			executeSql.append("    AND JYUTYU.CD_JIGYOSYO = CODE_KUBUN.CD_JIGYOSYO ");
			executeSql.append("    AND JYUTYU.KB_GOYOMEI = CODE_KUBUN.CD_KUBUN ");
		}
		
		executeSql.append(SELECT_URIAGE_SAGYO_FROM_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
		paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
		// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
		if (t220217gBean.getKbSagyo().equals("10")) {
			paramBean.setString("01");						// 作業区分（まるクリ）
		} else {
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
			paramBean.setString(t220217gBean.getKbSagyo());	// 作業区分
		}
		paramBean.setString(ddSyukei);						// 受注日

		if (BatchConst.DATA_FLG_SU_URIAGE.equals(dataFlg)) {
			// 売上
			executeSql.append("  AND URIAGE_SEISAN.KB_CANCEL IS NULL ");
		} else if (BatchConst.DATA_FLG_SU_URIAGE_CANCEL.equals(dataFlg)) {
			// 売上取消
			executeSql.append("  AND URIAGE_SEISAN.KB_CANCEL = '1' ");
		}

		if (BatchConst.DATA_FLG_SU_HEADLIGHT.equals(dataFlg2)) {
			// ヘッドライトクリーニング
			executeSql.append("  AND JYUTYU_MEISAI.NO_BUHIN = '00' ");
			executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO = 'FM10' ");
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 start
			if (t220217gBean.getKbSagyo().equals("01") || t220217gBean.getKbSagyo().equals("10")) {	
				executeSql.append("INTERSECT ");
				
				executeSql.append(SELECT_URIAGE_SAGYO_SQL);

				executeSql.append(LEFT_JOIN_T220212G_SQL);
				
				executeSql.append(SELECT_URIAGE_SAGYO_FROM_SQL);
				
				// パラメータセット<条件>
				paramBean.setString(t220217gBean.getCdKaisya());	// 会社コード
				paramBean.setString(t220217gBean.getCdJigyosyo());	// 事業所コード
				paramBean.setString(t220217gBean.getCdHanbaitn());	// 販売店コード
				paramBean.setString("01");							// 作業区分（まるクリ）
				paramBean.setString(ddSyukei);						// 受注日
				
				if (BatchConst.DATA_FLG_SU_URIAGE.equals(dataFlg)) {
					// 売上
					executeSql.append("  AND URIAGE_SEISAN.KB_CANCEL IS NULL ");
				} else if (BatchConst.DATA_FLG_SU_URIAGE_CANCEL.equals(dataFlg)) {
					// 売上取消
					executeSql.append("  AND URIAGE_SEISAN.KB_CANCEL = '1' ");
				}
				
				executeSql.append("  AND JYUTYU_MEISAI.NO_BUHIN = '00' ");
				executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO <> 'FM10' ");
				if (t220217gBean.getKbSagyo().equals("01")) {
					// まるクリ
					executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO NOT LIKE 'FM05%' ");
				} else {				
					// ルームクリーニング
					executeSql.append("  AND JYUTYU_MEISAI.CD_SAGYO LIKE 'FM05%' ");				
				}
			}
			// 2013.08.23 C.Ohta 修正 ルームクリーニング値集計 end
		} else if (BatchConst.DATA_FLG_SU_BPKANI.equals(dataFlg2)) {
			// BP簡易台数
			executeSql.append("  AND CODE_KUBUN.KB_ID = '23' ");
			executeSql.append("  AND CODE_KUBUN.MJ_INFO3 = '1' ");
		}

		paramBean.setSql(executeSql.toString());
		paramBean.setOrderSql(SELECT_URIAGE_ORDER_SQL);

		// 取得
		count = getRecordCount(paramBean);

		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.batch.daily.datacreate.model.data.CreateSeibiUriageNippouDAOIF#updateT220218G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb010gBean)
	 */
	@Override
	public SimpleExecuteResultBean updateT220218G(Ucbb010gBean t220218gBean)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220218G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220218gBean.getDdDate1()); 	// 日付1
		paramBean.setString(t220218gBean.getDdDate2()); 	// 日付2
		paramBean.setTimestamp(new Timestamp(t220218gBean.getDtKosin().getTime())); // データ更新日時
		paramBean.setString(t220218gBean.getCdKsnsya()); 	// 更新ユーザID
		paramBean.setString(t220218gBean.getCdKsnapp()); 	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220218gBean.getKbBatch());	// バッチ区分

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

}
