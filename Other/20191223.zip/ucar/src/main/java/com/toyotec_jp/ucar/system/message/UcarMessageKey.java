/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarMessageKey.java
 * 【  説  明  】
 * 【  作  成  】2010/12/24 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.system.message;

import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;
import com.toyotec_jp.ucar.UcarApplicationManager;

/**
 * <strong>メッセージキー。</strong>
 * @author H.O(SCC)
 * @version 1.00 2010/12/24 新規作成<br>
 * @since 1.00
 */
public enum UcarMessageKey implements TecMessageKeyIF {

	/** 業務エラーメッセージ:アプリケーションエラーが発生しました。 */
	WF_E_DEFAULT_SYSTEM_EXCEPTION_MESSAGE_KEY(UcarApplicationManager.WF_ROOT + ".E0001"),
	/** 業務エラーメッセージ:データベースエラーが発生しました。 */
	WF_E_DEFAULT_DATABASE_EXCEPTION_MESSAGE_KEY(UcarApplicationManager.WF_ROOT + ".E0002"),
	;
	private String messageKey;

	private UcarMessageKey(String messageKey){
		this.messageKey = messageKey;
	}
	public String toString(){
		return messageKey;
	}
	@Override
	public String getMessageKey() {
		return messageKey;
	}

}
