/**
 * IM関連共通パッケージ
 * @version 1.00 2011/01/05 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp;
