package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SiwakeCodeMasterBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>仕分用コード区分マスタ操作DAOの実装。</strong>
 * @author C.O(TEC)
 * @version 1.00 2013/02/15 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SiwakeCodeMasterDAOImpl extends UcarSharedDBDAO implements SiwakeCodeMasterDAOIF {

	private static final String SELECT_SIWAKECODE_MASTER_SQL =
		"SELECT "					+
		"    CD_KAISYA "			+
		"  , CD_HANBAITN "			+
		"  , KB_ID "				+
		"  , CD_KUBUN "				+
		"  , MJ_KUBUN "				+
		"  , MJ_KBNRK "				+
		"  , NO_SORT "				+
		"  , MJ_INFO1 "				+
		"  , MJ_INFO2 "				+
		"  , MJ_INFO3 "				+
		"  , MJ_INFO4 "				+
		"  , MJ_INFO5 "				+
		"FROM "						+
		"    T220204M "				+
		"WHERE " 					+
		"     CD_KAISYA = ? "		+
		" AND CD_HANBAITN = ? "		+
		" AND KB_ID = ? ";

	private static final String SELECT_SIWAKECODE_MASTER_ORDER_SQL =
		"ORDER BY NO_SORT ASC ";

	/* (非 Javadoc)
	 * @see jp.co.core.lcm.common.model.dao.SiwakeCodeMasterDAOIF#getSiwakeCodeMasterList(java.lang.String)
	 */
	@Override
	public ResultArrayList<SiwakeCodeMasterBean> getSiwakeCodeMasterList(String key, UserInformationBean userInfoBean) throws TecDAOException {

		ResultArrayList<SiwakeCodeMasterBean> resList = null;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_SIWAKECODE_MASTER_SQL, SELECT_SIWAKECODE_MASTER_ORDER_SQL);
			paramBean.setString(userInfoBean.getCdKaisya()); 	// 会社コード 
			paramBean.setString(userInfoBean.getCdHanbaitn());	// 販売店コード 
			paramBean.setString(key);
			resList = executeSimpleSelectQuery(paramBean, SiwakeCodeMasterBean.class);

		} finally {
		}

		return resList;
	}

}
