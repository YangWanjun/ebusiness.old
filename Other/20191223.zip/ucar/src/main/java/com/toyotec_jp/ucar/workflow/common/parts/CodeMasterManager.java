package com.toyotec_jp.ucar.workflow.common.parts;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.intra_mart.framework.base.event.EventException;
import jp.co.intra_mart.framework.base.event.EventManager;
import jp.co.intra_mart.framework.base.event.EventManagerException;
import jp.co.intra_mart.framework.base.event.EventPropertyException;
import jp.co.intra_mart.framework.base.util.UserInfo;
import jp.co.intra_mart.framework.base.util.UserInfoException;
import jp.co.intra_mart.framework.base.util.UserInfoUtil;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarEventKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CodeMasterEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.CodeMasterBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>コード区分マスタ管理クラス。</strong>
 * <p>
 * コード区分マスタの値を管理する。
 * </p>
 * @author Y.M(TEC)
 * @version 1.00 2012/01/16 新規作成<br>
 * @since 1.00
 */
public class CodeMasterManager {

	private static final CodeMasterManager codeMasterMng = new CodeMasterManager();

	private volatile EventManager eventManager;

	private HashMap<String, ResultArrayList<CodeMasterBean>> codeMap;

	/** 区分IDIF */
	public interface KbIdIF {
		/** 区分ID取得 */
		public String getKbId();
	}

	private CodeMasterManager(){
	}

	/**
	 * コード区分マスタリスト取得。
	 * <pre>
	 * コード区分マスタから指定した区分IDを持つリストを取得する。
	 * </pre>
	 * @param kbId 区分ID
	 * @param req リクエスト
	 * @param res レスポンス
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return コード区分マスタリスト
	 * @throws TecSystemException
	 */
	public static List<CodeMasterBean> getCodeMasterList(
			KbIdIF kbId, 
			HttpServletRequest req, 
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//			HttpServletResponse res) throws TecSystemException {
			HttpServletResponse res, String kaisya, String jigyosyo) throws TecSystemException {
//		return getCodeMasterList(kbId.getKbId(), req, res);
		return getCodeMasterList(kbId.getKbId(), req, res, kaisya, jigyosyo);
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
	}

	/**
	 * コード区分マスタリスト取得。
	 * <pre>
	 * コード区分マスタから指定した区分IDを持つリストを取得する。<br>
	 * </pre>
	 * @param kbId 区分ID
	 * @param req リクエスト
	 * @param res レスポンス
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return コード区分マスタリスト
	 * @throws TecSystemException
	 */
	 public static List<CodeMasterBean> getCodeMasterList(
			String kbId, HttpServletRequest 
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//			req, HttpServletResponse res) throws TecSystemException {
			req, HttpServletResponse res, String kaisya, String jigyosyo) throws TecSystemException {
//		return getCodeMasterList(kbId, req, res, null);
		return getCodeMasterList(kbId, req, res, null, kaisya, jigyosyo);
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
	}

	/**
	 * コード区分マスタリスト取得。
	 * <pre>
	 * コード区分マスタから指定した区分IDと条件パラメータよりリストを取得する。<br>
	 * </pre>
	 * @param kbId 区分ID
	 * @param req リクエスト
	 * @param res レスポンス
	 * @param whereParam 条件パラメータ
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return コード区分マスタリスト
	 * @throws TecSystemException
	 */
	public static List<CodeMasterBean> getCodeMasterList(
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//			String kbId, HttpServletRequest req, HttpServletResponse res, CodeMasterBean whereParam) throws TecSystemException {
			String kbId, HttpServletRequest req, HttpServletResponse res, CodeMasterBean whereParam, String kaisya, String jigyosyo) throws TecSystemException {
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
		UserInfo userInfo = null;
		UserInformationBean userInfoBean = null;
		try {
			userInfo = UserInfoUtil.createUserInfo(req, res);
			userInfoBean = getLoginSessionBean(req, res);
		} catch (UserInfoException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//		return getCodeMasterList(kbId, userInfo, whereParam, userInfoBean);
		return getCodeMasterList(kbId, userInfo, whereParam, userInfoBean, kaisya, jigyosyo);
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
	}
	
	/**
	 * ログインセッションビーン取得。
	 * <pre>
	 * ログインユーザの情報が格納されているビーンをセッションから返却する。<br>
	 * 存在しない場合、ログインセッションビーンを生成しセッションに設定した後、返却する。
	 * </pre>
	 * @return ログインセッションビーン
	 * @throws UserInfoException
	 */
	public static UserInformationBean getLoginSessionBean(HttpServletRequest req, HttpServletResponse res) throws TecSystemException {
		UserInfo userInfo = null;
		try {
			userInfo = UserInfoUtil.createUserInfo(req, res);
		} catch (UserInfoException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		return sessionMng.getLoginSessionBean(req, userInfo).getUserInfoBean();
	}


	/**
	 * コード区分マスタリスト取得。
	 * <pre>
	 * コード区分マスタから指定した区分IDを持つリストを取得する。
	 * </pre>
	 * @param kbId 区分ID
	 * @param userInfo ユーザ情報
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return コード区分マスタリスト
	 * @throws TecSystemException
	 */
	public static List<CodeMasterBean> getCodeMasterList(
			KbIdIF kbId, 
			UserInfo userInfo, 
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//			UserInformationBean userInfoBean) throws TecSystemException {
			UserInformationBean userInfoBean, 
			String kaisya, 
			String jigyosyo) throws TecSystemException {
//		return getCodeMasterList(kbId.getKbId(), userInfo , userInfoBean);
		return getCodeMasterList(kbId.getKbId(), userInfo , userInfoBean, kaisya, jigyosyo);
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
	}

	/**
	 * コード区分マスタリスト取得。
	 * <pre>
	 * コード区分マスタから指定した区分IDを持つリストを取得する。(条件拡張(AND))<br>
	 * </pre>
	 * @param kbId 区分ID
	 * @param userInfo ユーザ情報
	 * @param whereParam 条件パラメータ
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return コード区分マスタリスト
	 * @throws TecSystemException
 	 */
	public static List<CodeMasterBean> getCodeMasterList(
			String kbId, 
			UserInfo userInfo, 
			CodeMasterBean whereParam, 
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//			UserInformationBean userInfoBean) throws TecSystemException {
			UserInformationBean userInfoBean, 
			String kaisya, 
			String jigyosyo) throws TecSystemException {
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
		
		
		// コード区分マスタリスト
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//		ResultArrayList<CodeMasterBean> workList = (ResultArrayList<CodeMasterBean>) getCodeMasterList(kbId, userInfo, userInfoBean);
		ResultArrayList<CodeMasterBean> workList = (ResultArrayList<CodeMasterBean>) getCodeMasterList(kbId, userInfo, userInfoBean, kaisya, jigyosyo);
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end

		// 返却用リスト
		ResultArrayList<CodeMasterBean> resultList = null;

		if(whereParam != null){

			// パラメータ指定時はフィルタ(大文字小文字区別なし、文字列限定)
			resultList = workList.getFilterdNewList(whereParam, true, true);
		}else{
			// パラメータ未指定時はそのまま返却
			resultList = workList;
		}
		return resultList;
	}

	/**
	 * コード区分マスタリスト取得。
	 * <pre>
	 * コード区分マスタから指定した区分IDを持つリストを取得する。
	 * </pre>
	 * @param kbId 区分ID
	 * @param userInfo ユーザ情報
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return コード区分マスタリスト
	 * @throws TecSystemException
	 */
	public static List<CodeMasterBean> getCodeMasterList(
			String kbId, 
			UserInfo userInfo, 
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//			UserInformationBean userInfoBean) throws TecSystemException {
			UserInformationBean userInfoBean, 
			String kaisya, 
			String jigyosyo) throws TecSystemException {
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
		ResultArrayList<CodeMasterBean> codeList = null;
		boolean isExist = false;
		codeMasterMng.initCodeMap();
		
//	常にＤＢサーバーアクセスに切り替え		
//		synchronized (codeMasterMng.codeMap) {
//			isExist = codeMasterMng.codeMap.containsKey(kbId);
//			if(isExist){
//				codeList = codeMasterMng.codeMap.get(kbId);
//			}
//		}
		if(!isExist){
			try {
				codeMasterMng.initEventMng();
			} catch (EventManagerException e) {
				TecLogger.error(e);
				throw new TecSystemException(e);
			}
//			codeList = codeMasterMng.getNewCodeMasterList(kbId, userInfo, userInfoBean);
			codeList = codeMasterMng.getNewCodeMasterList(kbId, userInfo, userInfoBean, kaisya, jigyosyo);
		}
		return codeList;
	}

	/**
	 * 表示値取得。
	 * <pre>
	 * 区分ID、区分コードに対応する表示値を取得。
	 * </pre>
	 * @param kbId 区分ID
	 * @param cdKubun 区分コード
	 * @param userInfo ユーザ情報
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return 表示値
	 * @throws TecSystemException
	 */
	// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//	public static String getName(KbIdIF kbId, String cdKubun, UserInfo userInfo, UserInformationBean userInfoBean) throws TecSystemException {
	public static String getName(KbIdIF kbId, String cdKubun, UserInfo userInfo, UserInformationBean userInfoBean, String kaisya, String jigyosyo) throws TecSystemException {
//		return getName(kbId.getKbId(), cdKubun, userInfo, userInfoBean);
		return getName(kbId.getKbId(), cdKubun, userInfo, userInfoBean, kaisya, jigyosyo);
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
	}

	/**
	 * 表示値取得。
	 * <pre>
	 * 区分ID、区分コードに対応する表示値を取得。
	 * </pre>
	 * @param kbId 区分ID
	 * @param cdKubun 区分コード
	 * @param userInfo ユーザ情報
	 * @param kaisya 会社コード
	 * @param jigyosyo 事業所コード
	 * @return 表示値
	 * @throws TecSystemException
	 */
	// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//	public static String getName(String kbId, String cdKubun, UserInfo userInfo, UserInformationBean userInfoBean) throws TecSystemException {
	public static String getName(String kbId, String cdKubun, UserInfo userInfo, UserInformationBean userInfoBean, String kaisya, String jigyosyo) throws TecSystemException {
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
		String result = null;
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//		ResultArrayList<CodeMasterBean> codeList = (ResultArrayList<CodeMasterBean>)getCodeMasterList(kbId, userInfo, userInfoBean);
		ResultArrayList<CodeMasterBean> codeList = (ResultArrayList<CodeMasterBean>)getCodeMasterList(kbId, userInfo, userInfoBean, kaisya, jigyosyo);
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
		if(codeList != null){
			for(CodeMasterBean bean : codeList){
				if(bean.getCdKubun() != null && bean.getCdKubun().equals(cdKubun)){
					result = bean.getMjKubun();
				}
			}
		}
		return result;
	}

	/**
	 * 保存しているコード区分マスタの情報をクリア。
	 */
	public static void clearCategoryMap(){
		if(codeMasterMng.codeMap != null){
			synchronized (codeMasterMng.codeMap) {
				codeMasterMng.codeMap.clear();
			}
		}
	}

	// codeMap初期化
	private void initCodeMap(){
		synchronized (this) {
			if(this.codeMap == null){
				TecLogger.trace("--- new CodeMap ---");
				this.codeMap = new HashMap<String, ResultArrayList<CodeMasterBean>>();
			}
		}
	}

	// EventManager取得
	private void initEventMng() throws EventManagerException {
		synchronized (this) {
			if(this.eventManager == null){
				TecLogger.trace("--- new EventManager ---");
				this.eventManager = EventManager.getEventManager();
			}
		}
	}

	@SuppressWarnings("unchecked")
	private ResultArrayList<CodeMasterBean> getNewCodeMasterList(
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
//			String kbId, UserInfo userInfo, UserInformationBean userInfoBean) throws TecSystemException {
			String kbId, UserInfo userInfo, UserInformationBean userInfoBean, String kaisya, String jigyosyo) throws TecSystemException {
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
		ResultArrayList<CodeMasterBean> codeMasterList = null;
		try{
			CodeMasterEvent event = (CodeMasterEvent)this.eventManager.createEvent(
					UcarEventKey.VIEW_CODE_MASTER.getApplicationId(), UcarEventKey.VIEW_CODE_MASTER.getEventKey(), userInfo);
			event.setKbID(kbId);
			event.setUserInfoBean(userInfoBean);
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
			event.setCdKaisya(kaisya);
			event.setCdJigyosyo(jigyosyo);
			// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
			codeMasterList = (ResultArrayList<CodeMasterBean>)this.eventManager.dispatch(event);
			synchronized (this.codeMap) {
				if(!this.codeMap.containsKey(kbId)){
					TecLogger.trace("--- put new category[" + kbId + "] ---");
					this.codeMap.put(kbId, codeMasterList);
				}
			}
		} catch (ClassCastException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (EventPropertyException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (EventException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (SystemException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} catch (ApplicationException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		} finally {

		}
		return codeMasterList;
	}
}
