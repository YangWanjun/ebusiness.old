/*
 * 【システム名】リース管理システム
 * 【ファイル名】CalendarReloadServiceController.java
 * 【  説  明  】カレンダー用サービスコントローラ
 * 【  作  成  】2010/06/18 T.H(SCC)
 */
package com.toyotec_jp.ucar.workflow.common.calendar.service.controller;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.workflow.common.calendar.model.object.CalendarSessionBean;

/**
 * ユニットリスト
 */
public class CalendarReloadServiceController extends UcarServiceController {

	/**
	 * 呼出しに対する処理を実行します。
	 *
	 * @return 処理結果
	 * @throws SystemException 処理実行時にシステム例外が発生
	 * @throws ApplicationException 処理実行時にアプリケーション例外が発生
	 */
	public ServiceResult service() throws SystemException, ApplicationException {

		// セッション情報を取得
		CalendarSessionBean sessionBean = getApplicationSessionBean("calendarSessionBean", CalendarSessionBean.class);
		// 設定されている情報をデフォルトとする
//2015.4.22 前後追加 START
//一度int型に入れゼロサプレスする		
		//前月
		sessionBean.setYearBefore ((String) getRequest().getParameter("yearBefore"));
		int dspMm = Integer.parseInt(getRequest().getParameter("monthBefore"));
		sessionBean.setMonthBefore(String.valueOf(dspMm));
		
		//当月
		sessionBean.setYear	((String) getRequest().getParameter("year"));
		dspMm = Integer.parseInt(getRequest().getParameter("month"));
		sessionBean.setMonth(String.valueOf(dspMm));
		
		//翌月
		sessionBean.setYearAfter ((String) getRequest().getParameter("yearAfter"));
		dspMm = Integer.parseInt(getRequest().getParameter("monthAfter"));
		sessionBean.setMonthAfter(String.valueOf(dspMm));
//2015.4.22 前後追加 END		
		// 結果を返却します。
		return null;
	}

}
