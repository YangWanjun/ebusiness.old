package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;

/**
 * <strong>車両搬出情報取得イベント。</strong>
 * <p>
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/04 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class GetCarryoutRegisterDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/** 車両搬出情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean 車両搬出情報 プライマリーキーBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean 車両搬出情報 プライマリーキーBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}

}
