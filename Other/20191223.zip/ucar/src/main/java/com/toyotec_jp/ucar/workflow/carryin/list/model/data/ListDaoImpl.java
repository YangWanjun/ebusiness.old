
package com.toyotec_jp.ucar.workflow.carryin.list.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinUtilsSql;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListDataBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListPageingBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListParamBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;
/**
 * <strong>車両搬入一覧 Dao</strong>
 * @author Y.F(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class ListDaoImpl extends UcarSharedDBDAO implements ListDaoIF {

	private static final String SELECT_T220005M =
		"SELECT "
		+ "  CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , KB_CHECK "
		+ "  , MJ_CHECK "
		+ "  , KB_DISP "
		+ "  , NU_HYZYUN "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP  "
		+ "FROM "
		+ "  T220005M "
		+ "WHERE "
		+ "  CD_KAISYA = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_DISP = ? ";

	private static final String SELECT_T220004M =
		"SELECT "
		+ "  CD_KAISYA "
		+ "  , CD_HANBAITN "
		+ "  , KB_SIIRE "
		+ "  , MJ_SIIRE "
		+ "  , MJ_TANSIIRE "
		+ "  , KB_DISP "
		+ "  , NU_HYZYUN "
		+ "  , DT_SAKUSEI "
		+ "  , DT_KOSIN "
		+ "  , CD_SKSISYA "
		+ "  , CD_KSNSYA "
		+ "  , CD_SKSIAPP "
		+ "  , CD_KSNAPP "
		+ "FROM "
		+ "  T220004M "
		+ "WHERE "
		+ "  CD_KAISYA = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_DISP = ? ";

	@Override
	public ListPageingBean selectMain(String kbScenter
									, ListParamBean prmData
									, ResultArrayList<Ucaa005mBean> t220005mList
									, ResultArrayList<Ucaa004mBean> t220004mList
									, String sortParam
									, String sortOrder
									, String page
									, String pageSize) throws TecDAOException {

		ListPageingBean result = null;

		try {
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

			// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため start
			StringBuilder selectSql = CarryinUtilsSql.createSelectSql(prmData, t220004mList, t220005mList, false);
			// 検索条件
			selectSql.append(CarryinUtilsSql.createConditionSql(prmData, false));

			if (!UcarConst.KB_SCENTER_SCENTER.equals(kbScenter)) {
				// 店舗の場合

				selectSql.append(" union ");
				// 受取日で該当するデータを取得する
				StringBuilder selectTenpoSql = CarryinUtilsSql.createSelectSql(prmData, t220004mList, t220005mList, true);
				// 検索条件
				selectTenpoSql.append(CarryinUtilsSql.createConditionSql(prmData, true));

				selectSql.append(selectTenpoSql);
			}
			paramBean.setSql(selectSql.toString());
			// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため end

//			paramBean.setString(prmData.getCdKaisya());		// 会社コード
//			paramBean.setString(prmData.getCdHanbaitn());	// 販売店コード
//			// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
//			paramBean.setString(prmData.getCdTenpo());		// 搬入店舗コード
//			// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end


			/*  2011.10.20 H.Yamashita 書類チェックモード追加に伴う対応
			paramBean.setString(prmData.getDdHannyuFrom().replace("/", ""));	// 搬入日(From)
			paramBean.setString(prmData.getDdHannyuTo().replace("/", ""));		// 搬入日(To)
			 */

			StringBuilder orderSql = new StringBuilder();
			//並び順がない場合は昇順とする
			if (sortOrder.equals("")){
				sortOrder = "ASC";
			}
			//ソート条件
			if(!sortParam.equals("")){
				if (sortParam.equals("DD_HANNYU")){
					// 搬入日
					orderSql.append(" ORDER BY CD_KAISYA "   +
							        "         ,CD_HANBAITN " +
							        "         ,DD_HANNYU "   + sortOrder +
							        "         ,NO_KANRI ");
				} else if (sortParam.equals("CD_SIRTENPO")) {
					// 仕入店舗コード(搬入拠点)
					orderSql.append(" ORDER BY CD_KAISYA "   +
									"         ,CD_HANBAITN " +
									"         ,CD_SIRTENPO " + sortOrder +
									"         ,DD_HANNYU "   +
									"         ,NO_KANRI ");
				} else if (sortParam.equals("MJ_SYAMEI")) {
					// 車名の場合
					orderSql.append(" ORDER BY CD_KAISYA "   +
									"         ,CD_HANBAITN " +
									"         ,MJ_SYAMEI "   + sortOrder +
									"         ,DD_HANNYU "   +
									"         ,NO_KANRI ");

				} else if (sortParam.equals("DD_SRKNB")) {
					// 書類完備日 2011.10.20 H.Yamashita add
					orderSql.append(" ORDER BY CD_KAISYA "   +
									"         ,CD_HANBAITN " +
									"         ,DD_SRKNB "    + sortOrder +
									"         ,DD_HANNYU "   +
									"         ,NO_KANRI ");
				} else if (sortParam.equals("DD_SRKHR")) {
					// 2012.01.30 T.Hayato 追加 ソート条件追加 start
					// 書類保留日
					orderSql.append(" ORDER BY CD_KAISYA "   +
							"         ,CD_HANBAITN " +
							"         ,DD_SRKHR "    + sortOrder +
							"         ,DD_HANNYU "   +
							"         ,NO_KANRI ");
					// 2012.01.30 T.Hayato 追加 ソート条件追加 end
				} else if (sortParam.equals("DD_INKANKGN")) {
					// 2012.03.16 C.Ohta 追加 ソート条件追加 start
					// 印鑑証明期限日
					orderSql.append(" ORDER BY CD_KAISYA "   +
							"         ,CD_HANBAITN " +
							"         ,DD_INKANKGN "    + sortOrder +
							"         ,DD_HANNYU "   +
							"         ,NO_KANRI ");
					// 2012.03.16 C.Ohta 追加 ソート条件追加 end
				} else {
					orderSql.append(" ORDER BY CD_KAISYA "   +
							        "         ,CD_HANBAITN " +
							        "         ,DD_HANNYU "   + sortOrder +
							        "         ,NO_KANRI ");
				}
			} else {
				// 未指定の場合
				orderSql.append(" ORDER BY CD_KAISYA "   +
				        "         ,CD_HANBAITN " +
				        "         ,DD_HANNYU "   + sortOrder +
				        "         ,NO_KANRI ");
			}
			// ソート条件
			paramBean.setOrderSql(orderSql.toString());
			// ページ番号
			paramBean.setPageNo(Integer.parseInt(page));
			// ページサイズ
			paramBean.setPageSize(Integer.parseInt(pageSize));

			result = executeSimplePagingQuery(paramBean, ListPageingBean.class, ListDataBean.class);

		} finally {

		}

		return result;
	}

	@Override
	public ResultArrayList<Ucaa005mBean> selectT220005M(ListParamBean prmData)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220005M);

		// パラメータセット<条件>
		paramBean.setString(prmData.getCdKaisya());		// 会社コード
		paramBean.setString(prmData.getCdHanbaitn());	// 販売店コード
		paramBean.setString(UcarConst.KB_DISP_ON);		// DispFlgが１のもの

		ResultArrayList<Ucaa005mBean> t220005mList = executeSimpleSelectQuery(paramBean, Ucaa005mBean.class);

		return t220005mList;
	}

	@Override
	public ResultArrayList<Ucaa004mBean> selectT220004M(ListParamBean prmData)
			throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220004M);

		// パラメータセット<条件>
		paramBean.setString(prmData.getCdKaisya());		// 会社コード
		paramBean.setString(prmData.getCdHanbaitn());	// 販売店コード
		paramBean.setString(UcarConst.KB_DISP_ON);		// DispFlgが１のもの

		ResultArrayList<Ucaa004mBean> t220004mList = executeSimpleSelectQuery(paramBean, Ucaa004mBean.class);

		return t220004mList;
	}

	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListDaoIF#updateSyaryoHannyu(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateSyaryoHannyu(Ucaa001gBean t220001gBean,
														String loginKbScenter,
														Timestamp executeDate,
														String kbData) throws TecDAOException {

		String executeSql
			= "UPDATE "
			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
//			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ UcarTableManager.getSyaryoHannyuUpdate(loginKbScenter, kbData)
			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
			+ "SET "
			+ "  NO_SYARYOU = ? "
			+ "  , DD_SIIRE = ? "
			+ "  , DT_KOSIN = ? "
			+ "  , CD_KSNSYA = ? "
			+ "  , CD_KSNAPP = ? "
			+ "WHERE "
			+ "  CD_KAISYA = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU = ? "
			+ "  AND NO_KANRI = ? ";

		// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
		// ログイン店舗コードで絞り込みを行う
		if (UcarConst.KB_DATA_UKETORI.equals(kbData)) {
			// 車両受取情報の場合
			executeSql += "  AND CD_UKETENPO    = ? ";
		} else {
			// 車両搬入情報、車両搬入情報(店舗用)の場合
			executeSql += "  AND CD_HANTENPO    = ? ";
		}
		// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<値>
		paramBean.setString(t220001gBean.getNoSyaryou());	// ai21車両NO
		paramBean.setString(t220001gBean.getDdSiire());		// ai21仕入日

		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220001gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220001gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220001gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220001gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220001gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220001gBean.getNoKanri());		// 管理番号
		// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
		paramBean.setString(t220001gBean.getCdHantenpo());// 搬入店舗コード、受取店舗コード
		// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListDaoIF#selectT220001g(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public Ucaa001gBean selectSyaryoHannyu(String cdKaisya,
											String cdHanbaitn,
											String ddHannyu,
											String noKanri,
											String loginKbScenter) throws TecDAOException {

		final String executeSql
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , CD_OKYAKU "
			+ "  , KJ_OKYAKUM "
			+ "  , CD_NORIKUSI "
			+ "  , KB_NOSYASYU "
			+ "  , CD_NOGYOTAI "
			+ "  , NO_NOSEIRI "
			+ "  , CD_HANTENPO "
			+ "  , MJ_SITKATA "
			+ "  , NO_SYADAI "
			+ "  , MJ_SYAMEI "
			+ "  , DD_SYODOTOR "
			+ "  , DD_SYKNMANR "
			+ "  , NO_KATARUIB "
			+ "  , CD_TOSYOKU "
			+ "  , NU_SOUKUKM "
			+ "  , CD_SIRTENPO "
			+ "  , CD_SDTAN "
			+ "  , KI_NYUKOK "
			+ "  , CD_KOZINZYHO "
			+ "  , NO_ZYUTYU "
			+ "  , MJ_UKETAN "
			+ "  , NO_SYARYOU "
			+ "  , DD_SIIRE "
			+ "  , MJ_BIKOU "
			+ "  , DT_ZAIKO "
			+ "  , DT_KOUTEI "
			+ "  , DD_INKANKGN "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
//			+ "  T220001G "
			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
			+ UcarTableManager.getSyaryoHannyuSelectOnly(loginKbScenter) + " "
			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
			+ "WHERE "
			+ "  CD_KAISYA = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU = ? "
			+ "  AND NO_KANRI = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdHanbaitn);	// 販売店コード
		paramBean.setString(ddHannyu);		// 搬入日
		paramBean.setString(noKanri);		// 管理番号

		ResultArrayList<Ucaa001gBean> ucca001gList = executeSimpleSelectQuery(paramBean, Ucaa001gBean.class);

		Ucaa001gBean t220001gBean = null;
		if (ucca001gList.size() > 0) {
			t220001gBean = ucca001gList.get(0);
		}

		return t220001gBean;
	}
	// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end
}