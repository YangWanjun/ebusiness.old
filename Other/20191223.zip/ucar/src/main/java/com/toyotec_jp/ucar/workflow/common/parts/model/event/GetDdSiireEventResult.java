package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>ai21仕入日取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/05/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetDdSiireEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** ai21仕入日 */
	private String ddSiire;

	/**
	 * ddSiireを取得する。
	 * @return ddSiire ai21仕入日
	 */
	public String getDdSiire() {
		return ddSiire;
	}

	/**
	 * ddSiireを設定する。
	 * @param ddSiire ai21仕入日
	 */
	public void setDdSiire(String ddSiire) {
		this.ddSiire = ddSiire;
	}

}
