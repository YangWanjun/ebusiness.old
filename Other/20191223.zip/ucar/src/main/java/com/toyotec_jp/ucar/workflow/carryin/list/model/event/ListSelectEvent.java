package com.toyotec_jp.ucar.workflow.carryin.list.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListParamBean;

/**
 * @category [[車両搬入一覧]]
 */
public class ListSelectEvent extends UcarEvent {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private ListParamBean listParamBean;
	private String sortParam;
	private String sortOrder;
	private String pageNo;
	private String pageSize;
	private String isKensakuOn;

	public ListSelectEvent() {

	}

	/**
	 * 検索パラメータを取得します
	 * @return
	 */
	public ListParamBean getListParamBean() {
		return listParamBean;
	}

	/**
	 * 検索パラメーターを設定します
	 * @param prmData
	 */
	public void setListParamBean(ListParamBean listParamBean) {
		this.listParamBean = listParamBean;
	}

	/**
	 *
	 * @return
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	/**
	 * ソートパラメータを返却します
	 * @return
	 */
	public String getSortParam() {
		return sortParam;
	}

	/**
	 * ソートパラメーターを設定します
	 * @param sortParam
	 */
	public void setSortParam(String sortParam) {
		this.sortParam = sortParam;
	}

	/**
	 * ソート順を返却します
	 * @return
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * ソート順を設定します
	 * @param sortOrder
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * ページを返却します
	 * @return
	 */
	public String getPageNo() {
		return pageNo;
	}

	/**
	 * ページを設定します
	 * @param page
	 */
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}


	public String getIsKensakuOn() {
		return isKensakuOn;
	}

	public void setIsKensakuOn(String isKensakuOn) {
		this.isKensakuOn = isKensakuOn;
	}
}
