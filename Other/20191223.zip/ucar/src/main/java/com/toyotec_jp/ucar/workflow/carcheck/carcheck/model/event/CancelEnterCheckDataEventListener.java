package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventException;
import jp.co.intra_mart.framework.base.event.EventManagerException;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.UpdateZoneDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb005gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;

/**
 * <strong>入庫検査取消イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/19 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class CancelEnterCheckDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {
		TecLogger.trace("cancel registerData start");

		CancelEnterCheckDataEvent targetEvent = (CancelEnterCheckDataEvent) event;

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarCheckConst.APPID_CARCHECK_ENTERCHECK;

		ArrayList<String> selectDataList = new ArrayList<String>(Arrays.asList(targetEvent.getSelectData()));

		// DAOIF取得
		CarCheckDAOIF dao = getDAO(CarCheckDAOKey.CAR_CHECK_DAO, targetEvent, CarCheckDAOIF.class);

		int resultCount = 0;
		for (String selectData : selectDataList) {

			String[] arraySelectData = selectData.split(",");
			
			// ステータスDBチェック
			checkStatusDB(targetEvent, arraySelectData);
	
			// 入庫チェックDB：会社コード・販売店コード・搬入日・管理番号
//			T220008gBean t220008gBean = new T220008gBean(targetEvent.getCdKaisya(),
//			Uccb005gBean t220008gBean = new Uccb005gBean(targetEvent.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
//					targetEvent.getCdHanbaitn(),
														// 2019.03.31 T.Osada start
			Uccb005gBean t220008gBean = new Uccb005gBean(arraySelectData[0],
														arraySelectData[1],
														arraySelectData[2],
														arraySelectData[3],
														// 2019.03.31 T.Osada end
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
														targetEvent.getUserInfoBean().getCdTenpo(),	
														targetEvent.getUserInfoBean().getKbScenter());
														// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

			int countSelect = dao.selectT220008GCount(t220008gBean);
			if (countSelect == 0) {
				// 入庫チェックDBに削除対象のデータが無い場合
				continue;
			}

			String nyukoDtKosin = getNyukoDtKosin(targetEvent, arraySelectData);
			SimpleExecuteResultBean deleteResult = dao.deleteT220008G(t220008gBean, nyukoDtKosin);

			if (deleteResult.getExecuteCount() == 0) {
				// 削除件数が0件の場合は排他エラー
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
			}
			resultCount++;

			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
			// ステータスDB：会社コード・販売店コード・搬入日・管理番号
			//			   在庫店舗コード・商品化センター区分	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			//			   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start	
//			T220012gInputDataBean t220012gInputDataBean = new T220012gInputDataBean(targetEvent.getCdKaisya(),
//			Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(targetEvent.getCdKaisya(),
//					targetEvent.getCdHanbaitn(),
																					// 2019.03.31 T.Osada Strat
			Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(arraySelectData[0],
																					arraySelectData[1],
																					arraySelectData[2],
																					arraySelectData[3],
																					// 2019.03.31 T.Osada
																					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																					targetEvent.getUserInfoBean().getCdTenpo(),	
																					targetEvent.getUserInfoBean().getKbScenter(),
																					// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																					updateUserId,
																					updateUserId,
																					updateAppId,
																					updateAppId);

			// ステータスDB：ステータス05
			t220012gInputDataBean.setStrDtStatus05(null);
			// ステータスDB:ステータス06
			t220012gInputDataBean.setStrDtStatus06(null);

			// ステータス更新処理
			SimpleExecuteResultBean updateStatusResult = dao.updateT220012GEnterCheck(t220012gInputDataBean, executeDate);
			if (updateStatusResult.getExecuteCount() == 0) {
				// 更新件数が0件の場合はInsert処理

				// Insertの場合はステータス01をセット
				String strDtStatus01 = UcarUtils.getStringDateFormatShort(arraySelectData[0]);
				t220012gInputDataBean.setStrDtStatus01(strDtStatus01);

				dao.insertT220012G(t220012gInputDataBean, executeDate);
			}
			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

			// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
			UpdateZoneDateEvent updateZoneDateEvent
				= createEvent(UcarEventKey.UPDATE_ZONE_DATE, targetEvent.getUserInfo(), UpdateZoneDateEvent.class);

			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//			T220001gPKBean t220001gPKBean = new T220001gPKBean(targetEvent.getCdKaisya(),
//			Uccb007gPKBean t220001gPKBean = new Uccb007gPKBean(targetEvent.getCdKaisya(),
//					targetEvent.getCdHanbaitn(),
																// 2019.03.31 T.Osada Strat
			Uccb007gPKBean t220001gPKBean = new Uccb007gPKBean(arraySelectData[0],
																arraySelectData[1],
																arraySelectData[2],
																arraySelectData[3],
																// 2019.03.31 T.Osada end
																// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
																targetEvent.getUserInfoBean().getCdTenpo(),	
																targetEvent.getUserInfoBean().getKbScenter());
																// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

//			updateZoneDateEvent.setT220001gPkBean(t220001gPKBean);
			updateZoneDateEvent.setT220107gPkBean(t220001gPKBean);					// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２			
//			updateZoneDateEvent.setT220012gInputDataBean(t220012gInputDataBean);
			updateZoneDateEvent.setUccb007gInputDataBean(t220012gInputDataBean);	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			updateZoneDateEvent.setExecuteDtStatus03(false);
			updateZoneDateEvent.setExecuteDtStatus05(true);
			updateZoneDateEvent.setExecuteDtStatus07(false);

			updateZoneDateEvent.setExecuteDate(executeDate);

			// イベント実行
			dispatchEvent(updateZoneDateEvent);
			// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため end

		}

		CancelEnterCheckDataEventResult eventResult = new CancelEnterCheckDataEventResult();
		eventResult.setCountExecute(resultCount);

		TecLogger.trace("cancel registerData end");
		return eventResult;
	}

	/**
	 * ステータスDBチェック
	 * @param targetEvent
	 * @param arraySelectData
	 * @throws TecSystemException
	 * @throws EventManagerException
	 * @throws EventException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void checkStatusDB(CancelEnterCheckDataEvent targetEvent,
								String[] arraySelectData)
			throws TecSystemException, EventManagerException, EventException,
			SystemException, ApplicationException {

		CheckStatusEvent checkStatusEvent
			= createEvent(UcarEventKey.CHECK_STATUS, targetEvent.getUserInfo(), CheckStatusEvent.class);

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
//		T220001gPKBean t220001gPkBean = new T220001gPKBean(targetEvent.getCdKaisya(),
//															targetEvent.getCdHanbaitn(),
//															arraySelectData[0],
//															arraySelectData[1]);
		Uccb007gPKBean t220107gPKBean = new Uccb007gPKBean(targetEvent.getCdKaisya(),
															targetEvent.getCdHanbaitn(),
															arraySelectData[0],
															arraySelectData[1],
															targetEvent.getUserInfoBean().getCdTenpo(),	
															targetEvent.getUserInfoBean().getKbScenter());
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		
//		checkStatusEvent.setT220001gPkBean(t220001gPkBean);
		checkStatusEvent.setT220107gPkBean(t220107gPKBean);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// ステータス07から
		checkStatusEvent.setStartDtStatus(7);
		// ステータス08まで
		checkStatusEvent.setEndDtStatus(8);
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		// イベント実行
		CheckStatusEventResult checkStatusResult
			= (CheckStatusEventResult)dispatchEvent(checkStatusEvent);

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		if (checkStatusResult.isExistDtStatus()) {
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
			throw new TecApplicationException("次工程に入力があるため、削除できません。");
		}
	}

	/**
	 * 入庫チェックDB データ更新日時取得
	 * <pre>
	 * 取得したデータ更新日時を使用して、排他制御を実行する
	 * </pre>
	 * @param targetEvent
	 * @param arraySelectData
	 * @return
	 */
	private String getNyukoDtKosin(CancelEnterCheckDataEvent targetEvent, String[] arraySelectData) {

		String nyukoDtKosin = null;

		for (CarCheckDataBean carCheckDataBean : targetEvent.getCarCheckDataList()) {
			// 画面表示リスト件数分

			// 2019.03.31 T.Osada Strat
//			if (targetEvent.getCdKaisya().equals(carCheckDataBean.getCdKaisya())
//				&& targetEvent.getCdHanbaitn().equals(carCheckDataBean.getCdHanbaitn())
//				&& arraySelectData[0].equals(carCheckDataBean.getDdHannyu())
//				&& arraySelectData[1].equals(carCheckDataBean.getNoKanri())) {
			if (arraySelectData[0].equals(carCheckDataBean.getCdKaisya())
					&& arraySelectData[1].equals(carCheckDataBean.getCdHanbaitn())
					&& arraySelectData[2].equals(carCheckDataBean.getDdHannyu())
					&& arraySelectData[3].equals(carCheckDataBean.getNoKanri())) {
				// 更新対象のキーと一致した場合
				// 2019.03.31 T.Osada end

				if (carCheckDataBean.getNyukoDtKosin() != null) {
					// 入庫チェックDBのデータ更新日時がNullでなければ、更新日時を取得
					nyukoDtKosin = DateUtils.dateToString(carCheckDataBean.getNyukoDtKosin(), DateUtils.DB_FORMAT_LONG_M);
				}
				break;
			}
		}
		return nyukoDtKosin;
	}

}
