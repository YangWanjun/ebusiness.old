package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.event;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.utils.NumericUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst;
import com.toyotec_jp.ucar.workflow.adjustment.common.AdjustmentConst.AdjustmentDAOKey;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.data.SalesAdjustmentDAOIF;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentDataBean;
import com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object.SalesAdjustmentRuisekiDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetSyouhizeirituEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetSyouhizeirituEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb004gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb005gBean;
import com.toyotec_jp.ucar.workflow.receipt.common.ReceiptConst;

/**
 * <strong>精算イベントリスナ</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/25 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SaveSalesAdjustmentDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		SaveSalesAdjustmentDataEvent targetEvent = (SaveSalesAdjustmentDataEvent)event;

		// DAOIF取得
		SalesAdjustmentDAOIF executeDao = getDAO(AdjustmentDAOKey.SALESADJUSTMENT_DAO, targetEvent, SalesAdjustmentDAOIF.class);

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = AdjustmentConst.APPID_ADJUSTMENT_SALESADJUSTMENT;

		if (targetEvent.isExecuteAdjustment() == true) {
			// 受注明細情報
			updateT220212g(targetEvent, executeDao, executeDate, updateUserId, updateAppId);
		}
		// 売上精算情報
		insertT220214g(targetEvent, executeDao, executeDate, updateUserId, updateAppId);

		// 売上集計累積情報
		if (targetEvent.isExecuteAdjustment() == true) {

			insertT220215g(targetEvent, executeDao, executeDate, updateUserId, updateAppId);

		} else {
			// 精算取消の場合

			insertCancelT220215g(targetEvent, executeDao, executeDate, updateUserId, updateAppId);

		}

		// 受注情報
		updateT220211g(targetEvent, executeDao, executeDate, updateUserId, updateAppId);

		return null;
	}

	/**
	 * キャンセルデータ作成処理
	 * @param targetEvent
	 * @param executeDao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecDAOException
	 */
	private void insertCancelT220215g(SaveSalesAdjustmentDataEvent targetEvent,
										SalesAdjustmentDAOIF executeDao,
										Timestamp executeDate,
										String updateUserId,
										String updateAppId) throws TecDAOException {

		SalesAdjustmentDataBean salesAdjustmentDataBean = targetEvent.getSalesAdjustmentDataBean();

		Ucbb005gBean t220215gBean = new Ucbb005gBean(salesAdjustmentDataBean.getCdKaisya(),
													salesAdjustmentDataBean.getCdJigyosyo(),
													salesAdjustmentDataBean.getNoJucyu());

		ResultArrayList<Ucbb005gBean> cancelTargetDataList = executeDao.selectT220215GCancel(t220215gBean);

		Ucbb005gBean cancelDataBean = new Ucbb005gBean(salesAdjustmentDataBean.getCdKaisya(),
														salesAdjustmentDataBean.getCdJigyosyo(),
														salesAdjustmentDataBean.getNoJucyu());

		// 連番最大値を取得する
		String noRenban = createMaxRenban(executeDao, cancelDataBean);

		for (Ucbb005gBean cancelTargetDataBean : cancelTargetDataList) {

			cancelDataBean = new Ucbb005gBean(salesAdjustmentDataBean.getCdKaisya(),
												salesAdjustmentDataBean.getCdJigyosyo(),
												salesAdjustmentDataBean.getNoJucyu());

			cancelDataBean.setNoRenban(noRenban);	// 連番

			// 仕訳区分
			cancelDataBean.setKbSiwake(cancelTargetDataBean.getKbSiwake());
			// キャンセル区分
			cancelDataBean.setKbCancel("1");
			// 販売店コード
			cancelDataBean.setCdHanbaitn(cancelTargetDataBean.getCdHanbaitn());
			// 振替部門コード
			cancelDataBean.setCdFrbumon(null);
			// 売上日
			cancelDataBean.setDdUriage(executeDate);

			// 工賃　原価
			cancelDataBean.setKiGenkou(cancelTargetDataBean.getKiGenkou() * -1);
			// 工賃　売価
			cancelDataBean.setKiBaikou(cancelTargetDataBean.getKiBaikou() * -1);
			// 部品　原価
			cancelDataBean.setKiGenbuhin(cancelTargetDataBean.getKiGenbuhin() * -1);
			// 部品　売価
			cancelDataBean.setKiBaibuhin(cancelTargetDataBean.getKiBaibuhin() * -1);
			// 油脂　原価
			cancelDataBean.setKiGenyusi(cancelTargetDataBean.getKiGenyusi() * -1);
			// 油脂　売価
			cancelDataBean.setKiBaiyusi(cancelTargetDataBean.getKiBaiyusi() * -1);
			// 外注　原価
			cancelDataBean.setKiGengai(cancelTargetDataBean.getKiGengai() * -1);
			// 外注　売価
			cancelDataBean.setKiBaigai(cancelTargetDataBean.getKiBaigai() * -1);

			// 消費税
			cancelDataBean.setKiTax(cancelTargetDataBean.getKiTax() * -1);
			// 消費税率
			cancelDataBean.setSuTaxritu(cancelTargetDataBean.getSuTaxritu());

			// 備考
			cancelDataBean.setMjBikou(null);

			// データ作成日時
			cancelDataBean.setDtSakusei(executeDate);
			// データ更新日時
			cancelDataBean.setDtKosin(executeDate);
			// 作成ユーザID
			cancelDataBean.setCdSksisya(updateUserId);
			// 更新ユーザID
			cancelDataBean.setCdKsnsya(updateUserId);
			// 作成アプリID
			cancelDataBean.setCdSksiapp(updateAppId);
			// 更新アプリID
			cancelDataBean.setCdKsnapp(updateAppId);

			executeDao.insertT220215g(cancelDataBean);
		}
	}

	/**
	 * 最大連番作成処理
	 * @param executeDao
	 * @param t220215gBean
	 * @return
	 * @throws TecDAOException
	 */
	private String createMaxRenban(SalesAdjustmentDAOIF executeDao,
			Ucbb005gBean t220215gBean) throws TecDAOException {

		String noRenban = "";
		String maxNoRenban = executeDao.selectT220215GMaxNoRenban(t220215gBean);
		if (maxNoRenban  == null) {
			// データが無い場合
			noRenban = "01";
		} else {
			// データがある場合
			int intNoSagyo = Integer.parseInt(maxNoRenban) + 1;
			noRenban = StringUtils.padLeft(String.valueOf(intNoSagyo), new Character('0'), 2);
		}
		return noRenban;
	}

	/**
	 * 売上集計累積作成処理
	 * @param targetEvent
	 * @param executeDao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws ApplicationException
	 * @throws SystemException
	 */
	private void insertT220215g(SaveSalesAdjustmentDataEvent targetEvent,
								SalesAdjustmentDAOIF executeDao, Timestamp executeDate,
								String updateUserId, String updateAppId) throws ApplicationException, SystemException {

		SalesAdjustmentDataBean salesAdjustmentDataBean = targetEvent.getSalesAdjustmentDataBean();

		Ucbb002gBean t220212gBean = new Ucbb002gBean(salesAdjustmentDataBean.getCdKaisya(),
													salesAdjustmentDataBean.getCdJigyosyo(),
													salesAdjustmentDataBean.getNoJucyu());

		// 受注明細情報の売価合計：社内区分がブランク(社内振替なし)のデータが対象
		ResultArrayList<SalesAdjustmentRuisekiDataBean> ruisekiDataList = executeDao.selectT220212GSumKiBaika(t220212gBean, true);

		// 値引合計(得意先値引き+値引き)
		BigDecimal bdKiNebiki = new BigDecimal(salesAdjustmentDataBean.getKiTnebiki() + salesAdjustmentDataBean.getKiNebiki());
		// 全体売上額(=画面項目：売上額)
		BigDecimal bdKiUriage = new BigDecimal(salesAdjustmentDataBean.getKiUriage());

		ResultArrayList<SalesAdjustmentRuisekiDataBean> anbunDataList = new ResultArrayList<SalesAdjustmentRuisekiDataBean>();

		if (bdKiNebiki.intValue() > 0) {
			// 値引き金額(得意先値引き+値引き)が存在する場合
			createAnbunKiNebiki(executeDao, ruisekiDataList, anbunDataList,
								salesAdjustmentDataBean, t220212gBean, bdKiNebiki,
								bdKiUriage);
		}

		createAnbunKiTax(executeDao, ruisekiDataList, anbunDataList,
						salesAdjustmentDataBean, t220212gBean, bdKiNebiki, bdKiUriage);

		// 外注仕入情報の原価合計（仕入金額 - 消費税）を取得する
		int kiGengai = createGaichuGoukeiZeinuki(executeDao, t220212gBean);

		Ucbb002gBean urikamo002gBean = new Ucbb002gBean(salesAdjustmentDataBean.getCdKaisya(),
														salesAdjustmentDataBean.getCdJigyosyo(),
														salesAdjustmentDataBean.getNoJucyu());
		urikamo002gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_GAICHU);
		// 売上科目区分'4'（外注）の受注明細情報.原価の合計を取得する
		int sumUrikamoGaichu = executeDao.selectT220212GSumKingaku(urikamo002gBean, false).getKiGenka();

		int diffGaichu = kiGengai - sumUrikamoGaichu;
		boolean diffAddFlg = true;

		// 仕訳区分単位、売上科目区分別の原価合計、売価合計を求める
		ResultArrayList<SalesAdjustmentRuisekiDataBean> insertDataList = executeDao.selectT220212GSumKiBaika(t220212gBean, false);

		HashMap<String, Integer> sumKiGenkaMap 			= new HashMap<String, Integer>();

		for (SalesAdjustmentRuisekiDataBean insertBean : insertDataList) {
			// 原価
			sumKiGenkaMap.put(insertBean.getKbSiwake() + "," + insertBean.getKbUrikamo(), insertBean.getSumKiGenka());
		}

		ResultArrayList<SalesAdjustmentRuisekiDataBean> insertDataIsNullList = executeDao.selectT220212GSumKiBaika(t220212gBean, true);

		HashMap<String, Integer> sumKiBaikaZeinukiMap 	= new HashMap<String, Integer>();
		HashMap<String, Integer> sumKiTaxMap		 	= new HashMap<String, Integer>();

		for (SalesAdjustmentRuisekiDataBean insertBean : insertDataIsNullList) {
			// 売価(税抜)：売価-消費税
			sumKiBaikaZeinukiMap.put(insertBean.getKbSiwake() + "," + insertBean.getKbUrikamo(), insertBean.getSumKiBaika() - insertBean.getSumKiTax());
			// 消費税
			sumKiTaxMap.put(insertBean.getKbSiwake() + "," + insertBean.getKbUrikamo(), insertBean.getSumKiTax());
		}

		// Insert対象の仕訳区分を取得する
		ResultArrayList<SalesAdjustmentRuisekiDataBean> targetKbSiwakeDataList = executeDao.selectT220212G(t220212gBean);

		Ucbb005gBean t220215gBean = new Ucbb005gBean(salesAdjustmentDataBean.getCdKaisya(),
													  salesAdjustmentDataBean.getCdJigyosyo(),
													  salesAdjustmentDataBean.getNoJucyu());

		// 最大連番作成
		String noRenban = createMaxRenban(executeDao, t220215gBean);

		// 売上集計累積情報にデータを新規登録する
		for (SalesAdjustmentRuisekiDataBean targetKbSiwakeDataBean : targetKbSiwakeDataList) {

			t220215gBean = new Ucbb005gBean(salesAdjustmentDataBean.getCdKaisya(),
											salesAdjustmentDataBean.getCdJigyosyo(),
											salesAdjustmentDataBean.getNoJucyu());

			t220215gBean.setNoRenban(noRenban);	// 連番

			// 仕訳区分
			t220215gBean.setKbSiwake(targetKbSiwakeDataBean.getKbSiwake());
			// キャンセル区分
			t220215gBean.setKbCancel(null);
			// 販売店コード
			t220215gBean.setCdHanbaitn(salesAdjustmentDataBean.getCdHanbaitn());
			// 振替部門コード
			t220215gBean.setCdFrbumon(null);
			// 売上日
			t220215gBean.setDdUriage(executeDate);

			Integer sumKiGenkaKoutin 	= sumKiGenkaMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_KOUTIN);
			Integer sumKiGenkaBuhin 	= sumKiGenkaMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_BUHIN);
			Integer sumKiGenkaYusi 		= sumKiGenkaMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_YUSI);
			Integer sumKiGenkaGaichu 	= sumKiGenkaMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_GAICHU);

			Integer sumKiBaikaKoutin 	= 0;
			Integer sumKiBaikaBuhin 	= 0;
			Integer sumKiBaikaYusi 		= 0;
			Integer sumKiBaikaGaichu 	= 0;

			if (bdKiNebiki.intValue() > 0) {
				// 値引き金額(得意先値引き+値引き)が存在する場合
				sumKiBaikaKoutin 	= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_KOUTIN).getKiBaikaZeinuki();
				sumKiBaikaBuhin 	= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_BUHIN).getKiBaikaZeinuki();
				sumKiBaikaYusi 		= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_YUSI).getKiBaikaZeinuki();
				sumKiBaikaGaichu 	= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_GAICHU).getKiBaikaZeinuki();
			} else {
				sumKiBaikaKoutin 	= NumericUtils.defaultValue(sumKiBaikaZeinukiMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_KOUTIN));
				sumKiBaikaBuhin 	= NumericUtils.defaultValue(sumKiBaikaZeinukiMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_BUHIN));
				sumKiBaikaYusi 		= NumericUtils.defaultValue(sumKiBaikaZeinukiMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_YUSI));
				sumKiBaikaGaichu 	= NumericUtils.defaultValue(sumKiBaikaZeinukiMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_GAICHU));
			}

			if (sumKiGenkaKoutin != null) {

				// 工賃　原価
				t220215gBean.setKiGenkou(sumKiGenkaKoutin);
				// 工賃　売価
				t220215gBean.setKiBaikou(sumKiBaikaKoutin);

			}
			if (sumKiGenkaBuhin != null) {

				// 部品　原価
				t220215gBean.setKiGenbuhin(sumKiGenkaBuhin);
				// 部品　売価
				t220215gBean.setKiBaibuhin(sumKiBaikaBuhin);

			}
			if (sumKiGenkaYusi != null) {

				// 油脂　原価
				t220215gBean.setKiGenyusi(sumKiGenkaYusi);
				// 油脂　売価
				t220215gBean.setKiBaiyusi(sumKiBaikaYusi);

			}
			if (sumKiGenkaGaichu != null) {

				// 外注　原価
				int sumKiGenka = sumKiGenkaGaichu;

				// 原価調整を行う
				if (sumKiGenka > 0 && diffAddFlg) {
					sumKiGenka += diffGaichu;
					diffAddFlg = false;
				}
				t220215gBean.setKiGengai(sumKiGenka);
				// 外注　売価
				t220215gBean.setKiBaigai(sumKiBaikaGaichu);

			}

			// 消費税
			int sumKiTaxKoutin 	= 0;
			int sumKiTaxBuhin 	= 0;
			int sumKiTaxYusi 	= 0;
			int sumKiTaxGaichu 	= 0;

			if (bdKiNebiki.intValue() > 0) {
				// 値引き金額(得意先値引き+値引き)が存在する場合
				sumKiTaxKoutin 	= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_KOUTIN).getSumKiTax();
				sumKiTaxBuhin 	= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_BUHIN).getSumKiTax();
				sumKiTaxYusi 	= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_YUSI).getSumKiTax();
				sumKiTaxGaichu 	= getKiBaikaZeinuki(anbunDataList, targetKbSiwakeDataBean, ReceiptConst.KB_URIKAMO_GAICHU).getSumKiTax();
			} else {
				sumKiTaxKoutin 	= NumericUtils.defaultValue(sumKiTaxMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_KOUTIN));
				sumKiTaxBuhin 	= NumericUtils.defaultValue(sumKiTaxMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_BUHIN));
				sumKiTaxYusi 	= NumericUtils.defaultValue(sumKiTaxMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_YUSI));
				sumKiTaxGaichu 	= NumericUtils.defaultValue(sumKiTaxMap.get(targetKbSiwakeDataBean.getKbSiwake() + "," + ReceiptConst.KB_URIKAMO_GAICHU));
			}

			t220215gBean.setKiTax(sumKiTaxKoutin + sumKiTaxBuhin + sumKiTaxYusi + sumKiTaxGaichu);

			// 消費税率
			GetSyouhizeirituEvent syouhizeirituEvent = createEvent(UcarEventKey.GET_SYOUHIZEIRITU,
																	targetEvent.getUserInfo(),
																	GetSyouhizeirituEvent.class);
			syouhizeirituEvent.setCdKaisya(salesAdjustmentDataBean.getCdKaisya());
			syouhizeirituEvent.setCdJigyosyo(salesAdjustmentDataBean.getCdJigyosyo());
			syouhizeirituEvent.setTargetDate(new Date());
			GetSyouhizeirituEventResult syouhizeirituResult = (GetSyouhizeirituEventResult)dispatchEvent(syouhizeirituEvent);
			t220215gBean.setSuTaxritu(syouhizeirituResult.getBdSyouhizeiPercent().intValue());

			// 備考
			t220215gBean.setMjBikou(null);

			// データ作成日時
			t220215gBean.setDtSakusei(executeDate);
			// データ更新日時
			t220215gBean.setDtKosin(executeDate);
			// 作成ユーザID
			t220215gBean.setCdSksisya(updateUserId);
			// 更新ユーザID
			t220215gBean.setCdKsnsya(updateUserId);
			// 作成アプリID
			t220215gBean.setCdSksiapp(updateAppId);
			// 更新アプリID
			t220215gBean.setCdKsnapp(updateAppId);

			executeDao.insertT220215g(t220215gBean);
		}
	}

	/**
	 * 按分消費税作成
	 * @param executeDao
	 * @param ruisekiDataList
	 * @param anbunDataList
	 * @param salesAdjustmentDataBean
	 * @param t220212gBean
	 * @param bdKiNebiki
	 * @param bdKiUriage
	 * @throws TecDAOException
	 */
	private void createAnbunKiTax(SalesAdjustmentDAOIF executeDao,
			ResultArrayList<SalesAdjustmentRuisekiDataBean> ruisekiDataList,
			ResultArrayList<SalesAdjustmentRuisekiDataBean> anbunDataList,
			SalesAdjustmentDataBean salesAdjustmentDataBean,
			Ucbb002gBean t220212gBean, BigDecimal bdKiNebiki,
			BigDecimal bdKiUriage) throws TecDAOException {

		// 全体消費税(=画面項目：内消費税)
		BigDecimal bdKiTax 		= new BigDecimal(salesAdjustmentDataBean.getKiTax());

		int sumKitax = 0;
		int maxKitax = 0;
		int countKitax = 0;

		HashMap<String, Boolean> maxKiTaxCheckMap = new HashMap<String, Boolean>();

		for (SalesAdjustmentRuisekiDataBean ruisekiDataBean : ruisekiDataList) {
			// 仕訳区分単位、売上科目区分別に消費税を算出する

			// 仕訳区分単位、売上科目区分別売価合計
			BigDecimal bdSumKiBaika = new BigDecimal(ruisekiDataBean.getSumKiBaika());
			// 全体の内消費税×受注明細情報の仕訳区分、科目ごとの売価の合計÷売上額合計(小数点以下切捨て)
			BigDecimal bdUrikamoTax;
			if (bdKiUriage.intValue() == 0) {
				bdUrikamoTax = new BigDecimal(0);
			} else {
				bdUrikamoTax = bdKiTax.multiply(bdSumKiBaika).divide(bdKiUriage, 0, BigDecimal.ROUND_DOWN);
			}

			SalesAdjustmentRuisekiDataBean aubunDataBean = new SalesAdjustmentRuisekiDataBean(ruisekiDataBean.getKbSiwake(),
																						  	   ruisekiDataBean.getKbUrikamo());

			// 売価合計
			aubunDataBean.setSumKiBaika(ruisekiDataBean.getSumKiBaika());
			// 仕訳区分単位、売上科目区分別消費税
			int intUrikamoTax = bdUrikamoTax.intValue();
			aubunDataBean.setSumKiTax(intUrikamoTax);

			// 按分合計消費税の作成
			sumKitax += intUrikamoTax;

			if (maxKitax < intUrikamoTax) {
				maxKitax = intUrikamoTax;
				countKitax = 1;

				// 最高金額のパターンが複数件以上存在する場合に使用する
				maxKiTaxCheckMap.put(ruisekiDataBean.getKbSiwake() + "," + ruisekiDataBean.getKbUrikamo(), true);

			} else if (maxKitax == intUrikamoTax) {
				countKitax++;
				// 最高金額のパターンが複数件以上存在する場合に使用する
				maxKiTaxCheckMap.put(ruisekiDataBean.getKbSiwake() + "," + ruisekiDataBean.getKbUrikamo(), true);
			}

			if (bdKiNebiki.intValue() > 0) {
				// 値引きありの場合
				for (SalesAdjustmentRuisekiDataBean anbunDataBaseBean : anbunDataList) {
					if (anbunDataBaseBean.getKbSiwake().equals(aubunDataBean.getKbSiwake())
						&& anbunDataBaseBean.getKbUrikamo().equals(aubunDataBean.getKbUrikamo())) {
						// 仕訳区分、売上科目区分が一致した場合

						// 仕訳区分単位、売上科目区分別に消費税をセットする
						anbunDataBaseBean.setSumKiTax(aubunDataBean.getSumKiTax());
					}
				}
			} else {
				// 値引きなしの場合
				anbunDataList.add(aubunDataBean);
			}
		}

		// 全体消費税 - 按分合計消費税
		int deffTax = salesAdjustmentDataBean.getKiTax() - sumKitax;

		// 消費税が最大のものを求める
		if (countKitax == 1) {
			// 最大金額が1件の場合

			// 最大消費税を持つデータに差分消費税を加算する
			for (SalesAdjustmentRuisekiDataBean kiTaxDataBean : anbunDataList) {
				if (kiTaxDataBean.getSumKiTax() == maxKitax) {
					kiTaxDataBean.setSumKiTax(kiTaxDataBean.getSumKiTax() + deffTax);
				}
			}

		} else {
			// 複数件の場合

			// 仕訳区分コードを取得する
			ResultArrayList<Ucba004mBean> kbSiwakeList = executeDao.selectT220204MCdKubun(t220212gBean);

			// 売上科目区分チェックパターン：外注→工賃→部品→油脂
			String kbUrikamoCheckPattern[] = {ReceiptConst.KB_URIKAMO_GAICHU,
											ReceiptConst.KB_URIKAMO_KOUTIN,
											ReceiptConst.KB_URIKAMO_BUHIN,
											ReceiptConst.KB_URIKAMO_YUSI};

			String targetKbSiwake = "";
			String targetKbUrikamo = "";

			loopBreak: for (Ucba004mBean kbSiwakeBean : kbSiwakeList) {
				for (String kbUrikamo : kbUrikamoCheckPattern) {
					Boolean targetFlg = maxKiTaxCheckMap.get(kbSiwakeBean.getCdKubun() + "," + kbUrikamo);
					if (targetFlg != null && targetFlg == true) {
						// 差分消費税加算対象の仕訳区分と売上科目区分を取得する
						targetKbSiwake = kbSiwakeBean.getCdKubun();
						targetKbUrikamo = kbUrikamo;

						// 加算対象が見つかった場合は、多重ループを抜ける
						break loopBreak;
					}
				}
			}

			// 差分消費税加算対象の仕訳区分と売上科目区分に差分消費税を加算する
			for (SalesAdjustmentRuisekiDataBean kiTaxDataBean : anbunDataList) {
				if (targetKbSiwake.equals(kiTaxDataBean.getKbSiwake()) && targetKbUrikamo.equals(kiTaxDataBean.getKbUrikamo())) {
					kiTaxDataBean.setSumKiTax(kiTaxDataBean.getSumKiTax() + deffTax);
					break;
				}
			}
		}
	}

	/**
	 * 按分値引き作成
	 * @param executeDao
	 * @param ruisekiDataList
	 * @param anbunDataList
	 * @param salesAdjustmentDataBean
	 * @param t220212gBean
	 * @param bdKiNebiki
	 * @param bdKiUriage
	 * @throws TecDAOException
	 */
	private void createAnbunKiNebiki(SalesAdjustmentDAOIF executeDao,
			ResultArrayList<SalesAdjustmentRuisekiDataBean> ruisekiDataList,
			ResultArrayList<SalesAdjustmentRuisekiDataBean> anbunDataList,
			SalesAdjustmentDataBean salesAdjustmentDataBean,
			Ucbb002gBean t220212gBean, BigDecimal bdKiNebiki,
			BigDecimal bdKiUriage) throws TecDAOException {
		int sumKiNebiki = 0;
		int maxKiNebiki = 0;
		int countKiNebiki = 0;

		HashMap<String, Boolean> maxKiNebikiCheckMap = new HashMap<String, Boolean>();

		for (SalesAdjustmentRuisekiDataBean ruisekiDataBean : ruisekiDataList) {
			// 仕訳区分単位、売上科目区分別に値引きを算出する

			// 仕訳区分単位、売上科目区分別売価合計
			BigDecimal bdSumKiBaika = new BigDecimal(ruisekiDataBean.getSumKiBaika());
			// 全体の値引き×受注明細情報の仕訳区分、科目ごとの売価の合計÷売上額合計(小数点以下切捨て)
			BigDecimal bdUrikamoNebiki;
			if (bdKiUriage.intValue() == 0) {
				bdUrikamoNebiki = new BigDecimal(0);
			} else {
				bdUrikamoNebiki = bdKiNebiki.multiply(bdSumKiBaika).divide(bdKiUriage, 0, BigDecimal.ROUND_DOWN);
			}

			SalesAdjustmentRuisekiDataBean aubunDataBean = new SalesAdjustmentRuisekiDataBean(ruisekiDataBean.getKbSiwake(),
																						  	   ruisekiDataBean.getKbUrikamo());

			// 売価合計
			aubunDataBean.setSumKiBaika(ruisekiDataBean.getSumKiBaika());
			// 仕訳区分単位、売上科目区分別値引き
			int intUrikamoNebiki = bdUrikamoNebiki.intValue();
			aubunDataBean.setSumKiNebiki(intUrikamoNebiki);

			// 按分合計値引きの作成
			sumKiNebiki += intUrikamoNebiki;

			if (maxKiNebiki < intUrikamoNebiki) {
				maxKiNebiki = intUrikamoNebiki;
				countKiNebiki = 1;

				// 最高金額のパターンが複数件以上存在する場合に使用する
				maxKiNebikiCheckMap.put(ruisekiDataBean.getKbSiwake() + "," + ruisekiDataBean.getKbUrikamo(), true);

			} else if (maxKiNebiki == intUrikamoNebiki) {
				countKiNebiki++;
				// 最高金額のパターンが複数件以上存在する場合に使用する
				maxKiNebikiCheckMap.put(ruisekiDataBean.getKbSiwake() + "," + ruisekiDataBean.getKbUrikamo(), true);
			}

			anbunDataList.add(aubunDataBean);
		}

		// (得意先値引き + 値引き) - 按分合計値引き
		int deffNebiki = (salesAdjustmentDataBean.getKiTnebiki() + salesAdjustmentDataBean.getKiNebiki()) - sumKiNebiki;

		// 消費税が最大のものを求める
		if (countKiNebiki == 1) {
			// 最大金額が1件の場合

			// 最大消費税を持つデータに差分消費税を加算する
			for (SalesAdjustmentRuisekiDataBean kiNebikiDataBean : anbunDataList) {
				if (kiNebikiDataBean.getSumKiNebiki() == maxKiNebiki) {
					kiNebikiDataBean.setSumKiNebiki(kiNebikiDataBean.getSumKiNebiki() + deffNebiki);
				}
			}

		} else {
			// 複数件の場合

			// 仕訳区分コードを取得する
			ResultArrayList<Ucba004mBean> kbSiwakeList = executeDao.selectT220204MCdKubun(t220212gBean);

			// 売上科目区分チェックパターン：外注→工賃→部品→油脂
			String kbUrikamoCheckPattern[] = {ReceiptConst.KB_URIKAMO_GAICHU,
											ReceiptConst.KB_URIKAMO_KOUTIN,
											ReceiptConst.KB_URIKAMO_BUHIN,
											ReceiptConst.KB_URIKAMO_YUSI};

			String targetKbSiwake = "";
			String targetKbUrikamo = "";

			loopBreak: for (Ucba004mBean kbSiwakeBean : kbSiwakeList) {
				for (String kbUrikamo : kbUrikamoCheckPattern) {
					Boolean targetFlg = maxKiNebikiCheckMap.get(kbSiwakeBean.getCdKubun() + "," + kbUrikamo);
					if (targetFlg != null && targetFlg == true) {
						// 差分値引き加算対象の仕訳区分と売上科目区分を取得する
						targetKbSiwake = kbSiwakeBean.getCdKubun();
						targetKbUrikamo = kbUrikamo;

						// 加算対象が見つかった場合は、多重ループを抜ける
						break loopBreak;
					}
				}
			}

			// 差分値引き加算対象の仕訳区分と売上科目区分に差分値引きを加算する
			for (SalesAdjustmentRuisekiDataBean kiNebikiDataBean : anbunDataList) {
				if (targetKbSiwake.equals(kiNebikiDataBean.getKbSiwake()) && targetKbUrikamo.equals(kiNebikiDataBean.getKbUrikamo())) {
					kiNebikiDataBean.setSumKiNebiki(kiNebikiDataBean.getSumKiNebiki() + deffNebiki);
					break;
				}
			}
		}
	}

	/**
	 * 外注合計税抜作成
	 * @param getDao
	 * @param t220212gBean
	 * @throws TecDAOException
	 */
	private int createGaichuGoukeiZeinuki(SalesAdjustmentDAOIF getDao,
											Ucbb002gBean t220212gBean) throws TecDAOException {

		// 伝票NOを取得する
		ResultArrayList<Ucbb003gBean> noDenpyoList = getDao.selectT220213GNoDenpyo(t220212gBean);

		// 仕入金額、消費税を取得する
		int kiSiire = 0;
		int kiTax = 0;
		for (Ucbb003gBean t220213gBean : noDenpyoList) {
			Ucbb003gBean kingakuBean = getDao.selectT220213GKingaku(t220213gBean);
			if (kingakuBean != null) {
				kiSiire += kingakuBean.getKiSiire();
				kiTax 	+= kingakuBean.getKiTax();
			}
		}

		return kiSiire - kiTax;
	}

	/**
	 * 売価(税抜)/消費税取得処理
	 * @param anbunDataList
	 * @param targetDataBean
	 * @param kbUrikamo
	 * @return
	 */
	private SalesAdjustmentRuisekiDataBean getKiBaikaZeinuki(ResultArrayList<SalesAdjustmentRuisekiDataBean> anbunDataList,
															  SalesAdjustmentRuisekiDataBean targetDataBean,
															  String kbUrikamo) {

		SalesAdjustmentRuisekiDataBean returnBean = new SalesAdjustmentRuisekiDataBean();

		if (ReceiptConst.KB_SYANAI_SYANAI.equals(targetDataBean.getKbSyanai())) {
			// 社内の場合は処理なし
		} else {
			for (SalesAdjustmentRuisekiDataBean anbunDataBean : anbunDataList) {
				if (targetDataBean.getKbSiwake().equals(anbunDataBean.getKbSiwake())
					&& kbUrikamo.equals(anbunDataBean.getKbUrikamo())) {
					returnBean = anbunDataBean;
					break;
				}
			}
		}
		return returnBean;
	}

	/**
	 * 受注明細情報：売上科目区分更新処理
	 * @param targetEvent
	 * @param executeDao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecDAOException
	 */
	private void updateT220212g(SaveSalesAdjustmentDataEvent targetEvent,
			SalesAdjustmentDAOIF executeDao, Timestamp executeDate,
			String updateUserId, String updateAppId) throws TecDAOException {

		Ucbb002gBean t220212gBean = new Ucbb002gBean(targetEvent.getSalesAdjustmentDataBean().getCdKaisya(),
													targetEvent.getSalesAdjustmentDataBean().getCdJigyosyo(),
													targetEvent.getSalesAdjustmentDataBean().getNoJucyu());

		// 売上科目区分
		t220212gBean.setKbUrikamo(ReceiptConst.KB_URIKAMO_KOUTIN);

		// データ更新日時
		t220212gBean.setDtKosin(executeDate);
		// 更新ユーザID
		t220212gBean.setCdKsnsya(updateUserId);
		// 更新アプリID
		t220212gBean.setCdKsnapp(updateAppId);
		executeDao.updateT220212GKbUrikamo(t220212gBean);
	}

	/**
	 * 売上精算情報 新規登録処理
	 * @param targetEvent
	 * @param executeDao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecDAOException
	 */
	private void insertT220214g(SaveSalesAdjustmentDataEvent targetEvent,
			SalesAdjustmentDAOIF executeDao, Timestamp executeDate,
			String updateUserId, String updateAppId) throws TecDAOException {

		SalesAdjustmentDataBean salesAdjustmentDataBean = targetEvent.getSalesAdjustmentDataBean();
		Ucbb004gBean t220214gBean = new Ucbb004gBean(salesAdjustmentDataBean.getCdKaisya(),
													salesAdjustmentDataBean.getCdJigyosyo(),
													salesAdjustmentDataBean.getNoJucyu());

		// 連番最大値を取得する
		String noRenban = "";
		String maxNoRenban = executeDao.selectT220214GMaxNoRenban(t220214gBean);
		if (maxNoRenban  == null) {
			// データが無い場合
			noRenban = "01";
		} else {
			// データがある場合
			int intNoSagyo = Integer.parseInt(maxNoRenban) + 1;
			noRenban = StringUtils.padLeft(String.valueOf(intNoSagyo), new Character('0'), 2);
		}
		t220214gBean.setNoRenban(noRenban);	// 連番

		// キャンセル区分
		if (targetEvent.isExecuteAdjustment()) {
			t220214gBean.setKbCancel(null);
		} else {
			t220214gBean.setKbCancel("1");
		}

		t220214gBean.setCdHanbaitn(salesAdjustmentDataBean.getCdHanbaitn());// 販売店コード
		t220214gBean.setMjCustomer(salesAdjustmentDataBean.getMjCustomer());// 請求先お客様名
		t220214gBean.setDdUriage(executeDate);	// 売上日

		// 売上担当者
		if (targetEvent.isExecuteAdjustment()) {
			t220214gBean.setCdUritan(salesAdjustmentDataBean.getCdUritan());
		} else {
			// 精算取消時
			t220214gBean.setCdUritan(targetEvent.getCdUritanCancel());
		}

		if (targetEvent.isExecuteAdjustment()) {
			// 精算の場合
			t220214gBean.setKiSeikyu(salesAdjustmentDataBean.getKiSeikyu());	// 請求金額
			t220214gBean.setKiTax(salesAdjustmentDataBean.getKiTax());			// 消費税
			t220214gBean.setKiTnebiki(salesAdjustmentDataBean.getKiTnebiki());	// 得意先値引き
			t220214gBean.setKiNebiki(salesAdjustmentDataBean.getKiNebiki());	// 値引き
			t220214gBean.setKiGenka(salesAdjustmentDataBean.getKiGenka());		// 原価額
			t220214gBean.setKiUriage(salesAdjustmentDataBean.getKiUriage());	// 売上額
			t220214gBean.setKiSyanai(salesAdjustmentDataBean.getKiSyanai());	// 社内振替
		} else {
			// 精算取消の場合
			t220214gBean.setKiSeikyu(salesAdjustmentDataBean.getKiSeikyu() 	* -1);	// 請求金額
			t220214gBean.setKiTax(salesAdjustmentDataBean.getKiTax() 		* -1);	// 消費税
			t220214gBean.setKiTnebiki(salesAdjustmentDataBean.getKiTnebiki() * -1);	// 得意先値引き
			t220214gBean.setKiNebiki(salesAdjustmentDataBean.getKiNebiki() 	* -1);	// 値引き
			t220214gBean.setKiGenka(salesAdjustmentDataBean.getKiGenka() 	* -1);	// 原価額
			t220214gBean.setKiUriage(salesAdjustmentDataBean.getKiUriage() 	* -1);	// 売上額
			t220214gBean.setKiSyanai(salesAdjustmentDataBean.getKiSyanai() 	* -1);	// 社内振替
		}

		t220214gBean.setMjMessage(salesAdjustmentDataBean.getMjMessage());	// メッセージ

		Ucba004mBean ucba004gBean = new Ucba004mBean(salesAdjustmentDataBean.getCdKaisya(),
													salesAdjustmentDataBean.getCdJigyosyo(),
													"04");
		ucba004gBean.setMjInfo2(salesAdjustmentDataBean.getCdHanbaitn());

		String kbUrikake = executeDao.selectUcba004GKbUrikake(ucba004gBean);
		t220214gBean.setKbUrikake(kbUrikake);	// 売掛金管理区分

		if (targetEvent.isExecuteAdjustment()) {
			// 精算の場合
			t220214gBean.setKiGenkou(salesAdjustmentDataBean.getKiGenkou());	// 工賃　原価
			t220214gBean.setKiGenbuhin(salesAdjustmentDataBean.getKiGenbuhin());// 部品　原価
			t220214gBean.setKiGenyusi(salesAdjustmentDataBean.getKiGenyusi());	// 油脂　原価
			t220214gBean.setKiGengai(salesAdjustmentDataBean.getKiGengai());	// 外注　原価
			t220214gBean.setKiUrikou(salesAdjustmentDataBean.getKiUrikou());	// 工賃　売上
			t220214gBean.setKiUribuhin(salesAdjustmentDataBean.getKiUribuhin());// 部品　売上
			t220214gBean.setKiUriyusi(salesAdjustmentDataBean.getKiUriyusi());	// 油脂　売上
			t220214gBean.setKiUrigai(salesAdjustmentDataBean.getKiUrigai());	// 外注　売上
			t220214gBean.setKiSyafkou(salesAdjustmentDataBean.getKiSyafkou());	// 工賃　社内振替
			t220214gBean.setKiSyafbuhin(salesAdjustmentDataBean.getKiSyafbuhin());	// 部品　社内振替
			t220214gBean.setKiSyafyusi(salesAdjustmentDataBean.getKiSyafyusi());	// 油脂　社内振替
			t220214gBean.setKiSyafgai(salesAdjustmentDataBean.getKiSyafgai());	// 外注　社内振替
		} else {
			// 精算取消の場合
			t220214gBean.setKiGenkou(salesAdjustmentDataBean.getKiGenkou() 		* -1);	// 工賃　原価
			t220214gBean.setKiGenbuhin(salesAdjustmentDataBean.getKiGenbuhin() 	* -1);	// 部品　原価
			t220214gBean.setKiGenyusi(salesAdjustmentDataBean.getKiGenyusi() 	* -1);	// 油脂　原価
			t220214gBean.setKiGengai(salesAdjustmentDataBean.getKiGengai() 		* -1);	// 外注　原価
			t220214gBean.setKiUrikou(salesAdjustmentDataBean.getKiUrikou() 		* -1);	// 工賃　売上
			t220214gBean.setKiUribuhin(salesAdjustmentDataBean.getKiUribuhin() 	* -1);	// 部品　売上
			t220214gBean.setKiUriyusi(salesAdjustmentDataBean.getKiUriyusi() 	* -1);	// 油脂　売上
			t220214gBean.setKiUrigai(salesAdjustmentDataBean.getKiUrigai() 		* -1);	// 外注　売上
			t220214gBean.setKiSyafkou(salesAdjustmentDataBean.getKiSyafkou() 	* -1);	// 工賃　社内振替
			t220214gBean.setKiSyafbuhin(salesAdjustmentDataBean.getKiSyafbuhin() * -1);	// 部品　社内振替
			t220214gBean.setKiSyafyusi(salesAdjustmentDataBean.getKiSyafyusi() 	* -1);	// 油脂　社内振替
			t220214gBean.setKiSyafgai(salesAdjustmentDataBean.getKiSyafgai() 	* -1);	// 外注　社内振替
		}

		// データ作成日時
		t220214gBean.setDtSakusei(executeDate);
		// データ更新日時
		t220214gBean.setDtKosin(executeDate);
		// 作成ユーザID
		t220214gBean.setCdSksisya(updateUserId);
		// 更新ユーザID
		t220214gBean.setCdKsnsya(updateUserId);
		// 作成アプリID
		t220214gBean.setCdSksiapp(updateAppId);
		// 更新アプリID
		t220214gBean.setCdKsnapp(updateAppId);

		executeDao.insertT220214g(t220214gBean);
	}

	/**
	 * 受注情報：精算日更新処理
	 * @param targetEvent
	 * @param executeDao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecDAOException
	 */
	private void updateT220211g(SaveSalesAdjustmentDataEvent targetEvent,
			SalesAdjustmentDAOIF executeDao, Timestamp executeDate,
			String updateUserId, String updateAppId) throws TecDAOException {

		Ucbb001gBean t220211gBean = new Ucbb001gBean(targetEvent.getSalesAdjustmentDataBean().getCdKaisya(),
													targetEvent.getSalesAdjustmentDataBean().getCdJigyosyo(),
													targetEvent.getSalesAdjustmentDataBean().getNoJucyu());

		// 得意先値引適用区分
		t220211gBean.setKbNebiki(targetEvent.getSalesAdjustmentDataBean().getKbNebiki());
		// 依頼伝票NO
		t220211gBean.setNoIrdenpyo(targetEvent.getSalesAdjustmentDataBean().getNoIrdenpyo());

		// 2013/08/28 要望対応 start
		// ご用命事項区分
		t220211gBean.setKbGoyomei(targetEvent.getSalesAdjustmentDataBean().getKbGoyomei());
		// 2013/08/28 要望対応 end
		// 精算日
		if (targetEvent.isExecuteAdjustment()) {
			t220211gBean.setDdSeisan(executeDate);
		} else {
			t220211gBean.setDdSeisan(null);
		}

		// データ更新日時
		t220211gBean.setDtKosin(executeDate);
		// 更新ユーザID
		t220211gBean.setCdKsnsya(updateUserId);
		// 更新アプリID
		t220211gBean.setCdKsnapp(updateAppId);
		executeDao.updateT220211GDdSeisan(t220211gBean);
	}

}
