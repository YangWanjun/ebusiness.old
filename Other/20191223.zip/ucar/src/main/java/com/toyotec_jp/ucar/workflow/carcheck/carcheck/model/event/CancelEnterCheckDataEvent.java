package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;

/**
 * <strong>入庫検査取消イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/19 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class CancelEnterCheckDataEvent extends UcarEvent {

	private static final long serialVersionUID = -7744179601001490388L;

	/** 会社コード */
	private String	cdKaisya;
	/** 販売店コード */
	private String	cdHanbaitn;
	/** 搬入日、管理番号配列
	 * <pre>
	 * 形式：yyyymmdd,000(数値3桁)
	 * </pre>
	 *  */
	private String selectData[];

	/** 表示リスト(排他チェック用) */
	private List<CarCheckDataBean> carCheckDataList;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * selectDataを取得する。
	 * @return selectData
	 */
	public String[] getSelectData() {
		return selectData;
	}

	/**
	 * selectDataを設定する。
	 * @param selectData
	 */
	public void setSelectData(String[] selectData) {
		this.selectData = selectData;
	}

	/**
	 * carCheckDataListを取得する。
	 * @return carCheckDataList
	 */
	public List<CarCheckDataBean> getCarCheckDataList() {
		return carCheckDataList;
	}

	/**
	 * carCheckDataListを設定する。
	 * @param carCheckDataList
	 */
	public void setCarCheckDataList(List<CarCheckDataBean> carCheckDataList) {
		this.carCheckDataList = carCheckDataList;
	}

}