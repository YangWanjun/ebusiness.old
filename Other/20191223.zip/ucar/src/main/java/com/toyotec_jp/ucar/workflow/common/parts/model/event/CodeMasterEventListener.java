package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.CodeMasterDAOIF;

/**
 * <strong>コード区分マスタ操作用イベントリスナ。</strong>
 *
 * @author Y.M(TEC)
 * @version 1.00 2012/01/16 新規作成<br>
 * @since 1.00
 */
public class CodeMasterEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {
		CodeMasterEvent cmEvent = (CodeMasterEvent)event;
		CodeMasterDAOIF cmDaoIF = getDAO(UcarDAOKey.CODE_MASTER_DAO, event, CodeMasterDAOIF.class);
		
		if (cmEvent.getCdKaisya().equals("")) {	// 2013.03.01 C.Ohta 追加　搬入拠点分散
			return cmDaoIF.getCodeMasterList(cmEvent.getKbID()
											,cmEvent.getUserInfoBean());
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
		} else { 
			return cmDaoIF.getCodeMasterListD(cmEvent.getKbID()
											,cmEvent.getCdKaisya()
											,cmEvent.getCdJigyosyo());
		}	
		// 2013.03.01 C.Ohta 追加　搬入拠点分散　end
	}
}