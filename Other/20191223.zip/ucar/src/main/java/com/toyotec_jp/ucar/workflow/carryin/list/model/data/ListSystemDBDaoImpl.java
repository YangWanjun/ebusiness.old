package com.toyotec_jp.ucar.workflow.carryin.list.model.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.intra_mart.framework.base.data.DataAccessException;
import jp.co.intra_mart.framework.base.data.SharedDBDAO;

import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.ucar.batch.common.BatchUtils;
/**
 * <strong>車両搬入一覧 System Dao</strong>
 * <pre>
 *  system-data-sourceで直接addonDBにアクセスするために使用する
 * </pre>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/04 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class ListSystemDBDaoImpl extends SharedDBDAO implements ListSystemDBDaoIF {

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListDaoIF#selectAll()
	 */
	@Override
	public String selectDdSiire(String dbLink, String cdKaisya, String noSyaryou) throws DataAccessException {

		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String ddSiire = null;

		try {
			String executeSql
				= "SELECT "
				+ "    * "
				+ "FROM "
				+ "  TBBC001G" + dbLink + " "
				+ "WHERE "
				+ "  CD_KAISYA = ? "
				+ "  AND NO_SYARYOU = ? ";

			statement = getConnection().prepareStatement(executeSql);
			statement.setString(1, cdKaisya);
			statement.setString(2, noSyaryou);

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				ddSiire = resultSet.getString("DD_SIIRE");
			}

		} catch (Exception e) {
			// 接続できなくてもエラーは起こさない
			TecLogger.warn(BatchUtils.createLogString("ai21の中古車在庫情報取得ができませんでした。"));
			//throw new DataAccessException(e.getMessage(), e);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
			}
		}

		return ddSiire;
	}

}