/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】NumericUtils.java
 * 【  説  明  】
 * 【  作  成  】2010/06/08 T.H(SCC)
 * 【  変  更  】2012/10/18 H.T(TEC) defaultValueを追加
 */
package com.toyotec_jp.im_common.system.utils;

import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.StringTokenizer;

/**
 * <strong>数値チェック系ユーティリティクラス</strong>
 * <p>
 * 数値チェック関連支援処理を管理するクラス
 *
 * @author T.H(SCC)
 * @version 1.00 2010/06/08 新規作成<br>
 */
public class NumericUtils {

	/** 文字　ゼロ. */
	public static final String ZERO = "0";
	/** 文字　プラス. */
	public static final String PLUS = "+";
	/** 文字　マイナス. */
	public static final String MINUS;
	/** 文字　小数点	".". */
	public static final String PERIOD;
	/** 文字　桁	 ",". */
	public static final String COMMA;

	/** 数字の大小判定：パラメータ不良. */
	public static final int COMP_UNKNOWN = -3;
	/** 数字の大小判定：一致. */
	public static final int COMP_MATCH = 0;
	/** 数字の大小判定：A > B . */
	public static final int COMP_A_GREATER = 1;
	/** 数字の大小判定：A < B . */
	public static final int COMP_B_GREATER = -1;

	static {

        DecimalFormatSymbols ss = new DecimalFormatSymbols(Locale.getDefault());

        char[] dss = { ss.getDecimalSeparator() };
        PERIOD = new String(dss);

        char[] minus = { ss.getMinusSign() };
        MINUS = new String(minus);

        char[] conma = { ss.getGroupingSeparator() };
        COMMA = new String(conma);
    }

	/*
     * デフォルトコンストラクタ
     */
	private NumericUtils() {
	}

	/**
	 * 整数部小数部桁数取得関数(不要桁未カウント版)
	 * <pre>
	 * 処理対象も数字文字列を整数部と小数部に分解した後、
	 * それぞれ数字としての桁数を取得する
	 * 処置対象の文字列の数字としての妥当性は保証されて
	 * いることが前提
	 * [例]
	 * 　0000123.4567000　は　整数部３桁で小数部４桁
	 * 　0.05　は　整数部１桁で小数部２桁
	 * 　123.0　は　整数部３桁で、小数部ゼロ桁
	 * </pre>
	 * @param num 対象文字列
	 * @return 整数部小数部桁数のint配列
	 */
	public static int[] getLengthOfIntegerAndDecimalInNumeric(String num) {
		int[] ret = { 0, 0 };
		String[] tmp =  separateIntegerAndDecimal(num);
		if (tmp[0].length() == 0) {
		    ret[0] = 0;
		} else 	{
		    ret[0] = String.valueOf(Integer.parseInt(tmp[0])).length();
		}
		if (tmp[1].length() == 0) {
            ret[1] = 0;
        } else 	{
		    ret[1] = String.valueOf(Integer.parseInt(tmp[1])).length();
		}
		for (int i = tmp[1].length() - 1; i > -1; i--) {
			if (tmp[1].substring(i, i + 1).equals(ZERO)) {
				ret[1]--;
			}
		}
		return ret;
	}

	/**
	 * 整数部小数部桁数取得関数(不要桁カウント版)
	 * <pre>
	 * 処理対象も数字文字列を整数部と小数部に分解した後、
	 * それぞれ文字としての桁数を取得する
	 * 処置対象の文字列の数字としての妥当性は保証されて
	 * いることが前提
	 * [例]
	 * 　0000123.4567000　は　整数部７桁で小数部８桁
	 * 　0.05　は　整数部１桁で小数部２桁
	 * 　123.0　は　整数部３桁で、小数部１桁
	 * </pre>
	 * @param num 対象文字列
	 * @return 整数部小数部桁数のint配列
	 */
	public static int[] getLengthOfIntegerAndDecimal(String num) {
		int[] ret = { 0, 0 };
		String[] tmp =  separateIntegerAndDecimal(num);
		ret[0] = tmp[0].length();
		ret[1] = tmp[1].length();
		return ret;
	}


	/**
	 * 整数部小数部分離関数
	 * <pre>
	 * 処理対象の文字をピリオドで分離する（配列数２）
	 * 分離対象がない場合は、空文字
	 * 複数のピリオドがあった場合は、整数部小数部ともに空文字
	 * </pre>
	 * @param num 対象文字列
	 * @return 分離結果のString配列
	 */
	public static String[] separateIntegerAndDecimal(String num) {
		String[] ret = { "", ""	};

		StringTokenizer st = new StringTokenizer(num, PERIOD);
		int tokenCount = st.countTokens();
		switch (tokenCount) {
			case 0:
				return ret;
			case 1:
				//いきなりピリオドで始まっていたら、小数部のみ
				if (num.startsWith(PERIOD)) {
					ret[1] = (String)st.nextToken();
				} else {
					ret[0] = (String)st.nextToken();
				}
				break;
			case 2:
				ret[0] = (String)st.nextToken();
				ret[1] = (String)st.nextToken();
				break;
			default:
				return ret;
		}
		return ret;
	}

	/**
	 * デフォルト数値設定関数。
	 * <pre>
	 * 対象数値がnullの場合、0に変換する。
	 * </pre>
	 * @param target 対象数値
	 * @return 結果数値
	 */
	public static int defaultValue(Integer target) {
		return defaultValue(target, 0);
	}

	/**
	 * デフォルト数値設定関数。
	 * <pre>
	 * 対象数値がnullの場合にデフォルト数値に変換する。
	 * </pre>
	 * @param target 対象数値
	 * @param defaultInt デフォルト数値
	 * @return 結果数値
	 */
	public static int defaultValue(Integer target, int defaultInt) {
		if (target == null) {
			return defaultInt;
		} else {
			return target;
		}
	}

}
