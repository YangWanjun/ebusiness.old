package com.toyotec_jp.ucar.batch.common;

import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.DateUtils;

/**
 * <strong>バッチ関連共通ユーティリティクラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/03/09 新規作成<br>
 * @since 1.00
 * @category [[バッチ(共通)]]
 */
public class BatchUtils {

	/** インスタンスを生成しない。 */
	private BatchUtils(){
	}

	/**
	 * ログ出力文字列を作成。
	 * @param message メッセージ
	 * @return 「yyyy-MM-dd HH:mm:ss.SSS + message」形式の文字列
	 */
	public static String createLogString(String message){

		String result = DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + " " +
						message;

		return result;
	}

	/**
	 * ログ出力文字列を作成。
	 * @param tableName 実行対象テーブル名
	 * @param execute 実行(追加/更新/削除)
	 * @param executeCount 実行件数
	 * @return 作成されたログ出力文字列
	 */
	public static String createLogString(String tableName, String execute, int executeCount){

		String result = DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + " " +
						tableName + " " +
						execute  + " " +
						"実行件数：" + executeCount;

		return result;
	}

	/**
	 * infoログを出力。
	 * <pre>
	 * 「yyyy-MM-dd HH:mm:ss.SSS + message」形式でinfoログを出力する。
	 * </pre>
	 * @param message メッセージ
	 */
	public static void outputInfoLog(String message){

		String infoLog = DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + " " +
						message;

		TecLogger.info(infoLog);

	}

	/**
	 * infoログを出力。
	 * <pre>
	 * 「yyyy-MM-dd HH:mm:ss.SSS + executeClassName + message」形式でinfoログを出力する。
	 * </pre>
	 * @param executeClassName 実行クラス名
	 * @param message メッセージ
	 */
	public static void outputInfoLog(String executeClassName, String message){

		String infoLog = DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + " " +
						executeClassName + " " +
						message;

		TecLogger.info(infoLog);

	}

	/**
	 * ログ出力文字列を作成。
	 * <pre>
	 * 「yyyy-MM-dd HH:mm:ss.SSS + executeClassName + tableName + execute + 実行件数：executeCount」形式でinfoログを出力する。
	 * </pre>
	 * @param executeClassName 実行クラス名
	 * @param tableName 実行対象テーブル名
	 * @param execute 実行(追加/更新/削除)
	 * @param executeCount 実行件数
	 * @return 作成されたログ出力文字列
	 */
	public static void outputInfoLog(
			String executeClassName, String tableName, String execute, int executeCount){

		String infoLog = DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + " " +
						executeClassName + " " +
						tableName + " " +
						execute  + " " +
						"実行件数：" + executeCount;

		TecLogger.info(infoLog);

	}
	
	/**
	 * 処理時間ログ出力文字列を作成。
	 * <pre>
	 * 「yyyy-MM-dd HH:mm:ss.SSS + executeClassName + tableName + execute + 実行速度：endTime - startTime」形式でinfoログを出力する。
	 * </pre>
	 * @param executeClassName 実行クラス名
	 * @param tableName 実行対象テーブル名
	 * @param execute 実行(追加/更新/削除)
	 * @param startTime 処理開始
	 * @param endTime 処理終了
	 * @return 作成されたログ出力文字列
	 */
	public static void outputInfoLog(
			String executeClassName, String tableName, String execute, long startTime, long endTime){

		String infoLog = DateUtils.getCurrentDateStr(DateUtils.DB_FORMAT_LONG_M) + " " +
						executeClassName + " " +
						tableName + " " +
						execute  + " " +
						"処理時間：" + (endTime - startTime) + " ms";

		TecLogger.info(infoLog);
	}
}