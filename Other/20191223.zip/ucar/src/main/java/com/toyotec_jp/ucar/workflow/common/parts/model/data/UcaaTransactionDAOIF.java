package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;

/**
 * <strong>U-Car商品化システム トランザクション操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/07/05 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface UcaaTransactionDAOIF {

	/**
	 * 型式指定類別NO件数取得処理(車両搬入情報)
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	noKataruib 	型式指定類別NO
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectNoKataruibCount(String cdKaisya,
									String cdHanbaitn,
									String noKataruib) throws TecDAOException;

	/**
	 * 型式指定類別NO件数取得処理 詳細確認・修正モード用(車両搬入情報)
	 * <pre>
	 * ai21車両NOを更新対象以外のデータが保持しているかをチェック
	 * </pre>
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @param 	noKataruib 	型式指定類別NO
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectNoKataruibEditCount(String cdKaisya,
										String cdHanbaitn,
										String ddHannyu,
										String noKanri,
										String noKataruib) throws TecDAOException;

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/**
	 * ステータスチェック
	 * <pre>
	 * ステータスDB(新)対応用
	 * </pre>
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @return ステータスDBBean
	 * @throws LcmDAOException DAO例外クラス
	 */
//	public T220012gBean selectT220012g(String cdKaisya,
	public Uccb007gBean selectT220012g(String cdKaisya,		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
										String cdHanbaitn,
										String ddHannyu,
										String noKanri,
										// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
										String cdTenpo,
										String kbScenter) throws TecDAOException;
										// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため start
	/**
	 * ステータス項目チェック
	 * <pre>
	 * ステータスDB(新)対応用
	 * </pre>
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @param  checkStatusNo チェックステータス番号
	 * @return ステータスDBBean
	 * @throws LcmDAOException DAO例外クラス
	 */
//	public T220012gBean selectT220012g(String cdKaisya,
	public Uccb007gBean selectT220012g(String cdKaisya,		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String cdTenpo,
			String kbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			int checkStatusNo) throws TecDAOException;
	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため end

	// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
	/**
	 * 更新処理（ステータスDB）Aゾーン日数・ABゾーン日数 更新用
	 * @param	t220012gInputDataBean ステータスDBBean(新規登録・更新用)
	 * @param	executeDate           実行日時
	 * @throws TecDAOException       DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220012GZoneDate(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean updateT220012GZoneDate(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			Timestamp executeDate) throws TecDAOException;
	// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため end
}
