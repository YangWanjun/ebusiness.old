package com.toyotec_jp.ucar.workflow.carryin.storelist.view;

import java.util.List;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinEventKey;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinTitle;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.event.GetStoreListDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.event.GetStoreListDataEventResult;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListDataBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListParamBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListSessionBean;
import com.toyotec_jp.ucar.workflow.common.parts.SagyoKubunManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SagyoKubunBean;

/**
 * <strong>展示店舗受取処理ヘルパービーン</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/23 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */

public class StoreListHelperBean extends UcarHelperBean {

private static final long serialVersionUID = 1L;

	/** 展示店舗受取処理 画面出力値リスト */
	private List<StoreListDataBean> storeListDataList;
	/** 展示店舗受取処理セッションBean */
	private StoreListSessionBean storeListSessionBean;
	/** 展示店舗受取処理 検索条件Bean */
	private StoreListParamBean storeListParamBean = new StoreListParamBean();
	/** サービスID */
	private CarryinServiceId targetServiceId;
	/** データ有無フラグ */
	private String listFlg;
	/** エラーメッセージ */
	private String errMsg;
	/** 合計レコード数 */
	private int totalRecordCount;
	/** ページ番号 */
	private int pageNo;
	/** ページサイズ */
	private int pageSize;
	/** 受取チェック状態 */
	private String chkUketoriChecked = "";

	private String serviceUrlInit;
	private String serviceUrlSearch;
	private String serviceUrlSort;
	private String serviceUrlUpdate;

	// 2014.03.10 T.Hayato 修正 作業名をマスタから取得するため start
	/** 作業区分Bean */
	private SagyoKubunBean sagyoKubunBean;
	// 2014.03.10 T.Hayato 修正 作業名をマスタから取得するため end

	/** デフォルトコンストラクタ */
	public StoreListHelperBean() throws HelperBeanException {
		super();
	}
	@Override
	public void init() throws HelperBeanException {

		// セッションの取得
		storeListSessionBean = getApplicationSessionBean(StoreListSessionBean.class);

		String serviceId = storeListSessionBean.getServiceId();
		targetServiceId = CarryinServiceId.getTargetCarryinServiceId(serviceId);

		// サービス呼び出し用URL設定
		setServiceURLs();

		try {
			// イベントの生成
			GetStoreListDataEvent getStoreListDataEvent = createEvent(CarryinEventKey.GET_STORELIST_DATA,GetStoreListDataEvent.class);
			UcarSessionManager sessionMng = UcarSessionManager.getInstance();
			LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());

			// サービスごとの処理
			if (targetServiceId != null) {
				switch (targetServiceId) {
					case STORELIST_INIT:
					case STORELIST_SEARCH:
					case STORELIST_SORTING:
					case STORELIST_UPDATE:
					case STORELIST_RELORD:
						// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
						String cdKaisya 	= loginSessionBean.getUserInfoBean().getCdKaisya();
						String cdHanbaitn 	= loginSessionBean.getUserInfoBean().getCdHanbaitn();

						getStoreListDataEvent.setCdKaisya(cdKaisya);
						getStoreListDataEvent.setCdHanbaitn(cdHanbaitn);
						// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end
						getStoreListDataEvent.setStoreListParamBean(storeListSessionBean.getStoreListParamBean());
						getStoreListDataEvent.setSortOrder(storeListSessionBean.getSortOrder());
						getStoreListDataEvent.setSortParam(storeListSessionBean.getSortParam());
						getStoreListDataEvent.setPageNo(storeListSessionBean.getPageNo());
						getStoreListDataEvent.setPageSize(storeListSessionBean.getPageSize());
						getStoreListDataEvent.setInit(storeListSessionBean.isInit());
						break;
					default:
						break;
				}
			}
			// イベントリスナー実行
			GetStoreListDataEventResult eventResult = (GetStoreListDataEventResult) dispatchEvent(getStoreListDataEvent);

			storeListDataList = eventResult.getStoreListDataList();
			// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため start
			storeListSessionBean.setStoreListDataList(storeListDataList);
			// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため end

			totalRecordCount = eventResult.getTotalRecordCount();
			setPageSize(eventResult.getPageSize());

			// 2014.03.10 T.Hayato 修正 作業名をマスタから取得するため start
			sagyoKubunBean = SagyoKubunManager.getSagyoKubun(getRequest(), getResponse());
			// 2014.03.10 T.Hayato 修正 作業名をマスタから取得するため end

			// 受取チェック状態 2012.04.04 A.Yoshinami 追加 受取チェック状態 start
			if (storeListSessionBean.getStoreListParamBean().getArrayChkUketori() != null) {
				for (int i = 0; i < storeListSessionBean.getStoreListParamBean().getArrayChkUketori().length; i++) {
					String chkUketori = storeListSessionBean.getStoreListParamBean().getArrayChkUketori()[i];
					if (!(chkUketori == null)) {
						if (i != 0) {
							chkUketoriChecked += ",";
						}
						chkUketoriChecked += chkUketori;
					}
				}
			}
			// 受取チェック状態 2012.04.04 A.Yoshinami 追加 受取チェック状態 end

			// データの有無表示
			if (storeListDataList == null || storeListDataList.size() == 0) {
				listFlg = "false";  // データ無し
				errMsg = "該当データはありません";
			} else {
				listFlg = "true";   // データ有り
			}

		}catch (SystemException e) {
			throw new HelperBeanException(e.getMessage());
		} catch (Exception e) {
			throw new HelperBeanException(e.getMessage());
		}

	}

	/** サービス呼び出し用URL設定 */
	private void setServiceURLs() throws HelperBeanException {
		serviceUrlInit 		= getServiceUrl(CarryinServiceId.STORELIST_INIT);
		serviceUrlSearch	= getServiceUrl(CarryinServiceId.STORELIST_SEARCH);
		serviceUrlSort      = getServiceUrl(CarryinServiceId.STORELIST_SORTING);
		serviceUrlUpdate    = getServiceUrl(CarryinServiceId.STORELIST_UPDATE);
	}

	/** 画面タイトル取得 */
	public String getTitleLabel() {
		return CarryinTitle.StoreList.getTitleLabel();
	}

	/**
	 * storeListDataListを取得する。
	 * @return storeListDataList 展示店舗受取処理 画面出力値リスト
	 */
	public List<StoreListDataBean> getStoreListDataList() {
		return storeListDataList;
	}

	/**
	 * storeListDataListを設定する。
	 * @return storeListDataList 展示店舗受取処理 画面出力値リスト
	 */
	public void setStoreListDataList(List<StoreListDataBean> storeListDataList) {
		this.storeListDataList = storeListDataList;
	}

	/**
	 * storeListSessionBeanを取得する。
	 * @return storeListSessionBean 展示店舗受取処理 セッションBean
	 */
	public StoreListSessionBean getStoreListSessionBean() {
		return storeListSessionBean;
	}

	/**
	 * storeListSessionBeanを設定する。
	 * @return storeListSessionBean 展示店舗受取処理 セッションBean
	 */
	public void setStoreListSessionBean(StoreListSessionBean storeListSessionBean) {
		this.storeListSessionBean = storeListSessionBean;
	}

	/**
	 * targetServiceIdを取得する。
	 * @return targetServiceId サービスID
	 */
	public CarryinServiceId getTargetServiceId() {
		return targetServiceId;
	}

	/**
	 * targetServiceIdを設定する。
	 * @return targetServiceId サービスID
	 */
	public void setTargetServiceId(CarryinServiceId targetServiceId) {
		this.targetServiceId = targetServiceId;
	}

	/**
	 * storeListParamBeanを取得する。
	 * @return storeListParamBean 展示店舗受取処理 検索条件Bean
	 */
	public StoreListParamBean getStoreListParamBean() {
		return storeListParamBean;
	}

	/**
	 * storeListParamBeanを設定する。
	 * @return storeListParamBean 展示店舗受取処理 検索条件Bean
	 */
	public void setStoreListParamBean(StoreListParamBean storeListParamBean) {
		this.storeListParamBean = storeListParamBean;
	}

	/**
	 * listFlgを取得する。
	 * @return listFlg データ有無フラグ
	 */
	public String getListFlg() {
		return listFlg;
	}

	/**
	 * listFlgを設定する。
	 * @return listFlg データ有無フラグ
	 */
	public void setListFlg(String listFlg) {
		this.listFlg = listFlg;
	}

	/**
	 * errMsgを取得する。
	 * @return errMsg エラーメッセージ
	 */
	public String getErrMsg() {
		return errMsg;
	}

	/**
	 * errMsgを設定する。
	 * @return errMsg エラーメッセージ
	 */
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	/**
	 * totalRecordCountを取得する。
	 * @return totalRecordCount 合計レコード数
	 */
	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	/**
	 * totalRecordCountを設定する。
	 * @return totalRecordCount 合計レコード数
	 */
	public void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo ページ番号
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @return pageNo ページ番号
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize ページサイズ
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @return pageSize ページサイズ
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * chkUketoriCheckedを取得する。
	 * @return chkUketoriChecked 受取チェック状態
	 */
	public String getChkUketoriChecked() {
		return chkUketoriChecked;
	}

	/**
	 * serviceUrlInitを取得する。
	 * @return serviceUrlInit
	 */
	public String getServiceUrlInit() {
		return serviceUrlInit;
	}

	/**
	 * serviceUrlInitを設定する。
	 * @return serviceUrlInit
	 */
	public void setServiceUrlInit(String serviceUrlInit) {
		this.serviceUrlInit = serviceUrlInit;
	}

	/**
	 * serviceUrlSearchを取得する。
	 * @return serviceUrlSearch
	 */
	public String getServiceUrlSearch() {
		return serviceUrlSearch;
	}

	/**
	 * serviceUrlSearchを設定する。
	 * @return serviceUrlSearch
	 */
	public void setServiceUrlSearch(String serviceUrlSearch) {
		this.serviceUrlSearch = serviceUrlSearch;
	}

	/**
	 * serviceUrlSortを取得する。
	 * @return serviceUrlSort
	 */
	public String getServiceUrlSort() {
		return serviceUrlSort;
	}

	/**
	 * serviceUrlSortを設定する。
	 * @return serviceUrlSort
	 */
	public void setServiceUrlSort(String serviceUrlSort) {
		this.serviceUrlSort = serviceUrlSort;
	}

	/**
	 * serviceUrlUpdateを取得する。
	 * @return serviceUrlUpdate
	 */
	public String getServiceUrlUpdate() {
		return serviceUrlUpdate;
	}

	/**
	 * serviceUrlUpdateを設定する。
	 * @return serviceUrlUpdate
	 */
	public void setServiceUrlUpdate(String serviceUrlUpdate) {
		this.serviceUrlUpdate = serviceUrlUpdate;
	}

	// 2014.03.10 T.Hayato 修正 作業名をマスタから取得するため start
	/**
	 * 作業区分Beanを取得する。
	 * @return 作業区分Bean
	 */
	public SagyoKubunBean getSagyoKubunBean() {
		return sagyoKubunBean;
	}
	// 2014.03.10 T.Hayato 修正 作業名をマスタから取得するため end

}