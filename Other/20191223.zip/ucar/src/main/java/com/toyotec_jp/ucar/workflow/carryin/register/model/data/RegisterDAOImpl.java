package com.toyotec_jp.ucar.workflow.carryin.register.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbv0201mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb011vBean;

/**
 * <strong>車両搬入登録DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterDAOImpl extends UcarSharedDBDAO implements RegisterDAOIF {

//--2019.3.20 from

	private String InitialParam = "com.toyotec_jp.ucar.workflow.carryin.InitialNumber";
	private String LimitParam = "com.toyotec_jp.ucar.workflow.carryin.LimitNumber";

//--2019.3.20 to	
	
	/** 管理番号最大値取得処理 SQL */
	private static final String SELECT_NO_KANRI_FOR_MAX_SQL
		= "SELECT "
		+ " MAX(NO_KANRI) NO_KANRI "
		+ "FROM "
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		+ " T220901V "
//		+ " T220001G "
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
		+ "WHERE "
		+ "    CD_KAISYA 	= ? "
		+ "AND CD_HANBAITN 	= ? "
/*--2019.3.20 FROM		
		+ "AND DD_HANNYU 	= ? ";
*/
		
		+ "AND DD_HANNYU 	= ? "
		+ "AND NO_KANRI 	BETWEEN TO_NUMBER(?) AND TO_NUMBER(?) ";
//--2019.3.20 to		

// 2014.7.18 H.Yamashita add start P相模原 連番対応

	
	/** 管理番号最大値取得処理 SQL(商品化センター用) */
	private static final String SELECT_NO_KANRI_FOR_SC_MAX_SQL
		= "SELECT "
		+ " MAX(NO_KANRI) NO_KANRI "
		+ "FROM "
		+ " T220001G "
		+ "WHERE "
/*--2019.3.20 from		
		+ "    CD_KAISYA 	= ? "
		+ "AND CD_HANBAITN 	= ? "
		+ "AND DD_HANNYU 	= ? ";
*/
		+ "    DD_HANNYU 	= ? "
		+ "AND CD_HANTENPO 	= ? ";
//--2019.3.20 to		
		
//2019.03.30 TO start	
	/** 管理番号最大値取得処理 SQL (業販用)*/
	private static final String SELECT_NO_KANRI_FOR_GYOHAN_MAX_SQL
		= "SELECT "
		+ " MAX(NO_KANRI) NO_KANRI "
		+ "FROM "
		+ " T220901V "
		+ "WHERE "
		+ "    DD_HANNYU 	= ? "
		+ "AND NO_KANRI 	BETWEEN TO_NUMBER(?) AND TO_NUMBER(?) ";
//2019.03.30 TO end	

	/** 管理番号最大値取得処理 SQL(店舗用) */
	private static final String SELECT_NO_KANRI_FOR_SHOP_MAX_SQL
		= "SELECT "
		+ " MAX(NO_KANRI) NO_KANRI "
		+ "FROM "
		+ " T220101G "
		+ "WHERE "
/* 2019.03.30 TO
		+ "    CD_KAISYA 	= ? "
		+ "AND CD_HANBAITN 	= ? "
/*--2019.3.20 FROM		
		+ "AND DD_HANNYU 	= ? ";
*/
		+ "    DD_HANNYU 	= ? "
		+ "AND NO_KANRI 	BETWEEN ? AND ? ";
//--2019.3.20 to		

// 2014.7.18 H.Yamashita add end P相模原 連番対応

	
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * 書類情報（新規登録）取得

	 * @param loginKbScenter 商品化センター区分

	 * @return
	 */
	private String getSyoruiCheckInsert(String loginKbScenter) {

		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** 新規登録処理（書類情報）SQL */
		final String INSERT_T220007G_SQL
			= "INSERT INTO "
//			+ " T220007G "
			+ " " + UcarTableManager.getSyoruiCheck(loginKbScenter) + " "
			+ "(CD_KAISYA "
			+ ",CD_HANBAITN "
			+ ",DD_HANNYU "
			+ ",NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２


			+ ",DD_SRKNB "
			+ ",DD_SRKHR "
			+ ",DD_SRKFK "
			+ ",MJ_SRKBK "

			+ ",DT_SAKUSEI "
			+ ",DT_KOSIN "
			+ ",CD_SKSISYA "
			+ ",CD_KSNSYA "
			+ ",CD_SKSIAPP "
			+ ",CD_KSNAPP "
			+ ") VALUES "
			+ "(? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ") ";

		return INSERT_T220007G_SQL;
	}

	// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
	/**
	 * 仕入種別情報取得

	 * @param loginKbScenter 商品化センター区分

	 * @return
	 */
	private String getSiireSyubetu(String loginKbScenter) {

		/** 仕入種別情報取得処理（仕入種別情報）SQL */
		final String SELECT_T220002G_SQL
			= "SELECT "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , KB_SIIRE "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
			+ UcarTableManager.getSiireSyubetu(loginKbScenter)
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? ";

		return SELECT_T220002G_SQL;
	}

	/**
	 * チェック内容情報取得

	 * @param loginKbScenter 商品化センター区分

	 * @return
	 */
	private String getCheckNaiyo(String loginKbScenter) {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** チェック内容情報取得処理（チェック内容情報）SQL */
		final String SELECT_T220003G_SQL
			= "SELECT "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , KB_CHECK "
			+ "  , DD_CHECK "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
			+ UcarTableManager.getCheckNaiyo(loginKbScenter)
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２


		return SELECT_T220003G_SQL;
	}
	// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/** データ区分取得処理（車両搬入受取情報ビュー）SQL */
	private static final String SELECT_T220902V_KB_DATA_SQL
		= "SELECT "
		+ "    KB_DATA "
		+ "FROM "
		+ "  T220902V "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND DD_HANNYU   = ? "
		+ "  AND NO_KANRI    = ? "
		+ "  AND CD_HANTENPO = ? ";
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectTStatusMax(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override

	public String selectNoKanriMax(String cdKaisya,
									String cdHanbaitn,
									String ddHannyu
	// 2014.7.18 H.Yamashita add start P相模原 連番対応
									,String loginKbScenter
	// 2014.7.18 H.Yamashita add start P相模原 連番対応
//--2019.3.20 from
									,String loginKbGyohan
									,String cdHantenpo
//--2019.3.20 to									
	) throws TecDAOException {

		SimpleQueryParamBean paramBean;
		
/*--2019.3.20 from
		// 2014.7.18 H.Yamashita add start P相模原 連番対応

		if (UcarConst.TOYOPET.equals(cdHanbaitn)) {
			if (UcarConst.KB_SCENTER_SCENTER.equals(loginKbScenter)) {
				// ログインユーザが商品化センターの場合

				paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_SC_MAX_SQL);
			} else {
				paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_SHOP_MAX_SQL);
			}

		} else {
			paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_MAX_SQL);
		}
		
		//SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_MAX_SQL);
		// 2014.7.18 H.Yamashita add end P相模原 連番対応

		paramBean.setString(cdKaisya);		// 会社コード

		paramBean.setString(cdHanbaitn);	// 販売店コード

		paramBean.setString(ddHannyu);		// 搬入日

		paramBean.setString(cdHantenpo);	// 搬入店舗
*/		
		
		String startNoKanri = "";
		String endNoKanri   = "";
		
		if (UcarConst.WCOROLLA.equals(cdHanbaitn)) {
			startNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".CW.shop");
			endNoKanri   = UcarApplicationManager.getConfigValue(LimitParam+".CW.shop");
			
			paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_MAX_SQL);
			
			paramBean.setString(cdKaisya);		// 会社コード
			paramBean.setString(cdHanbaitn);	// 販売店コード
			paramBean.setString(ddHannyu);		// 搬入日
			paramBean.setString(startNoKanri);	// 管理ＮＯ(from)
			paramBean.setString(endNoKanri);	// 管理ＮＯ(to)
					
		}else{
			if (UcarConst.KB_SCENTER_SCENTER.equals(loginKbScenter)) {
				paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_SC_MAX_SQL);
				
				paramBean.setString(ddHannyu);		// 搬入日
				paramBean.setString(cdHantenpo);	// 搬入店舗
				
			}else if (UcarConst.KB_GYOHAN.equals(loginKbGyohan)) {
				startNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".TMT.gyohan");
				endNoKanri   = UcarApplicationManager.getConfigValue(LimitParam+".TMT.gyohan");
				
				//2019.03.30 T.Osada start
				//paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_MAX_SQL);
				paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_GYOHAN_MAX_SQL);
				
				//paramBean.setString(cdKaisya);		// 会社コード
				//paramBean.setString(cdHanbaitn);	// 販売店コード
				//2019.03.30 T.Osada end
				paramBean.setString(ddHannyu);		// 搬入日
				paramBean.setString(startNoKanri);	// 管理ＮＯ(from)
				paramBean.setString(endNoKanri);	// 管理ＮＯ(to)
	
			}else{
				startNoKanri = UcarApplicationManager.getConfigValue(InitialParam+".TMT.shop");
				endNoKanri   = UcarApplicationManager.getConfigValue(LimitParam+".TMT.shop");

				paramBean = new SimpleQueryParamBean(SELECT_NO_KANRI_FOR_SHOP_MAX_SQL);

				//2019.03.30 T.Osada start
				//paramBean.setString(cdKaisya);		// 会社コード
				//paramBean.setString(cdHanbaitn);	// 販売店コード
				//2019.03.30 T.Osada end
				paramBean.setString(ddHannyu);		// 搬入日
				paramBean.setString(startNoKanri);	// 管理ＮＯ(from)
				paramBean.setString(endNoKanri);	// 管理ＮＯ(to)
				
			}
		}
		
//--2019.3.20 to

		ResultArrayList<Ucaa001gBean> t220001gList = executeSimpleSelectQuery(paramBean, Ucaa001gBean.class);

		String noKanri = "";
		if(t220001gList.size() > 0){
			noKanri = t220001gList.get(0).getNoKanri();
			if(t220001gList.size() > 1){
				TecLogger.warn("車両搬入情報 不整合");
			}
		}
		return noKanri;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220002GCount(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectT220002GCount(String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			String loginKbScenter)	throws TecDAOException {

		int count = 0;

		try{
			String sql = getSiireSyubetu(loginKbScenter);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(sql);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

			// パラメータセット<条件>
			paramBean.setString(cdKaisya);		// 会社コード
			paramBean.setString(cdHanbaitn);	// 販売店コード
			paramBean.setString(ddHannyu);		// 搬入日
			paramBean.setString(noKanri);		// 管理番号

			// 取得

			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220003GCount(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public int selectT220003GCount(String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			String loginKbScenter)	throws TecDAOException {

		int count = 0;

		try{
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(getCheckNaiyo(loginKbScenter));
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

			// パラメータセット<条件>
			paramBean.setString(cdKaisya);		// 会社コード
/*2019.3.20
			paramBean.setString(cdHanbaitn);	// 販売店コード
*/
			paramBean.setString(ddHannyu);		// 搬入日
			paramBean.setString(noKanri);		// 管理番号

			// 取得

			count = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return count;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#insertT220001G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean insertSyaryoHannyu(
			RegisterInputBean registerInputBean,
			String loginKbScenter,
			Timestamp executeDate) throws TecDAOException {

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 新規登録処理（車両搬入情報）SQL */
		String executeSql
			= "INSERT INTO "
			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ "(CD_KAISYA "
			+ ",CD_HANBAITN "
			+ ",DD_HANNYU "
			+ ",NO_KANRI "
			+ ",CD_OKYAKU "
			+ ",KJ_OKYAKUM "
			+ ",CD_NORIKUSI "
			+ ",KB_NOSYASYU "
			+ ",CD_NOGYOTAI "
			+ ",NO_NOSEIRI "
			+ ",CD_HANTENPO "
			+ ",MJ_SITKATA "
			+ ",NO_SYADAI "
			+ ",MJ_SYAMEI "
			+ ",DD_SYODOTOR "
			+ ",DD_SYKNMANR "
			+ ",NO_KATARUIB "
			+ ",CD_TOSYOKU "
			+ ",NU_SOUKUKM "
			+ ",CD_SIRTENPO "
			+ ",CD_SDTAN "
			+ ",KI_NYUKOK "
			+ ",CD_KOZINZYHO "
			+ ",NO_ZYUTYU "
			+ ",MJ_UKETAN "
			+ ",NO_SYARYOU "
			// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため start
			+ ",DD_SIIRE "
			// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため end
			+" ,NO_UKETAN"	//追加	2015.5.7		
			
			+ ",MJ_BIKOU "
			+ ",DT_SAKUSEI "
			+ ",DT_KOSIN "
			+ ",CD_SKSISYA "
			+ ",CD_KSNSYA "
			+ ",CD_SKSIAPP "
			+ ",CD_KSNAPP "
			+ ") VALUES "
			+ "(? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため start
			+ ",? "
			// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため end
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<値>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード
/*--2019.3.20 from
		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード
*/
		paramBean.setString(registerInputBean.getCdTenpoHanbaitnSel());
//--2019.3.20 to
		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		paramBean.setString(registerInputBean.getCdOkyaku());	// お客様コード

		paramBean.setString(registerInputBean.getKjOkyakum());	// お客様名
		paramBean.setString(registerInputBean.getCdNorikusi());	// 登録NO陸支コード

		paramBean.setString(registerInputBean.getKbNosyasyu());	// 登録NO車種区分

		paramBean.setString(registerInputBean.getCdNogyotai());	// 登録NO業態コード

		paramBean.setString(registerInputBean.getNoNoseiri());	// 登録NO整理番号
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		paramBean.setString(registerInputBean.getCdHantenpo());	// 搬入店舗コード

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		paramBean.setString(registerInputBean.getMjSitkata());	// 指定型式

		paramBean.setString(registerInputBean.getNoSyadai());	// 車台番号
		paramBean.setString(registerInputBean.getMjSyamei());	// 車名
		paramBean.setString(registerInputBean.getDdSyodotor());	// 初度登録日

		paramBean.setString(registerInputBean.getDdSyknmanr());	// 車検満了日
		paramBean.setString(registerInputBean.getNoKataruib());	// 型式指定類別NO
		paramBean.setString(registerInputBean.getCdTosyoku());	// 塗色コード

		paramBean.setInt(registerInputBean.getNuSoukukm());		// 走行距離
		paramBean.setString(registerInputBean.getCdSirtenpo());	// 仕入店舗コード

		paramBean.setString(registerInputBean.getCdSdtan());	// 下取担当者コード

		paramBean.setInt(registerInputBean.getKiNyukok());		// 入庫価格
		paramBean.setString(registerInputBean.getCdKozinzyho());// 個人情報処理コード

		paramBean.setString(registerInputBean.getNoZyutyu());	// 受注番号
		paramBean.setString(registerInputBean.getMjUketan());	// 受付担当者

		paramBean.setString(registerInputBean.getNoSyaryou());	// ai21車両NO
		// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため start
		paramBean.setString(registerInputBean.getDdSiire());	// ai21仕入日
		// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため end
		paramBean.setString(registerInputBean.getNoUketan());	// 受付担当者コード　2015/5/7
		
		paramBean.setString(registerInputBean.getMjBikou());	// 備考


		paramBean.setTimestamp(executeDate);	// データ作成日時

		paramBean.setTimestamp(executeDate);	// データ更新日時


		paramBean.setString(registerInputBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#insertT220002G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean insertT220002G(
			RegisterInputBean registerInputBean,
			String loginKbScenter,
			String kbSiire,
			Timestamp executeDate) throws TecDAOException {

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 新規登録処理（仕入種別情報）SQL */
		String executeSql
			= "INSERT INTO "
			+ UcarTableManager.getSiireSyubetu(loginKbScenter)
			+ "(CD_KAISYA "
			+ ",CD_HANBAITN "
			+ ",DD_HANNYU "
			+ ",NO_KANRI "
			+ ",KB_SIIRE "
			+ ",DT_SAKUSEI "
			+ ",DT_KOSIN "
			+ ",CD_SKSISYA "
			+ ",CD_KSNSYA "
			+ ",CD_SKSIAPP "
			+ ",CD_KSNAPP "
			+ ") VALUES "
			+ "(? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<値>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード
/*--2019.3.20 from
		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード
*/
		paramBean.setString(registerInputBean.getCdTenpoHanbaitnSel());
//--2019.3.20 to		
		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		paramBean.setString(kbSiire);		// 仕入種別
		paramBean.setTimestamp(executeDate);	// データ作成日時

		paramBean.setTimestamp(executeDate);	// データ更新日時

		paramBean.setString(registerInputBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#insertT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean insertT220003G(
			RegisterInputBean registerInputBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String loginKbScenter,
			String kbCheck,
			String ddCheck,
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 新規登録処理（チェック内容情報）SQL */
		String executeSql
			= "INSERT INTO "
			+ UcarTableManager.getCheckNaiyo(loginKbScenter)
			+ "(CD_KAISYA "
			+ ",CD_HANBAITN "
			+ ",DD_HANNYU "
			+ ",NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ ",KB_CHECK "
			+ ",DD_CHECK "
			+ ",DT_SAKUSEI "
			+ ",DT_KOSIN "
			+ ",CD_SKSISYA "
			+ ",CD_KSNSYA "
			+ ",CD_SKSIAPP "
			+ ",CD_KSNAPP "
			+ ") VALUES "
			+ "(? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<値>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード
/*--2019.3.20 from
		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード
*/
		paramBean.setString(registerInputBean.getCdTenpoHanbaitnSel());
//--2019.3.20 to		
		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);	// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		paramBean.setString(kbCheck);		// チェック内容区分

		paramBean.setString(ddCheck);		// チェック日
		paramBean.setTimestamp(executeDate);	// データ作成日時

		paramBean.setTimestamp(executeDate);	// データ更新日時

		paramBean.setString(registerInputBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#insertT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean insertT220007G(
			RegisterInputBean registerInputBean,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String loginCdTenpo,
			String loginKbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			Timestamp executeDate) throws TecDAOException {

//		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220007G_SQL);
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(getSyoruiCheckInsert(loginKbScenter));

		// パラメータセット<値>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード
		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);				// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 書類完備日チェック:有りの場合 → 書類完備保留日に移送

		if(registerInputBean.getArrayCheckSrk()!= null){
			paramBean.setString("");	// 書類完備日
			paramBean.setString(registerInputBean.getDdSrk());	// 書類完備保留日

		// 無しの場合 → 書類完備日に移送

		}else{
			paramBean.setString(registerInputBean.getDdSrk());	// 書類完備日
			paramBean.setString("");	// 書類完備保留日

		}
		paramBean.setString("");	// 書類完備保留復帰予定日
		paramBean.setString("");	// 書類完備備考


		paramBean.setTimestamp(executeDate);	// データ作成日時

		paramBean.setTimestamp(executeDate);	// データ更新日時

		paramBean.setString(registerInputBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#insertT220007G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean insertT220007G(Ucab002gBean t220007gBean,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String loginCdTenpo,
			String loginKbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			Timestamp executeDate) throws TecDAOException {

//		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220007G_SQL);
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(getSyoruiCheckInsert(loginKbScenter));	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２


		// パラメータセット<値>
		paramBean.setString(t220007gBean.getCdKaisya());	// 会社コード

		paramBean.setString(t220007gBean.getCdHanbaitn());	// 販売店コード

		paramBean.setString(t220007gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220007gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);				// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		paramBean.setString(t220007gBean.getDdSrknb());		// 書類完備日
		paramBean.setString(t220007gBean.getDdSrkhr());		// 書類完備保留日

		paramBean.setString(t220007gBean.getDdSrkfk());		// 書類完備保留復帰予定日
		paramBean.setString(t220007gBean.getMjSrkbk());		// 書類完備備考


		paramBean.setTimestamp(executeDate);				// データ作成日時

		paramBean.setTimestamp(executeDate);				// データ更新日時

		paramBean.setString(t220007gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220007gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220007gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220007gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#insertT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
//	public SimpleExecuteResultBean insertT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean insertT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													String cdTenpoHanbaitnSel,
													String loginKbScenter,
													String menuId,
													Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		/** 新規登録処理（ステータスＤＢ）SQL1 */
		final String INSERT_T220012G_SQL1
			= "INSERT INTO "
			+ UcarTableManager.getStatus(loginKbScenter)
			+ "(CD_KAISYA "
			+ ",CD_HANBAITN "
			+ ",DD_HANNYU "
			+ ",NO_KANRI "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２


		/** 新規登録処理（ステータスＤＢ）SQL2 */
		final String INSERT_T220012G_SQL2
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
			= ",NU_AZONE "
			+ ",NU_BZONE "
			+ ",NU_ABZONE "
			+ ",NU_SYOHN "
			+ ",MJ_KASYU "
			+ ",MJ_MARUCL "
			+ ",MJ_SEIBI "
			+ ",MJ_AMUSU "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
			+ ",DT_SAKUSEI "
			+ ",DT_KOSIN "
			+ ",CD_SKSISYA "
			+ ",CD_KSNSYA "
			+ ",CD_SKSIAPP "
			+ ",CD_KSNAPP "
			+ ") VALUES "
			+ "(? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ sqlTenpo2;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２


		/** 新規登録処理（ステータスＤＢ）SQL3 */
		final String INSERT_T220012G_SQL3
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
			= ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ") ";
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder targetSql = new StringBuilder(INSERT_T220012G_SQL1);

		// パラメータセット<値>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード

		// 2019.04.04 T.Osada start
		//paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード　
		paramBean.setString(cdTenpoHanbaitnSel);	// 販売店コード
		// 2019.04.04 T.Osada End

		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		targetSql.append(",DT_STATUS01 ");
		targetSql.append(",DT_STATUS03 ");
		targetSql.append(",DT_STATUS04 ");

		targetSql.append(INSERT_T220012G_SQL2);

		// ステータス01
		targetSql.append(",TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') ");
		paramBean.setString(t220012gInputDataBean.getStrDtStatus01());
		// ステータス03
		targetSql.append(",TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') ");
		paramBean.setString(t220012gInputDataBean.getStrDtStatus03());
		// ステータス04
		targetSql.append(",TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') ");
		paramBean.setString(t220012gInputDataBean.getStrDtStatus04());

		targetSql.append(INSERT_T220012G_SQL3);

		// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
		paramBean.setInt(0);		// Aゾーン日数
		paramBean.setInt(0);		// Bゾーン日数
		paramBean.setInt(0);		// ABゾーン日数
		paramBean.setInt(0);		// 商品化日数
		paramBean.setString("0");	// 加修フラグ
		paramBean.setString("0");	// まるクリフラグ
		paramBean.setString("0");	// 整備フラグ
		paramBean.setString("0");	// アムスフラグ
		// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
		paramBean.setTimestamp(executeDate);	// データ作成日時

		paramBean.setTimestamp(executeDate);	// データ更新日時

		paramBean.setString(t220012gInputDataBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		paramBean.setSql(targetSql.toString());

		SimpleExecuteResultBean result = executeSimpleUpdateQuery(paramBean);

		return result;
	}
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220001G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<Ucaa001gBean> selectT220001G(
			Ucaa001gPKBean t220001gPkBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			String loginKbScenter) throws TecDAOException {

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 車両搬入情報取得処理（車両搬入情報）SQL */
		final String SELECT_T220001G_SQL
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , CD_OKYAKU "
			+ "  , KJ_OKYAKUM "
			+ "  , CD_NORIKUSI "
			+ "  , KB_NOSYASYU "
			+ "  , CD_NOGYOTAI "
			+ "  , NO_NOSEIRI "
			+ "  , MJ_SITKATA "
			+ "  , NO_SYADAI "
			+ "  , MJ_SYAMEI "
			+ "  , DD_SYODOTOR "
			+ "  , DD_SYKNMANR "
			+ "  , NO_KATARUIB "
			+ "  , CD_TOSYOKU "
			+ "  , NU_SOUKUKM "
			+ "  , CD_SIRTENPO "
			+ "  , CD_SDTAN "
			+ "  , KI_NYUKOK "
			+ "  , CD_KOZINZYHO "
			+ "  , NO_ZYUTYU "
			+ "  , MJ_UKETAN "
			+ "  , NO_SYARYOU "
			// 2013.05.20 T.Hayato 追加 ai21仕入日取得のため start
			+ "  , DD_SIIRE "
			// 2013.05.20 T.Hayato 追加 ai21仕入日取得のため end
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
			+ "  , DD_INKANKGN "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end
			+ "  , NO_UKETAN"	//追加	2015.5.7			
			+ "  , MJ_BIKOU "
			+ "  , DT_SAKUSEI "
			+ "  , TO_CHAR (DT_KOSIN,'yyyy-mm-dd hh24:mi:ss.ff3') as DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
//			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ UcarTableManager.getSyaryoHannyuSelectOnly(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ "  AND CD_HANTENPO = ? ";	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220001G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード

		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード

		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２


		ResultArrayList<Ucaa001gBean> t220001gList = executeSimpleSelectQuery(paramBean, Ucaa001gBean.class);

		return t220001gList;
	}

//	/* (non-Javadoc)
//	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectSyaryoHannyu(com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean)
//	 */
//	@Override
//	public ResultArrayList<Ucaa001gBean> selectSyaryoHannyu(
//			Ucaa001gPKBean t220001gPkBean) throws TecDAOException {
//
//		String cdKaisya 	= t220001gPkBean.getCdKaisya();
//		String cdHanbaitn 	= t220001gPkBean.getCdHanbaitn();
//		String ddHannyu 	= t220001gPkBean.getDdHannyu();
//		String noKanri 		= t220001gPkBean.getNoKanri();
//
//		String executeSql = createSql("T220001G", cdKaisya, cdHanbaitn, ddHannyu, noKanri);
//		executeSql += " UNION ";
//		executeSql += createSql("T220101G", cdKaisya, cdHanbaitn, ddHannyu, noKanri);
//
//		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
//
////		// パラメータセット<条件>
////		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード

////		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード

////		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
////		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
//
//		ResultArrayList<Ucaa001gBean> t220001gList = executeSimpleSelectQuery(paramBean, Ucaa001gBean.class);
//		return t220001gList;
//	}

//	/**
//	 * @param tableName
//	 * @param cdKaisya
//	 * @param cdHanbaitn
//	 * @param ddHannyu
//	 * @param noKanri
//	 * @return
//	 */
//	private String createSql(String tableName, String cdKaisya,
//			String cdHanbaitn, String ddHannyu, String noKanri) {
//
//		/** 車両搬入情報取得処理（車両搬入情報）SQL */
//		String SELECT_SYARYOHANNYU_SQL
//			= "SELECT "
//			+ "    CD_KAISYA "
//			+ "  , CD_HANBAITN "
//			+ "  , DD_HANNYU "
//			+ "  , NO_KANRI "
//			+ "  , CD_OKYAKU "
//			+ "  , KJ_OKYAKUM "
//			+ "  , CD_NORIKUSI "
//			+ "  , KB_NOSYASYU "
//			+ "  , CD_NOGYOTAI "
//			+ "  , NO_NOSEIRI "
//			+ "  , MJ_SITKATA "
//			+ "  , NO_SYADAI "
//			+ "  , MJ_SYAMEI "
//			+ "  , DD_SYODOTOR "
//			+ "  , DD_SYKNMANR "
//			+ "  , NO_KATARUIB "
//			+ "  , CD_TOSYOKU "
//			+ "  , NU_SOUKUKM "
//			+ "  , CD_SIRTENPO "
//			+ "  , CD_SDTAN "
//			+ "  , KI_NYUKOK "
//			+ "  , CD_KOZINZYHO "
//			+ "  , NO_ZYUTYU "
//			+ "  , MJ_UKETAN "
//			+ "  , NO_SYARYOU "
//			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
//			+ "  , DD_INKANKGN "
//			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end
//			+ "  , MJ_BIKOU "
//			+ "  , DT_SAKUSEI "
//			+ "  , DT_KOSIN "
//			+ "  , CD_SKSISYA "
//			+ "  , CD_KSNSYA "
//			+ "  , CD_SKSIAPP "
//			+ "  , CD_KSNAPP "
//			+ "FROM "
//			+ tableName
//			+ "WHERE "
//			+ "      CD_KAISYA   = " + cdKaisya + " "
//			+ "  AND CD_HANBAITN = " + cdHanbaitn + " "
//			+ "  AND DD_HANNYU   = " + ddHannyu + " "
//			+ "  AND NO_KANRI    = " + noKanri + " ";
//		return SELECT_SYARYOHANNYU_SQL;
//	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220002G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<Ucaa002gBean> selectT220002G(
			Ucaa001gPKBean t220001gPkBean,
			String loginKbScenter) throws TecDAOException {

		String sql = getSiireSyubetu(loginKbScenter);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(sql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号

		ResultArrayList<Ucaa002gBean> t220002gList = executeSimpleSelectQuery(paramBean, Ucaa002gBean.class);

		return t220002gList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220002G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<Ucab002gBean> selectT220007G(
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//			Ucaa001gPKBean t220001gPkBean) throws TecDAOException {
			Ucaa001gPKBean t220001gPkBean,
			String loginCdTenpo,
			String loginKbScenter) throws TecDAOException {

		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 書類チェックDB SQL */
		final String SELECT_T220007G_SQL
			= "SELECT "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , DD_SRKNB "
			+ "  , DD_SRKHR "
			+ "  , DD_SRKFK "
			+ "  , MJ_SRKBK "
			+ "  , DT_SAKUSEI "
			+ "  , TO_CHAR (DT_KOSIN,'yyyy-mm-dd hh24:mi:ss.ff3') as DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
//			+ "  T220007G "
			+ "  " + UcarTableManager.getSyoruiCheck(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "WHERE "
			+ "      CD_KAISYA   = ? "
/*2019.3.20			
			+ "  AND CD_HANBAITN = ? "
*/
			//2019.03.30 T.Osada start
			+ "  AND CD_HANBAITN = ? "
			//2019.03.30 T.Osada end
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２


		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220007G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
/*2019.3.20
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
*/
		//2019.03.30 T.Osada start
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード
		//2019.03.30 T.Osada end
		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);					// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		ResultArrayList<Ucab002gBean> t220007gList = executeSimpleSelectQuery(paramBean, Ucab002gBean.class);

		return t220007gList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<Ucaa003gBean> selectT220003G(Ucaa001gPKBean t220001gPkBean,
														String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

														String loginKbScenter,
														String excludeKbCheck) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder();
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		selectSql.append(getCheckNaiyo(loginKbScenter));
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード

		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード

		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);					// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		if (excludeKbCheck != null) {
			// 除外条件追加
			selectSql.append(" AND KB_CHECK <> ? ");
			paramBean.setString(excludeKbCheck);
		}
		paramBean.setSql(selectSql.toString());

		ResultArrayList<Ucaa003gBean> t220003gList = executeSimpleSelectQuery(paramBean, Ucaa003gBean.class);

		return t220003gList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#deleteT220001G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220001G(
			Ucaa001gPKBean t220001gPkBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String loginKbScenter,
			String kbData,		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String t220001gDtKosin) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (kbData.equals(UcarConst.KB_DATA_UKETORI)) {
			sqlTenpo = "  AND CD_UKETENPO = ? ";
		} else {
			sqlTenpo = "  AND CD_HANTENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 削除処理（車両搬入情報）SQL */
		final String DELETE_T220001G_SQL
			= "DELETE "
			+ "FROM "
//			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ UcarTableManager.getSyaryoHannyuUpdate(loginKbScenter, kbData)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  and CD_HANBAITN = ? "
			+ "  and DD_HANNYU   = ? "
			+ "  and NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleExecuteResultBean resultBean = null;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220001G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード

		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード

		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		paramBean.setString(t220001gDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行


		resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#deleteT220002G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220002G(
			String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			String loginKbScenter,
			String exclusionDtKosin) throws TecDAOException {

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 削除処理（仕入種別情報）SQL */
		String DELETE_T220002G_SQL
			= "DELETE "
			+ "FROM "
			+ UcarTableManager.getSiireSyubetu(loginKbScenter)
			+ "WHERE "
/*2019.3.20	from	
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
*/
			+ "      CD_KAISYA   = ? ";
		if(cdHanbaitn.equals(UcarConst.WCOROLLA)){
			DELETE_T220002G_SQL += "  AND CD_HANBAITN = ? ";
		}
		DELETE_T220002G_SQL += ""
//2019.3.20 to
			//2019.03.30 T.Osada start
			+ "  AND CD_HANBAITN = ? "
			//2019.03.30 T.Osada end
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220002G_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);			// 会社コード
/*2019.3.20 from
		paramBean.setString(cdHanbaitn);		// 販売店コード
*/
		// 2019.03.30 T.Osada Start
		paramBean.setString(cdHanbaitn);		// 販売店コード
		// 2019.03.30 T.Osada end
		if(cdHanbaitn.equals(UcarConst.WCOROLLA)){
			paramBean.setString(UcarConst.WCOROLLA);	// 販売店コード
		}			
//2019.3.20 to
		paramBean.setString(ddHannyu);			// 搬入日
		paramBean.setString(noKanri);			// 管理番号
		paramBean.setString(exclusionDtKosin);	// 更新日時(排他制御)：SQL側で加工処理実行

 
			
		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#deleteT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220003G(
			String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String kbCheck,
			String loginKbScenter,
			String exclusionDtKosin) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 削除処理（チェック内容情報）SQL */
		String DELETE_T220003G_SQL
			= "DELETE "
			+ "FROM "
			+ UcarTableManager.getCheckNaiyo(loginKbScenter)
			+ "WHERE "
/*2019.3.20	from	
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
*/
			+ "      CD_KAISYA   = ? ";
		if(cdHanbaitn.equals(UcarConst.WCOROLLA)){
			DELETE_T220003G_SQL += "  AND CD_HANBAITN = ? ";
		}
		DELETE_T220003G_SQL += ""
//2019.3.20 to			
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder deleteSql = new StringBuilder(DELETE_T220003G_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);			// 会社コード
/*2019.3.20
		paramBean.setString(cdHanbaitn);		// 販売店コード
*/
		if(cdHanbaitn.equals(UcarConst.WCOROLLA)){
			paramBean.setString(UcarConst.WCOROLLA);	// 販売店コード
		}			
//2019.3.20 to			
		paramBean.setString(ddHannyu);			// 搬入日
		paramBean.setString(noKanri);			// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);	// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
		paramBean.setString(exclusionDtKosin);	// 更新日時(排他制御)：SQL側で加工処理実行


		if (kbCheck != null) {
			// チェック内容区分条件追加
			deleteSql.append(" AND KB_CHECK = ? ");
			paramBean.setString(kbCheck);
		}

		paramBean.setSql(deleteSql.toString());
		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#deleteT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220007G(
			String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
			String loginCdTenpo,
			String loginKbScenter,
			// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
			String exclusionDtKosin) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		/** 削除処理（書類チェック情報）SQL */
		String DELETE_T220007G_SQL
			= "DELETE "
			+ "FROM "
//			+ "  T220007G "
			+ "  " + UcarTableManager.getSyoruiCheck(loginKbScenter) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "WHERE "
/*2019.3.20	from	
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
*/
			+ "      CD_KAISYA   = ? ";
		if(cdHanbaitn.equals(UcarConst.WCOROLLA)){
			DELETE_T220007G_SQL += "  AND CD_HANBAITN = ? ";
		}
		DELETE_T220007G_SQL += ""
//2019.3.20 to			
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
/*--2019.3.22 from
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";
*/
			+ sqlTenpo;
		
		if(exclusionDtKosin != null){
			DELETE_T220007G_SQL += " AND DT_KOSIN = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";
		}
//--2019.3.22 to			
		SimpleExecuteResultBean resultBean = null;
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220007G_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);			// 会社コード
/*2019.3.20 from
		paramBean.setString(cdHanbaitn);		// 販売店コード
*/
		if(cdHanbaitn.equals(UcarConst.WCOROLLA)){
			paramBean.setString(UcarConst.WCOROLLA);	// 販売店コード
		}			
//2019.3.20 to
		paramBean.setString(ddHannyu);			// 搬入日
		paramBean.setString(noKanri);			// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);	// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
/*--2019.3.22 from		
		paramBean.setString(exclusionDtKosin);	// 更新日時(排他制御)：SQL側で加工処理実行
*/
		if(exclusionDtKosin != null){
			paramBean.setString(exclusionDtKosin);	// 更新日時(排他制御)：SQL側で加工処理実行
		}
//--2019.3.22 to
		resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#updateT220001G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean, java.util.Date)
	 */
	@Override
	public SimpleExecuteResultBean updateT220001G(
			RegisterInputBean registerInputBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String loginKbScenter,
			String kbData,		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String t220001gDtKosin,
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (kbData.equals(UcarConst.KB_DATA_UKETORI)) {
			sqlTenpo = "  AND CD_UKETENPO = ? ";
		} else {
			sqlTenpo = "  AND CD_HANTENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 更新処理（車両搬入情報）SQL */
		String executeSql = "UPDATE "
//			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ UcarTableManager.getSyaryoHannyuUpdate(loginKbScenter, kbData)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "SET "
/*--2019.3.20			
			+ "    DD_HANNYU 	= ? "
*/
			+ "    CD_HANBAITN  = ? "
			+ "  , DD_HANNYU 	= ? "
//--2019.3.20			
			+ "  , NO_KANRI 	= ? "
			+ "  , KJ_OKYAKUM   = ? "
			+ "  , CD_NORIKUSI 	= ? "
			+ "  , KB_NOSYASYU 	= ? "
			+ "  , CD_NOGYOTAI 	= ? "
			+ "  , NO_NOSEIRI 	= ? "
			+ "  , MJ_SITKATA 	= ? "
			+ "  , NO_SYADAI 	= ? "
			+ "  , MJ_SYAMEI 	= ? "
			+ "  , DD_SYODOTOR 	= ? "
			+ "  , DD_SYKNMANR 	= ? "
//			+ "  , NO_KATARUIB 	= ? "
			+ "  , CD_TOSYOKU 	= ? "
			+ "  , NU_SOUKUKM 	= ? "
			+ "  , CD_SIRTENPO 	= ? "
			+ "  , CD_SDTAN 	= ? "
			+ "  , KI_NYUKOK 	= ? "

			+ "  , CD_KOZINZYHO = ? "
			+ "  , NO_ZYUTYU 	= ? "
			+ "  , MJ_UKETAN 	= ? "

			+ "  , NO_SYARYOU 	= ? "
			// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため start
			+ "  , DD_SIIRE 	= ? "
			// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため end
			+"   ,NO_UKETAN	    = ? "   //追加	2015.5.7

			+ "  , MJ_BIKOU 	= ? "
			+ "  , DT_KOSIN 	= ? "
			+ "  , CD_KSNSYA 	= ? "
			+ "  , CD_KSNAPP 	= ? "
			+ "WHERE "
/*2019.3.20			
			+ "      CD_KAISYA 	 = ? "
			+ "  AND CD_HANBAITN = ? "
*/
			+ "      CD_KAISYA 	 = ? ";
		
		if(UcarConst.WCOROLLA.equals(registerInputBean.getCdHanbaitn())){
			executeSql += "  AND CD_HANBAITN = ? ";
		}
		executeSql += ""
//2019.3.20
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<値>
//--2019.3.20 FROM
		if(UcarConst.WCOROLLA.equals(registerInputBean.getCdHanbaitn())){
			paramBean.setString(UcarConst.WCOROLLA);
		}else{
			paramBean.setString(registerInputBean.getCdTenpoHanbaitnSel());	// 販社コード			
		}
//--2019.3.20 TO
		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		paramBean.setString(registerInputBean.getKjOkyakum());	// お客様名
		paramBean.setString(registerInputBean.getCdNorikusi());	// 登録NO陸支コード

		paramBean.setString(registerInputBean.getKbNosyasyu());	// 登録NO業種区分

		paramBean.setString(registerInputBean.getCdNogyotai());	// 登録NO業態コード

		paramBean.setString(registerInputBean.getNoNoseiri());	// 登録NO整理番号
		paramBean.setString(registerInputBean.getMjSitkata());	// 指定型式

		paramBean.setString(registerInputBean.getNoSyadai());	// 車台番号
		paramBean.setString(registerInputBean.getMjSyamei());	// 車名
		paramBean.setString(registerInputBean.getDdSyodotor());	// 初度登録日

		paramBean.setString(registerInputBean.getDdSyknmanr());	// 車検満了日
//		paramBean.setString(registerInputBean.getNoKataruib());	// 型式指定類別NO
		paramBean.setString(registerInputBean.getCdTosyoku());	// 塗色コード

		paramBean.setInt(registerInputBean.getNuSoukukm());		// 走行距離
		paramBean.setString(registerInputBean.getCdSirtenpo());	// 仕入店舗コード

		paramBean.setString(registerInputBean.getCdSdtan());	// 下取担当者コード

		paramBean.setInt(registerInputBean.getKiNyukok());		// 入庫価格

		paramBean.setString(registerInputBean.getCdKozinzyho());// 個人情報処理コード

		paramBean.setString(registerInputBean.getNoZyutyu());	// 受注番号
		paramBean.setString(registerInputBean.getMjUketan());	// 受付担当者


		paramBean.setString(registerInputBean.getNoSyaryou());	// ai21車両NO
		// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため start
		paramBean.setString(registerInputBean.getDdSiire());	// ai21仕入日
		// 2013.05.20 T.Hayato 追加 ai21仕入日登録のため end
		paramBean.setString(registerInputBean.getNoUketan());	// 受付担当者コード	2015.5.7
		paramBean.setString(registerInputBean.getMjBikou());	// 備考

		paramBean.setTimestamp(executeDate);	// データ更新日時

		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード
/*2019.3.20 from
		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード 
*/		
		if(UcarConst.WCOROLLA.equals(registerInputBean.getCdHanbaitn())){
			paramBean.setString(UcarConst.WCOROLLA);
		}
//2019.3.20 to

		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		paramBean.setString(t220001gDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行


		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#updateT220001G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean, java.util.Date)
	 */
	@Override
	public SimpleExecuteResultBean updateT220001GOnlyHannyuCheck(
			RegisterInputBean registerInputBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String loginKbScenter,
			String kbData,		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String t220001gDtKosin,
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (kbData.equals(UcarConst.KB_DATA_UKETORI)) {
			sqlTenpo = "  AND CD_UKETENPO = ? ";
		} else {
			sqlTenpo = "  AND CD_HANTENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 更新処理（車両搬入情報：搬入チェック情報のみ）SQL 2011.10.31 H.Yamashita*/
		String executeSql
			= "UPDATE "
//			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ UcarTableManager.getSyaryoHannyuUpdate(loginKbScenter, kbData)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "SET "
			+ "   CD_KOZINZYHO = ? "
			+ "  , NO_ZYUTYU 	= ? "
			+ "  , MJ_UKETAN 	= ? "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
			+ "  , DD_INKANKGN 	= ? "
			// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end
			+ "  , MJ_BIKOU 	= ? "
			+ "  , DT_KOSIN 	= ? "
			+ "  , CD_KSNSYA 	= ? "
			+ "  , CD_KSNAPP 	= ? "
			+ "WHERE "
			+ "      CD_KAISYA 	 = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		// チェック内容　書類完備日　個人情報　受注№　受付担当者　備　考


		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<値>
		paramBean.setString(registerInputBean.getCdKozinzyho());// 個人情報処理コード

		paramBean.setString(registerInputBean.getNoZyutyu());	// 受注番号
		paramBean.setString(registerInputBean.getMjUketan());	// 受付担当者

		// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
		paramBean.setString(registerInputBean.getDdInkankgn());	// 印鑑証明期限日
		// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end

		paramBean.setString(registerInputBean.getMjBikou());	// 備考

		paramBean.setTimestamp(executeDate);					// データ更新日時

		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード

		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード

		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		paramBean.setString(t220001gDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行


		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#updateT220001GOnlyMjBikou(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean, java.lang.String, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220001GOnlyMjBikou(
			RegisterInputBean registerInputBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String loginKbScenter,
			String kbData,		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String t220001gDtKosin,
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (kbData.equals(UcarConst.KB_DATA_UKETORI)) {
			sqlTenpo = "  AND CD_UKETENPO = ? ";
		} else {
			sqlTenpo = "  AND CD_HANTENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		/** 更新処理（車両搬入情報：備考のみ）SQL */
		String executeSql
			= "UPDATE "
//			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ UcarTableManager.getSyaryoHannyuUpdate(loginKbScenter, kbData)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "SET "
			+ "    MJ_BIKOU 	= ? "
			+ "  , DT_KOSIN 	= ? "
			+ "  , CD_KSNSYA 	= ? "
			+ "  , CD_KSNAPP 	= ? "
			+ "WHERE "
			+ "      CD_KAISYA 	 = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		// 備　考

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// パラメータセット<値>
		paramBean.setString(registerInputBean.getMjBikou());	// 備考

		paramBean.setTimestamp(executeDate);					// データ更新日時

		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード

		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード

		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		paramBean.setString(t220001gDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行


		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#updateT220001GOnlyMjBikou(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean, java.lang.String, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220001GAlsoNuSoukukm(
			RegisterInputBean registerInputBean,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String loginKbScenter,
			String kbData,		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String t220001gDtKosin,
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (kbData.equals(UcarConst.KB_DATA_UKETORI)) {
			sqlTenpo = "  AND CD_UKETENPO = ? ";
		} else {
			sqlTenpo = "  AND CD_HANTENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため start
		/** 更新処理（車両搬入情報：走行距離、備考のみ）SQL */
		String executeSql
			= "UPDATE "
//			+ UcarTableManager.getSyaryoHannyu(loginKbScenter)
			+ UcarTableManager.getSyaryoHannyuUpdate(loginKbScenter, kbData)	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

			+ "SET "
			+ "    NU_SOUKUKM 	= ? "
			+ "  , MJ_BIKOU 	= ? "
			+ "  , DT_KOSIN 	= ? "
			+ "  , CD_KSNSYA 	= ? "
			+ "  , CD_KSNAPP 	= ? "
			+ "WHERE "
			+ "      CD_KAISYA 	 = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";
		// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため end

		// 備　考

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start

		// パラメータセット<値>
		paramBean.setInt(registerInputBean.getNuSoukukm());		// 走行距離
		paramBean.setString(registerInputBean.getMjBikou());	// 備考

		paramBean.setTimestamp(executeDate);					// データ更新日時

		paramBean.setString(registerInputBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(registerInputBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(registerInputBean.getCdKaisya());	// 会社コード

		paramBean.setString(registerInputBean.getCdHanbaitn());	// 販売店コード

		paramBean.setString(registerInputBean.getDdHannyu());	// 搬入日
		paramBean.setString(registerInputBean.getNoKanri());	// 管理番号
		paramBean.setString(loginCdTenpo);						// 搬入または受取店舗コード	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		paramBean.setString(t220001gDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行


		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}
	// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため end

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#updateT220001G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean, java.util.Date)
	 */
	@Override
//	public SimpleExecuteResultBean updateT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean updateT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
													String cdTenpoHanbaitnSel, // 2019.04.04 T.Osada
													String loginKbScenter,
													String menuId,
													Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		/** 更新処理（ステータスＤＢ）SQL1 */
		String executeSql
			= "UPDATE "
			+ UcarTableManager.getStatus(loginKbScenter)
			+ "SET ";

		/** 更新処理（ステータスＤＢ）SQL2 */
		String executeSql2
			= "  , DT_KOSIN 	= ? "
			+ "  , CD_KSNSYA 	= ? "
			+ "  , CD_KSNAPP 	= ? "
			+ "WHERE "
			+ "      CD_KAISYA 	 = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder targetSql = new StringBuilder(executeSql);

		// パラメータセット<値>
		if(menuId.equals(CarryinConst.CarryinMenuId.List.toString())){
			// 車両搬入一覧
			targetSql.append("    DT_STATUS01 	= TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') ");
			paramBean.setString(t220012gInputDataBean.getStrDtStatus01());	// ステータス01

		}else if(menuId.equals(CarryinConst.CarryinMenuId.DocumentCheck.toString())){
			// 書類完備時

			targetSql.append("     DT_STATUS03 	= TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') ");
			paramBean.setString(t220012gInputDataBean.getStrDtStatus03());	// ステータス03
			targetSql.append("    ,DT_STATUS04 	= TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') ");
			paramBean.setString(t220012gInputDataBean.getStrDtStatus04());	// ステータス04
		}

		targetSql.append(executeSql2);
		paramBean.setSql(targetSql.toString());

		paramBean.setTimestamp(executeDate);	// データ更新日時

		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		/* 2019.04.04 T.Osada
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		*/
		paramBean.setString(cdTenpoHanbaitnSel);                    // 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectT220002G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterSearchConditionBean)
	 */
	@Override
	public ResultArrayList<Ucab007gBean> selectT220012G(
//			Ucaa001gPKBean t220001gPkBean,
			Uccb007gPKBean t220001gPkBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String cdTenpoHanbaitnSel,
			String loginKbScenter) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220001gPkBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		/** ステータスDB SQL */
		String SELECT_T220012G_SQL
			= "SELECT "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			// 2012.02.10 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
			+ "  , DT_STATUS01 "
			+ "  , DT_STATUS03 "
			+ "  , DT_STATUS05 "
			+ "  , DT_STATUS07 "
			+ "  , NU_AZONE "
			+ "  , NU_BZONE "
			// 2012.02.10 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため end
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ "FROM "
			+ UcarTableManager.getStatus(loginKbScenter)
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220012G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220001gPkBean.getCdKaisya());		// 会社コード
		/*2019.3.20 from
		paramBean.setString(t220001gPkBean.getCdHanbaitn());	// 販売店コード cdTenpoHanbaitnSel
		if(t220001gPkBean.getCdHanbaitn().equals(UcarConst.WCOROLLA)){
			paramBean.setString(UcarConst.WCOROLLA);	// 販売店コード
		}			
		*/
		paramBean.setString(cdTenpoHanbaitnSel);	// 販売店コード 
		//2019.3.20 to		
		paramBean.setString(t220001gPkBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPkBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!t220001gPkBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220001gPkBean.getCdZaitenpo());	// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		ResultArrayList<Ucab007gBean> t220012gList = executeSimpleSelectQuery(paramBean, Ucab007gBean.class);

		return t220012gList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#deleteT220003G(com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean)
	 */
	@Override
	public SimpleExecuteResultBean deleteT220012G(
			String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			String loginCdTenpo,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			String loginKbScenter) throws TecDAOException {

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		/** 削除処理（ステータス情報）SQL */
		final String DELETE_T220012G_SQL
			= "DELETE "
			+ "FROM "
			+ UcarTableManager.getStatus(loginKbScenter)
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220012G_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);			// 会社コード

		paramBean.setString(cdHanbaitn);		// 販売店コード

		paramBean.setString(ddHannyu);			// 搬入日
		paramBean.setString(noKanri);			// 管理番号
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(loginCdTenpo);	// 在庫店舗コード

		}
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectKbData(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public String selectKbData(
			String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri,
			String loginCdTenpo) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220902V_KB_DATA_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);			// 会社コード

		paramBean.setString(cdHanbaitn);		// 販売店コード

		paramBean.setString(ddHannyu);			// 搬入日
		paramBean.setString(noKanri);			// 管理番号
		paramBean.setString(loginCdTenpo);		// 搬入または受取店舗コード


		ResultArrayList<Uccb011vBean> T220902vList = executeSimpleSelectQuery(paramBean, Uccb011vBean.class);

		String kbData = "";
		if(T220902vList.size() > 0){
			kbData = T220902vList.get(0).getKbData();
			if(T220902vList.size() > 1){
				TecLogger.warn("車両搬入受取情報ビュー 不整合");
			}
		}
		return kbData;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectNoSyadaiCount(java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Ucaa001gBean> selectCdHantenpo(String noSyadai,
//			String loginKbScenter)	throws TecDAOException {						// 2014.10.20(2015.9.9再設定 H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加
			String loginKbScenter, String cdHanbaitn)	throws TecDAOException {	// 2014.10.20(2015.9.9再設定 H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加
		
		String sqlTenpo = "";
		if (!loginKbScenter.equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "    AND HANNYU.CD_HANTENPO = HANSYUTU.CD_ZAITENPO ";
		}
		
		/** 車台番号で搬入店舗コード取得処理（車両搬入情報）SQL */
		final String SELECT_CD_HANTENPO_SQL
			= "SELECT "
			+ "  HANNYU.CD_KAISYA "
			+ "  , HANNYU.CD_HANTENPO "
			+ "FROM "
			+ "  " + UcarTableManager.getSyaryoHannyuSelectOnly(loginKbScenter) + " HANNYU "	
			+ "  LEFT JOIN " + UcarTableManager.getSyaryoHansyutu(loginKbScenter) + " HANSYUTU "
			+ "    ON HANNYU.CD_KAISYA		= HANSYUTU.CD_KAISYA "
			+ "    AND HANNYU.CD_HANBAITN	= HANSYUTU.CD_HANBAITN "
			+ "    AND HANNYU.DD_HANNYU		= HANSYUTU.DD_HANNYU "
			+ "    AND HANNYU.NO_KANRI		= HANSYUTU.NO_KANRI "
			+ sqlTenpo
			+ "WHERE "
			+ "      TRIM(HANNYU.NO_SYADAI)	= ? "
			+ "  AND HANSYUTU.DD_HANSYT		IS NULL "
		
		// 2014.10.20(2015.9.9再設定 H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加 start
			+ "  AND HANNYU.CD_HANBAITN		= ? ";	
		// 2014.10.20(2015.9.9再設定 H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加 end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_CD_HANTENPO_SQL);

		// パラメータセット<条件>
		paramBean.setString(noSyadai.trim());	// 車台番号
		
		// 2014.10.20(2015.9.9再設定 H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加 start
		paramBean.setString(cdHanbaitn);	// 販売店コード
		// 2014.10.20(2015.9.9再設定 H.Hara) H.Yamashita 障害票278対応 販売店コードを条件に追加 end

		ResultArrayList<Ucaa001gBean> t220001gList = executeSimpleSelectQuery(paramBean, Ucaa001gBean.class);

		return t220001gList;
	}
	
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF#selectKjTentanms(java.lang.String, java.lang.String)
	 */
	@Override
	public String selectKjTentanms(String cdKaisya,
									String cdHanbaitn,
									String cdTenpo) throws TecDAOException {

		final String SELECT_KJ_TENTANMS_SQL
			= "SELECT "
			+ "  TRIM('　' FROM KJ_TENTANMS) AS KJ_TENTANMS "
			+ "FROM "
			+ "  " + AddonTableManager.getKyoutuTenpo(cdHanbaitn) + " "
			+ "WHERE "
			+ "      CD_KAISYA = ? "
			+ "  AND CD_TENPO  = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_KJ_TENTANMS_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード

		paramBean.setString(cdTenpo);		// 店舗コード


		ResultArrayList<Tbv0201mBean> tbv0201mList = executeSimpleSelectQuery(paramBean, Tbv0201mBean.class);

		String kjTentanms = "";
		if(tbv0201mList.size() > 0){
			kjTentanms = tbv0201mList.get(0).getKjTentanms();
			if(tbv0201mList.size() > 1){
				TecLogger.warn("共通店舗DB 不整合");
			}
		}
		return kjTentanms;
	}
	// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　end
	
}