package com.toyotec_jp.ucar.workflow.carryin.common;

import java.util.List;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListDataBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListParamBean;
import com.toyotec_jp.ucar.workflow.report.model.object.HannyuIchiranSingleParamBean;

/**
 * <strong>車両搬入セッションBean。</strong>
 * <p>
 * セッションに格納する車両搬入パッケージ共通セッションBean。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[車両搬入(共通)]]
 */
public class CarryinSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** サービスID */
	private String serviceId;
	/** メニューID */
	private String menuId;
	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;
	/** 車両搬入一覧画面検索情報Bean */
	private ListParamBean listParamBean;

	/** 車両搬入一覧画面検索情報Bean */
	private HannyuIchiranSingleParamBean hannyuIchiranSingleParamBean;

	/** ソート順 */
	private String sortOrder;
	/** ソートキー */
	private String sortParam;
	/** ページ番号 */
	private String pageNo;
	/** ページサイズ */
	private String pageSize;
	/** 車両搬入情報：データ更新日時(排他チェック用) */
	private String t220001gDtKosin;

	/** ダウンロードファイルパス */
	private String downloadFilePath;

	/** 搬入一覧 検索on/off */
	private String isKensakuOn;
	/** 車両チェック(入庫検査／作業仕分)からの画面遷移であるかを判定 */
	private boolean isTransCarCheck;
	/** 車両搬入一覧／書類チェック画面での選択行番号 */
	private String selectRowNumber;
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
	/** 搬入書類チェックからの画面遷移であるかを判定 */
	private boolean isTransDocumentCheck;
	/** 表示リスト(排他チェック用) */
	private List<ListDataBean> documentCheckDataList;
	/** 実行処理内容
	 * <pre>
	 * いずれかの処理の時に文字列を設定
	 * 登録処理：register
	 * 保留処理：reserve
	 * 取消処理：cancel
	 * </pre>
	 *  */
	private String documentCheckExecute;
	/** 処理実行件数
	 * <pre>
	 * 登録、保留、取消時の処理実行件数
	 * </pre> */
	private int countExecute;
	/** 搬入書類チェックでの保留時に先頭で選択されたPKキー */
	private String selectHeadReservePk;
	// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end
	
/*2016.9.5 
	// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
	/// ログインユーザ：店舗コード 
	private String loginCdTenpo;
	// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
--*/
	/**
	 * デフォルトコンストラクタ。
	 */
	public CarryinSessionBean() {
		setDefaultParams();
	}

	/**
	 * デフォルトパラメータ設定。
	 * <pre>
	 * メニューID以外のパラメータ初期化。
	 * </pre>
	 */
	public void setDefaultParams(){
		t220001gPkBean 		= new Ucaa001gPKBean();
		sortOrder			= "";
		sortParam			= "";
		pageNo				= "1";
		pageSize			= "100";
		listParamBean		= new ListParamBean();
		isTransCarCheck		= false;
		selectRowNumber     = "0";
		documentCheckExecute= "";
		countExecute		= 0;
	}

	/**
	 * serviceIdを取得する。
	 * @return serviceId サービスID
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * serviceIdを設定する。
	 * @param serviceId サービスID
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * menuIdを取得する。
	 * @return menuId メニューID
	 */
	public String getMenuId() {
		return menuId;
	}

	/**
	 * menuIdを設定する。
	 * @param menuId メニューID
	 */
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean 車両搬入情報 プライマリーキーBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean 車両搬入情報 プライマリーキーBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}

	/**
	 * listParamBeanを取得する。
	 * @return listParamBean 車両搬入一覧画面検索情報Bean
	 */
	public ListParamBean getListParamBean() {
		return listParamBean;
	}

	/**
	 * listParamBeanを設定する。
	 * @param listParamBean 車両搬入一覧画面検索情報Bean
	 */
	public void setListParamBean(ListParamBean listParamBean) {
		this.listParamBean = listParamBean;
	}

	/**
	 * sortOrderを取得する。
	 * @return sortOrder ソート順
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * sortOrderを設定する。
	 * @param sortOrder ソート順
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * sortParamを取得する。
	 * @return sortParam ソートキー
	 */
	public String getSortParam() {
		return sortParam;
	}

	/**
	 * sortParamを設定する。
	 * @param sortParam ソートキー
	 */
	public void setSortParam(String sortParam) {
		this.sortParam = sortParam;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo ページ番号
	 */
	public String getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @return pageNo ページ番号
	 */
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @param pageSize ページサイズ
	 */
	public String getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize ページサイズ
	 */
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}


	/**
	 * t220001gDtKosinを取得する。
	 * @return t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 */
	public String getT220001gDtKosin() {
		return t220001gDtKosin;
	}

	/**
	 * t220001gDtKosinを設定する。
	 * @param t220001gDtKosin 車両搬入情報：データ更新日時(排他チェック用)
	 */
	public void setT220001gDtKosin(String t220001gDtKosin) {
		this.t220001gDtKosin = t220001gDtKosin;
	}

	/**
	 * downloadFilePathを取得する。
	 * @return downloadFilePath ダウンロードファイルパス
	 */
	public String getDownloadFilePath() {
		return downloadFilePath;
	}

	/**
	 * downloadFilePathを設定する。
	 * @param downloadFilePath ダウンロードファイルパス
	 */
	public void setDownloadFilePath(String downloadFilePath) {
		this.downloadFilePath = downloadFilePath;
	}

	public String getIsKensakuOn() {
		return isKensakuOn;
	}

	public void setIsKensakuOn(String isKensakuOn) {
		this.isKensakuOn = isKensakuOn;
	}

	public HannyuIchiranSingleParamBean getHannyuIchiranSingleParamBean() {
		return hannyuIchiranSingleParamBean;
	}

	public void setHannyuIchiranSingleParamBean(
			HannyuIchiranSingleParamBean hannyuIchiranSingleParamBean) {
		this.hannyuIchiranSingleParamBean = hannyuIchiranSingleParamBean;
	}

	/**
	 * isTransCarCheckを取得する。
	 * @return isTransCarCheck
	 */
	public boolean isTransCarCheck() {
		return isTransCarCheck;
	}

	/**
	 * isTransCarCheckを設定する。
	 * @param isTransCarCheck
	 */
	public void setTransCarCheck(boolean isTransCarCheck) {
		this.isTransCarCheck = isTransCarCheck;
	}

	/**
	 * isTransDocumentCheckを取得する。
	 * @return isTransDocumentCheck
	 */
	public boolean isTransDocumentCheck() {
		return isTransDocumentCheck;
	}

	/**
	 * isTransDocumentCheckを設定する。
	 * @param isTransDocumentCheck
	 */
	public void setTransDocumentCheck(boolean isTransDocumentCheck) {
		this.isTransDocumentCheck = isTransDocumentCheck;
	}

	/**
	 * selectRowNumberを取得する。
	 * @return selectRowNumber
	 */
	public String getSelectRowNumber() {
		return selectRowNumber;
	}

	/**
	 * selectRowNumberを設定する。
	 * @param selectRowNumber
	 */
	public void setSelectRowNumber(String selectRowNumber) {
		this.selectRowNumber = selectRowNumber;
	}

	/**
	 * documentCheckDataListを取得する。
	 * @return documentCheckDataList
	 */
	public List<ListDataBean> getDocumentCheckDataList() {
		return documentCheckDataList;
	}

	/**
	 * documentCheckDataListを設定する。
	 * @param documentCheckDataList
	 */
	public void setDocumentCheckDataList(List<ListDataBean> documentCheckDataList) {
		this.documentCheckDataList = documentCheckDataList;
	}

	/**
	 * documentCheckExecuteを取得する。
	 * @return documentCheckExecute
	 */
	public String getDocumentCheckExecute() {
		return documentCheckExecute;
	}

	/**
	 * documentCheckExecuteを設定する。
	 * @param documentCheckExecute
	 */
	public void setDocumentCheckExecute(String documentCheckExecute) {
		this.documentCheckExecute = documentCheckExecute;
	}

	/**
	 * countExecuteを取得する。
	 * @return countExecute
	 */
	public int getCountExecute() {
		return countExecute;
	}

	/**
	 * countExecuteを設定する。
	 * @param countExecute
	 */
	public void setCountExecute(int countExecute) {
		this.countExecute = countExecute;
	}

	/**
	 * selectHeadReservePkを取得する。
	 * @return selectHeadReservePk
	 */
	public String getSelectHeadReservePk() {
		return selectHeadReservePk;
	}

	/**
	 * selectHeadReservePkを設定する。
	 * @param selectHeadReservePk
	 */
	public void setSelectHeadReservePk(String selectHeadReservePk) {
		this.selectHeadReservePk = selectHeadReservePk;
	}

	/**
	 * loginCdTenpoを取得する。
	 * @return loginCdTenpo
	 */
/*2016.9.5 	
	public String getLoginCdTenpo() {
		return loginCdTenpo;
	}
--*/
	/**
	 * loginCdTenpoを設定する。
	 * @param loginCdTenpo
	 */
/*2016.9.5	
	public void setLoginCdTenpo(String loginCdTenpo) {
		this.loginCdTenpo = loginCdTenpo;
	}
--*/
}
