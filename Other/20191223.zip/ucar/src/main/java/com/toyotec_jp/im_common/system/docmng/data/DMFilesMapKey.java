/*
 * 【システム名】
 * 【ファイル名】DMFilesMapKey.java
 * 【  説  明  】マッピング用キー項目クラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

/**
 * <strong>DMFilesMapKey</strong>
 * <p>
 * マッピング用キー項目クラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMFilesMapKey {

	/**
	 * コンストラクタ
	 * @param sheetIdx 様式シート定義-シートインデックス
	 * @param shoriShosaiKbn 様式項目定義-処理詳細区分(0201:通常セット、0211:縦方向リスト、0212:横方向リスト)
	 * @param listId 様式項目定義-リストID
	 */
	public DMFilesMapKey(int sheetIdx, String shoriShosaiKbn, String listId){
		this.sheetIdx = sheetIdx;
		this.shoriShosaiKbn = shoriShosaiKbn;
		this.listId = listId;
	}

	private int sheetIdx;
	private String shoriShosaiKbn;
	private String listId;

	/**
	 * equals<br>
	 * オーバーライド<br>
	 * @param obj 対象オブジェクト
	 * @return true:対象のシートインデックス、処理詳細区分、リストIDの値が等しい場合
	 * @since 1.00
	 */
	public boolean equals(Object obj){
		if(this == obj){
			return true;
		}
		if(!(obj instanceof DMFilesMapKey)){
			return false;
		}
		DMFilesMapKey target = (DMFilesMapKey)obj;
		return
			(sheetIdx == target.sheetIdx) &&
			((shoriShosaiKbn == null) ? target.shoriShosaiKbn == null : shoriShosaiKbn.equals(target.shoriShosaiKbn)) &&
			((listId == null) ? target.listId == null : listId.equals(target.listId));
	}

	/**
	 * ハッシュコード値返却<br>
	 * オーバーライド<br>
	 * シートインデックス、処理詳細区分、リストIDから算出
	 * @return ハッシュコード値
	 * @since 1.00
	 */
	public int hashCode(){
		int hash = 1;
		hash = hash * 31 + sheetIdx;
		hash = hash * 31 + (shoriShosaiKbn == null ? 0 : shoriShosaiKbn.hashCode());
		hash = hash * 31 + (listId == null ? 0 : listId.hashCode());
		return hash;
	}

	/**
	 * 様式項目定義-リストID取得
	 * @return 様式項目定義-リストID
	 * @since 1.00
	 */
	public String getListId() {
		return listId;
	}
	/**
	 * 様式シート定義-シートインデックス取得
	 * @return 様式シート定義-シートインデックス
	 * @since 1.00
	 */
	public int getSheetIdx() {
		return sheetIdx;
	}
	/**
	 * 様式項目定義-処理詳細区分取得
	 * @return 様式項目定義-処理詳細区分(0201:通常セット、0211:縦方向リスト、0212:横方向リスト)
	 * @since 1.00
	 */
	public String getShoriShosaiKbn() {
		return shoriShosaiKbn;
	}

}
