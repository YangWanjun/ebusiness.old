package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.SagyousyaMasterDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba008mBean;

/**
 * <strong>作業者マスタDB操作用イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/07/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SagyousyaMasterEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		SagyousyaMasterEvent targetEvent = (SagyousyaMasterEvent) event;

		SagyousyaMasterDAOIF dao
			= getDAO(UcarDAOKey.SAGYOUSYA_MASTER_DAO, event, SagyousyaMasterDAOIF.class);

		// 作業マスタ取得
		ResultArrayList<Ucba008mBean> sagyousyaMasterList
			= dao.getSagyousyaMasterList(targetEvent.getCdKaisya(), targetEvent.getCdJigyosyo(), targetEvent.getCdSyokusyu());

		return sagyousyaMasterList;
	}

}
