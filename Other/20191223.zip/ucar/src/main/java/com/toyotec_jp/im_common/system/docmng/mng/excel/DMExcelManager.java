/*
 * 【システム名】
 * 【ファイル名】DMExcelManager.java
 * 【  説  明  】Excel操作クラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.mng.excel;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Footer;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapKey;
import com.toyotec_jp.im_common.system.docmng.data.DMResultColumn;
import com.toyotec_jp.im_common.system.docmng.data.DMResultList;
import com.toyotec_jp.im_common.system.docmng.data.DMResultSheet;
import com.toyotec_jp.im_common.system.docmng.data.DMSheetMap;
import com.toyotec_jp.im_common.system.docmng.data.DMYoshikiMap;
import com.toyotec_jp.im_common.system.exception.TecExcelMngException;
import com.toyotec_jp.im_common.system.exception.TecFileMngException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.IMFileManagerIF;
import com.toyotec_jp.im_common.system.utils.IMStorageServiceManager;

/**
 * <strong>DMExcelManager</strong>
 * <p>
 * Excel操作クラス<br>
 * POI 3.5.0 版
 * </p>
 * @author H.O(SCC)
 * @version 1.03 2011/04/01 <br>
 */
public class DMExcelManager {

	// TODO
	// POI 3.0.2 版だったが
	// 3.0.2では入力規則が消えるという問題が発生したため
	// 急遽3.2.0に変更になった
	// そのため対応し切れていない可能性あり
	// 次期バージョン開発時にはその対応も検討すること

	private static final String className = DMExcelManager.class.getName();

	/** コンストラクタ */
	private DMExcelManager() {
	}

	/** インスタンス */
	private static final DMExcelManager instance = new DMExcelManager();

	/** 改ページ区分 0:固定 */
	private static final int PAGE_KBN_DEF = 0;
	/** 改ページ区分 1:縦 */
	private static final int PAGE_KBN_VRT = 1;

	/** エラーメッセージ:ブックNull */
	private static final String MSG_ERR_NULL_BOOK = "対象ブックがNullになっています";
	/** エラーメッセージ:シートNull */
	private static final String MSG_ERR_NULL_SHEET = "対象シートがNullになっています";
	/** エラーメッセージ:対象ファイルNull */
	private static final String MSG_ERR_NULL_FILE = "対象ファイルがNullになっています";
	/** エラーメッセージ:様式定義Null */
	private static final String MSG_ERR_NULL_YOSHIKI_DEF = "様式定義がNullになっています";

	/** エラーメッセージ:ブック取得失敗 */
	private static final String MSG_ERR_GET_BOOK = "対象ブック取得に失敗しました";
	/** エラーメッセージ:ブック保存失敗 */
	private static final String MSG_ERR_SAVE_BOOK = "対象ブック保存に失敗しました";

	/** エラーメッセージ:シートインデックス不正 */
	private static final String MSG_ERR_SHEET_IDX = "シートインデックス不正";

	/** エラーメッセージ:項目定義引数インデックス不正 */
	private static final String MSG_ERR_DEF_PARAM_IDX = "引数インデックスが不正または項目設定値の配列長が不足しています";
	/** エラーメッセージ:項目定義配列インデックス不正 */
	private static final String MSG_ERR_DEF_ARRAY_IDX = "配列インデックスが不正または項目設定値の配列長が不足しています";

	/**
	 * インスタンス取得
	 * @return Excel操作インスタンス
	 * @since 1.00
	 */
	public static DMExcelManager getInstance(){
		return instance;
	}

	/**
	 * Hiddenプロパティ取得
	 * @param originalByteStream 対象ファイルのバイト配列
	 * @param mapYoshiki 様式情報格納用マップ
	 * @return シート情報リスト
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	public DMResultSheet[] getDataHiddenProperties(
			byte[] originalByteStream,
			DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> mapYoshiki
			) throws TecExcelMngException {

		String funcName = className + ".getDataHiddenProperties";
		TecLogger.trace(funcName + ":start");

		if(originalByteStream == null){
			TecLogger.error(funcName + ":call_error(originalByteStream)");
			throw new TecExcelMngException(MSG_ERR_NULL_FILE);
		}
		if(mapYoshiki == null){
			TecLogger.error(funcName + ":call_error(DMYoshikiMap)");
			throw new TecExcelMngException(MSG_ERR_NULL_YOSHIKI_DEF);
		}

		DMResultSheet[] ret = null;
		DMWorkbook baseBook = new DMWorkbook(new ByteArrayInputStream(originalByteStream), null);
		ArrayList<DMResultSheet> sheetResultList = new ArrayList<DMResultSheet>();

		// シート単位処理
		for(int sheetKey : mapYoshiki.keySet()){
			DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet = mapYoshiki.get(sheetKey);
			DMResultSheet sheetResult = new DMResultSheet(mapSheet.getSheetIdx(), mapSheet.getSheetNm());
			ArrayList<DMResultList> listResList = new ArrayList<DMResultList>();
			// 対象シート取得
			DMSheet baseSheet = baseBook.getSheet(mapSheet.getSheetNm(), mapSheet);
			// 対象シートが存在する場合(Hiddenプロパティ操作時にシートが存在しない場合、例外としない)
			if(baseSheet != null && baseSheet.sheet != null){
				// 処理、リスト単位の処理
				for(DMFilesMapKey key : mapSheet.keySet()){
					ArrayList<DMFilesMapData> fileMapList = mapSheet.get(key);
					// 汎用項目取得
					if(DMFilesMapData.ShoriShosaiKbn.GET_DEF.toString().equals(key.getShoriShosaiKbn())){
						sheetResult.setSimpleColumns(getStandardValues(baseSheet, fileMapList));
					}
				}
				sheetResult.setResultLists(listResList.toArray(new DMResultList[listResList.size()]));
			}
			sheetResultList.add(sheetResult);
		}
		ret = sheetResultList.toArray(new DMResultSheet[sheetResultList.size()]);

		TecLogger.trace(funcName + ":end");
		return ret;
	}

	/**
	 * ファイル内容を取得
	 * @param originalByteStream 対象ファイルのバイト配列
	 * @param mapYoshiki 様式情報格納用マップ
	 * @return シート情報リスト
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	public DMResultSheet[] getData(
			byte[] originalByteStream,
			DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> mapYoshiki
			) throws TecExcelMngException {

		String funcName = className + ".getData";
		TecLogger.trace(funcName + ":start");

		if(originalByteStream == null){
			TecLogger.error(funcName + ":call_error(originalByteStream)");
			throw new TecExcelMngException(MSG_ERR_NULL_FILE);
		}
		if(mapYoshiki == null){
			TecLogger.error(funcName + ":call_error(DMYoshikiMap)");
			throw new TecExcelMngException(MSG_ERR_NULL_YOSHIKI_DEF);
		}

		DMResultSheet[] ret = null;
		DMWorkbook baseBook = new DMWorkbook(new ByteArrayInputStream(originalByteStream), null);
		ArrayList<DMResultSheet> sheetResultList = new ArrayList<DMResultSheet>();

		// シート単位処理
		for(int sheetKey : mapYoshiki.keySet()){
			TecLogger.trace("sheetKey:" + sheetKey);
			DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet = mapYoshiki.get(sheetKey);
			DMResultSheet sheetResult = new DMResultSheet(mapSheet.getSheetIdx(), mapSheet.getSheetNm());
			ArrayList<DMResultList> listResList = new ArrayList<DMResultList>();
			// 対象シート取得
			DMSheet baseSheet = baseBook.getSheet(mapSheet.getSheetNm(), mapSheet);
			// 対象シートが存在しない場合はエラー
			if(baseSheet == null || baseSheet.sheet == null){
				TecLogger.error(funcName + ":no_sheet_error");
				TecLogger.debug("[" + mapSheet.getSheetNm() + "]");
				throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
			}
			// 処理、リスト単位の処理
			for(DMFilesMapKey key : mapSheet.keySet()){
				TecLogger.trace("get[" + key.getShoriShosaiKbn() + "][" + key.getListId() + "]");
				ArrayList<DMFilesMapData> fileMapList = mapSheet.get(key);
				// 汎用項目取得
				if(DMFilesMapData.ShoriShosaiKbn.GET_DEF.toString().equals(key.getShoriShosaiKbn())){
					TecLogger.trace("map_get_def:" + fileMapList.size());
					sheetResult.setSimpleColumns(getStandardValues(baseSheet, fileMapList));
				// 縦方向リスト取得
				} else if(DMFilesMapData.ShoriShosaiKbn.GET_VRT.toString().equals(key.getShoriShosaiKbn())){
					TecLogger.trace("map_get_vrt:" + fileMapList.size());
					DMResultList listResult = new DMResultList(
							key.getSheetIdx(), key.getShoriShosaiKbn(), key.getListId());
					listResult.setListColumns(getVrtListValues(baseSheet, fileMapList));
					listResList.add(listResult);
				// 横方向リスト取得
				} else if(DMFilesMapData.ShoriShosaiKbn.GET_HRZ.toString().equals(key.getShoriShosaiKbn())){
					TecLogger.trace("map_get_hrz:" + fileMapList.size());
					DMResultList listResult = new DMResultList(
							key.getSheetIdx(), key.getShoriShosaiKbn(), key.getListId());
					listResult.setListColumns(getHrzListValues(baseSheet, fileMapList));
					listResList.add(listResult);
				}
			}
			sheetResult.setResultLists(listResList.toArray(new DMResultList[listResList.size()]));
			sheetResultList.add(sheetResult);
		}
		TecLogger.trace("getLen:" + sheetResultList.size());
		ret = sheetResultList.toArray(new DMResultSheet[sheetResultList.size()]);

		TecLogger.trace(funcName + ":end");
		return ret;
	}

	/**
	 * 汎用項目取得
	 * @param baseSheet 対象シート
	 * @param fileMapList シート、処理単位のマッピングリスト
	 * @return 汎用項目取得結果リスト
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private DMResultColumn<?>[] getStandardValues(
			DMSheet baseSheet, ArrayList<DMFilesMapData> fileMapList) throws TecExcelMngException{

		DMCellManager xlsCellMng = DMCellManager.getInstance();
		ArrayList<DMResultColumn<String>> columnList = new ArrayList<DMResultColumn<String>>();
		for(DMFilesMapData fileMapRec : fileMapList){
			// セルの値を取得
			DMResultColumn<String> fCol = new DMResultColumn<String>(
					fileMapRec.getKomokuNm(), fileMapRec.getKomokuKbn(),
					xlsCellMng.getCellValue(baseSheet, 0, 0, fileMapRec));
			columnList.add(fCol);
		}
		TecLogger.trace("col:" + columnList.size());
		return columnList.toArray(new DMResultColumn[columnList.size()]);
	}

	/**
	 * 縦方向リスト取得
	 * @param baseSheet 対象シート
	 * @param fileMapList シート、処理、リスト単位のマッピングリスト
	 * @return リスト取得結果リスト
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private DMResultColumn<?>[] getVrtListValues(
			DMSheet baseSheet, ArrayList<DMFilesMapData> fileMapList) throws TecExcelMngException{

		DMCellManager xlsCellMng = DMCellManager.getInstance();
		ArrayList<DMResultColumn<String[]>> columnList = new ArrayList<DMResultColumn<String[]>>();
		int lastRowIdx = baseSheet.sheet.getLastRowNum();
		//int lastColIdx = baseSheet.getShokiSaishuretsu();
		for(DMFilesMapData fileMapRec : fileMapList){
			ArrayList<String> valList = new ArrayList<String>();
			int pageStartRowIdx = 0;
			int baseRowIdx = 0;
			int baseColIdx = 0;
			int targetPageIdx = 0;
			int targetCnt = 1;
			int unitNowLen = 1;
			// 繰り返し(最大65536)
			while(targetCnt <= 65536){
				// １ユニットあたりの項目数が最大値を超えた、または基準行が対象ページ最終行を超えた場合
				// ユニット初期化、基準行、基準列修正
				if(
						(fileMapRec.getUnitKomokusu() > 0 && fileMapRec.getUnitKomokusu() < unitNowLen) ||
						(baseRowIdx > baseSheet.getLastRowIdx(targetPageIdx))){
					// 改ページ区分:固定の場合は終了
					if(baseSheet.getKaiPageKbn() == PAGE_KBN_DEF){
						break;
					}
					unitNowLen = 1;
					pageStartRowIdx = baseSheet.getLastRowIdx(targetPageIdx) + 1;
					baseRowIdx = pageStartRowIdx + baseSheet.getTsuikaGyoHoseichi();
					baseColIdx = baseSheet.getTsuikaRetsuHoseichi();
					targetPageIdx++;
				}
				// ページ開始行インデックスが最終行インデックスを超えた場合
				if(pageStartRowIdx > lastRowIdx){
					break;
				}
				// 最大項目数を超えた場合
				if(fileMapRec.getSaidaiKomokusu() > 0 && fileMapRec.getSaidaiKomokusu() < targetCnt){
					break;
				}
				// セルの値を取得
				valList.add(
						xlsCellMng.getCellValue(baseSheet, baseRowIdx, baseColIdx, fileMapRec));

				baseRowIdx += fileMapRec.getZobunchi();
				targetCnt++;
				unitNowLen++;
			}
			// セルの値を取得
			DMResultColumn<String[]> fCol = new DMResultColumn<String[]>(
					fileMapRec.getKomokuNm(), fileMapRec.getKomokuKbn(), valList.toArray(new String[valList.size()]));
			columnList.add(fCol);
		}
		return columnList.toArray(new DMResultColumn[columnList.size()]);
	}

	/**
	 * 横方向リスト取得
	 * @param baseSheet 対象シート
	 * @param fileMapList シート、処理、リスト単位のマッピングリスト
	 * @return リスト取得結果リスト
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private DMResultColumn<?>[] getHrzListValues(
			DMSheet baseSheet, ArrayList<DMFilesMapData> fileMapList) throws TecExcelMngException{

		DMCellManager xlsCellMng = DMCellManager.getInstance();
		ArrayList<DMResultColumn<String[]>> columnList = new ArrayList<DMResultColumn<String[]>>();
		int lastRowIdx = baseSheet.sheet.getLastRowNum();
		int lastColIdx = baseSheet.getShokiSaishuretsu();
		for(DMFilesMapData fileMapRec : fileMapList){
			ArrayList<String> valList = new ArrayList<String>();
			int pageStartRowIdx = 0;
			int baseRowIdx = 0;
			int baseColIdx = 0;
			int targetPageIdx = 0;
			int targetCnt = 1;
			int unitNowLen = 1;
			// 繰り返し(最大65536)
			while(targetCnt <= 65536){
				// １ユニットあたりの項目数が最大値を超えた、または基準列が最終列を超えた場合
				// ユニット初期化、基準行、基準列修正
				if(
						(fileMapRec.getUnitKomokusu() > 0 && fileMapRec.getUnitKomokusu() < unitNowLen) ||
						(baseColIdx > lastColIdx)){
					// 改ページ区分:固定の場合は終了
					if(baseSheet.getKaiPageKbn() == PAGE_KBN_DEF){
						break;
					}
					unitNowLen = 1;
					pageStartRowIdx = baseSheet.getLastRowIdx(targetPageIdx) + 1;
					baseRowIdx = pageStartRowIdx + baseSheet.getTsuikaGyoHoseichi();
					baseColIdx = baseSheet.getTsuikaRetsuHoseichi();
					targetPageIdx++;
				}
				// ページ開始行インデックスが最終行インデックスを超えた場合
				if(pageStartRowIdx > lastRowIdx){
					break;
				}
				// 最大項目数を超えた場合
				if(fileMapRec.getSaidaiKomokusu() > 0 && fileMapRec.getSaidaiKomokusu() < targetCnt){
					break;
				}
				// セルの値を取得
				valList.add(
						xlsCellMng.getCellValue(baseSheet, baseRowIdx, baseColIdx, fileMapRec));

				baseColIdx += fileMapRec.getZobunchi();
				targetCnt++;
				unitNowLen++;
			}
			// セルの値を取得
			DMResultColumn<String[]> fCol = new DMResultColumn<String[]>(
					fileMapRec.getKomokuNm(), fileMapRec.getKomokuKbn(), valList.toArray(new String[valList.size()]));
			columnList.add(fCol);
		}
		return columnList.toArray(new DMResultColumn[columnList.size()]);
	}

	/**
	 * Hiddenプロパティ設定後のファイル(バイト配列)取得
	 * @param byteArray 設定対象ファイル(バイト配列)
	 * @param mapYoshiki 様式情報格納用マップ
	 * @param writeStrings 汎用項目設定値
	 * @return 情報設定後のファイル(バイト配列)
	 * @throws TecExcelMngException
	 * @throws TecFileMngException
	 * @since 1.00
	 */
	public byte[] getFileByteArrayAfterSetHiddenProperties(
			byte[] byteArray,
			DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> mapYoshiki,
			String[] writeStrings
			) throws TecExcelMngException, TecFileMngException {

		String funcName = className + ".getFileByteArrayAfterSetHiddenProperties";
		TecLogger.trace(funcName + ":start");

		if(byteArray == null || byteArray.length == 0){
			TecLogger.error(funcName + ":call_error(byteArray)");
			throw new TecExcelMngException(MSG_ERR_NULL_FILE);
		}
		if(mapYoshiki == null){
			TecLogger.error(funcName + ":call_error(DMYoshikiMap)");
			throw new TecExcelMngException(MSG_ERR_NULL_YOSHIKI_DEF);
		}

		byte[] ret = null;
		DMWorkbook baseBook = new DMWorkbook(new ByteArrayInputStream(byteArray), null);
		DMCellManager xlsCellMng = DMCellManager.getInstance();

		// シート単位処理
		for(int sheetKey : mapYoshiki.keySet()){
			DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet = mapYoshiki.get(sheetKey);
			// 対象シート取得
			DMSheet baseSheet = baseBook.getSheet(mapSheet.getSheetNm(), mapSheet);
			// 対象シートが存在する場合(Hiddenプロパティ操作時にシートが存在しない場合、例外としない)
			if(baseSheet != null && baseSheet.sheet != null){
				// 処理、リスト単位の処理
				for(DMFilesMapKey key : mapSheet.keySet()){
					ArrayList<DMFilesMapData> fileMapList = mapSheet.get(key);
					// 汎用項目設定
					if(DMFilesMapData.ShoriShosaiKbn.SET_DEF.toString().equals(key.getShoriShosaiKbn())){
						for(DMFilesMapData fileMapRec : fileMapList){
							int arrIdx = fileMapRec.getHairetsuIdx();
							// 配列インデックスチェック
							if(writeStrings != null && writeStrings.length > arrIdx){
								// セルに値を設定
								xlsCellMng.setValue(baseBook, baseSheet, 0, 0, fileMapRec, writeStrings[arrIdx]);
							} else {
								int len = 0;
								if(writeStrings != null){
									len = writeStrings.length;
								}
								TecLogger.error(funcName + ":index_error(array)");
								TecLogger.debug("[" + arrIdx + "][" + len + "]");
								throw new TecExcelMngException(MSG_ERR_DEF_ARRAY_IDX);
							}
						}
					}
				}
			}
		}

		// バイト出力
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		baseBook.write(baos);
		ret = baos.toByteArray();

		TecLogger.trace(funcName + ":end");
		return ret;
	}

	/**
	 * 情報設定後のファイル(バイト配列)取得
	 * @param byteArray 設定対象ファイル(バイト配列)
	 * @param baseFilePath 情報設定対象ファイルのパス(IMStorageServiceRoot相対)
	 * @param mapYoshiki 様式情報格納用マップ
	 * @param writeStrings 汎用項目設定値
	 * @param writeLists リスト項目設定値
	 * @return 情報設定後のファイル(バイト配列)
	 * @throws TecExcelMngException
	 * @throws TecFileMngException
	 * @since 1.00
	 */
	public byte[] getFileByteArrayAfterSetData(
			byte[] byteArray, String baseFilePath,
			DMYoshikiMap<Integer, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>>> mapYoshiki,
			String[] writeStrings, String[][][] writeLists
			) throws TecExcelMngException, TecFileMngException {

		String funcName = className + ".getFileByteArrayAfterSetData";
		TecLogger.trace(funcName + ":start");

		if(byteArray == null || byteArray.length == 0){
			TecLogger.error(funcName + ":call_error(byteArray)");
			throw new TecExcelMngException(MSG_ERR_NULL_FILE);
		}
		if(mapYoshiki == null){
			TecLogger.error(funcName + ":call_error(DMYoshikiMap)");
			throw new TecExcelMngException(MSG_ERR_NULL_YOSHIKI_DEF);
		}

		byte[] ret = null;
		DMWorkbook baseBook = new DMWorkbook(new ByteArrayInputStream(byteArray), baseFilePath);

		// シート単位処理
		for(int sheetKey : mapYoshiki.keySet()){
			DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet = mapYoshiki.get(sheetKey);
			// 対象シート初期処理、取得
			DMSheet baseSheet = getAndSetupBaseSheet(baseBook, mapSheet);
			// 追加ページ用ブック、シート取得
			Workbook addPageBook = getHSSFWorkbook(mapSheet.getTsuikaFilePath());
			Sheet addPageSheet = getHSSFSheet(addPageBook, mapSheet.getTsuikaSheetNm());
			// 処理、リスト単位の処理
			for(DMFilesMapKey key : mapSheet.keySet()){
				ArrayList<DMFilesMapData> fileMapList = mapSheet.get(key);
				// 汎用項目設定
				if(DMFilesMapData.ShoriShosaiKbn.SET_DEF.toString().equals(key.getShoriShosaiKbn())){
					setStandardValues(
							baseBook, baseSheet, addPageBook, addPageSheet,
							fileMapList, writeStrings);
				// 縦方向リスト設定
				} else if(DMFilesMapData.ShoriShosaiKbn.SET_VRT.toString().equals(key.getShoriShosaiKbn())){
					setVrtListValues(
							baseBook, baseSheet, addPageBook, addPageSheet,
							fileMapList, writeLists);
				// 横方向リスト設定
				} else if(DMFilesMapData.ShoriShosaiKbn.SET_HRZ.toString().equals(key.getShoriShosaiKbn())){
					setHrzListValues(
							baseBook, baseSheet, addPageBook, addPageSheet,
							fileMapList, writeLists);
				}
				TecLogger.trace("pageIdx:" + baseSheet.getPageIdx());
			}
		}

		// シート選択状態初期化
		baseBook.initSheetSelect();

		// バイト出力
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		baseBook.write(baos);
		ret = baos.toByteArray();

		TecLogger.trace(funcName + ":end");
		return ret;
	}

	/**
	 * 対象シート初期設定、取得
	 * @param baseBook 対象ブック
	 * @param mapSheet シート情報格納用マップ
	 * @return 対象シート
	 * @throws TecFileMngException
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private DMSheet getAndSetupBaseSheet(
			DMWorkbook baseBook,
			DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet) throws TecFileMngException, TecExcelMngException{

		String funcName = className + ".getAndSetupBaseSheet";
		DMSheet baseSheet = null;
		boolean isSameBookCopy = false;
		if(mapSheet.getShokiFilePath() == null || mapSheet.getShokiFilePath().equals(baseBook.getFilePath())){
			isSameBookCopy = true;
		}

		// 対象シートインデックス
		int targetSheetIndex = mapSheet.getSheetIdx();
		// 対象シート名
		String targetSheetName = mapSheet.getSheetNm();
		boolean isCreateSheet = false;

		// 元ブックの対象シートインデックス
		int baseSheetIndex = baseBook.getSheetIndex(targetSheetName);
		// 元ブックに対象シート無し
		if(baseSheetIndex < 0){
			isCreateSheet = true;
			baseBook.createSheet(targetSheetName, mapSheet);
			baseSheetIndex = baseBook.getSheetIndex(targetSheetName);
		}
		// シートインデックスが異なる
		if(baseSheetIndex != targetSheetIndex){
			baseBook.setSheetOrder(targetSheetName, targetSheetIndex);
		}
		// 対象シート取得
		baseSheet = baseBook.getSheetAt(targetSheetIndex, mapSheet);
		if(baseSheet == null || baseSheet.sheet == null){
			TecLogger.error(funcName + ":no_sheet_error");
			TecLogger.debug("[" + targetSheetIndex + "]");
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}

		// 初期ページ用ブック、シート取得
		Workbook mainPageBook = null;
		Sheet mainPageSheet = null;
		if(!isSameBookCopy || isCreateSheet){
			mainPageBook = getHSSFWorkbook(mapSheet.getShokiFilePath());
			mainPageSheet = getHSSFSheet(mainPageBook, mapSheet.getShokiSheetNm());
		}
		// 初期ページ有り
		if(mainPageSheet != null){
			int insCnt = mapSheet.getShokiSaishugyo() + 1;
			removeRow(baseSheet.sheet, 0, insCnt);
			copyInsertRow(
					mainPageBook, mainPageSheet, baseBook.workbook, baseSheet.sheet,
					0, 0, insCnt, isSameBookCopy);
			copySheetInitial(
					mainPageSheet, baseBook.workbook, baseSheet.sheet, targetSheetIndex,
					mapSheet.getShokiSaishugyo(), mapSheet.getShokiSaishuretsu());
		} else {
			// 最終行に改ページ挿入
			baseSheet.sheet.setRowBreak(mapSheet.getShokiSaishugyo());
		}
		setForceFormulaRecalculation(baseSheet.sheet);
		return baseSheet;
	}

	/**
	 * 汎用項目設定
	 * @param baseBook 対象ブック
	 * @param baseSheet 対象シート
	 * @param addPageBook 追加ページ用ブック
	 * @param addPageSheet 追加ページ用シート
	 * @param fileMapList シート、処理単位のマッピングリスト
	 * @param writeStrings 汎用項目設定値
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private void setStandardValues(
			DMWorkbook baseBook, DMSheet baseSheet,
			Workbook addPageBook, Sheet addPageSheet,
			ArrayList<DMFilesMapData> fileMapList,
			String[] writeStrings) throws TecExcelMngException{

		String funcName = className + ".setStandardValues";
		DMCellManager xlsCellMng = DMCellManager.getInstance();
		for(DMFilesMapData fileMapRec : fileMapList){
			// シート内ページ設定
			setPage(baseBook, baseSheet, addPageBook, addPageSheet, fileMapRec.getTaishogyo());
			int paramIdx = fileMapRec.getHikisuIdx();
			int arrIdx = fileMapRec.getHairetsuIdx();
			// 配列インデックスチェック
			if(writeStrings != null && writeStrings.length > arrIdx){
				// セルに値を設定
				xlsCellMng.setValue(
						baseBook, baseSheet, 0, 0, fileMapRec, writeStrings[arrIdx]);
			} else {
				int len = 0;
				if(writeStrings != null){
					len = writeStrings.length;
				}
				TecLogger.error(funcName + ":index_error(array)");
				TecLogger.debug("[" + paramIdx + "][" + arrIdx + "][" + len + "]");
				throw new TecExcelMngException(MSG_ERR_DEF_ARRAY_IDX);
			}
		}
	}

	/**
	 * 縦方向リスト設定
	 * @param baseBook 対象ブック
	 * @param baseSheet 対象シート
	 * @param addPageBook 追加ページ用ブック
	 * @param addPageSheet 追加ページ用シート
	 * @param fileMapList シート、処理、リスト単位のマッピングリスト
	 * @param writeLists リスト項目設定値
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private void setVrtListValues(
			DMWorkbook baseBook, DMSheet baseSheet,
			Workbook addPageBook, Sheet addPageSheet,
			ArrayList<DMFilesMapData> fileMapList,
			String[][][] writeLists) throws TecExcelMngException{

		String funcName = className + ".setVrtListValues";
		DMCellManager xlsCellMng = DMCellManager.getInstance();
		for(DMFilesMapData fileMapRec : fileMapList){
			int baseRowIdx = 0;
			int baseColIdx = 0;
			int targetPageIdx = 0;
			int targetCnt = 1;
			int unitNowLen = 1;

			int paramIdx = fileMapRec.getHikisuIdx();
			int arrIdx = fileMapRec.getHairetsuIdx();
			// 引数インデックスチェック
			if(writeLists != null && writeLists.length > paramIdx){
				for(String[] targetRec : writeLists[fileMapRec.getHikisuIdx()]){
					// １ユニットあたりの項目数が最大値を超えた、または基準行が対象ページ最終行を超えた場合
					// ユニット初期化、基準行、基準列修正
					if(
							(fileMapRec.getUnitKomokusu() > 0 && fileMapRec.getUnitKomokusu() < unitNowLen) ||
							(baseRowIdx > baseSheet.getLastRowIdx(targetPageIdx))){
						// 改ページ区分:固定の場合は終了
						if(baseSheet.getKaiPageKbn() == PAGE_KBN_DEF){
							break;
						}
						unitNowLen = 1;
						int nextPageStartRowIdx = baseSheet.getLastRowIdx(targetPageIdx) + 1;
						baseRowIdx = nextPageStartRowIdx + baseSheet.getTsuikaGyoHoseichi();
						baseColIdx = baseSheet.getTsuikaRetsuHoseichi();
						// シート内ページ設定
						setPage(baseBook, baseSheet, addPageBook, addPageSheet, nextPageStartRowIdx);
						targetPageIdx++;
					}
					// 最大項目数を超えた場合
					if(fileMapRec.getSaidaiKomokusu() > 0 && fileMapRec.getSaidaiKomokusu() < targetCnt){
						break;
					}

					// 配列インデックスチェック
					if(targetRec != null && targetRec.length > arrIdx){
						// セルに値を設定
						xlsCellMng.setValue(
								baseBook, baseSheet, baseRowIdx, baseColIdx, fileMapRec, targetRec[arrIdx]);
					} else {
						int len = 0;
						if(targetRec != null){
							len = targetRec.length;
						}
						TecLogger.error(funcName + ":index_error(array)");
						TecLogger.debug("[" + paramIdx + "][" + arrIdx + "][" + len + "]");
						throw new TecExcelMngException(MSG_ERR_DEF_ARRAY_IDX);
					}

					baseRowIdx += fileMapRec.getZobunchi();
					targetCnt++;
					unitNowLen++;
				}
			} else {
				int len = 0;
				if(writeLists != null){
					len = writeLists.length;
				}
				TecLogger.error(funcName + ":index_error(param)");
				TecLogger.debug("[" + paramIdx + "][" + arrIdx + "][" + len + "]");
				throw new TecExcelMngException(MSG_ERR_DEF_PARAM_IDX);
			}
		}
	}

	/**
	 * 横方向リスト設定
	 * @param baseBook 対象ブック
	 * @param baseSheet 対象シート
	 * @param addPageBook 追加ページ用ブック
	 * @param addPageSheet 追加ページ用シート
	 * @param fileMapList シート、処理、リスト単位のマッピングリスト
	 * @param writeLists リスト項目設定値
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private void setHrzListValues(
			DMWorkbook baseBook, DMSheet baseSheet,
			Workbook addPageBook, Sheet addPageSheet,
			ArrayList<DMFilesMapData> fileMapList,
			String[][][] writeLists) throws TecExcelMngException{

		String funcName = className + ".setHrzListValues";
		DMCellManager xlsCellMng = DMCellManager.getInstance();
		for(DMFilesMapData fileMapRec : fileMapList){
			int baseRowIdx = 0;
			int baseColIdx = 0;
			int targetPageIdx = 0;
			int targetCnt = 1;
			int unitNowLen = 1;

			int paramIdx = fileMapRec.getHikisuIdx();
			int arrIdx = fileMapRec.getHairetsuIdx();
			// 引数インデックスチェック
			if(writeLists != null && writeLists.length > paramIdx){
				for(String[] targetRec : writeLists[paramIdx]){
					// １ユニットあたりの項目数が最大値を超えた、または基準列が最終列を超えた場合
					// ユニット初期化、基準行、基準列修正
					if(
							(fileMapRec.getUnitKomokusu() > 0 && fileMapRec.getUnitKomokusu() < unitNowLen) ||
							(baseColIdx > fileMapRec.getShokiSaishuretsu())){
						// 改ページ区分:固定の場合は終了
						if(baseSheet.getKaiPageKbn() == PAGE_KBN_DEF){
							break;
						}
						unitNowLen = 1;
						int nextPageStartRowIdx = baseSheet.getLastRowIdx(targetPageIdx) + 1;
						baseRowIdx = nextPageStartRowIdx + baseSheet.getTsuikaGyoHoseichi();
						baseColIdx = baseSheet.getTsuikaRetsuHoseichi();
						// シート内ページ設定
						setPage(baseBook, baseSheet, addPageBook, addPageSheet, nextPageStartRowIdx);
						targetPageIdx++;
					}
					// 最大項目数を超えた場合
					if(fileMapRec.getSaidaiKomokusu() > 0 && fileMapRec.getSaidaiKomokusu() < targetCnt){
						break;
					}

					// 配列インデックスチェック
					if(targetRec != null && targetRec.length > arrIdx){
						// セルに値を設定
						xlsCellMng.setValue(
								baseBook, baseSheet, baseRowIdx, baseColIdx, fileMapRec, targetRec[arrIdx]);
					} else {
						int len = 0;
						if(targetRec != null){
							len = targetRec.length;
						}
						TecLogger.error(funcName + ":index_error(array)");
						TecLogger.debug("[" + paramIdx + "][" + arrIdx + "][" + len + "]");
						throw new TecExcelMngException(MSG_ERR_DEF_ARRAY_IDX);
					}

					baseColIdx += fileMapRec.getZobunchi();
					targetCnt++;
					unitNowLen++;
				}
			} else {
				int len = 0;
				if(writeLists != null){
					len = writeLists.length;
				}
				TecLogger.error(funcName + ":index_error(param)");
				TecLogger.debug("[" + paramIdx + "][" + arrIdx + "][" + len + "]");
				throw new TecExcelMngException(MSG_ERR_DEF_PARAM_IDX);
			}
		}
	}

//	/**
//	 * ブック取得
//	 * @param filePath ブック物理ファイルパス
//	 * @return ブック
//	 * @throws TecFileMngException
//	 * @throws TecExcelMngException
//	 * @throws IOException
//	 * @since 1.00
//	 */
//	private DMWorkbook getWorkbook(String filePath) throws TecFileMngException, TecExcelMngException, IOException{
//		IMStorageServiceManager imSSMng = IMStorageServiceManager.getInstance();
//		DMWorkbook ret = null;
//		if(filePath != null){
//			ret = new DMWorkbook(new ByteArrayInputStream(imSSMng.loadFile(filePath)), true, filePath);
//		}
//		return ret;
//	}

	/**
	 * HSSFブック取得(StorageService)
	 * @param filePath ブック物理ファイルパス
	 * @return HSSFブック
	 * @throws TecFileMngException
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private Workbook getHSSFWorkbook(String filePath) throws TecFileMngException, TecExcelMngException {
		IMStorageServiceManager imSSMng = IMStorageServiceManager.getInstance();
		Workbook ret = getWorkbook(filePath, imSSMng);
		return ret;
	}

	/**
	 * ワークブック取得
	 * @param filePath ブック物理ファイルパス
	 * @param fileManager IMファイル操作インターフェース(Null時はjava.io.Fileを使用)
	 * @return ワークブック
	 * @throws TecFileMngException
	 * @throws TecExcelMngException
	 * @since 1.03
	 */
	private Workbook getWorkbook(
			String filePath, IMFileManagerIF fileManager) throws TecFileMngException, TecExcelMngException {
		Workbook ret = null;
		if(filePath != null){
			try{
				if(fileManager != null){
					ret = WorkbookFactory.create(new ByteArrayInputStream(fileManager.loadFile(filePath)));
				} else {
					ret = WorkbookFactory.create(new FileInputStream(new File(filePath)));
				}
			} catch (InvalidFormatException e) {
				TecLogger.error(className + ":file_format_error");
				TecLogger.debug("[" + filePath + "][" + e.getMessage() + "]");
				throw new TecExcelMngException(MSG_ERR_GET_BOOK, e);
			} catch (FileNotFoundException e) {
				TecLogger.error(className + ":file_not_found_error");
				TecLogger.debug("[" + filePath + "][" + e.getMessage() + "]");
				throw new TecExcelMngException(MSG_ERR_GET_BOOK, e);
			} catch (IOException e) {
				TecLogger.error(className + ":io_error");
				TecLogger.debug("[" + filePath + "][" + e.getMessage() + "]");
				throw new TecExcelMngException(MSG_ERR_GET_BOOK, e);
			}
		}
		return ret;
	}

//	/**
//	 * HSSFシート取得
//	 * @param filePath ブック物理ファイルパス
//	 * @param sheetName シート名
//	 * @return HSSFシート
//	 * @throws TecFileMngException
//	 * @throws IOException
//	 * @since 1.00
//	 */
//	private HSSFSheet getHSSFSheet(String filePath, String sheetName) throws TecFileMngException, IOException{
//		HSSFSheet ret = null;
//		if(filePath != null){
//			ret = getHSSFSheet(getHSSFWorkbook(filePath), sheetName);
//		}
//		return ret;
//	}

	/**
	 * HSSFシート取得
	 * @param targetBook ブック
	 * @param sheetName シート名
	 * @return HSSFシート
	 * @since 1.00
	 */
	private Sheet getHSSFSheet(Workbook targetBook, String sheetName){
		Sheet ret = null;
		if(targetBook != null && sheetName != null){
			ret = targetBook.getSheet(sheetName);
		}
		return ret;
	}

	/**
	 * シート内ページ設定<br>
	 * 対象行が現在のページ設定範囲外の場合、ページ追加
	 * @param baseBook 対象ブック
	 * @param baseSheet 対象シート
	 * @param addPageBook 追加ページ用ブック
	 * @param addPageSheet 追加ページ用シート
	 * @param targetRowIdx 対象行(これから設定する項目の行インデックス)
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private void setPage(
			DMWorkbook baseBook, DMSheet baseSheet,
			Workbook addPageBook, Sheet addPageSheet,
			int targetRowIdx) throws TecExcelMngException{

		if(baseSheet.getKaiPageKbn() == PAGE_KBN_VRT){
			// 改ページ区分:縦
			// 対象行が現在のページ設定範囲外の場合、ページ追加
			if(isOverRow(baseSheet, targetRowIdx)){
				addPage(baseBook, baseSheet, addPageBook, addPageSheet);
				setPage(baseBook, baseSheet, addPageBook, addPageSheet, targetRowIdx);
			}
		}
	}

	/**
	 * 対象シートにページを追加
	 * @param baseBook 対象ブック
	 * @param baseSheet 対象シート
	 * @param addPageBook 追加ページ用ブック
	 * @param addPageSheet 追加ページ用シート
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	private void addPage(
			DMWorkbook baseBook, DMSheet baseSheet,
			Workbook addPageBook, Sheet addPageSheet) throws TecExcelMngException{

		boolean isSameBookCopy = false;
		if(baseSheet.getTsuikaFilePath() == null || baseSheet.getTsuikaFilePath().equals(baseBook.getFilePath())){
			isSameBookCopy = true;
		}
		int fromRowIdx = baseSheet.getTsuikaKaishigyo();
		int insCnt = baseSheet.getAddPageInsCnt();
		int addStartRowIdx = baseSheet.getLastRowIdx() + 1;
		copyInsertRow(
				addPageBook, addPageSheet, baseBook.workbook, baseSheet.sheet,
				addStartRowIdx, fromRowIdx, insCnt, isSameBookCopy);
		// ページインデックス加算
		baseSheet.addPageIdx();
		baseBook.workbook.setPrintArea(baseSheet.getSheetIdx(),
				0, baseSheet.getShokiSaishuretsu(),
				0, baseSheet.getLastRowIdx());
		baseSheet.sheet.setRowBreak(baseSheet.getLastRowIdx());
	}

	/**
	 * コピー(行単位)<br>
	 * コピー先に行をコピー行数分挿入しコピーを行う
	 * @param fromBook コピー元ブック
	 * @param fromSheet コピー元シート
	 * @param toBook コピー先ブック
	 * @param toSheet コピー先シート
	 * @param insStartRowIdx コピー先挿入開始行インデックス
	 * @param fromRowIdx コピー元開始行インデックス
	 * @param copyRowCnt コピー行数
	 * @param isSameBookCopy true:同一ブック上のコピー
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected void copyInsertRow(
			Workbook fromBook, Sheet fromSheet,
			Workbook toBook, Sheet toSheet,
			int insStartRowIdx, int fromRowIdx, int copyRowCnt, boolean isSameBookCopy) throws TecExcelMngException{

		DMCellManager xlsCellMng = DMCellManager.getInstance();
		if(fromBook == null || toBook == null){
			throw new TecExcelMngException(MSG_ERR_NULL_BOOK);
		}
		if(fromSheet == null || toSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		try{
			xlsCellMng.checkExcelRowIdx(insStartRowIdx);
			xlsCellMng.checkExcelRowIdx(fromRowIdx);
			xlsCellMng.checkExcelRowIdx(insStartRowIdx + copyRowCnt -1);
			xlsCellMng.checkExcelRowIdx(toSheet.getLastRowNum() + copyRowCnt);
			xlsCellMng.checkExcelRowIdx(fromRowIdx + copyRowCnt -1);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + insStartRowIdx + "][" + fromRowIdx + "][" + copyRowCnt + "][" + toSheet.getLastRowNum() + "]");
			throw e;
		}
		if(copyRowCnt > 0){
			// 行の作成
			// 行シフトが設定されたデータやスタイルにより内部で例外となる場合があるため
			// コメントアウト(POI 3.2.0)
			//if(insStartRowIdx <= toSheet.getLastRowNum()){
			//	toSheet.shiftRows(insStartRowIdx, toSheet.getLastRowNum(), copyRowCnt, true, false);
			//}
			for(int i = 0; i < copyRowCnt; i++){
				// セルのコピー(スタイル、値)
				xlsCellMng.copyCell(fromBook, fromSheet, (fromRowIdx + i), toBook, toSheet, (insStartRowIdx + i), true, true, isSameBookCopy);
			}
			// セル結合
			xlsCellMng.copyMergeCellStyle(toSheet, insStartRowIdx, fromSheet, fromRowIdx, copyRowCnt);
		}
	}

	/**
	 * 指定した行を削除(上方向へシフト)
	 * @param targetSheet シート
	 * @param rowIdx 行インデックス
	 * @param delRowCnt 削除行数
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected void removeRow(Sheet targetSheet, int rowIdx, int delRowCnt) throws TecExcelMngException{
		DMCellManager xlsCellMng = DMCellManager.getInstance();
		if(targetSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		try{
			xlsCellMng.checkExcelRowIdx(rowIdx);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + rowIdx + "]");
			throw e;
		}
		int startRowIdx = rowIdx + delRowCnt;
		int endRowIdx = targetSheet.getLastRowNum();
		if(delRowCnt > 0 && endRowIdx >= 0 && rowIdx <= endRowIdx){
			if(startRowIdx > endRowIdx){
				// 最終行を削除対象として含む場合、
				// 指定行から最終行までを削除(シフトなし)
				removeAfterRows(targetSheet, rowIdx, delRowCnt);
			} else {
				// シフト後の最終行を取得
				int endRowIdxAfterShift = endRowIdx - delRowCnt;
				// シフト対象行数の調整
				int remainRowCnt = endRowIdx - startRowIdx + 1;
				if(remainRowCnt < delRowCnt){
					endRowIdx = startRowIdx + delRowCnt - 1;
				}
				// シフト
				targetSheet.shiftRows(startRowIdx, endRowIdx, -delRowCnt, true, true);
				// 余分な行を削除
				removeAfterRows(targetSheet, endRowIdxAfterShift + 1, delRowCnt);
			}

//			int delNum = -delRowCnt;
//			if(startRowIdx > endRowIdx){
//				// 最終行を削除対象として含むシフトを実行した場合、
//				// ブランク行が最終行として残るため、シフト後に最終行削除
//				startRowIdx = endRowIdx + 1;
//				endRowIdx = startRowIdx + (targetSheet.getLastRowNum() - rowIdx);
//				delNum = -(targetSheet.getLastRowNum() - rowIdx + 1);
//				System.out.println("a[" + startRowIdx + "][" + endRowIdx + "][" + delNum + "]");
//				targetSheet.shiftRows(startRowIdx, endRowIdx, delNum, true, true);
//				targetSheet.removeRow(targetSheet.getRow(targetSheet.getLastRowNum()));
//			} else {
//				int remainRowCnt = endRowIdx - startRowIdx + 1;
//				if(remainRowCnt < delRowCnt){
//					endRowIdx = startRowIdx + delRowCnt - 1;
//				}
//				System.out.println("b[" + startRowIdx + "][" + endRowIdx + "][" + delNum + "]");
//				targetSheet.shiftRows(startRowIdx, endRowIdx, delNum, true, true);
//			}
		}
	}

	/**
	 * 指定した行から最終行までを削除
	 * @param targetSheet シート
	 * @param removeStartRowIdx 指定行
	 * @param delRowCnt 削除行数(最大)
	 * @since 1.00
	 */
	private void removeAfterRows(Sheet targetSheet, int removeStartRowIdx, int delRowCnt){
		int lastRowIdx = targetSheet.getLastRowNum();
		if(lastRowIdx >= removeStartRowIdx){
			// 削除処理
			for(int i = 0; i < delRowCnt; i++){
				int delTargetRowIdx = lastRowIdx - i;
				if(removeStartRowIdx > delTargetRowIdx){
					break;
				}
				Row delRow = targetSheet.getRow(delTargetRowIdx);
				if(delRow == null){
					delRow = targetSheet.createRow(delTargetRowIdx);
				}
				targetSheet.removeRow(delRow);
			}
		}
	}

	/**
	 * 対象行が現在の最終行を越えているかどうか
	 * @param baseSheet 対象シート
	 * @param targetRowIdx 対象行インデックス
	 * @return true:越えている
	 * @since 1.00
	 */
	private boolean isOverRow(DMSheet baseSheet, int targetRowIdx){
		return baseSheet.getLastRowIdx() < targetRowIdx;
	}

//	/**
//	 * 対象列が現在の最終列を越えているかどうか
//	 * @param baseSheet 対象シート
//	 * @param targetColIdx 対象列インデックス
//	 * @return true:越えている
//	 * @since 1.00
//	 */
//	private boolean isOverCol(DMSheet baseSheet, int targetColIdx){
//		return baseSheet.getShokiSaishuretsu() < targetColIdx;
//	}

	/**
	 * シートコピー初期処理
	 * @param fromSheet コピー元シート
	 * @param toBook コピー先ブック
	 * @param toSheet コピー先シート
	 * @param toSheetIdx コピー先シートインデックス
	 * @param lastRowIdx コピー元最終行インデックス
	 * @param lastColIdx コピー元最終列インデックス
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	protected void copySheetInitial(
			Sheet fromSheet, Workbook toBook, Sheet toSheet, int toSheetIdx,
			int lastRowIdx, int lastColIdx) throws TecExcelMngException{

		DMCellManager xlsCellMng = DMCellManager.getInstance();
		if(toBook == null){
			throw new TecExcelMngException(MSG_ERR_NULL_BOOK);
		}
		if(fromSheet == null || toSheet == null){
			throw new TecExcelMngException(MSG_ERR_NULL_SHEET);
		}
		if(toSheetIdx < 0 || toSheetIdx >= toBook.getNumberOfSheets()){
			TecLogger.debug("[" + toSheetIdx + "][" + toBook.getNumberOfSheets() + "]");
			throw new TecExcelMngException(MSG_ERR_SHEET_IDX);
		}
		try{
			xlsCellMng.checkExcelRowIdx(lastRowIdx);
			xlsCellMng.checkExcelColIdx(lastColIdx);
		} catch(TecExcelMngException e){
			TecLogger.debug("[" + lastRowIdx + "][" + lastColIdx + "]");
			throw e;
		}
		// シートコピー初期処理
		toBook.setPrintArea(toSheetIdx, 0, lastColIdx, 0, lastRowIdx);
		copySheetStyle(fromSheet, toSheet, lastRowIdx, lastColIdx);
		toSheet.setRowBreak(lastRowIdx);
		copyHeader(fromSheet, toSheet);
		copyFooter(fromSheet, toSheet);
		copyPrintSetup(fromSheet, toSheet);
	}

	/**
	 * シートスタイルコピー
	 * @param fromSheet コピー元シート
	 * @param toSheet コピー先シート
	 * @param lastRowIdx コピー元最終行インデックス
	 * @param lastColIdx コピー元最終列インデックス
	 * @since 1.00
	 */
	private void copySheetStyle(
			Sheet fromSheet, Sheet toSheet,
			int lastRowIdx, int lastColIdx){

		toSheet.setAutobreaks(fromSheet.getAutobreaks());
		toSheet.setDefaultColumnWidth(fromSheet.getDefaultColumnWidth());
		toSheet.setDefaultRowHeight(fromSheet.getDefaultRowHeight());
		toSheet.setDisplayFormulas(fromSheet.isDisplayFormulas());
		toSheet.setDisplayGridlines(fromSheet.isDisplayGridlines());
		toSheet.setDisplayGuts(fromSheet.getDisplayGuts());
		toSheet.setDisplayRowColHeadings(fromSheet.isDisplayRowColHeadings());
		toSheet.setDisplayZeros(fromSheet.isDisplayZeros());
		toSheet.setFitToPage(fromSheet.getFitToPage());
		toSheet.setHorizontallyCenter(fromSheet.getHorizontallyCenter());
		toSheet.setMargin(Sheet.TopMargin, fromSheet.getMargin(Sheet.TopMargin));
		toSheet.setMargin(Sheet.LeftMargin, fromSheet.getMargin(Sheet.LeftMargin));
		toSheet.setMargin(Sheet.RightMargin, fromSheet.getMargin(Sheet.RightMargin));
		toSheet.setMargin(Sheet.BottomMargin, fromSheet.getMargin(Sheet.BottomMargin));
		toSheet.setPrintGridlines(fromSheet.isPrintGridlines());
		toSheet.setRowSumsBelow(fromSheet.getRowSumsBelow());
		toSheet.setRowSumsRight(fromSheet.getRowSumsRight());
		toSheet.setVerticallyCenter(fromSheet.getVerticallyCenter());

		// 行単位の設定
		for(int i = 0; i < lastRowIdx + 1; i++){
			if(fromSheet.isRowBroken(i)){
				if(!toSheet.isRowBroken(i)){
					toSheet.setRowBreak(i);
				}
			} else {
				if(toSheet.isRowBroken(i)){
					toSheet.removeRowBreak(i);
				}
			}
		}

		// 列単位の設定
		for(int i = 0; i < lastColIdx + 1; i++){
			//toSheet.setDefaultColumnStyle((short)i, defaultStyle);
			if(fromSheet.isColumnBroken(i)){
				if(!toSheet.isColumnBroken(i)){
					toSheet.setColumnBreak(i);
				}
			} else {
				if(toSheet.isColumnBroken(i)){
					toSheet.removeColumnBreak(i);
				}
			}
			toSheet.setColumnHidden(i, fromSheet.isColumnHidden(i));
			toSheet.setColumnWidth(i, fromSheet.getColumnWidth(i));
//			// 列幅のデフォルト値は8だが、0(非表示)、32(設定最小値(0.08))間の値が存在しないため非表示になる
//			// 回避策として2304(8.38)を設定(POI 3.0.2)
//			int fromColWidth = fromSheet.getColumnWidth(i);
//			if(fromColWidth == fromSheet.getDefaultColumnWidth() && fromColWidth == 8){
//				toSheet.setColumnWidth(i, 2304);
//			} else {
//				toSheet.setColumnWidth(i, fromColWidth);
//			}
		}
	}

	/**
	 * ヘッダ設定コピー
	 * @param fromSheet コピー元シート
	 * @param toSheet コピー先シート
	 * @since 1.00
	 */
	private void copyHeader(Sheet fromSheet, Sheet toSheet){
		Header fromHeader = fromSheet.getHeader();
		Header toHeader = toSheet.getHeader();
		toHeader.setCenter(fromHeader.getCenter());
		toHeader.setLeft(fromHeader.getLeft());
		toHeader.setRight(fromHeader.getRight());
	}

	/**
	 * フッタ設定コピー
	 * @param fromSheet コピー元シート
	 * @param toSheet コピー先シート
	 * @since 1.00
	 */
	private void copyFooter(Sheet fromSheet, Sheet toSheet){
		Footer fromFooter = fromSheet.getFooter();
		Footer toFooter = toSheet.getFooter();
		toFooter.setCenter(fromFooter.getCenter());
		toFooter.setLeft(fromFooter.getLeft());
		toFooter.setRight(fromFooter.getRight());
	}

	/**
	 * 印刷設定コピー
	 * @param fromSheet コピー元シート
	 * @param toSheet コピー先シート
	 * @since 1.00
	 */
	private void copyPrintSetup(Sheet fromSheet, Sheet toSheet){
		PrintSetup fromPrint = fromSheet.getPrintSetup();
		PrintSetup toPrint = toSheet.getPrintSetup();
		toPrint.setCopies(fromPrint.getCopies());
		toPrint.setDraft(fromPrint.getDraft());
		toPrint.setFitHeight(fromPrint.getFitHeight());
		toPrint.setFitWidth(fromPrint.getFitWidth());
		toPrint.setFooterMargin(fromPrint.getFooterMargin());
		toPrint.setHeaderMargin(fromPrint.getHeaderMargin());
		toPrint.setHResolution(fromPrint.getHResolution());
		toPrint.setLandscape(fromPrint.getLandscape());
		toPrint.setLeftToRight(fromPrint.getLeftToRight());
		toPrint.setNoColor(fromPrint.getNoColor());
		toPrint.setNoOrientation(fromPrint.getNoOrientation());
		toPrint.setNotes(fromPrint.getNotes());
		toPrint.setPageStart(fromPrint.getPageStart());
		toPrint.setPaperSize(fromPrint.getPaperSize());
		toPrint.setScale(fromPrint.getScale());
		toPrint.setUsePage(fromPrint.getUsePage());
		toPrint.setValidSettings(fromPrint.getValidSettings());
		toPrint.setVResolution(fromPrint.getVResolution());
	}

	/**
	 * 対象シートの再計算設定をONにする。(HSSFのみ)
	 * @param target 対象シート
	 * @since 1.03
	 */
	private void setForceFormulaRecalculation(Sheet target){
		if(target != null && target instanceof HSSFSheet){
			((HSSFSheet)target).setForceFormulaRecalculation(true);
		}
	}

	/**
	 * 複数のExcelファイルをまとめる。
	 * @param saveFilePath 保存先パス
	 * @param mergeFilePathList マージ対象ファイルパスリスト
	 * @param fileManager IMファイル操作インターフェース(Null時はjava.io.Fileを使用)
	 * @throws TecFileMngException
	 * @throws TecExcelMngException
	 * @since 1.03
	 */
	public void createNewMergeFile(
			String saveFilePath, ArrayList<String> mergeFilePathList,
			IMFileManagerIF fileManager) throws TecFileMngException, TecExcelMngException {
		// 保存先なし、マージ対象なしの場合はエラー
		if(saveFilePath == null || saveFilePath.length() == 0){
			TecLogger.error(className + ":save_file_path_null");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		if(mergeFilePathList == null || mergeFilePathList.size() == 0){
			TecLogger.error(className + ":merge_path_list_null");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		// 最初のファイルを元にする
		Workbook baseBook = getWorkbook(mergeFilePathList.get(0), fileManager);
		if(baseBook == null){
			TecLogger.error(className + ":merge_path_null[0]");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		// ファイル毎の処理
		for(int addBookIdx = 1; addBookIdx < mergeFilePathList.size(); addBookIdx++){
			Workbook addBook = getWorkbook(mergeFilePathList.get(addBookIdx), fileManager);
			if(addBook == null){
				TecLogger.error(className + ":merge_path_null[" + addBookIdx + "]");
				throw new TecExcelMngException(new IllegalArgumentException());
			}
			// シート毎の処理(元ブックに対してシートをコピー)
			for(int addSheetIdx = 0; addSheetIdx < addBook.getNumberOfSheets(); addSheetIdx++){
				Sheet addSheet = addBook.getSheetAt(addSheetIdx);
				Sheet baseSheet = baseBook.createSheet(addSheet.getSheetName() + "_" + (addBookIdx));
				int insCnt = addSheet.getLastRowNum() + 1;
				int lastRowIdx = addSheet.getLastRowNum();
				int lastColIdx = getLastColNum(addSheet) - 1;
				//removeRow(baseSheet, 0, insCnt);
				copyInsertRow(
						addBook, addSheet, baseBook, baseSheet,
						0, 0, insCnt, false);
				copySheetInitial(
						addSheet, baseBook, baseSheet, baseBook.getSheetIndex(baseSheet),
						lastRowIdx, lastColIdx);
			}
		}
		// ファイル保存
		saveWorkBook(baseBook, saveFilePath, fileManager);
	}
	
	/**
	 * 複数のExcelファイルをまとめる(ソート機能実装バージョン[一部解約覚書専用])
	 * @param saveFilePath 保存先パス
	 * @param mergeFilePathList マージ対象ファイルパスリスト
	 * @param fileManager IMファイル操作インターフェース(Null時はjava.io.Fileを使用)
	 * @throws TecFileMngException
	 * @throws TecExcelMngException
	 * @since 1.03
	 */
	public void createNewMergeFile(String saveFilePath, ArrayList<String> mergeFilePathList,
									IMFileManagerIF fileManager,
									int intSortFlg) throws TecFileMngException, TecExcelMngException {
		// 保存先なし、マージ対象なしの場合はエラー
		if(saveFilePath == null || saveFilePath.length() == 0){
			TecLogger.error(className + ":save_file_path_null");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		if(mergeFilePathList == null || mergeFilePathList.size() == 0){
			TecLogger.error(className + ":merge_path_list_null");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		// 最初のファイルを元にする
		Workbook baseBook = getWorkbook(mergeFilePathList.get(0), fileManager);
		if(baseBook == null){
			TecLogger.error(className + ":merge_path_null[0]");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		
		int i = 0;
		
		// ファイル毎の処理
		for(int addBookIdx = 1; addBookIdx < mergeFilePathList.size(); addBookIdx++){
			Workbook addBook = getWorkbook(mergeFilePathList.get(addBookIdx), fileManager);
			if(addBook == null){
				TecLogger.error(className + ":merge_path_null[" + addBookIdx + "]");
				throw new TecExcelMngException(new IllegalArgumentException());
			}
			// シート毎の処理(元ブックに対してシートをコピー)
			for(int addSheetIdx = 0; addSheetIdx < addBook.getNumberOfSheets(); addSheetIdx++){
				Sheet addSheet = addBook.getSheetAt(addSheetIdx);
				Sheet baseSheet;
				
				// ページ名からソートを実行する(雛形がこの順番になってないと機能しない)	
				if(addSheet.getSheetName().equals("一部解約覚書")){
					baseSheet = baseBook.createSheet(addSheet.getSheetName());
					baseBook.setSheetOrder(addSheet.getSheetName(), i);
					i += 1;
				}else if(addSheet.getSheetName().equals("覚書別紙(解約機器明細)")){
					baseSheet = baseBook.createSheet(addSheet.getSheetName());
					baseBook.setSheetOrder(addSheet.getSheetName(), i);
					i += 1;
				}else if(addSheet.getSheetName().equals("覚書別紙(解約機器明細)-2")){
					baseSheet = baseBook.createSheet(addSheet.getSheetName());
					baseBook.setSheetOrder(addSheet.getSheetName(), i);
					i += 1;
				}else{
					baseSheet = baseBook.createSheet(addSheet.getSheetName());
					baseBook.setSheetOrder(addSheet.getSheetName(), i);
					i += 1;
				}
				
				int insCnt = addSheet.getLastRowNum() + 1;
				int lastRowIdx = addSheet.getLastRowNum();
				int lastColIdx = getLastColNum(addSheet) - 1;
				//removeRow(baseSheet, 0, insCnt);
				copyInsertRow(addBook,
							  addSheet,
							  baseBook,
							  baseSheet,
							  0,
							  0,
							  insCnt,
							  false);
				
				copySheetInitial(addSheet,
								 baseBook,
								 baseSheet,
								 baseBook.getSheetIndex(baseSheet),
								 lastRowIdx,
								 lastColIdx);
			}
		}

		// ファイル保存
		saveWorkBook(baseBook, saveFilePath, fileManager);
	}
	
	/** ワークブック保存 */
	private void saveWorkBook(
			Workbook saveBook, String saveFilePath,
			IMFileManagerIF fileManager) throws TecFileMngException, TecExcelMngException {
		ByteArrayOutputStream baos = null;
		FileOutputStream fos = null;
		// ワークブックNull、保存先なしの場合はエラー
		if(saveBook == null){
			TecLogger.error(className + ":save_book_null");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		if(saveFilePath == null || saveFilePath.length() == 0){
			TecLogger.error(className + ":save_file_path_null");
			throw new TecExcelMngException(new IllegalArgumentException());
		}
		try{
			if(fileManager != null){
				// バイト出力
				baos = new ByteArrayOutputStream();
				saveBook.write(baos);
				// ファイル保存
				fileManager.saveFile(saveFilePath, baos.toByteArray(), true);
			} else {
				// ファイル保存
				fos = new FileOutputStream(new File(saveFilePath));
				saveBook.write(fos);
			}
		} catch (IOException e) {
			TecLogger.error(className + ":file_io_error(save)");
			TecLogger.debug("[" + saveFilePath + "][" + e.getMessage() + "]");
			throw new TecExcelMngException(MSG_ERR_SAVE_BOOK, e);
		} finally {
			try {
				if(baos != null){
					baos.close();
				}
				if(fos != null){
					fos.close();
				}
			} catch(Exception e){
				// close時の例外は無視
			}
		}
	}

	/** 最終列番号取得 */
	private int getLastColNum(Sheet target){
		int ret = 0;
		for(int i = 0; i < target.getLastRowNum(); i++){
			Row row = target.getRow(i);
			if(row != null){
				if(ret < row.getLastCellNum()){
					ret = row.getLastCellNum();
				}
			}
		}
		return ret;
	}

}
