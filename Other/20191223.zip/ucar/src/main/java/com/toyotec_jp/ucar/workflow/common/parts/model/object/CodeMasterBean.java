package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import java.util.Date;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>コード区分マスタBean</strong>
 * <p>T220204M</p>
 * @author Y.M(TEC)
 * @version 1.00 2012/01/16 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CodeMasterBean extends TecBean {

	private static final long serialVersionUID = -3965563691636732674L;

	/** 会社コード */
	private String cdKaisya;
	/** 事業所コード */
	private String cdJigyosyo;
	/** 区分ID */
	private String kbId;
	/** 区分コード */
	private String cdKubun;
	/** 区分名 */
	private String mjKubun;
	/** 区分略称 */
	private String mjKbnrk;
	/** 表示順 */
	private int noSort;
	/** 情報1 */
	private String mjInfo1;
	/** 情報2 */
	private String mjInfo2;
	/** 情報3 */
	private String mjInfo3;
	/** 情報4 */
	private String mjInfo4;
	/** 情報5 */
	private String mjInfo5;
	/** 備考 */
	private String mjBikou;
	/** データ作成日時 */
	private Date	dtSakusei;
	/** データ更新日時 */
	private Date	dtKosin;
	/** 作成ユーザID */
	private String	cdSksisya;
	/** 更新ユーザID */
	private String	cdKsnsya;
	/** 作成アプリID */
	private String	cdSksiapp;
	/** 更新アプリID */
	private String	cdKsnapp;

	/**
	 * コンストラクタ。
	 */
	public CodeMasterBean() {
	}

	/**
	 * 区分コード指定コンストラクタ。<br>
	 * コード区分マスタリストフィルタリング用。
	 * @param keyCd 区分コード
	 */
	public CodeMasterBean(String cdKubun){
		this.cdKubun = cdKubun;		// 区分コード
	}

	/**
	 * 汎用付属情報指定コンストラクタ。<br>
	 * コード区分マスタリストフィルタリング用。
	 * @param info1 汎用付属情報１
	 * @param info2 汎用付属情報２
	 * @param info3 汎用付属情報３
	 * @param info4 汎用付属情報４
	 * @param info5 汎用付属情報５
	 */
	public CodeMasterBean(String info1, String info2, String info3, String info4, String info5){
		this.mjInfo1 = info1;		// 汎用付属情報１
		this.mjInfo2 = info2;		// 汎用付属情報２
		this.mjInfo3 = info3;		// 汎用付属情報３
		this.mjInfo4 = info4;		// 汎用付属情報４
		this.mjInfo5 = info5;		// 汎用付属情報５
	}

	/**
	 * 区分コード、汎用付属情報指定コンストラクタ。<br>
	 * コード区分マスタリストフィルタリング用。
	 * @param keyCd 区分コード
	 * @param info1 汎用付属情報１
	 * @param info2 汎用付属情報２
	 * @param info3 汎用付属情報３
	 * @param info4 汎用付属情報４
	 * @param info5 汎用付属情報５
	 */
	public CodeMasterBean(String cdKubun, String info1, String info2, String info3, String info4, String info5){
		this.cdKubun = cdKubun;		// 区分コード
		this.mjInfo1 = info1;		// 汎用付属情報１
		this.mjInfo2 = info2;		// 汎用付属情報２
		this.mjInfo3 = info3;		// 汎用付属情報３
		this.mjInfo4 = info4;		// 汎用付属情報４
		this.mjInfo5 = info5;		// 汎用付属情報５
	}

	/**
	 * 会社コードを取得します。
	 * @return 会社コード
	 */
	public String getCdKaisya() {
	    return cdKaisya;
	}

	/**
	 * 会社コードを設定します。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
	    this.cdKaisya = cdKaisya;
	}

	/**
	 * 事業所コードを取得します。
	 * @return 事業所コード
	 */
	public String getCdJigyosyo() {
	    return cdJigyosyo;
	}

	/**
	 * 事業所コードを設定します。
	 * @param cdJigyosyo 事業所コード
	 */
	public void setCdJigyosyo(String cdJigyosyo) {
	    this.cdJigyosyo = cdJigyosyo;
	}

	/**
	 * 区分IDを取得します。
	 * @return 区分ID
	 */
	public String getKbId() {
	    return kbId;
	}

	/**
	 * 区分IDを設定します。
	 * @param kbId 区分ID
	 */
	public void setKbId(String kbId) {
	    this.kbId = kbId;
	}

	/**
	 * 区分コードを取得します。
	 * @return 区分コード
	 */
	public String getCdKubun() {
	    return cdKubun;
	}

	/**
	 * 区分コードを設定します。
	 * @param cdKubun 区分コード
	 */
	public void setCdKubun(String cdKubun) {
	    this.cdKubun = cdKubun;
	}

	/**
	 * 区分名を取得します。
	 * @return 区分名
	 */
	public String getMjKubun() {
	    return mjKubun;
	}

	/**
	 * 区分名を設定します。
	 * @param mjKubun 区分名
	 */
	public void setMjKubun(String mjKubun) {
	    this.mjKubun = mjKubun;
	}

	/**
	 * 区分略称を取得します。
	 * @return 区分略称
	 */
	public String getMjKbnrk() {
	    return mjKbnrk;
	}

	/**
	 * 区分略称を設定します。
	 * @param mjKbnrk 区分略称
	 */
	public void setMjKbnrk(String mjKbnrk) {
	    this.mjKbnrk = mjKbnrk;
	}

	/**
	 * 表示順を取得します。
	 * @return 表示順
	 */
	public int getNoSort() {
	    return noSort;
	}

	/**
	 * 表示順を設定します。
	 * @param noSort 表示順
	 */
	public void setNoSort(int noSort) {
	    this.noSort = noSort;
	}

	/**
	 * 情報1を取得します。
	 * @return 情報1
	 */
	public String getMjInfo1() {
	    return mjInfo1;
	}

	/**
	 * 情報1を設定します。
	 * @param mjInfo1 情報1
	 */
	public void setMjInfo1(String mjInfo1) {
	    this.mjInfo1 = mjInfo1;
	}

	/**
	 * 情報2を取得します。
	 * @return 情報2
	 */
	public String getMjInfo2() {
	    return mjInfo2;
	}

	/**
	 * 情報2を設定します。
	 * @param mjInfo2 情報2
	 */
	public void setMjInfo2(String mjInfo2) {
	    this.mjInfo2 = mjInfo2;
	}

	/**
	 * 情報3を取得します。
	 * @return 情報3
	 */
	public String getMjInfo3() {
	    return mjInfo3;
	}

	/**
	 * 情報3を設定します。
	 * @param mjInfo3 情報3
	 */
	public void setMjInfo3(String mjInfo3) {
	    this.mjInfo3 = mjInfo3;
	}

	/**
	 * 情報4を取得します。
	 * @return 情報4
	 */
	public String getMjInfo4() {
	    return mjInfo4;
	}

	/**
	 * 情報4を設定します。
	 * @param mjInfo4 情報4
	 */
	public void setMjInfo4(String mjInfo4) {
	    this.mjInfo4 = mjInfo4;
	}

	/**
	 * 情報5を取得します。
	 * @return 情報5
	 */
	public String getMjInfo5() {
	    return mjInfo5;
	}

	/**
	 * 情報5を設定します。
	 * @param mjInfo5 情報5
	 */
	public void setMjInfo5(String mjInfo5) {
	    this.mjInfo5 = mjInfo5;
	}

	/**
	 * 備考を取得します。
	 * @return 備考
	 */
	public String getMjBikou() {
	    return mjBikou;
	}

	/**
	 * 備考を設定します。
	 * @param mjBikou 備考
	 */
	public void setMjBikou(String mjBikou) {
	    this.mjBikou = mjBikou;
	}

	/**
	 * データ作成日時を取得します。
	 * @return データ作成日時
	 */
	public Date getDtSakusei() {
	    return dtSakusei;
	}

	/**
	 * データ作成日時を設定します。
	 * @param dtSakusei データ作成日時
	 */
	public void setDtSakusei(Date dtSakusei) {
	    this.dtSakusei = dtSakusei;
	}

	/**
	 * データ更新日時を取得します。
	 * @return データ更新日時
	 */
	public Date getDtKosin() {
	    return dtKosin;
	}

	/**
	 * データ更新日時を設定します。
	 * @param dtKosin データ更新日時
	 */
	public void setDtKosin(Date dtKosin) {
	    this.dtKosin = dtKosin;
	}

	/**
	 * 作成ユーザIDを取得します。
	 * @return 作成ユーザID
	 */
	public String getCdSksisya() {
	    return cdSksisya;
	}

	/**
	 * 作成ユーザIDを設定します。
	 * @param cdSksisya 作成ユーザID
	 */
	public void setCdSksisya(String cdSksisya) {
	    this.cdSksisya = cdSksisya;
	}

	/**
	 * 更新ユーザIDを取得します。
	 * @return 更新ユーザID
	 */
	public String getCdKsnsya() {
	    return cdKsnsya;
	}

	/**
	 * 更新ユーザIDを設定します。
	 * @param cdKsnsya 更新ユーザID
	 */
	public void setCdKsnsya(String cdKsnsya) {
	    this.cdKsnsya = cdKsnsya;
	}

	/**
	 * 作成アプリIDを取得します。
	 * @return 作成アプリID
	 */
	public String getCdSksiapp() {
	    return cdSksiapp;
	}

	/**
	 * 作成アプリIDを設定します。
	 * @param cdSksiapp 作成アプリID
	 */
	public void setCdSksiapp(String cdSksiapp) {
	    this.cdSksiapp = cdSksiapp;
	}

	/**
	 * 更新アプリIDを取得します。
	 * @return 更新アプリID
	 */
	public String getCdKsnapp() {
	    return cdKsnapp;
	}

	/**
	 * 更新アプリIDを設定します。
	 * @param cdKsnapp 更新アプリID
	 */
	public void setCdKsnapp(String cdKsnapp) {
	    this.cdKsnapp = cdKsnapp;
	}
}
