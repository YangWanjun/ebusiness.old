package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;


/**
 * <strong>作業区分取得イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2014/02/27 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetSagyoKubunEvent extends UcarEvent {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** 会社コード */
	private String	cdKaisya;
	/** 事業所コード */
	private String	cdJigyosyo;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdJigyosyoを取得する。
	 * @return cdJigyosyo 事業所コード
	 */
	public String getCdJigyosyo() {
		return cdJigyosyo;
	}

	/**
	 * cdJigyosyoを設定する。
	 * @param cdJigyosyo 事業所コード
	 */
	public void setCdJigyosyo(String cdJigyosyo) {
		this.cdJigyosyo = cdJigyosyo;
	}

}
