package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.CodeMasterBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>コード区分マスタ操作DAOインターフェース。</strong>
 * @author Y.M(TEC)
 * @version 1.00 2012/01/16 新規作成<br>
 * @since 1.00
 */
public interface CodeMasterDAOIF {

	/**
	 * コード区分マスタリスト取得。
	 * <pre>
	 * 削除フラグtrueのレコードは含まない。
	 * </pre>
	 * @param key
	 * @return コード区分マスタリスト
	 * @throws LcmDAOException
	 */
	public ResultArrayList<CodeMasterBean> getCodeMasterList(String key,UserInformationBean userInfoBean) throws TecDAOException;

	// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
	/**
	 * コード区分マスタリスト取得(データの会社コード、事業所コードより)。
	 * <pre>
	 * 削除フラグtrueのレコードは含まない。
	 * </pre>
	 * @param key
	 * @param kaisya
	 * @param jigyosyo
	 * @return コード区分マスタリスト
	 * @throws LcmDAOException
	 */
	public ResultArrayList<CodeMasterBean> getCodeMasterListD(String key,String kaisya,String jigyosyo) throws TecDAOException;
	// 2013.03.01 C.Ohta 追加　搬入拠点分散　end

}
