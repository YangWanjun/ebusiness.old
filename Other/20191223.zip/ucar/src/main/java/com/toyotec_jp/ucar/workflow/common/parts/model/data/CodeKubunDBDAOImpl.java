package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.CodeKubunDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbbf020mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;

/**
 * <strong>コード区分DB操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CodeKubunDBDAOImpl extends UcarSharedDBDAO implements CodeKubunDBDAOIF {

	private static final String SELECT_CODE_KUBUN_DB_LIST_SQL
		= "SELECT "
		+ " CD_KUBUN "
		+ ",NVL(TRIM('　' FROM MJ_KUBUNNAI),' ') AS MJ_KUBUNNAI "
		+ "FROM "
		;

	private static final String SELECT_CODE_KUBUN_DB_WHERE_SQL
		= " WHERE "
		+ "    CD_KAISYA  = ? "
		+ "AND MJ_BLOCKID = '03' "
		+ "AND MJ_KUBUNID = '0108' ";

	private static final String SELECT_CODE_KUBUN_DB_ORDER_SQL
		= "ORDER BY "
		+ " CD_KUBUN ";

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.workflow.common.parts.model.data.LeaseCompanyMasterDAOIF#getLeaseCompanyMasterList()
	 */
	@Override
	public ResultArrayList<CodeKubunDBBean> getCodeKubunDBList(String cdKaisya, String cdHanbaitn) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder(SELECT_CODE_KUBUN_DB_LIST_SQL);

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		selectSql.append(AddonTableManager.getCodeKubun(cdHanbaitn));

		selectSql.append(SELECT_CODE_KUBUN_DB_WHERE_SQL);
		// パラメータセット<条件>
		paramBean.setString(cdKaisya);
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		paramBean.setSql(selectSql.toString());

		paramBean.setOrderSql(SELECT_CODE_KUBUN_DB_ORDER_SQL);

		ResultArrayList<CodeKubunDBBean> resList
			= executeSimpleSelectQuery(paramBean, CodeKubunDBBean.class);

		return resList;
	}

	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.CodeKubunDBDAOIF#getCodeKubunDB(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public CodeKubunDBBean getCodeKubunDB(String cdKaisya,
											String cdHanbaitn,
											String mjBlockid,
											String mjKubunid,
											String cdKubun) throws TecDAOException {

		String executeSql
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , MJ_BLOCKID "
		+ "  , MJ_KUBUNID "
		+ "  , CD_KUBUN "
		+ "  , MJ_KUBUNMEI "
		+ "  , MJ_KUBUNNAI "
		+ "  , KB_MNTPATAN "
		+ "  , SU_YUKOKETA "
		+ "  , KB_CURSOR "
		+ "  , MJ_HYOJIJY "
		+ "  , SU_SIZEX "
		+ "  , SU_SIZEY "
		+ "  , KB_KANRI "
		+ "  , DD_SAISINUP "
		+ "FROM "
		+ AddonTableManager.getCodeKubun(cdHanbaitn) + " "
		+ "WHERE "
		+ "  CD_KAISYA = ? "
		+ "  AND MJ_BLOCKID = ? "
		+ "  AND MJ_KUBUNID = ? "
		+ "  AND TRIM(CD_KUBUN) = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(mjBlockid);	// ブロックID
		paramBean.setString(mjKubunid);	// 区分ID
		paramBean.setString(cdKubun);	// 区分コード

		ResultArrayList<CodeKubunDBBean> codeKubunDBList = executeSimpleSelectQuery(paramBean, CodeKubunDBBean.class);
		CodeKubunDBBean codeKubunDBBean = new CodeKubunDBBean();

		if (codeKubunDBList.size() > 0) {
			codeKubunDBBean = codeKubunDBList.get(0);
		}
		return codeKubunDBBean;
	}
	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため end
	// 2015.03.17 Y.Negishi U-Car帳票改善 add start
	/**
	 * 特別仕様名称取得処理
	 * @param 会社コード
	 * @param 販売店コード
	 * @param 区分ID
	 * @return 特別仕様名称
	 * @throws TecDAOException
	 */
	public String getMjSpecailWay(	String cdKaisya,
									String cdHanbaitn,
									String kbId
									) throws TecDAOException {
		
		StringBuffer executeSql = new StringBuffer();
		executeSql.append("SELECT MJ_INFO1 ");
		executeSql.append("FROM T220018M ");
		executeSql.append("WHERE CD_KAISYA = ? ");
		executeSql.append("AND CD_HANBAITN = ? ");
		executeSql.append("AND KB_ID = ? ");
		
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql.toString());
		paramBean.setString(cdKaisya);
		paramBean.setString(cdHanbaitn);
		paramBean.setString(kbId);
		
		ResultArrayList<Ucba004mBean> t220204mBeanList = executeSimpleSelectQuery(paramBean, Ucba004mBean.class);
		String mjSpecailWay = null;
		if(t220204mBeanList.size() > 0){
			mjSpecailWay = t220204mBeanList.get(0).getMjInfo1();
		}
		return mjSpecailWay;
	}
	
	/**
	 * 塗色名取得処理
	 * @param	中古車塗色コード/内装色
	 * @param	販売店コード
	 * @return	中古車塗色名/内装色名
	 * @throws	TecDAOException
	 */
	public String getKjTosikime(	String cdToshiki,
									String cdHanbaitn) throws TecDAOException{
		
		String cdKaisya ="";
		if (cdHanbaitn.equals(UcarConst.TOYOTA)) {
			cdKaisya = "01";
		} else if (cdHanbaitn.equals(UcarConst.TOYOPET)) {
			cdKaisya = "02";
		} else if (cdHanbaitn.equals(UcarConst.COROLLA)) {
			cdKaisya = "03";
		} else if (cdHanbaitn.equals(UcarConst.NETZ)) {
			cdKaisya = "05";
		} else if (cdHanbaitn.equals(UcarConst.LEXUS)) {
			cdKaisya = "06";
		}
		
		StringBuffer executeSql = new StringBuffer();
		executeSql.append("SELECT KJ_TOSIKIME ");
		executeSql.append("FROM ");
		/* 2019.04.30 T.Osada Satrt
		executeSql.append(AddonTableManager.getAddonTable(cdHanbaitn,"TBBF020M"));
		executeSql.append(" WHERE CD_TOSYOK =  '");
		*/
		// 2019.12.19 T.Osada start
		// executeSql.append("TBBF020M@TAPS010 ");
		executeSql.append("TBBF020M ");
		// 2019.12.19 T.Osada end
		executeSql.append(" WHERE CD_KAISYA =  '");
		executeSql.append(cdKaisya);
		executeSql.append("'");
		executeSql.append("   AND CD_TOSYOK =  '");
		// 2019.04.30 T.Osada end
		executeSql.append(cdToshiki);
		executeSql.append("'");
		
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql.toString());
		
		String kjTosiki = "";
		ResultArrayList<Tbbf020mBean> tbbf020mBeanList = executeSimpleSelectQuery(paramBean, Tbbf020mBean.class);
		if (tbbf020mBeanList.size() > 0) {
			kjTosiki = tbbf020mBeanList.get(0).getKjTosikime();
		}
		return StringUtils.trimRight(kjTosiki);
	}
	// 2015.03.17 Y.Negishi U-Car帳票改善 add end
}
