/*
 * 【システム名】リース管理システム
 * 【ファイル名】CalendarServiceController.java
 * 【  説  明  】カレンダー用サービスコントローラ
 * 【  作  成  】2010/06/18 T.H(SCC)
 */
package com.toyotec_jp.ucar.workflow.common.calendar.service.controller;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.utils.DateCheckUtils;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.workflow.common.calendar.model.object.CalendarSessionBean;

/**
 * ユニットリスト
 */
public class CalendarInitServiceController extends UcarServiceController {

	/**
	 * 呼出しに対する処理を実行します。
	 *
	 * @return 処理結果
	 * @throws SystemException 処理実行時にシステム例外が発生
	 * @throws ApplicationException 処理実行時にアプリケーション例外が発生
	 */
	public ServiceResult service() throws SystemException, ApplicationException {
//2015.4.22 前後追加 START		
		String yy;
		String mm;
//2015.4.22 前後追加 END
		// セッション情報を取得
		CalendarSessionBean sessionBean = getApplicationSessionBean("calendarSessionBean", CalendarSessionBean.class);

		// 当日を取得
		String currentDate = DateUtils.dateToString(DateUtils.getCurrentDate(), DateUtils.FORMAT_SHORT);

		// 設定されている年月を取得
		String targetDate  = (String) getRequest().getParameter("date");

		if (DateCheckUtils.isExistDate(targetDate, DateUtils.FORMAT_SHORT)) {
			// 日付が存在する場合は、設定されている日付を使用
//2015.4.22 前後追加 START	
//			sessionBean.setYear	(targetDate.split("/")[0]);
//			sessionBean.setMonth(targetDate.split("/")[1]);
			yy = targetDate.split("/")[0];
			mm = targetDate.split("/")[1];
				
//2015.4.22 前後追加 END			
			
		} else {
			// 日付が存在しない場合は、当日をデフォルトとして使用
//2015.4.22 前後追加 START
//			sessionBean.setYear	(currentDate.split("/")[0]);
//			sessionBean.setMonth(currentDate.split("/")[1]);
			yy = currentDate.split("/")[0];
			mm = currentDate.split("/")[1];
				
//2015.4.22 前後追加 END			
		}
//2015.4.22 前後追加 START
		int curYy	= Integer.parseInt(yy);
		int curMm	= Integer.parseInt(mm);
		
		//前月
		curMm += -1;
		if(curMm == 0){
			curYy += -1;
			curMm  = 12;
		}
		sessionBean.setYearBefore(String.valueOf(curYy));
		sessionBean.setMonthBefore(String.valueOf(curMm));
		
		//当月
		curMm += 1;
		if(curMm == 13){
			curYy += 1;
			curMm  = 1;
		}
		sessionBean.setYear(String.valueOf(curYy));
		sessionBean.setMonth(String.valueOf(curMm));
		
		//翌月
		curMm += 1;
		if(curMm == 13){
			curYy += 1;
			curMm  = 1;
		}
		sessionBean.setYearAfter(String.valueOf(curYy));
		sessionBean.setMonthAfter(String.valueOf(curMm));
		
//2015.4.22 前後追加 END			
		
		// その他の情報を設定
		sessionBean.setForm((String) getRequest().getParameter("form"));
		sessionBean.setName((String) getRequest().getParameter("name"));
		String defaultValue = StringUtils.defaultValue((String) getRequest().getParameter("dateformat"));
		sessionBean.setDateformat(defaultValue);

		// 結果を返却します。
		return null;
	}

}
