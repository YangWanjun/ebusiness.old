package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;

/**
 * <strong>作業工程マスタ操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/24 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface SagyoKouteiDAOIF {

	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
	/**
	 * 作業工程マスタリスト取得
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @param kbTenposk 店舗識別区分
	 * @return 作業工程マスタリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucac002mBean> getSagyoKouteiList(String cdKaisya, String cdHanbaitn, String kbTenposk) throws TecDAOException;
	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

}
