package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba008mBean;

/**
 * <strong>作業者マスタDB操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SagyousyaMasterDAOImpl extends UcarSharedDBDAO implements SagyousyaMasterDAOIF {

	private static final String SELECT_T220207M_SQL
		= "SELECT "
		+ "    CD_WORKER "
		+ "  , MJ_WORKER "
		+ "FROM "
		+ "  T220207M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? ";

	private static final String SELECT_T220207M_ORDER_SQL
		= "ORDER BY "
		+ "  CD_WORKER ";

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.workflow.common.parts.model.data.LeaseCompanyMasterDAOIF#getLeaseCompanyMasterList()
	 */
	@Override
	public ResultArrayList<Ucba008mBean> getSagyousyaMasterList(String cdKaisya,
																String cdJigyosyo,
																String cdSyokusyu) throws TecDAOException {

		StringBuilder selectSql = new StringBuilder(SELECT_T220207M_SQL);
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);		// 会社コード
		paramBean.setString(cdJigyosyo);	// 事業所コード
		if (!StringCheckUtils.isEmpty(cdSyokusyu)) {

			String[] arrayCdSyokusyu = cdSyokusyu.split(",");

			boolean firstSet = false;
			selectSql.append("  AND CD_SYOKUSYU IN ( ");

			for (String setCdSyokusyu : arrayCdSyokusyu) {

				if (!firstSet) {
					selectSql.append("?");
					firstSet = true;
				} else {
					selectSql.append(", ?");
				}
				paramBean.setString(setCdSyokusyu);	// 職種コード
			}
			selectSql.append(" ) ");
		}

		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_T220207M_ORDER_SQL);

		ResultArrayList<Ucba008mBean> T220207mList = executeSimpleSelectQuery(paramBean, Ucba008mBean.class);

		return T220207mList;

	}

}
