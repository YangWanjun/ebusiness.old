/**
 * ファイルダウンロード共通
 * @version 1.00 2019/10/11 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.download;
