package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>コード区分DBBean</strong>
 * <p>テーブル英名：TBV0231M</p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CodeKubunDBBean extends TecBean {

	/**
	 *
	 */
	private static final long	serialVersionUID	= 4875383729331795512L;

	/** 区分コード */
	private String	cdKubun;
	/** 区分内容 */
	private String	mjKubunnai;

	/**
	 *
	 */
	public CodeKubunDBBean() {
		super();
	}

	/**
	 * cdKubunを取得する。
	 * @return cdKubun 区分コード
	 */
	public String getCdKubun() {
		return cdKubun;
	}

	/**
	 * cdKubunを設定する。
	 * @param cdKubun 区分コード
	 */
	public void setCdKubun(String cdKubun) {
		this.cdKubun = cdKubun;
	}

	/**
	 * mjKubunnaiを取得する。
	 * @return mjKubunnai 区分内容
	 */
	public String getMjKubunnai() {
		return mjKubunnai;
	}

	/**
	 * mjKubunnaiを設定する。
	 * @param mjKubunnai 区分内容
	 */
	public void setMjKubunnai(String mjKubunnai) {
		this.mjKubunnai = mjKubunnai;
	}

}
