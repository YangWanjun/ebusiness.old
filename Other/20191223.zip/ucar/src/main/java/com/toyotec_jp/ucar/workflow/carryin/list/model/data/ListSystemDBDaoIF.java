package com.toyotec_jp.ucar.workflow.carryin.list.model.data;

import jp.co.intra_mart.framework.base.data.DataAccessException;


/**
 * <strong>車両搬入一覧 System Daoインターフェース</strong>
 * <pre>
 *  system-data-sourceで直接addonDBにアクセスするために使用する
 * </pre>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/04 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public interface ListSystemDBDaoIF {

	/**
	 * 仕入日取得処理
	 * @param dbLink 		DB連携名
	 * @param cdKaisya		会社コード
	 * @param noSyaryou		車両NO
	 * @return
	 * @throws DataAccessException
	 */
	public String selectDdSiire(String dbLink, String cdKaisya, String noSyaryou) throws DataAccessException;

}
