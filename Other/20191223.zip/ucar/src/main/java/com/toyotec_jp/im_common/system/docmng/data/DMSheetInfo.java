/*
 * 【システム名】
 * 【ファイル名】DMSheetInfo.java
 * 【  説  明  】シート設定共通情報クラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

import java.io.Serializable;

/**
 * <strong>DMSheetInfo</strong>
 * <p>
 * シート設定共通情報クラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMSheetInfo implements Serializable {

	/** シリアルバージョン */
	private static final long serialVersionUID = 5748128380751955450L;

	/**
	 * コンストラクタ
	 * @param sheetMap シート情報格納用マップクラス
	 */
	public DMSheetInfo(DMSheetMap<?, ?> sheetMap){
		if(sheetMap != null){
			yoshikiId = sheetMap.getYoshikiId();
			sheetIdx = sheetMap.getSheetIdx();
			sheetNm = sheetMap.getSheetNm();
			sheetKbn = sheetMap.getSheetKbn();
			kaiPageKbn = sheetMap.getKaiPageKbn();
			shokiFilePath = sheetMap.getShokiFilePath();
			shokiSheetNm = sheetMap.getShokiSheetNm();
			shokiSaishuretsu = sheetMap.getShokiSaishuretsu();
			shokiSaishugyo = sheetMap.getShokiSaishugyo();
			tsuikaFilePath = sheetMap.getTsuikaFilePath();
			tsuikaSheetNm = sheetMap.getTsuikaSheetNm();
			tsuikaKaishigyo = sheetMap.getTsuikaKaishigyo();
			tsuikaShuryogyo = sheetMap.getTsuikaShuryogyo();
			tsuikaRetsuHoseichi = sheetMap.getTsuikaRetsuHoseichi();
			tsuikaGyoHoseichi = sheetMap.getTsuikaGyoHoseichi();
		}
	}

	/**
	 * コンストラクタ
	 * @param fileMapData マッピング用データクラス
	 */
	public DMSheetInfo(DMFilesMapData fileMapData){
		if(fileMapData != null){
			yoshikiId = fileMapData.getYoshikiId();
			sheetIdx = fileMapData.getSheetIdx();
			sheetNm = fileMapData.getSheetNm();
			sheetKbn = fileMapData.getSheetKbn();
			kaiPageKbn = fileMapData.getKaiPageKbn();
			shokiFilePath = fileMapData.getShokiFilePath();
			shokiSheetNm = fileMapData.getShokiSheetNm();
			shokiSaishuretsu = fileMapData.getShokiSaishuretsu();
			shokiSaishugyo = fileMapData.getShokiSaishugyo();
			tsuikaFilePath = fileMapData.getTsuikaFilePath();
			tsuikaSheetNm = fileMapData.getTsuikaSheetNm();
			tsuikaKaishigyo = fileMapData.getTsuikaKaishigyo();
			tsuikaShuryogyo = fileMapData.getTsuikaShuryogyo();
			tsuikaRetsuHoseichi = fileMapData.getTsuikaRetsuHoseichi();
			tsuikaGyoHoseichi = fileMapData.getTsuikaGyoHoseichi();
		}
	}

	private String yoshikiId;
	private int sheetIdx;
	private String sheetNm;
	private int sheetKbn;
	private int kaiPageKbn;
	private String shokiFilePath;
	private String shokiSheetNm;
	private int shokiSaishuretsu;
	private int shokiSaishugyo;
	private String tsuikaFilePath;
	private String tsuikaSheetNm;
	private int tsuikaKaishigyo;
	private int tsuikaShuryogyo;
	private int tsuikaRetsuHoseichi;
	private int tsuikaGyoHoseichi;

	/**
	 * 様式シート定義-改ページ区分取得
	 * @return 様式シート定義-改ページ区分(方向設定(0:固定、1:縦))
	 * @since 1.00
	 */
	public int getKaiPageKbn() {
		return kaiPageKbn;
	}

	/**
	 * 様式シート定義-シートインデックス取得
	 * @return 様式シート定義-シートインデックス
	 * @since 1.00
	 */
	public int getSheetIdx() {
		return sheetIdx;
	}

	/**
	 * 様式シート定義-シート区分取得
	 * @return 様式シート定義-シート区分(0:任意、1:必須)
	 * @since 1.00
	 */
	public int getSheetKbn() {
		return sheetKbn;
	}

	/**
	 * 様式シート定義-シート名取得
	 * @return 様式シート定義-シート名
	 * @since 1.00
	 */
	public String getSheetNm() {
		return sheetNm;
	}

	/**
	 * 様式シート定義-初期ページ用ファイルパス取得
	 * @return 様式シート定義-初期ページ用ファイルパス
	 * @since 1.00
	 */
	public String getShokiFilePath() {
		return shokiFilePath;
	}

	/**
	 * 様式シート定義-初期ページ最終行取得
	 * @return 様式シート定義-初期ページ最終行
	 * @since 1.00
	 */
	public int getShokiSaishugyo() {
		return shokiSaishugyo;
	}

	/**
	 * 様式シート定義-初期ページ最終列取得
	 * @return 様式シート定義-初期ページ最終列
	 * @since 1.00
	 */
	public int getShokiSaishuretsu() {
		return shokiSaishuretsu;
	}

	/**
	 * 様式シート定義-初期ページ用シート名取得
	 * @return 様式シート定義-初期ページ用シート名
	 * @since 1.00
	 */
	public String getShokiSheetNm() {
		return shokiSheetNm;
	}

	/**
	 * 様式シート定義-追加ページ用ファイルパス取得
	 * @return 様式シート定義-追加ページ用ファイルパス
	 * @since 1.00
	 */
	public String getTsuikaFilePath() {
		return tsuikaFilePath;
	}

	/**
	 * 様式シート定義-追加ページ基準行補正値取得
	 * @return 様式シート定義-追加ページ基準行補正値
	 * @since 1.00
	 */
	public int getTsuikaGyoHoseichi() {
		return tsuikaGyoHoseichi;
	}

	/**
	 * 様式シート定義-追加ページコピー開始行取得
	 * @return 様式シート定義-追加ページコピー開始行取得
	 * @since 1.00
	 */
	public int getTsuikaKaishigyo() {
		return tsuikaKaishigyo;
	}

	/**
	 * 様式シート定義-追加ページ基準列補正値取得
	 * @return 様式シート定義-追加ページ基準列補正値
	 * @since 1.00
	 */
	public int getTsuikaRetsuHoseichi() {
		return tsuikaRetsuHoseichi;
	}

	/**
	 * 様式シート定義-追加ページ用シート名取得
	 * @return 様式シート定義-追加ページ用シート名
	 * @since 1.00
	 */
	public String getTsuikaSheetNm() {
		return tsuikaSheetNm;
	}

	/**
	 * 様式シート定義-追加ページコピー終了行取得
	 * @return 様式シート定義-追加ページコピー終了行
	 * @since 1.00
	 */
	public int getTsuikaShuryogyo() {
		return tsuikaShuryogyo;
	}

	/**
	 * 様式-様式ID取得
	 * @return 様式-様式ID
	 * @since 1.00
	 */
	public String getYoshikiId() {
		return yoshikiId;
	}

}
