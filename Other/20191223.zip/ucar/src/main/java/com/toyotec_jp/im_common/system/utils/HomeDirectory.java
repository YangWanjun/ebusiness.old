/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】HomeDirectory.java
 * 【  説  明  】
 * 【  作  成  】2019/10/10 MHH(SMT)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import jp.co.intra_mart.common.aid.jdk.java.io.file.ExtendedDirectory;
import jp.co.intra_mart.system.service.client.file.StorageInformation;

/**
 * <strong>HomeDirectoryストレージパスを取得クラス。</strong>
 * <p>
 * IMのストレージパスを取得する。
 * </p>
 * @author MHH(SMT)
 * @version 1.00 2019/10/10 新規作成<br>
 * @since 1.00
 */
public class HomeDirectory extends ExtendedDirectory{

    private static String HOME_DIRECTORY;
    
    private static HomeDirectory _instance = new HomeDirectory();

    public static HomeDirectory instance() {
        return _instance;
    }
    
    /** @deprecated */
    public static void definePath(String path) {
        if (path == null) {
            throw new NullPointerException("path is null");
        } else {
            _instance = new HomeDirectory(path.trim());
        }
    }

    public static String findPath() {
        return HOME_DIRECTORY;
    }
    
    private HomeDirectory() {
    	// ストレージパスを取得する
        this(new StorageInformation().getPublicStorageRootPath());
    }
    
    private HomeDirectory(String path) {
        super(path, 64);
        HOME_DIRECTORY = path;
    }
}
