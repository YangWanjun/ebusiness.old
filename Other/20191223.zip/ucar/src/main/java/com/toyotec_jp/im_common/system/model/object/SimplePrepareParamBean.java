/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】SimplePrepareParamBean.java
 * 【  説  明  】
 * 【  作  成  】2010/06/04 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.model.object;


/**
 * <strong>簡易クエリ実行用プリペアドステートメントパラメータビーン。</strong>
 *
 * @author H.O(SCC)
 * @version 1.00 2010/06/04 新規作成<br>
 * @since 1.00
 */
public class SimplePrepareParamBean extends TecBean {

	private static final long serialVersionUID = -3732070555737517455L;

	private int sqlType;

	private Object value;

	/**
	 * コンストラクタ。
	 * @param sqlType SQL型(java.sql.Types)
	 * @param value 値
	 */
	public SimplePrepareParamBean(int sqlType, Object value) {
		this.sqlType = sqlType;
		this.value = value;
	}

	/**
	 * SQL型を取得する。
	 * @return sqlType SQL型(java.sql.Types)
	 */
	public int getSqlType() {
		return sqlType;
	}

	/**
	 * SQL型を設定する。
	 * @param sqlType SQL型(java.sql.Types)
	 */
	public void setSqlType(int sqlType) {
		this.sqlType = sqlType;
	}

	/**
	 * 値を取得する。
	 * @return value 値
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * 値を設定する。
	 * @param value 値
	 */
	public void setValue(Object value) {
		this.value = value;
	}

}
