package com.toyotec_jp.ucar;

import java.util.ResourceBundle;

import com.toyotec_jp.im_common.TecApplicationManager.TecApplicationIdIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecConfigKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecConstantKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecServiceIdIF;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;

/**
 * <strong>アプリケーション管理クラス。</strong>
 * <p>
 * アプリケーションで使用する固定値、初期設定ファイルに定義した値を管理する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/08 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UcarApplicationManager {

	/** パッケージのルート */
	public static final String APPLICATION_ROOT = "com.toyotec_jp.ucar";

	/** 業務パッケージのルート */
	public static final String WF_ROOT = APPLICATION_ROOT + ".workflow";

	// 2012.02.03 T.Hayato 追加 バッチパッケージルート start
	/** バッチパッケージのルート */
	public static final String BATCH_ROOT = APPLICATION_ROOT + ".batch";
	// 2012.02.03 T.Hayato 追加 バッチパッケージルート end

	/** システム共通パッケージのルート */
	public static final String SYSTEM_COMMON_ROOT = APPLICATION_ROOT + ".system";

	/** メニューIDが設定されているリクエストパラメータの名称 */
	public static final String REQ_PARAM_NAME_MENU_ID = "menuId";

	/** 画面遷移用：画面遷移用ビーンを設定するリクエスト属性のキー名称 */
	public static final String REQ_ATTR_KEY_TRANSIT_BEAN = APPLICATION_ROOT + ".transit_bean";
	/** 画面遷移用：メッセージ、エラー画面用ビーンを設定するリクエスト属性のキー名称 */
	public static final String REQ_ATTR_KEY_MESSAGE_BEAN = APPLICATION_ROOT + ".message_bean";

	private UcarApplicationManager(){
	}

	/** アプリケーションID */
	public static enum UcarApplicationId implements TecApplicationIdIF {
		/** 業務共通 */
		COMMON(WF_ROOT + ".common.UcarCommon"),
		/** 業務共通部品 */
		COMMON_PARTS(WF_ROOT + ".common.parts.UcarCommonParts"),
		;
		private String applicationId;
		private UcarApplicationId(String applicationId){
			this.applicationId = applicationId;
		}
		public String toString(){
			return applicationId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
	}

	/** サービスID */
	public static enum UcarServiceId implements TecServiceIdIF {
		;
		private UcarApplicationId appId;
		private String serviceId;
		private UcarServiceId(UcarApplicationId appId, String serviceId){
			this.appId = appId;
			this.serviceId = serviceId;
		}
		public String toString(){
			return serviceId;
		}
		/** アプリケーションID取得 */
		public String getApplicationId(){
			return appId.toString();
		}
		/** サービスID取得 */
		public String getServiceId(){
			return serviceId;
		}
	}

	/** イベントキー */
	public static enum UcarEventKey implements TecEventKeyIF {
		/** Excel読み込みイベント */
		EXCEL_FORMAT_READ(UcarApplicationId.COMMON_PARTS, "ExcelFormatRead"),
		/** Excel書き込みイベント */
		EXCEL_FORMAT_WRITE(UcarApplicationId.COMMON_PARTS, "ExcelFormatWrite"),
		/** ユーザ情報取得イベント */
		USER_INFO_GET(UcarApplicationId.COMMON_PARTS, "UserInformationGet"),
		/** 共通店舗リスト取得イベント */
		KYOUTU_TENPO_LIST(UcarApplicationId.COMMON_PARTS, "KyoutuTenpoDBEvent"),
		/** 陸支コードリスト取得イベント */
		RIKUSI_CODE_LIST(UcarApplicationId.COMMON_PARTS, "RikusiCodeDBEvent"),
		/** コードマスタ取得イベント */
		VIEW_CODE_MASTER(UcarApplicationId.COMMON_PARTS, "ViewCodeMaster"),
		// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため start
		/** 配送候補連携イベント(初期表示用) */
		INIT_HAISO_KOUHO_RENKEI(UcarApplicationId.COMMON_PARTS, "InitHaisoKouhoRenkei"),
		/** 配送候補連携イベント(車両搬出用) */
		CARRYOUT_HAISO_KOUHO_RENKEI(UcarApplicationId.COMMON_PARTS, "CarryoutHaisoKouhoRenkei"),
		/** 配送候補連携イベント(作業仕分用) */
		WORKSORT_HAISO_KOUHO_RENKEI(UcarApplicationId.COMMON_PARTS, "WorkSortHaisoKouhoRenkei"),
		// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため end
		/** 作業者マスタリスト取得イベント */
		SAGYOUSYA_MASTER_LIST(UcarApplicationId.COMMON_PARTS, "SagyousyaMasterEvent"),
		/** コードマスタ取得イベント */
		VIEW_SIWAKECODE_MASTER(UcarApplicationId.COMMON_PARTS, "ViewSiwakeCodeMaster"),
		;
		private UcarApplicationId appId;
		private String eventKey;
		private UcarEventKey(UcarApplicationId appId, String eventKey){
			this.appId = appId;
			this.eventKey = eventKey;
		}
		public String toString(){
			return eventKey;
		}
		/** アプリケーションID取得 */
		public String getApplicationId(){
			return appId.toString();
		}
		/** イベントキー取得 */
		public String getEventKey(){
			return eventKey;
		}
	}

	/** DAOキー */
	public static enum UcarDAOKey implements TecDAOKeyIF {
		/** 書式操作DAO */
		DOC_FORMAT_DAO(UcarApplicationId.COMMON_PARTS, "DocFormatDAO"),
		/** ユーザ関連情報操作DAO */
		USER_INFO_DAO(UcarApplicationId.COMMON_PARTS, "UserInformationDAO"),
		/** 共通店舗DB取得DAO */
		KYOUTU_TENPO_DB_DAO(UcarApplicationId.COMMON_PARTS, "KyoutuTenpoDBDAO"),
		/** 陸支コードDB取得DAO */
		RIKUSI_CODE_DB_DAO(UcarApplicationId.COMMON_PARTS, "RikusiCodeDBDAO"),
		/** コード区分DB取得DAO */
		CODE_KUBUN_DB_DAO(UcarApplicationId.COMMON_PARTS, "CodeKubunDBDAO"),
		/** 社員DB取得DAO */
		SYAIN_DB_DAO(UcarApplicationId.COMMON_PARTS, "SyainDBDAO"),
		/** U-Car商品化マスタ関連DAO */
		UCAA_MASTER_DAO(UcarApplicationId.COMMON_PARTS, "UcaaMasterDAO"),
		/** U-Car商品化トランザクション関連DAO */
		UCAA_TRANSACTION_DAO(UcarApplicationId.COMMON_PARTS, "UcaaTransactionDAO"),
		/** 作業工程マスタ取得DAO */
		SAGYO_KOUTEI_DAO(UcarApplicationId.COMMON_PARTS, "SagyoKouteiDAO"),
		/** コードマスタDAO */
		CODE_MASTER_DAO(UcarApplicationId.COMMON_PARTS, "CodeMasterDAO"),
		// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため start
		/** 配送候補連携DAO */
		HAISO_KOUHO_RENKEI_DAO(UcarApplicationId.COMMON_PARTS, "HaisoKouhoRenkeiDAO"),
		// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため end
		/** 作業者マスタDB取得DAO */
		SAGYOUSYA_MASTER_DAO(UcarApplicationId.COMMON_PARTS, "SagyousyaMasterDAO"),
		/** コードマスタDAO */
		SIWAKECODE_MASTER_DAO(UcarApplicationId.COMMON_PARTS, "SiwakeCodeMasterDAO"),
		;
		private UcarApplicationId appId;
		private String daoKey;
		private UcarDAOKey(UcarApplicationId appId, String daoKey){
			this.appId = appId;
			this.daoKey = daoKey;
		}
		public String toString(){
			return daoKey;
		}
		/** アプリケーションID取得 */
		public String getApplicationId(){
			return appId.toString();
		}
		/** DAOキー取得 */
		public String getDAOKey(){
			return daoKey;
		}
	}

	/** コンスタントキー */
	public static enum UcarConstantKey implements TecConstantKeyIF {
		/** 連絡先 */
		DEFAULT_CONTACT_INFO(SYSTEM_COMMON_ROOT + ".message.DefaultContactInformation");
		private String constantKey;
		private UcarConstantKey(String constantKey){
			this.constantKey = constantKey;
		}
		public String toString(){
			return constantKey;
		}
		@Override
		public String getConstantKey() {
			return constantKey;
		}
	}

	/** コンフィグキー */
	public static enum UcarConfigKey implements TecConfigKeyIF {
		;
		private String configKey;
		private UcarConfigKey(String configKey){
			this.configKey = configKey;
		}
		public String toString(){
			return configKey;
		}
		@Override
		public String getConfigKey() {
			return configKey;
		}
	}

	/**
	 * システム固定値取得。
	 * <pre>
	 * システム固定値定義ファイル(UcarConstant.properties)から指定されたキーに対応する数値を取得する。
	 * </pre>
	 * @param constantKey キー
	 * @return キーに対応する数値
	 */
	public static final int getConstantInt(TecConstantKeyIF constantKey) {
		return getConstantInt(constantKey.getConstantKey());
	}

	/**
	 * システム固定値取得。
	 * <pre>
	 * システム固定値定義ファイル(UcarConstant.properties)から指定されたキーに対応する数値を取得する。
	 * </pre>
	 * @param key キー
	 * @return キーに対応する数値
	 */
	public static final int getConstantInt(String key) {
		String configValue = getConstantValue(key);
		if(StringCheckUtils.isEmpty(configValue)){
			return 0;
		}
		return Integer.parseInt(configValue, 10);
	}

	/**
	 * システム固定値取得。
	 * <pre>
	 * システム固定値定義ファイル(UcarConstant.properties)から指定されたキーに対応する文字列を取得する。
	 * </pre>
	 * @param constantKey キー
	 * @return キーに対応する文字列
	 */
	public static final String getConstantValue(TecConstantKeyIF constantKey) {
		return getConstantValue(constantKey.getConstantKey());
	}

	/**
	 * システム固定値取得。
	 * <pre>
	 * システム固定値定義ファイル(UcarConstant.properties)から指定されたキーに対応する文字列を取得する。
	 * </pre>
	 * @param key キー
	 * @return キーに対応する文字列
	 */
	public static final String getConstantValue(String key) {
		return ResourceBundle.getBundle(APPLICATION_ROOT + ".UcarConstant").getString(key);
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(UcarConfig.properties)から指定されたキーに対応する数値を取得する。
	 * </pre>
	 * @param configKey キー
	 * @return キーに対応する数値
	 */
	public static final int getConfigInt(TecConfigKeyIF configKey) {
		return getConfigInt(configKey.getConfigKey());
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(UcarConfig.properties)から指定されたキーに対応する数値を取得する。
	 * </pre>
	 * @param key キー
	 * @return キーに対応する数値
	 */
	public static final int getConfigInt(String key) {
		String configValue = getConfigValue(key);
		if(StringCheckUtils.isEmpty(configValue)){
			return 0;
		}
		return Integer.parseInt(configValue, 10);
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(UcarConfig.properties)から指定されたキーに対応する文字列を取得する。
	 * </pre>
	 * @param configKey キー
	 * @return キーに対応する文字列
	 */
	public static final String getConfigValue(TecConfigKeyIF configKey) {
		return getConfigValue(configKey.getConfigKey());
	}

	/**
	 * システム設定値取得。
	 * <pre>
	 * システム設定値定義ファイル(UcarConfig.properties)から指定されたキーに対応する文字列を取得する。
	 * </pre>
	 * @param key キー
	 * @return キーに対応する文字列
	 */
	public static final String getConfigValue(String key) {
		//return StringUtils.encode(RB_CONFIG.getString(key), CharSet.UTF8, CharSet.UTF8);
		//return StringUtil.encode(RB_CONFIG.getString(key), CharSet.ISO_8859_1, CharSet.UTF8);
		return ResourceBundle.getBundle(APPLICATION_ROOT + ".UcarConfig").getString(key);
	}

	/**
	 * プロパティファイル再取得。
	 * <pre>
	 * 本システムでは使用しない。<br>
	 * ResourceBundleのキャッシュをクリアすることで
	 * システム固定値定義ファイル(UcarConstant.properties)、
	 * システム設定値定義ファイル(UcarConfig.properties)
	 * を再読込させる。<br>
	 * ただし、staticフィールドに取得結果を設定し使用していることがあるため、
	 * 対象のクラスを再読込しなければ意図した結果とはならないため注意。
	 * </pre>
	 */
	public static void refreshProperties(){
		ResourceBundle.clearCache();
	}

}
