package com.toyotec_jp.ucar.workflow.carryin.list.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb004gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;

/**
 * <strong>搬入書類チェックDAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/18 新規作成<br>
 * @since 1.00
 * @category [[搬入書類チェック]]
 */
public interface DocumentCheckDAOIF {

	/**
	 * 件数取得処理
	 * @param 	t220007gBean    書類チェックDB(店舗用)Bean
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
//	public int selectT220007GCount(T220007gBean t220007gBean) throws TecDAOException;
	public int selectT220007GCount(Uccb004gBean t220007gBean) throws TecDAOException;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

	/**
	 * 新規登録処理（書類チェックDB）
	 * @param	t220007gBean    書類チェックDB(店舗用)Bean
	 * @param	executeDate     実行日時
	 * @return	簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220007G(T220007gBean t220007gBean,
	public SimpleExecuteResultBean insertT220007G(Uccb004gBean t220007gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（書類チェックDB）
	 * @param	t220007gBean    書類チェックDB(店舗用)Bean
	 * @param	nyukoDtKosin    書類チェックDB：データ更新日時(排他チェック用)
	 * @param	executeDate     実行日時
	 * @return	簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220007G(T220007gBean t220007gBean,
	public SimpleExecuteResultBean updateT220007G(Uccb004gBean t220007gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													String nyukoDtKosin,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 新規登録処理（ステータスDB）
	 * @param	t220012gInputDataBean ステータスDB(店舗用)Bean(新規登録・更新用)
	 * @param	executeDate           実行日時
	 * @return	簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException       DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean insertT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（ステータスDB）
	 * @param	t220012gInputDataBean ステータスDB(店舗用)Bean(新規登録・更新用)
	 * @param	executeDate           実行日時
	 * @return	簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException       DAO例外クラス
	 */
//	public SimpleExecuteResultBean updateT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean updateT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 新規登録処理（チェック内容情報）
	 * @param	t220003gBean チェック内容情報(店舗用)Bean
	 * @param	executeDate  実行日時
	 * @return	簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean insertT220003G(T220003gBean t220003gBean, Timestamp executeDate) throws TecDAOException;
	public SimpleExecuteResultBean insertT220003G(Uccb003gBean t220003gBean, Timestamp executeDate) throws TecDAOException;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

	/**
	 * 削除処理（チェック内容情報）
	 * @param 	t220003gBean チェック内容情報(店舗用)Bean
	 * @return	簡易更新クエリ実行結果ビーン
	 * @throws TecDAOException DAO例外クラス
	 */
//	public SimpleExecuteResultBean deleteT220003G(T220003gBean t220003gBean) throws TecDAOException;
	public SimpleExecuteResultBean deleteT220003G(Uccb003gBean t220003gBean) throws TecDAOException;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
	
}
