package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SiwakeCodeMasterBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>仕分用コード区分マスタ操作DAOインターフェース。</strong>
 * @author C.O(TEC)
 * @version 1.00 2013/02/05 新規作成<br>
 * @category [[U-Car商品化システム(共通)]]
 * @since 1.00
 */
public interface SiwakeCodeMasterDAOIF {

	/**
	 * 仕分用コード区分マスタリスト取得。
	 * <pre>
	 * 削除フラグtrueのレコードは含まない。
	 * </pre>
	 * @param key
	 * @return 仕分用コード区分マスタリスト
	 * @throws LcmDAOException
	 */
	public ResultArrayList<SiwakeCodeMasterBean> getSiwakeCodeMasterList(String key,UserInformationBean userInfoBean) throws TecDAOException;

}
