package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.RikusiCodeDBBean;

/**
 * <strong>陸支コードDB操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class RikusiCodeDBDAOImpl extends UcarSharedDBDAO implements RikusiCodeDBDAOIF {

	private static final String SELECT_RIKUSI_CODE_DB_LIST_SQL
		= "SELECT "
		+ " CD_RIKUSI "
		+ ",KJ_RIKUSIM "
		+ "FROM "
		;

	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
	private static final String SELECT_RIKUSI_CODE_DB_WHERE_SQL
		= " WHERE "
		+ "  CD_KAISYA = ? ";
	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

	private static final String SELECT_RIKUSI_CODE_DB_ORDER_SQL
		= "ORDER BY "
		+ " DECODE(MJ_NARABIJY, '  ', '99',MJ_NARABIJY) "
		+ ",CD_RIKUSI ";

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.workflow.common.parts.model.data.LeaseCompanyMasterDAOIF#getLeaseCompanyMasterList()
	 */
	@Override
	public ResultArrayList<RikusiCodeDBBean> getRikusiCodeDBList(String cdKaisya, String cdHanbaitn) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder(SELECT_RIKUSI_CODE_DB_LIST_SQL);

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		selectSql.append(AddonTableManager.getRikusiCode(cdHanbaitn));

		selectSql.append(SELECT_RIKUSI_CODE_DB_WHERE_SQL);
		paramBean.setString(cdKaisya);
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_RIKUSI_CODE_DB_ORDER_SQL);

		ResultArrayList<RikusiCodeDBBean> resList
			= executeSimpleSelectQuery(paramBean, RikusiCodeDBBean.class);

		return resList;
	}

	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.RikusiCodeDBDAOIF#getRikusiCodeDB(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public RikusiCodeDBBean getRikusiCodeDB(String cdKaisya,
											String cdHanbaitn,
											String cdRikusi) throws TecDAOException {

		String executeSql
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_RIKUSI "
		+ "  , KJ_RIKUSIM "
		+ "  , KB_RIKUSI "
		+ "  , KB_KENNAI "
		+ "  , KJ_SIYOHONK "
		+ "  , MJ_NARABIJY "
		+ "  , MJ_SYASYUKT "
		+ "  , DD_SAISINUP "
		+ "FROM "
		+ AddonTableManager.getRikusiCode(cdHanbaitn) + " "
		+ "WHERE "
		+ "  CD_KAISYA = ? "
		+ "  AND CD_RIKUSI = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(cdRikusi);	// 陸支コード

		ResultArrayList<RikusiCodeDBBean> rikusiCodeList = executeSimpleSelectQuery(paramBean, RikusiCodeDBBean.class);
		RikusiCodeDBBean rikusiCodeDBBean = new RikusiCodeDBBean();

		if (rikusiCodeList.size() > 0) {
			rikusiCodeDBBean = rikusiCodeList.get(0);
		}
		return rikusiCodeDBBean;
	}
	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため end

}
