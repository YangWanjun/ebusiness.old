/**
 * システム共通例外関連パッケージ。
 * @version 1.00 2010/05/24 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.im_common.system.exception;
