/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecFileMngException.java
 * 【  説  明  】
 * 【  作  成  】2010/07/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import java.util.ArrayList;

import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;


/**
 * <strong>ファイル操作例外クラス。</strong>
 * <p>
 * ファイル操作失敗時のシステム例外。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/01 新規作成<br>
 * @since 1.00
 */
public class TecFileMngException extends TecSystemException {

	private static final long serialVersionUID = -5000434472605271101L;

	/**
	 * コンストラクタ。
	 */
	public TecFileMngException() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param message
	 */
	public TecFileMngException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * @param cause
	 */
	public TecFileMngException(Throwable cause) {
		super(cause);
	}

	/**
	 * コンストラクタ。
	 * @param message
	 * @param cause
	 */
	public TecFileMngException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 */
	public TecFileMngException(TecMessageKeyIF messageKey) {
		super(messageKey);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 */
	public TecFileMngException(TecMessageKeyIF messageKey, ArrayList<Object> args) {
		super(messageKey, args);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param cause
	 */
	public TecFileMngException(TecMessageKeyIF messageKey, Throwable cause) {
		super(messageKey, cause);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey
	 * @param args
	 * @param cause
	 */
	public TecFileMngException(TecMessageKeyIF messageKey, ArrayList<Object> args, Throwable cause) {
		super(messageKey, args, cause);
	}

}
