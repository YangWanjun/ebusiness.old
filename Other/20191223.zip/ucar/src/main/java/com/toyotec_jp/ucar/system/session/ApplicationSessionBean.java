/*
 * 【システム名】リース管理システム
 * 【ファイル名】ApplicationSessionBean.java
 * 【  説  明  】
 * 【  作  成  】2010/06/24 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.system.session;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>アプリケーションセッションビーンクラス。</strong>
 * <p>
 * セッションに格納する各画面用のビーンはこのクラスを継承すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/24 新規作成<br>
 * @since 1.00
 */
public abstract class ApplicationSessionBean extends TecBean implements ApplicationSessionBeanIF {

	private static final long serialVersionUID = 2548059373057523716L;

}
