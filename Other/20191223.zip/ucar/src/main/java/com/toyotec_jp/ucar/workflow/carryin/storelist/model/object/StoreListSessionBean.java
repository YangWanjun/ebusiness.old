package com.toyotec_jp.ucar.workflow.carryin.storelist.model.object;

import java.util.Date;
import java.util.List;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;

/**
 * <strong>展示店舗受取処理セッションビーン</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/27 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class StoreListSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** サービスID */
	private String serviceId;
	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;

	/** 展示店舗受取処理 検索条件Bean */
	private StoreListParamBean storeListParamBean = new StoreListParamBean();

	/** ソート順 */
	private String sortOrder;
	/** ソートキー */
	private String sortParam;
	/** ページ番号 */
	private String pageNo;
	/** ページサイズ */
	private String pageSize = "100";

	/** ログインID判定フラグ
	 * <pre>
	 * true:本部
	 * false:本部以外
	 * </pre>
	 */
	private boolean honbuLoginId;

	/** データ更新日時:排他処理 */
	private Date dtKosin;

	/** 初期表示か検索処理かの判定フラグ
	 * <pre>
	 * true:初期表示
	 * false:検索処理
	 * </pre>
	 */
	private boolean isInit = true;
	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 展示店舗受取処理 画面出力値リスト */
	private List<StoreListDataBean> storeListDataList;
	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため end

	/**
	 * serviceIdを取得する。
	 * @return serviceId サービスID
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * serviceIdを設定する。
	 * @param serviceId サービスID
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean 車両搬入情報 プライマリーキーBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean 車両搬入情報 プライマリーキーBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}

	/**
	 * storeListDataBeanを取得する。
	 * @return storeListDataBean 展示店舗受取処理 検索条件Bean
	 */
	public StoreListParamBean getStoreListParamBean() {
		return storeListParamBean;
	}

	/**
	 * storeListDataBeanを設定する。
	 * @param storeListDataBean 展示店舗受取処理 検索条件Bean
	 */
	public void setStoreListParamBean(StoreListParamBean storeListParamBean) {
		this.storeListParamBean = storeListParamBean;
	}

	/**
	 * sortOrderを取得する。
	 * @return sortOrder ソート順
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * sortOrderを設定する。
	 * @param sortOrder ソート順
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * sortParamを取得する。
	 * @return sortParam ソートキー
	 */
	public String getSortParam() {
		return sortParam;
	}

	/**
	 * sortParamを設定する。
	 * @param sortParam ソートキー
	 */
	public void setSortParam(String sortParam) {
		this.sortParam = sortParam;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo ページ番号
	 */
	public String getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @param pageNo ページ番号
	 */
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @return pageSize ページサイズ
	 */
	public String getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize ページサイズ
	 */
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * honbuLoginIdを取得する。
	 * @return honbuLoginId ログインID判定フラグ
	 */
	public boolean isHonbuLoginId() {
		return honbuLoginId;
	}

	/**
	 * honbuLoginIdを設定する。
	 * @param honbuLoginId ログインID判定フラグ
	 */
	public void setHonbuLoginId(boolean honbuLoginId) {
		this.honbuLoginId = honbuLoginId;
	}

	/**
	 * dtKosinを取得する。
	 * @return dtKosin データ更新日時:排他処理
	 */
	public Date getDtKosin() {
		return dtKosin;
	}

	/**
	 * dtKosinを設定する。
	 * @param dtKosin データ更新日時:排他処理
	 */
	public void setDtKosin(Date dtKosin) {
		this.dtKosin = dtKosin;
	}

	/**
	 * isInitを取得する。
	 * @return isInit 初期表示か検索処理かの判定フラグ
	 */
	public boolean isInit() {
		return isInit;
	}

	/**
	 * isInitを設定する。
	 * @param isInit 初期表示か検索処理かの判定フラグ
	 */
	public void setInit(boolean isInit) {
		this.isInit = isInit;
	}

	/**
	 * storeListDataListを取得する。
	 * @return storeListDataList 展示店舗受取処理 画面出力値リスト
	 */
	public List<StoreListDataBean> getStoreListDataList() {
		return storeListDataList;
	}

	/**
	 * storeListDataListを設定する。
	 * @param storeListDataList 展示店舗受取処理 画面出力値リスト
	 */
	public void setStoreListDataList(List<StoreListDataBean> storeListDataList) {
		this.storeListDataList = storeListDataList;
	}

}
