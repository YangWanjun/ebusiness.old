/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecBean.java
 * 【  説  明  】
 * 【  作  成  】2010/05/06 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.model.object;

import java.io.Serializable;

/**
 * <strong>基本データビーン。</strong>
 * <p>
 * データビーンは、この基本データビーンを継承する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/17 新規作成<br>
 * @since 1.00
 */
public abstract class TecBean implements Serializable {

	private static final long serialVersionUID = 7756103864657005150L;

}
