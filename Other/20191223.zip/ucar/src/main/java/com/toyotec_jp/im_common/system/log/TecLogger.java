/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecLogger.java
 * 【  説  明  】
 * 【  作  成  】2010/05/10 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.log;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import jp.co.intra_mart.common.platform.log.Logger;

/**
 * <strong>Loggerクラス。</strong>
 * <p>
 * ログ出力を行う。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/17 新規作成<br>
 * @since 1.00
 */
public class TecLogger {

	private static List<String> excludeLoggerName4ClassName = new ArrayList<String>();

	static {
		// Threadクラス
		excludeLoggerName4ClassName.add("java.lang.Thread");
		// 自身
		excludeLoggerName4ClassName.add(TecLogger.class.getName());
	}

	/**
	 * エラーログ出力。
	 * @param message メッセージ
	 */
	public static void error(String message){
		error(message, null);
	}

	/**
	 * エラーログ出力。
	 * @param e Throwable
	 */
	public static void error(Throwable e){
		error(e.getMessage(), e);
	}

	/**
	 * エラーログ出力。
	 * @param message メッセージ
	 * @param detail 詳細オブジェクト
	 */
	public static void error(String message, Object detail){
		writeLog(Logger.Level.ERROR, message, detail);
	}

	/**
	 * ワーニングログ出力。
	 * @param message メッセージ
	 */
	public static void warn(String message){
		warn(message, null);
	}

	/**
	 * ワーニングログ出力。
	 * @param e Throwable
	 */
	public static void warn(Throwable e){
		warn(e.getMessage(), e);
	}

	/**
	 * ワーニングログ出力。
	 * @param message メッセージ
	 * @param detail 詳細オブジェクト
	 */
	public static void warn(String message, Object detail){
		writeLog(Logger.Level.WARN, message, detail);
	}

	/**
	 * インフォメーションログ出力。
	 * @param message メッセージ
	 */
	public static void info(String message){
		info(message, null);
	}

	/**
	 * インフォメーションログ出力。
	 * @param message メッセージ
	 * @param detail 詳細オブジェクト
	 */
	public static void info(String message, Object detail){
		writeLog(Logger.Level.INFO, message, detail);
	}

	/**
	 * デバッグログ出力。
	 * @param message メッセージ
	 */
	public static void debug(String message){
		debug(message, null);
	}

	/**
	 * デバッグログ出力。
	 * @param message メッセージ
	 * @param detail 詳細オブジェクト
	 */
	public static void debug(String message, Object detail){
		writeLog(Logger.Level.DEBUG, message, detail);
	}

	/**
	 * トレースログ出力。
	 * @param message メッセージ
	 */
	public static void trace(String message){
		trace(message, null);
	}

	/**
	 * トレースログ出力。
	 * @param message メッセージ
	 * @param detail 詳細オブジェクト
	 */
	public static void trace(String message, Object detail){
		writeLog(Logger.Level.TRACE, message, detail);
	}

	/**
	 * ログ出力。
	 * @param level ログレベル
	 * @param message メッセージ
	 * @param detail 詳細オブジェクト
	 */
	private static void writeLog(Logger.Level level, String message, Object detail){
		String detailString = getDetailString(detail);
		Logger logger = Logger.getLogger(getCallersLoggerName());
		if (detailString != null) {
			logger.log(level, message + " : " + detailString);
		} else {
			logger.log(level, message);
		}
	}

	private static String getDetailString(Object detail){
		Throwable e = null;
		String detailString = null;
		// 詳細文字列の作成
		// detailがThrowableのインスタンスである場合はそのスタックトレースの内容を、
		// そうでない場合はtoStringメソッドの戻り値を設定する
		if(detail != null){
			if (detail instanceof Throwable) {
				e = (Throwable)detail;
			}
			if (e != null) {
				StringWriter writer = new StringWriter();
				e.printStackTrace(new PrintWriter(writer));
				detailString = new String(writer.getBuffer());
			} else {
				detailString = detail.toString();
			}
		}
		return detailString;
	}

	private static String getCallersLoggerName(){
		StackTraceElement[] ste = Thread.currentThread().getStackTrace();
		String loggerName = null;
		for(int dept = 0; dept < ste.length; dept++){
			String name = ste[dept].getClassName();
			if(excludeLoggerName4ClassName.contains(name)){
				continue;
			}
			loggerName = ste[dept].getClassName();
			break;
		}
		if(loggerName == null){
			loggerName = "anonymous_logger_name";
		}
		return loggerName;
	}

}
