package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;

/**
 * <strong>配送候補連携DB操作用イベント(作業仕分用)</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/22 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class WorkSortHaisoKouhoRenkeiEvent extends UcarEvent {

	private static final long serialVersionUID = -8975344836334571960L;

	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPKBean;
	/** 実行処理内容
	 * <pre>
	 * いずれかの処理の時に文字列を設定
	 * 登録処理：register
	 * 保留処理：reserve
	 * 取消処理：cancel
	 * </pre>
	 *  */
	private String executeMode;
	/** 実行アプリID */
	private String executeAppId;

	/**
	 * t220001gPKBeanを取得する。
	 * @return t220001gPKBean
	 */
	public Ucaa001gPKBean getUcaa001gPKBean() {
		return t220001gPKBean;
	}

	/**
	 * t220001gPKBeanを設定する。
	 * @param t220001gPKBean
	 */
	public void setUcaa001gPKBean(Ucaa001gPKBean t220001gPKBean) {
		this.t220001gPKBean = t220001gPKBean;
	}

	/**
	 * executeModeを取得する。
	 * @return executeMode
	 */
	public String getExecuteMode() {
		return executeMode;
	}

	/**
	 * executeModeを設定する。
	 * @param executeMode
	 */
	public void setExecuteMode(String executeMode) {
		this.executeMode = executeMode;
	}

	/**
	 * executeAppIdを取得する。
	 * @return executeAppId
	 */
	public String getExecuteAppId() {
		return executeAppId;
	}

	/**
	 * executeAppIdを設定する。
	 * @param executeAppId
	 */
	public void setExecuteAppId(String executeAppId) {
		this.executeAppId = executeAppId;
	}

}
