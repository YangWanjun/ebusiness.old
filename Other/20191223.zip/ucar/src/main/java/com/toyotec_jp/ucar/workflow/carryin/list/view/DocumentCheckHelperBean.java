package com.toyotec_jp.ucar.workflow.carryin.list.view;

import java.util.List;

import jp.co.intra_mart.framework.base.event.EventException;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinEventKey;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinTitle;
import com.toyotec_jp.ucar.workflow.carryin.list.model.event.ListSelectEvent;
import com.toyotec_jp.ucar.workflow.carryin.list.model.event.ListSelectEventResult;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListDataBean;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListParamBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarButton;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;
/**
 * <strong>搬入書類チェックヘルパービーン</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/17 新規作成<br>
 * @since 1.00
 * @category [[搬入書類チェック]]
 */
public class DocumentCheckHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 8584928315609391060L;

	/** サービスURL格納領域 */
	private String serviceUrlInit;
	private String serviceUrlSearch;
	private String serviceUrlSort;
	private String	serviceUrlRegister;
	private String	serviceUrlCancel;
	private String serviceUrlTransRegister;
	private String serviceUrlHannyuDownload;

	/** 検索結果格納List */
	private List<ListDataBean> listData;
	/** チェック内容マスタ結果格納ArrayList */
	private ResultArrayList<Ucaa005mBean> masterData;
	/** 搬入日 */
	private String	ddHannyu = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT);
	/** セッション情報 */
	private CarryinSessionBean sessionBean;
	/** サービスID */
	private CarryinServiceId targetServiceId;
	/** 印刷チェックチェック状態 */
	private String	kbCheckPrintChecked = "";
	/** 陸支コード選択状態 */
	private String cdNorikusi;
	/** 仕入れ店舗コード選択状態 */
	private String cdSirtenpo;
	/** ページサイズ */
	private int pageSize;
	/** ページ番号 */
	private int pageNo;
	/** 合計レコード数 */
	private int totalRecordCount;
	/** リスト出力フラグ */
	private String listFlg = "NotSearch";
	/** エラーメッセージ */
	private String errMsg;

	private ListParamBean listParamBean = new ListParamBean();

	/** 状態チェック状態 */
	private String	checkSrkChecked = "";
	/** チェック内容Value値 */
	private String	kbCheckCheckvalues = "";
	/** チェック内容チェック状態 */
	private String	kbCheckChecked = "";
	/** 仕入種別checkvalues */
	private String	kbSiireCheckvalues = "";
	/** 仕入区分チェック状態 */
	private String	kbSiireChecked = "";
	/** 実行処理：区分ラジオボタンの値 */
	private String	radiovaluesKubun = "";

	/** デフォルトコンストラクタ。 */
	public DocumentCheckHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.base.view.TlsHelperBean#init()
	 */
	@Override
	public void init() throws HelperBeanException {

		// サービス呼び出し用URL設定
		setServiceURLs();

		// セッションの取得
		sessionBean = getApplicationSessionBean(CarryinSessionBean.class);
		String serviceId = sessionBean.getServiceId();
		targetServiceId = CarryinServiceId.getTargetCarryinServiceId(serviceId);

		try {
			kbCheckCheckvalues = UcarUtils.getT220005mCheckvalues(getRequest(), getResponse());

			// サービスごとの処理
			if(targetServiceId != null){
				switch (targetServiceId) {
					case DOCUMENT_CHECK_INIT:
					case DOCUMENT_CHECK_REGISTER:
					case DOCUMENT_CHECK_CANCEL:

						// 検索条件設定
						// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
						listParamBean.setCdKaisya(sessionBean.getT220001gPkBean().getCdKaisya());		// 会社コード
						listParamBean.setCdHanbaitn(sessionBean.getT220001gPkBean().getCdHanbaitn());	// 販売店コード
						// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

						// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため start
						UcarSessionManager sessionMng = UcarSessionManager.getInstance();
						LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());

						// 店舗コード
						listParamBean.setCdTenpo(loginSessionBean.getUserInfoBean().getCdTenpo());
						// 商品化センター区分
						listParamBean.setKbScenter(loginSessionBean.getUserInfoBean().getKbScenter());
						// 2013.04.05 T.Hayato 追加 搬入拠点分散対応2のため end

						String[] arrayCheckSrk = new String[] {"01"};		// 書類完備チェック(書類確認未完了で固定)
						listParamBean.setArrayCheckSrk(arrayCheckSrk);

						sessionBean.setListParamBean(listParamBean);

						//検索実行
						doSearch();
						break;
					case DOCUMENT_CHECK_SEARCH:
					case DOCUMENT_CHECK_SORT:
					case DOCUMENT_CHECK_RETURN_REGISTER:
						//検索実行
						doSearch();
						break;
					default:
						break;
				}
			}

			kbSiireCheckvalues = UcarUtils.getT220004mCheckvalues(getRequest(), getResponse());

			// 書類チェックDB(書類完備日／書類完備保留日)
			radiovaluesKubun  = CarryinConst.DOCUMENTCHECK_COMPLETE + "|書類完備,"
							  + CarryinConst.DOCUMENTCHECK_RESERVE 	+ "|保留(不備)";

		} catch (SystemException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		}
	}

	/** サービス呼び出し用URL設定 */
	private void setServiceURLs() throws HelperBeanException {
		serviceUrlInit 		= getServiceUrl(CarryinServiceId.DOCUMENT_CHECK_INIT);
		serviceUrlSearch 	= getServiceUrl(CarryinServiceId.DOCUMENT_CHECK_SEARCH);
		serviceUrlSort 		= getServiceUrl(CarryinServiceId.DOCUMENT_CHECK_SORT);
		serviceUrlRegister 	= getServiceUrl(CarryinServiceId.DOCUMENT_CHECK_REGISTER);
		serviceUrlCancel 	= getServiceUrl(CarryinServiceId.DOCUMENT_CHECK_CANCEL);
		serviceUrlTransRegister 	= getServiceUrl(CarryinServiceId.DOCUMENT_CHECK_TRANS_REGISTER);
		serviceUrlHannyuDownload 	= getServiceUrl(CarryinServiceId.HANNYU_DOWNLOAD);
	}

	/** セッションデータ画面戻し */
	private void setSessionData() throws HelperBeanException {

		if (sessionBean.getListParamBean().getArrayKbCheck() != null) {
			for (int i = 0; i < sessionBean.getListParamBean().getArrayKbCheck().length; i++) {
				String kbCheck = sessionBean.getListParamBean().getArrayKbCheck()[i];
				if(!(kbCheck == null)){
					if (i != 0){
						kbCheckChecked += ",";
					}
					kbCheckChecked += kbCheck;
				}
			}
		}
		if(sessionBean.getListParamBean().getArrayKbCheckPrint() != null){
			kbCheckPrintChecked += sessionBean.getListParamBean().getArrayKbCheckPrint()[0];
		}
		cdNorikusi = sessionBean.getListParamBean().getCdNorikusi();
		cdSirtenpo = sessionBean.getListParamBean().getCdSirtenpo();

		//  状態チェック状態
		if (sessionBean.getListParamBean().getArrayCheckSrk() != null) {
			for (int i = 0; i < sessionBean.getListParamBean().getArrayCheckSrk().length; i++) {
				String checkSrk= sessionBean.getListParamBean().getArrayCheckSrk()[i];
				if(!(checkSrk == null)){
					if (i != 0){
						checkSrkChecked += ",";
					}
					checkSrkChecked += checkSrk;
				}
			}
		}

		// 仕入種別チェック状態
		if (sessionBean.getListParamBean().getArrayKbSiire() != null) {
			for (int i = 0; i < sessionBean.getListParamBean().getArrayKbSiire().length; i++) {
				String kbSiire= sessionBean.getListParamBean().getArrayKbSiire()[i];
				if(!(kbSiire == null)){
					if (i != 0){
						kbSiireChecked += ",";
					}
					kbSiireChecked += kbSiire;
				}
			}
		}

	}

	/** 検索実行 関数化*/
	private void doSearch() throws HelperBeanException {

		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため start
		//検索イベント生成
		ListSelectEvent event
			= createEvent(CarryinEventKey.LIST_SELECT, ListSelectEvent.class);
		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため end

		event.setListParamBean(sessionBean.getListParamBean());
		event.setPageNo(sessionBean.getPageNo());
		event.setPageSize(sessionBean.getPageSize());
		event.setSortOrder(sessionBean.getSortOrder());
		event.setSortParam(sessionBean.getSortParam());

		// 検索on/off
		event.setIsKensakuOn(sessionBean.getIsKensakuOn());

		//	検索返却イベント
		ListSelectEventResult eventResult = null;
		try{
			eventResult	= (ListSelectEventResult) dispatchEvent(event);
			setPageSize(eventResult.getPageSize());
			setTotalRecordCount(eventResult.getTotalRecordCount());
			int pageMin = eventResult.getPageSize() * (eventResult.getPageNo() - 1);
			if (eventResult.getTotalRecordCount() < pageMin){
				setPageNo(1);
			} else {
				setPageNo(eventResult.getPageNo());
			}
		} catch (EventException e) {
			throw new HelperBeanException(e.getMessage());
		} catch (SystemException e) {
			throw new HelperBeanException(e.getMessage());
		} catch (ApplicationException e) {
			throw new HelperBeanException(e.getMessage());
		}

		//	イベントリザルトより一覧の取得
		listData = eventResult.getRtnData();
		masterData = eventResult.getT220005mList();
		setSessionData();
		//	データの有無表示
		if (listData == null || listData.size() == 0){
			setListFlg("listDataNull");
			setErrMsg("該当データはありません。");
			sessionBean.setDocumentCheckDataList(null);
		}else{
			setListFlg("listDataNotNull");
			sessionBean.setDocumentCheckDataList(listData);
		}

	}
	/** 画面タイトル取得 */
	public String getTitleLabel(){
		return CarryinTitle.DocumentCheck.getTitleLabel();
	}

	/** 条件絞込みボタンラベル取得 */
	public String getButtonLabelSearch(){
		return UcarButton.SEARCH_CONDITION.getButtonLabel();
	}

	/** 条件初期化ボタンラベル取得 */
	public String getButtonLabelClearCondition(){
		return UcarButton.CLEAR_CONDITION.getButtonLabel();
	}

	/** 搬入一覧表印刷ボタンラベル取得 */
	public String getButtonLabelHannyuDownload(){
		return UcarButton.HANNYU_DOWNLOAD.getButtonLabel();
	}

	/** チェックしたデータを登録ボタンラベル取得 */
	public String getButtonLabelCheckRegister(){
		return UcarButton.CHECK_REGISTER.getButtonLabel();
	}

	/** チェックしたデータを取消ボタンラベル取得 */
	public String getButtonLabelCheckCancel(){
		return UcarButton.CHECK_CANCEL.getButtonLabel();
	}

	/**
	 * serviceUrlInitを取得する。
	 * @return serviceUrlInit
	 */
	public String getServiceUrlInit() {
		return serviceUrlInit;
	}

	/**
	 * serviceUrlSearchを取得する。
	 * @return serviceUrlSearch
	 */
	public String getServiceUrlSearch() {
		return serviceUrlSearch;
	}
	/**
	 * serviceUrlSortを取得する。
	 * @return serviceUrlSearch
	 */
	public String getServiceUrlSort() {
		return serviceUrlSort;
	}

	/**
	 * serviceUrlRegisterを取得する。
	 * @return serviceUrlRegister
	 */
	public String getServiceUrlRegister() {
		return serviceUrlRegister;
	}

	/**
	 * serviceUrlCancelを取得する。
	 * @return serviceUrlCancel
	 */
	public String getServiceUrlCancel() {
		return serviceUrlCancel;
	}

	/**
	 * serviceUrlTransRegisterを取得する。
	 * @return serviceUrlSearch
	 */
	public String getServiceUrlTransRegister() {
		return serviceUrlTransRegister;
	}

	/**
	 * listDataを取得する。
	 * @return listData
	 */
	public List<ListDataBean> getListData() {
		return listData;
	}
	/**
	 * masterDataを取得する。
	 * @return masterData
	 */
	public ResultArrayList<Ucaa005mBean> getMasterData() {
		return masterData;
	}

	/**
	 * ddHannyuを取得する。
	 * @return ddHannyu
	 */
	public String getDdHannyu() {
		return ddHannyu;
	}

	/**
	 * sessionBeanを取得する。
	 * @return sessionBean
	 */
	public CarryinSessionBean getSessionBean() {
		return sessionBean;
	}

	/**
	 * targetServiceIdを取得する。
	 * @return targetServiceId
	 */
	public CarryinServiceId getTargetServiceId() {
		return targetServiceId;
	}
	/**
	 * ページサイズ返却します
	 * @return ページサイズ
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * ページサイズ設定します
	 * @return ページサイズ
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * ページ番号を返却します
	 * @return ページ番号
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * ページ番号を設定します
	 * @return ページ番号
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * 総レコード数を返却します
	 * @return 総レコード数
	 */
	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	/**
	 * 総レコード数を設定します
	 * @return 総レコード数
	 */
	public void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	/**
	 * データ有無を返却します
	 * @return データ有無
	 */
	public String getListFlg() {
		return listFlg;
	}

	/**
	 * データ有無を設定します
	 * @return データ有無
	 */
	public void setListFlg(String listFlg) {
		this.listFlg = listFlg;
	}

	/**
	 * エラーメッセージの返却
	 * 	@return
	 */
	public String getErrMsg() {
		return errMsg;
	}

	/**
	 * エラーメッセージの設定
	 * @param errMsg
	 */
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	/**
	 * kbCheckCheckvaluesを取得する。
	 * @return kbCheckCheckvalues
	 */
	public String getKbCheckCheckvalues() {
		return kbCheckCheckvalues;
	}

	/**
	 * kbCheckCheckedを取得する。
	 * @return kbCheckChecked
	 */
	public String getKbCheckChecked() {
		return kbCheckChecked;
	}

	/**
	 * kbCheckCheckedを取得する。
	 * @return kbCheckPrintChecked
	 */
	public String getKbCheckPrintChecked() {
		return kbCheckPrintChecked;
	}

	/**
	 * cdNoRikusiを取得する。
	 * @return cdNoRikusi
	 */
	public String getCdNorikusi() {
		return cdNorikusi;
	}

	/**
	 * kbCheckCheckedを取得する。
	 * @return kbCheckPrintChecked
	 */
	public String getCdSirtenpo() {
		return cdSirtenpo;
	}

	/**
	 * kbSiireCheckvaluesを取得する。
	 * @return kbSiireCheckvalues
	 */
	public String getKbSiireCheckvalues() {
		return kbSiireCheckvalues;
	}

	public String getCheckSrkChecked() {
		return checkSrkChecked;
	}

	public String getKbSiireChecked() {
		return kbSiireChecked;
	}

	public String getServiceUrlHannyuDownload() {
		return serviceUrlHannyuDownload;
	}

	/**
	 * radiovaluesKubunを取得する。
	 * @return radiovaluesKubun
	 */
	public String getRadiovaluesKubun() {
		return radiovaluesKubun;
	}

	public String getDocumentCheckExecuteRegister() {
		return UcarConst.EXECUTE_REGISTER;
	}

	public String getDocumentCheckExecuteReserve() {
		return UcarConst.EXECUTE_RESERVE;
	}

	public String getDocumentCheckExecuteCancel() {
		return UcarConst.EXECUTE_CANCEL;
	}

	public CarryinServiceId getServiceIdRegister() {
		return CarryinServiceId.DOCUMENT_CHECK_REGISTER;
	}

}
