package com.toyotec_jp.ucar.workflow.carryin.list.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListDaoIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcarCommonDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetDdSiireEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetDdSiireEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb011vBean;

/**
 * <strong>車両搬入一覧登録イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/04 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class RegisterListDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		RegisterListDataEvent targetEvent = (RegisterListDataEvent) event;

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarryinConst.APPID_CARRYIN_LIST;

		// DAOIF取得
		ListDaoIF dao = getDAO(CarryinDAOKey.LIST_DAO, targetEvent, ListDaoIF.class);
		UcarCommonDAOIF commonDao = getDAO(UcarDAOKey.UCARCOMMON_DAO, targetEvent, UcarCommonDAOIF.class);

		for (int i = 0; i < targetEvent.getCdKaisya().length; i++) {

			boolean isDdSiire = false;

			if ("".equals(targetEvent.getNoSyaryou()[i])
				&& !"".equals(targetEvent.getBeforeNoSyaryou()[i])) {
				// ai21車両№・ai21仕入日⇒ブランク登録

			} else if (!"".equals(targetEvent.getNoSyaryou()[i])
					&& "".equals(targetEvent.getBeforeNoSyaryou()[i])) {
				// ai21車両№・ai21仕入日⇒新規登録
				isDdSiire = true;

			} else if (targetEvent.getNoSyaryou()[i].equals(targetEvent.getBeforeNoSyaryou()[i])) {
				// 両方ブランク、あるいは両方同じ値の場合
				if ("".equals(targetEvent.getNoSyaryou()[i])
					&& "".equals(targetEvent.getBeforeNoSyaryou()[i])) {
					// 両方ブランクの場合
					continue;
				} else {
					// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
					// 車両搬入情報を取得する
					Ucaa001gBean t220001gBean = dao.selectSyaryoHannyu(targetEvent.getCdKaisya()[i],
																		targetEvent.getCdHanbaitn()[i],
																		targetEvent.getDdHannyu()[i],
																		targetEvent.getNoKanri()[i],
																		targetEvent.getUserInfoBean().getKbScenter());

					if (t220001gBean.getDdSiire() != null) {
						// 車両搬入情報にai21仕入日があれば、更新はしない
						continue;
					}
					isDdSiire = true;
					// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
				}
			} else if (!targetEvent.getNoSyaryou()[i].equals(targetEvent.getBeforeNoSyaryou()[i])) {
				// ai21車両№に変更あり⇒ai21仕入日を再取得して更新
				isDdSiire = true;
			}

			Ucaa001gBean t220001gBean = new Ucaa001gBean();

			t220001gBean.setCdKaisya(targetEvent.getCdKaisya()[i]);
			t220001gBean.setCdHanbaitn(targetEvent.getCdHanbaitn()[i]);
			t220001gBean.setDdHannyu(targetEvent.getDdHannyu()[i]);
			t220001gBean.setNoKanri(targetEvent.getNoKanri()[i]);

			t220001gBean.setNoSyaryou(targetEvent.getNoSyaryou()[i]);

			if (isDdSiire) {
				// 2013.05.20 T.Hayato 修正 ai21仕入日取得のため start
				// ai21仕入日取得
				GetDdSiireEvent executeEvent = createEvent(UcarEventKey.GET_DD_SIIRE,
															targetEvent.getUserInfo(),
															GetDdSiireEvent.class);

				executeEvent.setCdKaisya(targetEvent.getCdKaisya()[i]);
				executeEvent.setCdHanbaitn(targetEvent.getCdHanbaitn()[i]);
				executeEvent.setNoSyaryou(targetEvent.getNoSyaryou()[i]);

				GetDdSiireEventResult executeResult = (GetDdSiireEventResult)dispatchEvent(executeEvent);
				t220001gBean.setDdSiire(executeResult.getDdSiire());
				// 2013.05.20 T.Hayato 修正 ai21仕入日取得のため end

			} else {
				t220001gBean.setDdSiire(null);
			}

			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
			t220001gBean.setCdHantenpo(targetEvent.getUserInfoBean().getCdTenpo());
			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
			t220001gBean.setCdKsnsya(updateUserId);
			t220001gBean.setCdKsnapp(updateAppId);

			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため start
			String kbData = "";
			if (!UcarConst.KB_SCENTER_SCENTER.equals(targetEvent.getUserInfoBean().getKbScenter())) {
				// 業販・U-Car店舗の場合
				Uccb011vBean t220902vBean = commonDao.selectT220902v(targetEvent.getCdKaisya()[i],
																	targetEvent.getCdHanbaitn()[i],
																	targetEvent.getDdHannyu()[i],
																	targetEvent.getNoKanri()[i],
																	targetEvent.getUserInfoBean().getCdTenpo());

				if (t220902vBean == null) {
					throw new ApplicationException("対象データがありません。");
				}

				kbData = t220902vBean.getKbData();
			}

			dao.updateSyaryoHannyu(t220001gBean,
									targetEvent.getUserInfoBean().getKbScenter(),
									executeDate,
									kbData);
			// 2013.04.22 T.Hayato 修正 搬入拠点分散対応2のため end
		}

		return null;
	}

}
