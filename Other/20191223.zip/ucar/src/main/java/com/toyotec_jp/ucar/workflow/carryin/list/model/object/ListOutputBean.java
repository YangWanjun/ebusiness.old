package com.toyotec_jp.ucar.workflow.carryin.list.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>車両搬入一覧帳票出力用データ取得 Bean</strong>
 * @author Y.F(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入一覧]]
 */
public class ListOutputBean extends TecBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 会社コード */
	private String[] arrayCdKaisya;
	/** 販売店コード */
	private String[] arrayCdHanbaitn;
	/** 搬入日     */
	private String[] arrayDdHannyu;
	/** 管理番号     */
	private String[] arrayNoKanri;
	/** チェック状態 */
	private String[] arrayOutChkChecked;

	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 選択形態(セダン/バン) */
	private String[] arraySelectShape;
	// 2013.04.11 T.Hayato 追加 搬入拠点分散対応2のため end
	// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため start
	/** 搬入店舗コード */
	private String[] arrayCdHantenpo;
	// 2013.05.23 T.Hayato 修正 搬入拠点分散対応2のため end

	public ListOutputBean(){

	}

	public String[] getArrayCdKaisya() {
		return arrayCdKaisya;
	}

	public void setArrayCdKaisya(String[] arrayCdKaisya) {
		this.arrayCdKaisya = arrayCdKaisya;
	}

	public String[] getArrayCdHanbaitn() {
		return arrayCdHanbaitn;
	}

	public void setArrayCdHanbaitn(String[] arrayCdHanbaitn) {
		this.arrayCdHanbaitn = arrayCdHanbaitn;
	}

	public String[] getArrayDdHannyu() {
		return arrayDdHannyu;
	}

	public void setArrayDdHannyu(String[] arrayDdHannyu) {
		this.arrayDdHannyu = arrayDdHannyu;
	}

	public String[] getArrayNoKanri() {
		return arrayNoKanri;
	}

	public void setArrayNoKanri(String[] arrayNoKanri) {
		this.arrayNoKanri = arrayNoKanri;
	}

	public String[] getArrayOutChkChecked() {
		return arrayOutChkChecked;
	}

	public void setArrayOutChkChecked(String[] arrayOutChkChecked) {
		this.arrayOutChkChecked = arrayOutChkChecked;
	}

	/**
	 * arraySelectShapeを取得する。
	 * @return arraySelectShape 選択形態(セダン/バン)
	 */
	public String[] getArraySelectShape() {
		return arraySelectShape;
	}

	/**
	 * arraySelectShapeを設定する。
	 * @param arraySelectShape 選択形態(セダン/バン)
	 */
	public void setArraySelectShape(String[] arraySelectShape) {
		this.arraySelectShape = arraySelectShape;
	}

	/**
	 * arrayCdHantenpoを取得する。
	 * @return arrayCdHantenpo 搬入店舗コード
	 */
	public String[] getArrayCdHantenpo() {
		return arrayCdHantenpo;
	}

	/**
	 * arrayCdHantenpoを設定する。
	 * @param arrayCdHantenpo 搬入店舗コード
	 */
	public void setArrayCdHantenpo(String[] arrayCdHantenpo) {
		this.arrayCdHantenpo = arrayCdHantenpo;
	}

}
