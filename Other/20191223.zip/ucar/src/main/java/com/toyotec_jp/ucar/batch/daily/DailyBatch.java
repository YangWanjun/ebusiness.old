package com.toyotec_jp.ucar.batch.daily;

import java.util.Properties;

import jp.co.intra_mart.foundation.context.Contexts;
import jp.co.intra_mart.foundation.job_scheduler.Job;
import jp.co.intra_mart.foundation.job_scheduler.JobResult;
import jp.co.intra_mart.foundation.job_scheduler.JobSchedulerContext;
import jp.co.intra_mart.foundation.job_scheduler.JobSchedulerManagerFactory;
import jp.co.intra_mart.foundation.job_scheduler.exception.JobExecuteException;
import jp.co.intra_mart.foundation.job_scheduler.exception.JobSchedulerException;
import jp.co.intra_mart.foundation.job_scheduler.JobSchedulerManager;
import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventManager;
import jp.co.intra_mart.framework.base.event.EventManagerException;
import jp.co.intra_mart.framework.base.util.ConfigurationUserInfo;
import jp.co.intra_mart.foundation.job_scheduler.model.job.JobDetail;

import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.ucar.batch.common.BatchUtils;
import com.toyotec_jp.ucar.batch.common.BatchConst.BatchEventKey;

/**
 * <strong>日次バッチ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/10/12 新規作成<br>
 * @since 1.00
 * @category [[日次バッチ]]
 */
public class DailyBatch implements Job {

	/** バッチ名 */
	private static final String BATCH_NAME = "■日次バッチ■";
	/** クラス名 */
	private static final String CLASS_NAME = "DailyBatch";
	/** 統合バッチ名 */
	private static final String INTEGRATE_DATA_BATCH 	= "▼作成処理▼";
	/** 個別バッチ名：データ作成 */
	private static final String CREATE_DATA_BATCH 	= "データ作成処理";
	
	final JobSchedulerContext jobSchedulerContext = Contexts.get(JobSchedulerContext.class);

	@Override
	public JobResult execute() throws JobExecuteException {
		
		//========================================================================================
		// ユーザ情報作成
		//========================================================================================
		ConfigurationUserInfo userInfo = new ConfigurationUserInfo();
		userInfo.setLoginGroupID(jobSchedulerContext.getParameter("group"));
		userInfo.setUserID("SYSTEM");

		boolean dailyBatchSuccess = true;

		BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 開始");

		try {
			// 作成処理
			if (!createBatch(userInfo)) {
				dailyBatchSuccess = false;
			}
		} catch (Exception e) {
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 異常終了");
			throw new RuntimeException(e.getMessage(),e.getCause());
		}

		// バッチ設定変更処理
		updateBatchManager();

		if(dailyBatchSuccess){
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 正常終了");
			return JobResult.success(BATCH_NAME + " 正常終了");
		}else{
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " 異常終了");
			return JobResult.success(BATCH_NAME + " 異常終了");
		}
	}

	/**
	 * 作成処理
	 * @param userInfo
	 * @throws EventManagerException
	 * @throws TecMessageException
	 */
	private boolean createBatch(ConfigurationUserInfo userInfo) throws EventManagerException, TecMessageException {

		BatchUtils.outputInfoLog(CLASS_NAME, INTEGRATE_DATA_BATCH + " 開始");

		boolean batchSuccess = true;

		EventManager eventManager = EventManager.getEventManager();
		try {
			// 整備売上日報情報作成処理
			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0028", CREATE_DATA_BATCH));

			Event event = eventManager.createEvent(BatchEventKey.CREATE_DATA_SEIBIURIAGENIPPOU.getApplicationId(),
													BatchEventKey.CREATE_DATA_SEIBIURIAGENIPPOU.getEventKey(),
													userInfo);
			eventManager.dispatch(event);

			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0029", CREATE_DATA_BATCH));

		} catch (Exception e) {
			BatchUtils.outputInfoLog(CLASS_NAME, TecMessageManager.getMessage("com.toyotec_jp.ucar.workflow.W0030", CREATE_DATA_BATCH));
			batchSuccess = false;
		}

		if (batchSuccess) {
			BatchUtils.outputInfoLog(CLASS_NAME, INTEGRATE_DATA_BATCH + " 正常終了");
		} else {
			BatchUtils.outputInfoLog(CLASS_NAME, INTEGRATE_DATA_BATCH + " 異常終了");
		}

		return batchSuccess;
	}

	/**
	 * バッチ設定変更処理
	 * @param arg
	 */
	private void updateBatchManager() {

		try {
			// ジョブスケジューラマネージャの作成
			JobSchedulerManager batchMng = JobSchedulerManagerFactory.getJobSchedulerManager();
			// バッチ情報取得
			JobDetail batchInfo = batchMng.findJob("MonthlyBatch");	// バッチID
			// バッチ情報更新
			batchMng.updateJob(batchInfo);

		} catch (JobSchedulerException e) {
			// 処理なし
			BatchUtils.outputInfoLog(CLASS_NAME, BATCH_NAME + " バッチ設定変更 異常終了");
		}
	}
}