/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】MassageBean.java
 * 【  説  明  】共通メッセージ情報保持用Bean
 * 【  作  成  】2010/06/25 T.H(SCC)
 */
package com.toyotec_jp.im_common.system.model.object;


/**
 * 共通メッセージ情報保持用Bean
 */
public class MessageBean extends TecBean {

	public static final String ICON_INFORMATION   = "images/standard/information.gif";
	public static final String ICON_WARNING 		= "images/standard/warning.gif";
	public static final String ICON_ERROR 		= "images/standard/error.gif";

	private static final long serialVersionUID = 1L;
	private String returnFlg;
	private String returnApplicationId;
	private String returnServiceId;
	private String message;
	private String icon;


	/**
	 * コンストラクタ
	 */
	public MessageBean() {
		super();
		this.returnFlg					= "false";
		this.returnApplicationId		= "";
		this.returnServiceId			= "";
		this.message					= "";
		this.icon						= ICON_INFORMATION;
	}


	/**
	 * 戻る表示フラグを返却します
	 * @return 戻る表示フラグ
	 */
	public String getReturnFlg() {
		return returnFlg;
	}


	/**
	 * 戻る表示フラグを設定します
	 * @return 戻る表示フラグ
	 */
	public void setReturnFlg(String returnFlg) {
		this.returnFlg = returnFlg;
	}


	/**
	 * 戻り先のアプリケーションIDを返却します
	 * @return 戻り先のアプリケーションID
	 */
	public String getReturnApplicationId() {
		return returnApplicationId;
	}


	/**
	 * 戻り先のアプリケーションIDを設定します
	 * @return 戻り先のアプリケーションID
	 */
	public void setReturnApplicationId(String returnApplicationId) {
		this.returnApplicationId = returnApplicationId;
	}


	/**
	 * 戻り先のサービスIDを返却します
	 * @return 戻り先のサービスID
	 */
	public String getReturnServiceId() {
		return returnServiceId;
	}


	/**
	 * 戻り先のサービスIDを設定します
	 * @return 戻り先のサービスID
	 */
	public void setReturnServiceId(String returnServiceId) {
		this.returnServiceId = returnServiceId;
	}


	/**
	 * メッセージを返却します
	 * @return メッセージ
	 */
	public String getMessage() {
		return message;
	}


	/**
	 * メッセージを設定します
	 * @return メッセージ
	 */
	public void setMessage(String message) {
		this.message = message;
	}


	/**
	 * アイコンパスを返却します
	 * @return アイコンパス
	 */
	public String getIcon() {
		return icon;
	}


	/**
	 * アイコンパスを設定します
	 * @return アイコンパス
	 */
	public void setIcon(String icon) {
		this.icon = icon;
	}



}
