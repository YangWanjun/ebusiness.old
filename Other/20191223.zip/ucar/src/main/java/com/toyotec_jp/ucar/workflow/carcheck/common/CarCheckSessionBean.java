package com.toyotec_jp.ucar.workflow.carcheck.common;

import java.util.List;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckParamBean;

/**
 * <strong>車両チェックセッションBean。</strong>
 * <p>
 * セッションに格納する車両チェックパッケージ共通セッションBean。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/06 新規作成<br>
 * @since 1.00
 * @category [[車両チェック(共通)]]
 */
public class CarCheckSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	/** 店舗コード */
	private String cdTenpo;	// 2013.02.05 C.Ohta 追加　複数販売店化
	/** 商品化センター区分 */
	private String	kbScenter;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

	/** サービスID */
	private String serviceId;
	/** メニューID */
	private String menuId;
	/** ソート順 */
	private String sortOrder;
	/** ソートキー */
	private String sortParam;
	/** ページ番号 */
	private String pageNo;
	/** ページサイズ */
	private String pageSize;

	/** 入庫検査／作業仕分画面検索情報Bean */
	private CarCheckParamBean carCheckParamBean;

	/** 絞り込み検索
	 * <pre>
	 * true:絞り込み検索実行
	 * false:絞り込み検索未実行
	 * </pre>
	 * */
	private boolean isNarrowSearch;

	/** 実行処理内容
	 * <pre>
	 * いずれかの処理の時に文字列を設定
	 * 登録処理：register
	 * 保留処理：reserve
	 * 取消処理：cancel
	 * </pre>
	 *  */
	private String carCheckExecute;

	/** 処理実行件数
	 * <pre>
	 * 登録、保留、取消時の処理実行件数
	 * </pre> */
	private int countExecute;

	/** 表示リスト(排他チェック用) */
	private List<CarCheckDataBean> carCheckDataList;

	/** ダウンロードファイルパス */
	private String downloadFilePath;

	/** 入庫検査／作業仕分画面での選択行番号 */
	private String selectRowNumber;

	/** 入庫検査／作業仕分画面での保留時に先頭で選択されたPKキー */
	private String selectHeadReservePk;

	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
	/** 選択搬入日
	 * <pre>
	 * 入庫チェックの選択処理時に使用する
	 * </pre>
	 *  */
	private String selectDdHannyu;
	/** 選択管理番号
	 * <pre>
	 * 入庫チェックの選択処理時に使用する
	 * </pre>
	 *  */
	private String selectNoKanri;
	/** 選択データリスト
	 * <pre>
	 * 入庫チェックの選択処理で検索したデータを格納する
	 * </pre>
	 *  */
	private List<CarCheckDataBean> selectDataList;
	// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end

	/**
	 * デフォルトコンストラクタ。
	 */
	public CarCheckSessionBean() {
		setDefaultParams();
	}

	/**
	 * デフォルトパラメータ設定。
	 * <pre>
	 * メニューID以外のパラメータ初期化。
	 * </pre>
	 */
	public void setDefaultParams(){
		cdKaisya			= "";
		cdHanbaitn			= "";
		cdTenpo				= "";	// 2013.02.05 C.Ohta 追加　複数販売店化
		sortOrder			= "";
		sortParam			= "";
		pageNo				= "1";
		pageSize			= "100";
		carCheckParamBean	= new CarCheckParamBean();
		isNarrowSearch		= false;
		carCheckExecute		= "";
		countExecute		= 0;
		selectRowNumber     = "0";
	}

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	// 2013.02.05 C.Ohta 変更　複数販売店化　start
	/**
	 * cdTenpoを取得する。
	 * @return cdTenpo
	 */
	public String getCdTenpo() {
		return cdTenpo;
	}

	/**
	 * cdTenpoを設定する。
	 * @param cdTenpo
	 */
	public void setCdTenpo(String cdTenpo) {
		this.cdTenpo = cdTenpo;
	}
	// 2013.02.05 C.Ohta 変更　複数販売店化　end

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start	
	/**
	 * kbScenterを取得する。
	 * @return kbScenter 商品化センター区分
	 */
	public String getKbScenter() {
		return kbScenter;
	}

	/**
	 * kbScenterを設定する。
	 * @param kbScenter 商品化センター区分
	 */
	public void setKbScenter(String kbScenter) {
		this.kbScenter = kbScenter;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end	

	/**
	 * serviceIdを取得する。
	 * @return serviceId サービスID
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * serviceIdを設定する。
	 * @param serviceId サービスID
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * menuIdを取得する。
	 * @return menuId メニューID
	 */
	public String getMenuId() {
		return menuId;
	}

	/**
	 * menuIdを設定する。
	 * @param menuId メニューID
	 */
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	/**
	 * sortOrderを取得する。
	 * @return sortOrder ソート順
	 */
	public String getSortOrder() {
		return sortOrder;
	}

	/**
	 * sortOrderを設定する。
	 * @param sortOrder ソート順
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * sortParamを取得する。
	 * @return sortParam ソートキー
	 */
	public String getSortParam() {
		return sortParam;
	}

	/**
	 * sortParamを設定する。
	 * @param sortParam ソートキー
	 */
	public void setSortParam(String sortParam) {
		this.sortParam = sortParam;
	}

	/**
	 * pageNoを取得する。
	 * @return pageNo ページ番号
	 */
	public String getPageNo() {
		return pageNo;
	}

	/**
	 * pageNoを設定する。
	 * @return pageNo ページ番号
	 */
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * pageSizeを取得する。
	 * @param pageSize ページサイズ
	 */
	public String getPageSize() {
		return pageSize;
	}

	/**
	 * pageSizeを設定する。
	 * @param pageSize ページサイズ
	 */
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * carCheckParamBeanを取得する。
	 * @return carCheckParamBean
	 */
	public CarCheckParamBean getCarCheckParamBean() {
		return carCheckParamBean;
	}

	/**
	 * carCheckParamBeanを設定する。
	 * @param carCheckParamBean
	 */
	public void setCarCheckParamBean(CarCheckParamBean carCheckParamBean) {
		this.carCheckParamBean = carCheckParamBean;
	}

	/**
	 * isNarrowSearchを取得する。
	 * @return isNarrowSearch
	 */
	public boolean isNarrowSearch() {
		return isNarrowSearch;
	}

	/**
	 * isNarrowSearchを設定する。
	 * @param isNarrowSearch
	 */
	public void setNarrowSearch(boolean isNarrowSearch) {
		this.isNarrowSearch = isNarrowSearch;
	}

	/**
	 * carCheckExecuteを取得する。
	 * @return carCheckExecute
	 */
	public String getCarCheckExecute() {
		return carCheckExecute;
	}

	/**
	 * carCheckExecuteを設定する。
	 * @param carCheckExecute
	 */
	public void setCarCheckExecute(String carCheckExecute) {
		this.carCheckExecute = carCheckExecute;
	}

	/**
	 * countExecuteを取得する。
	 * @return countExecute
	 */
	public int getCountExecute() {
		return countExecute;
	}

	/**
	 * countExecuteを設定する。
	 * @param countExecute
	 */
	public void setCountExecute(int countExecute) {
		this.countExecute = countExecute;
	}

	/**
	 * carCheckDataListを取得する。
	 * @return carCheckDataList
	 */
	public List<CarCheckDataBean> getCarCheckDataList() {
		return carCheckDataList;
	}

	/**
	 * carCheckDataListを設定する。
	 * @param carCheckDataList
	 */
	public void setCarCheckDataList(List<CarCheckDataBean> carCheckDataList) {
		this.carCheckDataList = carCheckDataList;
	}

	/**
	 * downloadFilePathを取得する。
	 * @return downloadFilePath
	 */
	public String getDownloadFilePath() {
		return downloadFilePath;
	}

	/**
	 * downloadFilePathを設定する。
	 * @param downloadFilePath
	 */
	public void setDownloadFilePath(String downloadFilePath) {
		this.downloadFilePath = downloadFilePath;
	}

	/**
	 * selectRowNumberを取得する。
	 * @return selectRowNumber
	 */
	public String getSelectRowNumber() {
		return selectRowNumber;
	}

	/**
	 * selectRowNumberを設定する。
	 * @param selectRowNumber
	 */
	public void setSelectRowNumber(String selectRowNumber) {
		this.selectRowNumber = selectRowNumber;
	}

	/**
	 * selectHeadReservePkを取得する。
	 * @return selectHeadReservePk
	 */
	public String getSelectHeadReservePk() {
		return selectHeadReservePk;
	}

	/**
	 * selectHeadReservePkを設定する。
	 * @param selectHeadReservePk
	 */
	public void setSelectHeadReservePk(String selectHeadReservePk) {
		this.selectHeadReservePk = selectHeadReservePk;
	}

	/**
	 * selectDdHannyuを取得する。
	 * @return selectDdHannyu
	 */
	public String getSelectDdHannyu() {
		return selectDdHannyu;
	}

	/**
	 * selectDdHannyuを設定する。
	 * @param selectDdHannyu
	 */
	public void setSelectDdHannyu(String selectDdHannyu) {
		this.selectDdHannyu = selectDdHannyu;
	}

	/**
	 * selectNoKanriを取得する。
	 * @return selectNoKanri
	 */
	public String getSelectNoKanri() {
		return selectNoKanri;
	}

	/**
	 * selectNoKanriを設定する。
	 * @param selectNoKanri
	 */
	public void setSelectNoKanri(String selectNoKanri) {
		this.selectNoKanri = selectNoKanri;
	}

	/**
	 * selectDataListを取得する。
	 * @return selectDataList
	 */
	public List<CarCheckDataBean> getSelectDataList() {
		return selectDataList;
	}

	/**
	 * selectDataListを設定する。
	 * @param selectDataList
	 */
	public void setSelectDataList(List<CarCheckDataBean> selectDataList) {
		this.selectDataList = selectDataList;
	}

}
