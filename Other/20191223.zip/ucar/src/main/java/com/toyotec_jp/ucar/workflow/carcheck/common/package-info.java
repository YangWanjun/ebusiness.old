/**
 * 車両チェック関連共通パッケージ
 * @version 1.00 2011/10/04 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.ucar.workflow.carcheck.common;
