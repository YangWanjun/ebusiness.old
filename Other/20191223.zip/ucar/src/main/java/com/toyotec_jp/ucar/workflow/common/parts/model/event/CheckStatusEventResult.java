package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>ステータスDB存在チェックイベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/04 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CheckStatusEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/** ステータスDB日付存在
	 * <pre>
	 * ・true：ステータスDBに日付が存在する
	 * ・false：ステータスDBに日付が存在しない
	 * </pre>
	 *  */
	private boolean existDtStatus;
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	/**
	 * existDtStatusを取得する。
	 * @return existDtStatus
	 */
	public boolean isExistDtStatus() {
		return existDtStatus;
	}

	/**
	 * existDtStatusを設定する。
	 * @param existDtStatus
	 */
	public void setExistDtStatus(boolean existDtStatus) {
		this.existDtStatus = existDtStatus;
	}

}
