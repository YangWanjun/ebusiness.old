package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.util.Date;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaTransactionDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gBean;

/**
 * <strong>ステータスDB日付比較チェックイベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/25 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CheckStatusDateEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		CheckStatusDateEvent targetEvent = (CheckStatusDateEvent)event;

		UcaaTransactionDAOIF dao
			= getDAO(UcarDAOKey.UCAA_TRANSACTION_DAO, targetEvent, UcaaTransactionDAOIF.class);

		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
//		Ucca007gBean t220012gBean = dao.selectT220012g(targetEvent.getT220001gPkBean().getCdKaisya(),
//													targetEvent.getT220001gPkBean().getCdHanbaitn(),
//													targetEvent.getT220001gPkBean().getDdHannyu(),
//													targetEvent.getT220001gPkBean().getNoKanri(),
//													targetEvent.getCheckStatusNo());
		Uccb007gBean t220012gBean = dao.selectT220012g(targetEvent.getT220107gPkBean().getCdKaisya(),
													targetEvent.getT220107gPkBean().getCdHanbaitn(),
													targetEvent.getT220107gPkBean().getDdHannyu(),
													targetEvent.getT220107gPkBean().getNoKanri(),
													targetEvent.getT220107gPkBean().getCdZaitenpo(),
													targetEvent.getT220107gPkBean().getKbScenter(),
													targetEvent.getCheckStatusNo());
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		Date dtStatus = null;

		if (t220012gBean != null) {
			// ステータスDBにデータがある場合
			switch (targetEvent.getCheckStatusNo()) {
				case 1:
					dtStatus = t220012gBean.getDtStatus01();
					break;
				case 2:
					dtStatus = t220012gBean.getDtStatus02();
					break;
				case 3:
					dtStatus = t220012gBean.getDtStatus03();
					break;
				case 4:
					dtStatus = t220012gBean.getDtStatus04();
					break;
				case 5:
					dtStatus = t220012gBean.getDtStatus05();
					break;
				case 6:
					dtStatus = t220012gBean.getDtStatus06();
					break;
				case 7:
					dtStatus = t220012gBean.getDtStatus07();
					break;
				case 8:
					dtStatus = t220012gBean.getDtStatus08();
					break;
				case 9:
					dtStatus = t220012gBean.getDtStatus09();
					break;
				case 10:
					dtStatus = t220012gBean.getDtStatus10();
					break;
				case 11:
					dtStatus = t220012gBean.getDtStatus11();
					break;
				case 12:
					dtStatus = t220012gBean.getDtStatus12();
					break;
				case 13:
					dtStatus = t220012gBean.getDtStatus13();
					break;
				case 14:
					dtStatus = t220012gBean.getDtStatus14();
					break;
				case 15:
					dtStatus = t220012gBean.getDtStatus15();
					break;
				case 16:
					dtStatus = t220012gBean.getDtStatus16();
					break;
				case 17:
					dtStatus = t220012gBean.getDtStatus17();
					break;
				case 18:
					dtStatus = t220012gBean.getDtStatus18();
					break;
				case 19:
					dtStatus = t220012gBean.getDtStatus19();
					break;
				case 20:
					dtStatus = t220012gBean.getDtStatus20();
					break;
				case 21:
					dtStatus = t220012gBean.getDtStatus21();
					break;
				case 22:
					dtStatus = t220012gBean.getDtStatus22();
					break;
				case 23:
					dtStatus = t220012gBean.getDtStatus23();
					break;
				case 24:
					dtStatus = t220012gBean.getDtStatus24();
					break;
				default:
					break;
			}
		}

		String strDtStatus = "";

		if (targetEvent.getDtStatus().length() == 8) {
			// yyyyMMdd→yyyy/MM/ddに変換
			strDtStatus = UcarUtils.getStringDateFormatShort(targetEvent.getDtStatus());
		} else {
			// yyyy/MM/ddの場合
			strDtStatus = targetEvent.getDtStatus();
		}

		if (dtStatus == null) {
			// データが無い場合→引数に設定された日付を返却
			strDtStatus = UcarUtils.getCurrentDateFormatLongSpace(strDtStatus);
		} else {
			String strSelectDtStatusShort = DateUtils.dateToString(dtStatus, DateUtils.FORMAT_SHORT);

			if (strDtStatus.equals(strSelectDtStatusShort)) {
				// 設定日と取得した年月日が同じ場合→DBから取得したデータを返却
				strDtStatus = DateUtils.dateToString(dtStatus, DateUtils.FORMAT_LONG_SPACE);
			} else {
				// 設定日と取得した年月日が違う場合→引数に設定された日付を返却
				strDtStatus = UcarUtils.getCurrentDateFormatLongSpace(strDtStatus);
			}
		}

		CheckStatusDateEventResult getResult = new CheckStatusDateEventResult();
		getResult.setDtStatus(strDtStatus);

		return getResult;
	}
}
