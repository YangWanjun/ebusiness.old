package com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.object.CleanPlanUnPlanDataBean;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;

/**
 * <strong>まるクリ作業計画入力DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/17 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public class CleanPlanDAOImpl extends UcarSharedDBDAO implements CleanPlanDAOIF {

	/** コード区分マスタ まるクリ色コード 画面出力値取得処理 SQL */
	private static final String SELECT_T220204M_SQL
		= "SELECT "
		+ "    MJ_KUBUN "
		+ "  , MJ_INFO1 CD_COLOR "
		+ "FROM "
		+ "  T220204M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_JIGYOSYO = ? "
		+ "  AND KB_ID       = ? "
		+ "ORDER BY "
		+ "  NO_SORT ";

	/** 未計画情報 画面出力値取得処理 SQL */
	private static final String SELECT_UNPLAN_SQL
		= "SELECT "
		+ "    UKETUKE.CD_KAISYA "
		+ "  , UKETUKE.CD_JIGYOSYO "
		+ "  , UKETUKE.MJ_SYAMEI "
		+ "  , UKETUKE.NO_SYADAI "
		+ "  , UKETUKE.CD_MARURANK "
		+ "  , UKETUKE.KB_AMS "
		+ "  , CODEKUBUN.MJ_INFO1 CD_COLOR "
		+ "FROM "
		+ "  T220201G UKETUKE "
		+ "  LEFT JOIN T220204M CODEKUBUN "
		+ "    ON UKETUKE.CD_KAISYA    = CODEKUBUN.CD_KAISYA "
		+ "    AND UKETUKE.CD_JIGYOSYO = CODEKUBUN.CD_JIGYOSYO "
		+ "    AND UKETUKE.CD_MARURANK = CODEKUBUN.CD_KUBUN "
		+ "    AND CODEKUBUN.KB_ID     = ? "
		+ "WHERE "
		+ "      UKETUKE.CD_KAISYA     = ? "
		+ "  AND UKETUKE.CD_JIGYOSYO   = ? "
		+ "  AND UKETUKE.KB_MPLAN      = ? ";

	/** 未計画情報 画面出力値取得処理 ORDER部分 */
	private static final String SELECT_UNPLAN_ORDER_SQL
		= "ORDER BY "
		+ "    UKETUKE.CD_KAISYA "
		+ "  , UKETUKE.CD_JIGYOSYO "
		+ "  , UKETUKE.CD_HANBAITN "
		+ "  , UKETUKE.DD_HANNYU "
		+ "  , UKETUKE.NO_KANRI ";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.data.CleanPlanDAOIF#selectColorCodeList(java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<Ucba004mBean> selectColorCodeList(String cdKaisya,
			String cdJigyosyo) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220204M_SQL);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);						// 会社コード
		paramBean.setString(cdJigyosyo);					// 事業所コード
		paramBean.setString(AllCleanConst.KB_ID_MARURANK);	// 区分ID

		paramBean.setOrderSql(SELECT_UNPLAN_ORDER_SQL);

		ResultArrayList<Ucba004mBean> resultList = executeSimpleSelectQuery(paramBean, Ucba004mBean.class);

		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.data.CleanPlanDAOIF#selectUnPlanList(java.lang.String, java.lang.String)
	 */
	@Override
	public ResultArrayList<CleanPlanUnPlanDataBean> selectUnPlanList(
			String cdKaisya, String cdJigyosyo) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_UNPLAN_SQL);

		// パラメータセット<条件>
		paramBean.setString(AllCleanConst.KB_ID_MARURANK);	// 区分ID
		paramBean.setString(cdKaisya);						// 会社コード
		paramBean.setString(cdJigyosyo);					// 事業所コード
		paramBean.setString(AllCleanConst.KB_MPLAN_UNPLAN);	// まるクリ計画区分

		paramBean.setOrderSql(SELECT_UNPLAN_ORDER_SQL);

		ResultArrayList<CleanPlanUnPlanDataBean> resultList = executeSimpleSelectQuery(paramBean, CleanPlanUnPlanDataBean.class);

		return resultList;
	}

}
