package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.KyoutuTenpoDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa006mBean;

/**
 * <strong>共通店舗DB操作DAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class KyoutuTenpoDBDAOImpl extends UcarSharedDBDAO implements KyoutuTenpoDBDAOIF {

	private static final String SELECT_KYOUTU_TENPO_DB_LIST_SQL
		= "SELECT "
//		+ " CD_TENPO " 2014.4.28 H.yamashita 店舗CD2桁対応
		
		+ "TRIM(CD_TENPO) AS  CD_TENPO "
		+ ",TRIM('　' FROM KJ_TENPOMEI) AS KJ_TENPOMEI "
		+ ",TRIM('　' FROM KJ_TENTANMS) AS KJ_TENTANMS "
/*--2019.3.20 add from
		+ "FROM "
*/
		+ ",KB_DUOTENPO AS KB_DUOTENPO "
//--2019.3.20 add to		
		;

	private static final String SELECT_KYOUTU_TENPO_DB_WHERE_SQL
		= " WHERE "
		+ "  CD_KAISYA = ? ";
/*--2019.3.20 add from
	private static final String SELECT_KYOUTU_TENPO_DB_WHERE_NOT_SQL
		= " WHERE "
			+ "  T1.CD_KAISYA IN('01','02','03','05', '06') "

			+ " AND EXISTS ("
				+ " SELECT 1 FROM TBV0201M T2 "
				+ "  WHERE T1.CD_TENPO = T2.CD_TENPO "
				+ "  GROUP BY T2.CD_TENPO "
				+ " HAVING COUNT(1) = 1"
				+ ")";
	
//--2019.3.20 add to */
	private static final String SELECT_KYOUTU_TENPO_DB_ORDER_SQL
		= "ORDER BY "
/*--2019.3.20 from
		+ " CD_KAISYA "
		+ ",CD_TENPO ";
*/
		+ " CD_TENPO";
//--2019.3.20 to			
/*--2019.3.20 from
	private static final String SELECT_T220006M_SQL
		= "SELECT "
//		+ "    CD_TENPO "  2014.4.28 H.yamashita 店舗CD2桁対応
		+ "TRIM(CD_TENPO) AS  CD_TENPO "
		+ "  , TRIM(KJ_TENPOMEI) AS KJ_TENPOMEI "
		+ "  , TRIM(KJ_TENTANMS) AS KJ_TENTANMS "
		+ "  , KB_TENPO "	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		+ "FROM "
		+ "  T220006M "
		+ "WHERE "
		+ "      CD_KAISYA   = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND KB_DISP     = ? ";
*/
	private static final String SELECT_T220006M_SQL
		= "SELECT "
//		+ "    CD_TENPO "  2014.4.28 H.yamashita 店舗CD2桁対応
			+ "TRIM(CD_TENPO) AS  CD_TENPO "
			+ "  , TRIM(KJ_TENPOMEI) AS KJ_TENPOMEI "
			+ "  , TRIM(KJ_TENTANMS) AS KJ_TENTANMS "
			+ "  , KB_TENPO "	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
//--2019.3.28 from
			+ "  , CD_HANBAITN AS CD_HANBAITN "
//--2019.3.28 to			
			+ "FROM "
			+ "  T220006M ";
	
	private static final String SELECT_T220006M_SQL_WHERE
			= " WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND KB_DISP     = ? ";

	private static final String SELECT_T220006M_SQL_NOT_WHERE
			= " WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN IN('"
									+ UcarConst.TOYOTA
									+ "','"
									+ UcarConst.TOYOPET
									+ "','"
									+ UcarConst.COROLLA
									+ "','"
									+ UcarConst.NETZ
									+ "','"
									+ UcarConst.TMT
									+ "','"
									+ UcarConst.LEXUS								
									+ "') "
			+ "  AND KB_DISP     = ? ";
//--2019.3.20 to	
	private static final String SELECT_T220006M_ORDER_SQL
		= "ORDER BY "
		+ "  NU_HYZYUN ";

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.workflow.common.parts.model.data.LeaseCompanyMasterDAOIF#getLeaseCompanyMasterList()
	 */
	@Override
	public ResultArrayList<KyoutuTenpoDBBean> getKyoutuTenpoDBList(String cdKaisya, String cdHanbaitn) throws TecDAOException {

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		StringBuilder selectSql = new StringBuilder(SELECT_KYOUTU_TENPO_DB_LIST_SQL);
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
/*--2019.3.20 from
		selectSql.append(AddonTableManager.getKyoutuTenpo(cdHanbaitn));
		selectSql.append(SELECT_KYOUTU_TENPO_DB_WHERE_SQL);
		paramBean.setString(cdKaisya);
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end
*/
		if(UcarConst.WCOROLLA.equals(cdHanbaitn)){
			selectSql.append(",'"+UcarConst.WCOROLLA + "' AS CD_HANBAITN ");
			// 2019.04.29 T.O start
			selectSql.append(" FROM TBV0201M ");
			/* 2019.04.26 T.O 
			selectSql.append(AddonTableManager.getKyoutuTenpo(cdHanbaitn));
			*/			
			selectSql.append(SELECT_KYOUTU_TENPO_DB_WHERE_SQL);
			//paramBean.setString(cdKaisya);
			paramBean.setString("04");
			// 2019.04.29 T.O end
			
		}else{
			selectSql.append(",DECODE(CD_KAISYA,'01','"+UcarConst.TOYOTA);
			selectSql.append("','02','" + UcarConst.TOYOPET);
			selectSql.append("','03','" + UcarConst.COROLLA);
			selectSql.append("','05','" + UcarConst.NETZ);
			selectSql.append("','06','" + UcarConst.LEXUS);
			selectSql.append("') AS CD_HANBAITN ");
			selectSql.append(" FROM ");
			selectSql.append(AddonTableManager.getKyoutuTenpo(cdHanbaitn));			
//--ﾚｸｻｽ			selectSql.append(SELECT_KYOUTU_TENPO_DB_WHERE_NOT_SQL);
			
		}
		
//--2019.3.20 to		
		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_KYOUTU_TENPO_DB_ORDER_SQL);

		ResultArrayList<KyoutuTenpoDBBean> resList
			= executeSimpleSelectQuery(paramBean, KyoutuTenpoDBBean.class);

		return resList;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.KyoutuTenpoDBDAOIF#selectT220006m()
	 */
	@Override
	public ResultArrayList<Ucaa006mBean> selectT220006m(String cdKaisya, String cdHanbaitn)
			throws TecDAOException {

		// パラメータセット<条件>
/*--2019.3.20 from		
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220006M_SQL);

		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
		paramBean.setString(cdKaisya);				// 会社コード
		paramBean.setString(cdHanbaitn);			// 販売店コード
		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end
		paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分
		
		paramBean.setOrderSql(SELECT_T220006M_ORDER_SQL);

*/
		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);
		StringBuilder selectSql = new StringBuilder(SELECT_T220006M_SQL);
		
		if(UcarConst.WCOROLLA.equals(cdHanbaitn)){
			selectSql.append(SELECT_T220006M_SQL_WHERE);
			
			paramBean.setString(cdKaisya);				// 会社コード
			paramBean.setString(cdHanbaitn);			// 販売店コード
			paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分
			
		}else{
			selectSql.append(SELECT_T220006M_SQL_NOT_WHERE);
			
			paramBean.setString(cdKaisya);				// 会社コード
			paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分
			
		}
		
		paramBean.setSql(selectSql.toString());
		paramBean.setOrderSql(SELECT_T220006M_ORDER_SQL);
//--2019.3.20 to		

		ResultArrayList<Ucaa006mBean> t220006mList = executeSimpleSelectQuery(paramBean, Ucaa006mBean.class);

		return t220006mList;
	}

	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.common.parts.model.data.KyoutuTenpoDBDAOIF#getKyoutuTenpoDB(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public KyoutuTenpoDBBean getKyoutuTenpoDB(String cdKaisya,
			String cdHanbaitn, String cdTenpo) throws TecDAOException {

		String executeSql
		= "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_TENPO "
		+ "  , KJ_TENPOMEI "
		+ "  , KJ_TENTANMS "
		+ "FROM "
		+ AddonTableManager.getKyoutuTenpo(cdHanbaitn) + " "
		+ "WHERE "
		+ "  CD_KAISYA = ? "
		+ "  AND CD_TENPO = ? "
		+ "UNION "
		+ "SELECT "
		+ "    CD_KAISYA "
		+ "  , CD_TENPO "
		+ "  , KJ_TENPOMEI "
		+ "  , KJ_TENTANMS "
		+ "FROM "
		+ "  T220006M "
		+ "WHERE "
		+ "  CD_KAISYA = ? "
		+ "  AND CD_HANBAITN = ? "
		+ "  AND CD_TENPO = ? "
		+ "  AND KB_DISP = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<条件>
		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(cdTenpo);	// 店舗コード

		paramBean.setString(cdKaisya);	// 会社コード
		paramBean.setString(cdHanbaitn);// 販売店コード
		paramBean.setString(cdTenpo);	// 店舗コード
		paramBean.setString(UcarConst.KB_DISP_ON);	// 表示区分

		ResultArrayList<KyoutuTenpoDBBean> kyoutuTenpoList = executeSimpleSelectQuery(paramBean, KyoutuTenpoDBBean.class);
		KyoutuTenpoDBBean kyoutuTenpoDBBean = new KyoutuTenpoDBBean();

		if (kyoutuTenpoList.size() > 0) {
			kyoutuTenpoDBBean = kyoutuTenpoList.get(0);
		}
		return kyoutuTenpoDBBean;
	}
	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため end

}
