/*
 * 【システム名】
 * 【ファイル名】DMWorkbook.java
 * 【  説  明  】ワークブッククラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】2010/09/01 H.O(SCC) version 1.02
 *                 POI 3.5.0対応
 */
package com.toyotec_jp.im_common.system.docmng.mng.excel;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapKey;
import com.toyotec_jp.im_common.system.docmng.data.DMSheetMap;
import com.toyotec_jp.im_common.system.exception.TecExcelMngException;
import com.toyotec_jp.im_common.system.log.TecLogger;

/**
 * <strong>DMWorkbook</strong>
 * <p>
 * ワークブッククラス<br>
 * POI 3.5.0 版
 * </p>
 * @author H.O(SCC)
 * @version 1.02 2010/09/01 <br>
 */
public class DMWorkbook {

	// TODO
	// POI 3.0.2 版だったが
	// 3.0.2では入力規則が消えるという問題が発生したため
	// 急遽3.2.0に変更になった
	// そのため対応し切れていない可能性あり
	// 次期バージョン開発時にはその対応も検討すること

	private static final String className = DMWorkbook.class.getName();

	/** エラーメッセージ:ワークブックオブジェクト取得 */
	private static final String MSG_ERR_NEW_BOOK = "ワークブックオブジェクト取得に失敗しました";

	/** エラーメッセージ:対象シートなし */
	private static final String MSG_ERR_NOT_EXIST_SHEET = "対象となるシートが存在しません";

	/** エラーメッセージ:シート名不正(作成時) */
	private static final String MSG_ERR_CREATE_BAD_SHEET_NAME = "シート名が不正であるため、シートを作成できません";
	/** エラーメッセージ:同名シートあり(作成時) */
	private static final String MSG_ERR_CREATE_SAME_SHEET_NAME = "同名のシートが既に存在するため、シートを作成できません";

	/** エラーメッセージ:シートインデックス不正(シート順変更) */
	private static final String MSG_ERR_CHANGE_SHEET_IDX = "シートインデックス範囲外への移動はできません";

	/** エラーメッセージ:ブック出力失敗 */
	private static final String MSG_ERR_WRITE_BOOK = "ブックデータ出力処理に失敗しました";

	protected Workbook workbook;

	private String filePath;

	private RichTextString textForCheckBox;


//	/**
//	 * コンストラクタ
//	 */
//	public DMWorkbook(String filePath) {
//		workbook = new HSSFWorkbook();
//		this.filePath = filePath;
//	}

//	/**
//	 * コンストラクタ
//	 * @param poiFS POIファイルシステム
//	 * @param filePath ファイルパス
//	 * @throws TecExcelMngException
//	 */
//	public DMWorkbook(POIFSFileSystem poiFS, String filePath) throws TecExcelMngException {
//		try{
//			workbook = WorkbookFactory.create(poiFS);
//			this.filePath = filePath;
//		} catch(Exception e){
//			TecLogger.error(className + ":exception");
//			TecLogger.debug("[" + e.getMessage() + "]");
//			throw new TecExcelMngException(MSG_ERR_NEW_BOOK, e);
//		}
//	}

//	/**
//	 * コンストラクタ
//	 * @param poiFS POIファイルシステム
//	 * @param preserveNodes true:マクロなどを保護する
//	 * @param filePath ファイルパス
//	 * @throws TecExcelMngException
//	 */
//	public DMWorkbook(POIFSFileSystem poiFS, boolean preserveNodes, String filePath) throws TecExcelMngException {
//		try{
//			workbook = WorkbookFactory.create(poiFS, preserveNodes);
//			this.filePath = filePath;
//		} catch(Exception e){
//			TecLogger.error(className + ":exception");
//			TecLogger.debug("[" + e.getMessage() + "]");
//			throw new TecExcelMngException(MSG_ERR_NEW_BOOK, e);
//		}
//	}

	/**
	 * コンストラクタ
	 * @param inStream 入力ストリーム
	 * @param filePath ファイルパス
	 * @throws TecExcelMngException
	 */
	public DMWorkbook(InputStream inStream, String filePath) throws TecExcelMngException {
		try{
			workbook = WorkbookFactory.create(inStream);
			this.filePath = filePath;
		} catch(Exception e){
			TecLogger.error(className + ":exception");
			TecLogger.debug("[" + e.getMessage() + "]");
			throw new TecExcelMngException(MSG_ERR_NEW_BOOK, e);
		}
	}

//	/**
//	 * コンストラクタ
//	 * @param inStream 入力ストリーム
//	 * @param preserveNodes true:マクロなどを保護する
//	 * @param filePath ファイルパス
//	 * @throws TecExcelMngException
//	 */
//	public DMWorkbook(InputStream inStream, boolean preserveNodes, String filePath) throws TecExcelMngException {
//		try{
//			workbook = WorkbookFactory.create(inStream, preserveNodes);
//			this.filePath = filePath;
//		} catch(Exception e){
//			TecLogger.error(className + ":exception");
//			TecLogger.debug("[" + e.getMessage() + "]");
//			throw new TecExcelMngException(MSG_ERR_NEW_BOOK, e);
//		}
//	}

	/**
	 * 同一ブック内におけるシート複製<br>
	 * シートを複製し最終シートインデックスの後ろに追加
	 * @param sheetIdx 複製元シートインデックス
	 * @param mapSheet シート情報格納用マップ
	 * @return 複製されたシート
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	public DMSheet cloneSheet(int sheetIdx, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet) throws TecExcelMngException {
		String funcName = className + ".cloneSheet";
		if(!existSheetIndex(sheetIdx)){
			TecLogger.error(funcName + ":no_sheet_error");
			TecLogger.debug("[" + sheetIdx + "]");
			throw new TecExcelMngException(MSG_ERR_NOT_EXIST_SHEET);
		}
		Sheet hssfSheet = workbook.cloneSheet(sheetIdx);
		return new DMSheet(hssfSheet, mapSheet);
	}

	/**
	 * シート作成
	 * @param mapSheet シート情報格納用マップ
	 * @return 作成したシート
	 * @since 1.00
	 */
	public DMSheet createSheet(DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet) {
		Sheet hssfSheet = workbook.createSheet();
		return new DMSheet(hssfSheet, mapSheet);
	}

	/**
	 * シート作成
	 * @param sheetName シート名
	 * @param mapSheet シート情報格納用マップ
	 * @return 作成したシート
	 * @throws TecExcelMngException
	 * @since 1.00
	 */
	public DMSheet createSheet(String sheetName, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet) throws TecExcelMngException {
		String funcName = className + ".createSheet";
		if(isWrongSheetName(sheetName)){
			TecLogger.error(funcName + ":sheetName_error");
			TecLogger.debug("[" + sheetName + "]");
			throw new TecExcelMngException(MSG_ERR_CREATE_BAD_SHEET_NAME);
		}
		if(workbook.getSheetIndex(sheetName) >= 0){
			TecLogger.error(funcName + ":sameSheetName_error");
			TecLogger.debug("[" + sheetName + "]");
			throw new TecExcelMngException(MSG_ERR_CREATE_SAME_SHEET_NAME);
		}
		Sheet hssfSheet = workbook.createSheet(sheetName);
		return new DMSheet(hssfSheet, mapSheet);
	}

	/**
	 * シート取得
	 * @param sheetName シート名
	 * @param mapSheet シート情報格納用マップ
	 * @return シート
	 * @since 1.00
	 */
	public DMSheet getSheet(String sheetName, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet){
		String funcName = className + ".getSheet";
		DMSheet dmSheet = null;
		Sheet hssfSheet = workbook.getSheet(sheetName);
		if(hssfSheet != null){
			dmSheet = new DMSheet(hssfSheet, mapSheet);
		} else {
			TecLogger.info(funcName + ":no_sheet");
			TecLogger.debug("[" + sheetName + "]");
		}
		return dmSheet;
	}

	/**
	 * シート取得
	 * @param sheetIdx シートインデックス
	 * @param mapSheet シート情報格納用マップ
	 * @return シート
	 * @since 1.00
	 */
	public DMSheet getSheetAt(int sheetIdx, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet){
		String funcName = className + ".getSheetAt";
		DMSheet dmSheet = null;
		if(existSheetIndex(sheetIdx)){
			Sheet hssfSheet = workbook.getSheetAt(sheetIdx);
			dmSheet = new DMSheet(hssfSheet, mapSheet);
		} else {
			TecLogger.info(funcName + ":no_sheet");
			TecLogger.debug("[" + sheetIdx + "]");
		}
		return dmSheet;
	}

	/**
	 * ファイルパス取得
	 * @return ファイルパス
	 * @since 1.00
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * オートシェイプ「レ」(チェック)用定義情報取得
	 * @return オートシェイプ「レ」(チェック)用定義情報
	 * @since 1.00
	 */
	protected RichTextString getTextForCheckBox(){
		if(textForCheckBox == null){
			textForCheckBox = workbook.getCreationHelper().createRichTextString("レ");
			Font fontForCheckBox = workbook.createFont();
			fontForCheckBox.setBoldweight(Font.BOLDWEIGHT_BOLD); // 太字
			fontForCheckBox.setFontHeightInPoints((short)8); // 8ポイント
			textForCheckBox.applyFont(fontForCheckBox);
		}
		return textForCheckBox;
	}

	/**
	 * シート選択状態初期化
	 * @since 1.00
	 */
	protected void initSheetSelect(){
		if(workbook != null && workbook.getNumberOfSheets() > 0){
			for(int i = 0; i < workbook.getNumberOfSheets(); i++){
				workbook.getSheetAt(i).setSelected(false);
			}
			Sheet firstSheet = workbook.getSheetAt(0);
			if(firstSheet != null){
				firstSheet.setSelected(true);
				//firstSheet.getRow(0).getCell((short)0).setAsActiveCell();
			}
		}
	}

	/**
	 * シートインデックス存在チェック
	 * @param sheetIdx チェック対象シートインデックス
	 * @return true:存在する
	 * @since 1.00
	 */
	private boolean existSheetIndex(int sheetIdx){
		boolean ret = false;
		if(workbook != null){
			if(sheetIdx >= 0 && sheetIdx < workbook.getNumberOfSheets()){
				ret = true;
			}
		}
		return ret;
	}

	/**
	 * シート名チェック
	 * @param sheetName シート名
	 * @return true:シート名として不正
	 * @since 1.00
	 */
	private boolean isWrongSheetName(String sheetName){
		boolean ret = false;
		if(
				(sheetName == null) || (sheetName.length() == 0) || (sheetName.length() > 31) ||
				(sheetName.indexOf("/") > -1) || (sheetName.indexOf("\\") > -1) ||
				(sheetName.indexOf("?") > -1) || (sheetName.indexOf("*") > -1) ||
				(sheetName.indexOf("]") > -1) || (sheetName.indexOf("[") > -1)){
			ret = true;
		}
		return ret;
	}

	/* (non-Javadoc)
	 * @see org.apache.poi.hssf.usermodel.HSSFWorkbook#getFontAt(short)
	 */
	public Font getFontAt(short arg0) {
		return workbook.getFontAt(arg0);
	}

	/* (non-Javadoc)
	 * @see org.apache.poi.hssf.usermodel.HSSFWorkbook#getNumberOfSheets()
	 */
	public int getNumberOfSheets() {
		return workbook.getNumberOfSheets();
	}

	/* (non-Javadoc)
	 * @see org.apache.poi.hssf.usermodel.HSSFWorkbook#getSheetIndex(java.lang.String)
	 */
	public int getSheetIndex(String arg0) {
		return workbook.getSheetIndex(arg0);
	}

	/* (non-Javadoc)
	 * @see org.apache.poi.hssf.usermodel.HSSFWorkbook#getSheetName(int)
	 */
	public String getSheetName(int arg0) {
		return workbook.getSheetName(arg0);
	}

	/* (non-Javadoc)
	 * @see org.apache.poi.hssf.usermodel.HSSFWorkbook#setSheetOrder(java.lang.String, int)
	 */
	public void setSheetOrder(String arg0, int arg1) throws TecExcelMngException {
		String funcName = className + ".setSheetOrder";
		if(!existSheetIndex(arg1)){
			TecLogger.error(funcName + ":sheetIdx_error");
			TecLogger.debug("[" + arg1 + "]");
			throw new TecExcelMngException(MSG_ERR_CHANGE_SHEET_IDX);
		}
		if(workbook.getSheetIndex(arg0) < 0){
			TecLogger.error(funcName + ":sheetName_error");
			TecLogger.debug("[" + arg0 + "]");
			throw new TecExcelMngException(MSG_ERR_NOT_EXIST_SHEET);
		}
		workbook.setSheetOrder(arg0, arg1);
	}

	/* (non-Javadoc)
	 * @see org.apache.poi.hssf.usermodel.HSSFWorkbook#write(java.io.OutputStream)
	 */
	public void write(OutputStream arg0) throws TecExcelMngException {
		String funcName = className + ".write";
		try{
			workbook.write(arg0);
		} catch(IOException e){
			TecLogger.error(funcName + ":io_error");
			TecLogger.debug("[" + e.getMessage() + "]");
			throw new TecExcelMngException(MSG_ERR_WRITE_BOOK, e);
		}
	}

	public ClientAnchor createClientAnchor(
			int startXPos, int startYPos, int endXPos, int endYPos,
			int startColIdx, int startRowIdx, int endColIdx, int endRowIdx) {
		return createClientAnchor(
				startXPos, startYPos, endXPos, endYPos,
				startColIdx, startRowIdx, endColIdx, endRowIdx, ClientAnchor.MOVE_AND_RESIZE);
	}

	public ClientAnchor createClientAnchor(
			int startXPos, int startYPos, int endXPos, int endYPos,
			int startColIdx, int startRowIdx, int endColIdx, int endRowIdx, int anchorType) {
		ClientAnchor anchor = workbook.getCreationHelper().createClientAnchor();
		anchor.setDx1(startXPos);
		anchor.setDy1(startYPos);
		anchor.setDx2(endXPos);
		anchor.setDy2(endYPos);
		anchor.setCol1(startColIdx);
		anchor.setRow1(startRowIdx);
		anchor.setCol2(endColIdx);
		anchor.setRow2(endRowIdx);
		anchor.setAnchorType(anchorType);
		return anchor;
	}

}
