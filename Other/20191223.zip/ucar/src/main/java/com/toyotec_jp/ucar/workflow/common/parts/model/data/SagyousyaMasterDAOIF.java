package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba008mBean;

/**
 * <strong>作業者マスタDB操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/07/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface SagyousyaMasterDAOIF {

	/**
	 * 作業者マスタDBリスト取得。
	 * @return 作業者マスタDBリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucba008mBean> getSagyousyaMasterList(String cdKaisya,
																String cdJigyosyo,
																String cdSyokusyu) throws TecDAOException;

}
