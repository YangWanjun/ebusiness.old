/*
 * 【システム名】リース管理システム
 * 【ファイル名】SessionBeanIF.java
 * 【  説  明  】
 * 【  作  成  】2010/06/23 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.system.session;

/**
 * <strong>セッションビーンインターフェース。</strong>
 * <p>
 * セッションビーン共通のインターフェース。<br>
 * 各画面用のセッションビーンは{@link ApplicationSessionBean}を継承、<br>
 * または{@link ApplicationSessionBeanIF}を実装すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/23 新規作成<br>
 * @since 1.00
 */
public interface SessionBeanIF {

//	/**
//	 * プロパティのクリア処理。
//	 */
//	public void clear();

}
