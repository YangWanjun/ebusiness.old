package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;


/**
 * <strong>コード区分マスタ操作用イベント。</strong>
 *
 * @author Y.M(TEC)
 * @version 1.00 2012/01/16 新規作成<br>
 * @since 1.00
 */
public class CodeMasterEvent extends UcarEvent {

	private static final long serialVersionUID = 131183458984028469L;

	/** 区分ID */
	private String kbID;
	/** ユーザーインフォビーン */
	private UserInformationBean userInfoBean;
	/**	会社**/
	private String cdKaisya;
	/**	事業所**/
	private String cdJigyosyo;
	
	
	

	/**
	 * 区分IDを取得します。
	 * @return 区分ID
	 */
	public String getKbID() {
	    return kbID;
	}

	/**
	 * 区分IDを設定します。
	 * @param kbID 区分ID
	 */
	public void setKbID(String kbID) {
	    this.kbID = kbID;
	}

	/**
	 * ユーザーインフォビーンを取得します。
	 * @return ユーザーインフォビーン
	 */
	public UserInformationBean getUserInfoBean() {
	    return userInfoBean;
	}

	/**
	 * ユーザーインフォビーンを設定します。
	 * @param userInfoBean ユーザーインフォビーン
	 */
	public void setUserInfoBean(UserInformationBean userInfoBean) {
	    this.userInfoBean = userInfoBean;
	}
	/**
	 * 会社コードを返却
	 * @return
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}
	/**
	 * 会社コードを設定
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}
	/**
	 * 事業所を返却
	 * @return
	 */
	public String getCdJigyosyo() {
		return cdJigyosyo;
	}
	/**
	 * 事業所を設定
	 * @param cdJigyosyo
	 */
	public void setCdJigyosyo(String cdJigyosyo) {
		this.cdJigyosyo = cdJigyosyo;
	}

}
