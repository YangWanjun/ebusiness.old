/*
 * 【システム名】
 * 【ファイル名】DMFilesMapData.java
 * 【  説  明  】マッピング用データクラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.docmng.data;

/**
 * <strong>DMFilesMapData</strong>
 * <p>
 * マッピング用データクラス
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2009/04/01 <br>
 */
public class DMFilesMapData {

	/**
	 * <strong>ShoriKbn</strong>
	 * <p>
	 * 処理区分
	 * </p>
	 * @author H.O(SCC)
	 * @version 1.00 2009/04/01 <br>
	 */
	public enum ShoriKbn {
		/** CHECK:チェック */
		CHECK("01"),
		/** SET:設定 */
		SET("02"),
		/** GET:取得 */
		GET("03");
		private String execType;
		private ShoriKbn(String execType){
			this.execType = execType;
		}
		public String toString(){
			return execType;
		}
	}

	/**
	 * <strong>ShoriShosaiKbn</strong>
	 * <p>
	 * 処理詳細区分
	 * </p>
	 * @author H.O(SCC)
	 * @version 1.00 2009/04/01 <br>
	 */
	public enum ShoriShosaiKbn {
		/** CHECK:汎用項目チェック */
		CHECK_DEF("0101"),
		/** SET:汎用項目設定 */
		SET_DEF("0201"),
		/** SET:縦方向リスト設定 */
		SET_VRT("0211"),
		/** SET:横方向リスト設定 */
		SET_HRZ("0212"),
		/** GET:汎用項目取得 */
		GET_DEF("0301"),
		/** GET:縦方向リスト取得 */
		GET_VRT("0311"),
		/** GET:横方向リスト取得 */
		GET_HRZ("0312");
		private String execDetailType;
		private ShoriShosaiKbn(String execDetailType){
			this.execDetailType = execDetailType;
		}
		public String toString(){
			return execDetailType;
		}
	}

	private String yoshikiId;
	private String yoshikiNm;
	private String torokuFileNm;
	private String butsuriFileNm;
	private int sheetIdx;
	private String sheetNm;
	private int sheetKbn;
	private int kaiPageKbn;
	private String shokiFilePath;
	private String shokiSheetNm;
	private int shokiSaishuretsu;
	private int shokiSaishugyo;
	private String tsuikaFilePath;
	private String tsuikaSheetNm;
	private int tsuikaKaishiretsu;
	private int tsuikaKaishigyo;
	private int tsuikaShuryoretsu;
	private int tsuikaShuryogyo;
	private int tsuikaRetsuHoseichi;
	private int tsuikaGyoHoseichi;

	private String shoriKbn;
	private String shoriShosaiKbn;
	private int hikisuIdx;
	private int hairetsuIdx;
	private String listId;
	private String komokuNm;
	private int komokuKbn;
	private int taishoretsu;
	private int taishogyo;
	private int shutenretsu;
	private int shutengyo;
	private int shitenXZahyo;
	private int shitenYZahyo;
	private int shutenXZahyo;
	private int shutenYZahyo;
	private String biko;
	private int zobunchi;
	private int unitKomokusu;
	private int saidaiKomokusu;

	/**
	 * 様式項目定義-備考取得
	 * @return 様式項目定義-備考
	 * @since 1.00
	 */
	public String getBiko() {
		return biko;
	}
	/**
	 * 様式項目定義-備考設定
	 * @param biko 様式項目定義-備考
	 * @since 1.00
	 */
	public void setBiko(String biko) {
		this.biko = biko;
	}
	/**
	 * 様式-物理ファイル名取得
	 * @return 様式-物理ファイル名
	 * @since 1.00
	 */
	public String getButsuriFileNm() {
		return butsuriFileNm;
	}
	/**
	 * 様式-物理ファイル名設定
	 * @param butsuriFileNm 様式-物理ファイル名
	 * @since 1.00
	 */
	public void setButsuriFileNm(String butsuriFileNm) {
		this.butsuriFileNm = butsuriFileNm;
	}
	/**
	 * 様式項目定義-配列インデックス取得
	 * @return 様式項目定義-配列インデックス
	 * @since 1.00
	 */
	public int getHairetsuIdx() {
		return hairetsuIdx;
	}
	/**
	 * 様式項目定義-配列インデックス設定
	 * @param hairetsuIdx 様式項目定義-配列インデックス
	 * @since 1.00
	 */
	public void setHairetsuIdx(int hairetsuIdx) {
		this.hairetsuIdx = hairetsuIdx;
	}
	/**
	 * 様式項目定義-引数インデックス取得
	 * @return 様式項目定義-引数インデックス
	 * @since 1.00
	 */
	public int getHikisuIdx() {
		return hikisuIdx;
	}
	/**
	 * 様式項目定義-引数インデックス設定
	 * @param hikisuIdx 様式項目定義-引数インデックス
	 * @since 1.00
	 */
	public void setHikisuIdx(int hikisuIdx) {
		this.hikisuIdx = hikisuIdx;
	}
	/**
	 * 様式シート定義-改ページ区分取得
	 * @return 様式シート定義-改ページ区分(方向設定(0:固定、1:縦))
	 * @since 1.00
	 */
	public int getKaiPageKbn() {
		return kaiPageKbn;
	}
	/**
	 * 様式シート定義-改ページ区分設定
	 * @param kaiPageKbn 様式シート定義-改ページ区分(方向設定(0:固定、1:縦))
	 * @since 1.00
	 */
	public void setKaiPageKbn(int kaiPageKbn) {
		this.kaiPageKbn = kaiPageKbn;
	}
	/**
	 * 様式項目定義-項目区分取得
	 * @return 様式項目定義-項目区分<br>
	 * (0:Numeric、1:String、2:Formula、3:Blank、4:Boolean、5:Error、<br>
	 * 10:オートシェイプ(○)、11:オートシェイプ(レ))
	 * @since 1.00
	 */
	public int getKomokuKbn() {
		return komokuKbn;
	}
	/**
	 * 様式項目定義-項目区分設定
	 * @param komokuKbn 様式項目定義-項目区分<br>
	 * (0:Numeric、1:String、2:Formula、3:Blank、4:Boolean、5:Error、<br>
	 * 10:オートシェイプ(○)、11:オートシェイプ(レ))
	 * @since 1.00
	 */
	public void setKomokuKbn(int komokuKbn) {
		this.komokuKbn = komokuKbn;
	}
	/**
	 * 様式項目定義-項目名取得
	 * @return 様式項目定義-項目名
	 * @since 1.00
	 */
	public String getKomokuNm() {
		return komokuNm;
	}
	/**
	 * 様式項目定義-項目名設定
	 * @param komokuNm 様式項目定義-項目名
	 * @since 1.00
	 */
	public void setKomokuNm(String komokuNm) {
		this.komokuNm = komokuNm;
	}
	/**
	 * 様式項目定義-リストID取得
	 * @return 様式項目定義-リストID
	 * @since 1.00
	 */
	public String getListId() {
		return listId;
	}
	/**
	 * 様式項目定義-リストID設定
	 * @param listId 様式項目定義-リストID
	 * @since 1.00
	 */
	public void setListId(String listId) {
		this.listId = listId;
	}
	/**
	 * 様式リスト定義-リスト用最大項目数取得
	 * @return 様式リスト定義-リスト用最大項目数
	 * @since 1.00
	 */
	public int getSaidaiKomokusu() {
		return saidaiKomokusu;
	}
	/**
	 * 様式リスト定義-リスト用最大項目数設定
	 * @param saidaiKomokusu 様式リスト定義-リスト用最大項目数
	 * @since 1.00
	 */
	public void setSaidaiKomokusu(int saidaiKomokusu) {
		this.saidaiKomokusu = saidaiKomokusu;
	}
	/**
	 * 様式シート定義-シートインデックス取得
	 * @return 様式シート定義-シートインデックス
	 * @since 1.00
	 */
	public int getSheetIdx() {
		return sheetIdx;
	}
	/**
	 * 様式シート定義-シートインデックス設定
	 * @param sheetIdx 様式シート定義-シートインデックス
	 * @since 1.00
	 */
	public void setSheetIdx(int sheetIdx) {
		this.sheetIdx = sheetIdx;
	}
	/**
	 * 様式シート定義-シート区分取得
	 * @return 様式シート定義-シート区分(0:任意、1:必須)
	 * @since 1.00
	 */
	public int getSheetKbn() {
		return sheetKbn;
	}
	/**
	 * 様式シート定義-シート区分設定
	 * @param sheetKbn 様式シート定義-シート区分(0:任意、1:必須)
	 * @since 1.00
	 */
	public void setSheetKbn(int sheetKbn) {
		this.sheetKbn = sheetKbn;
	}
	/**
	 * 様式シート定義-シート名取得
	 * @return 様式シート定義-シート名
	 * @since 1.00
	 */
	public String getSheetNm() {
		return sheetNm;
	}
	/**
	 * 様式シート定義-シート名設定
	 * @param sheetNm 様式シート定義-シート名
	 * @since 1.00
	 */
	public void setSheetNm(String sheetNm) {
		this.sheetNm = sheetNm;
	}
	/**
	 * 様式項目定義-オートシェイプ始点セルX座標取得
	 * @return 様式項目定義-オートシェイプ始点セルX座標(0-1023)
	 * @since 1.00
	 */
	public int getShitenXZahyo() {
		return shitenXZahyo;
	}
	/**
	 * 様式項目定義-オートシェイプ始点セルX座標設定
	 * @param shitenXZahyo 様式項目定義-オートシェイプ始点セルX座標(0-1023)
	 * @since 1.00
	 */
	public void setShitenXZahyo(int shitenXZahyo) {
		this.shitenXZahyo = shitenXZahyo;
	}
	/**
	 * 様式項目定義-オートシェイプ始点セルY座標取得
	 * @return 様式項目定義-オートシェイプ始点セルY座標(0-255)
	 * @since 1.00
	 */
	public int getShitenYZahyo() {
		return shitenYZahyo;
	}
	/**
	 * 様式項目定義-オートシェイプ始点セルY座標設定
	 * @param shitenYZahyo 様式項目定義-オートシェイプ始点セルY座標(0-255)
	 * @since 1.00
	 */
	public void setShitenYZahyo(int shitenYZahyo) {
		this.shitenYZahyo = shitenYZahyo;
	}
	/**
	 * 様式シート定義-初期ページ用ファイルパス取得
	 * @return 様式シート定義-初期ページ用ファイルパス
	 * @since 1.00
	 */
	public String getShokiFilePath() {
		return shokiFilePath;
	}
	/**
	 * 様式シート定義-初期ページ用ファイルパス設定
	 * @param shokiFilePath 様式シート定義-初期ページ用ファイルパス
	 * @since 1.00
	 */
	public void setShokiFilePath(String shokiFilePath) {
		this.shokiFilePath = shokiFilePath;
	}
	/**
	 * 様式シート定義-初期ページ最終行取得
	 * @return 様式シート定義-初期ページ最終行
	 * @since 1.00
	 */
	public int getShokiSaishugyo() {
		return shokiSaishugyo;
	}
	/**
	 * 様式シート定義-初期ページ最終行設定
	 * @param shokiSaishugyo 様式シート定義-初期ページ最終行
	 * @since 1.00
	 */
	public void setShokiSaishugyo(int shokiSaishugyo) {
		this.shokiSaishugyo = shokiSaishugyo;
	}
	/**
	 * 様式シート定義-初期ページ最終列取得
	 * @return 様式シート定義-初期ページ最終列
	 * @since 1.00
	 */
	public int getShokiSaishuretsu() {
		return shokiSaishuretsu;
	}
	/**
	 * 様式シート定義-初期ページ最終列設定
	 * @param shokiSaishuretsu 様式シート定義-初期ページ最終列
	 * @since 1.00
	 */
	public void setShokiSaishuretsu(int shokiSaishuretsu) {
		this.shokiSaishuretsu = shokiSaishuretsu;
	}
	/**
	 * 様式シート定義-初期ページ用シート名取得
	 * @return 様式シート定義-初期ページ用シート名
	 * @since 1.00
	 */
	public String getShokiSheetNm() {
		return shokiSheetNm;
	}
	/**
	 * 様式シート定義-初期ページ用シート名設定
	 * @param shokiSheetNm 様式シート定義-初期ページ用シート名
	 * @since 1.00
	 */
	public void setShokiSheetNm(String shokiSheetNm) {
		this.shokiSheetNm = shokiSheetNm;
	}
	/**
	 * 様式項目定義-処理区分取得
	 * @return 様式項目定義-処理区分(01:CHECK、02:SET、03:GET)
	 * @since 1.00
	 */
	public String getShoriKbn() {
		return shoriKbn;
	}
	/**
	 * 様式項目定義-処理区分設定
	 * @param shoriKbn 様式項目定義-処理区分(01:CHECK、02:SET、03:GET)
	 * @since 1.00
	 */
	public void setShoriKbn(String shoriKbn) {
		this.shoriKbn = shoriKbn;
	}
	/**
	 * 様式項目定義-処理詳細区分取得
	 * @return 様式項目定義-処理詳細区分(0201:通常セット、0211:縦方向リスト、0212:横方向リスト)
	 * @since 1.00
	 */
	public String getShoriShosaiKbn() {
		return shoriShosaiKbn;
	}
	/**
	 * 様式項目定義-処理詳細区分設定
	 * @param shoriShosaiKbn 様式項目定義-処理詳細区分(0201:通常セット、0211:縦方向リスト、0212:横方向リスト)
	 * @since 1.00
	 */
	public void setShoriShosaiKbn(String shoriShosaiKbn) {
		this.shoriShosaiKbn = shoriShosaiKbn;
	}
	/**
	 * 様式項目定義-オートシェイプ終点行取得
	 * @return 様式項目定義-オートシェイプ終点行
	 * @since 1.00
	 */
	public int getShutengyo() {
		return shutengyo;
	}
	/**
	 * 様式項目定義-オートシェイプ終点行設定
	 * @param shutengyo 様式項目定義-オートシェイプ終点行
	 * @since 1.00
	 */
	public void setShutengyo(int shutengyo) {
		this.shutengyo = shutengyo;
	}
	/**
	 * 様式項目定義-オートシェイプ終点列取得
	 * @return 様式項目定義-オートシェイプ終点列
	 * @since 1.00
	 */
	public int getShutenretsu() {
		return shutenretsu;
	}
	/**
	 * 様式項目定義-オートシェイプ終点列設定
	 * @param shutenretsu 様式項目定義-オートシェイプ終点列
	 * @since 1.00
	 */
	public void setShutenretsu(int shutenretsu) {
		this.shutenretsu = shutenretsu;
	}
	/**
	 * 様式項目定義-オートシェイプ終点セルX座標取得
	 * @return 様式項目定義-オートシェイプ終点セルX座標(0-1023)
	 * @since 1.00
	 */
	public int getShutenXZahyo() {
		return shutenXZahyo;
	}
	/**
	 * 様式項目定義-オートシェイプ終点セルX座標設定
	 * @param shutenXZahyo 様式項目定義-オートシェイプ終点セルX座標(0-1023)
	 * @since 1.00
	 */
	public void setShutenXZahyo(int shutenXZahyo) {
		this.shutenXZahyo = shutenXZahyo;
	}
	/**
	 * 様式項目定義-オートシェイプ終点セルY座標取得
	 * @return 様式項目定義-オートシェイプ終点セルY座標(0-255)
	 * @since 1.00
	 */
	public int getShutenYZahyo() {
		return shutenYZahyo;
	}
	/**
	 * 様式項目定義-オートシェイプ終点セルY座標設定
	 * @param shutenYZahyo 様式項目定義-オートシェイプ終点セルY座標(0-255)
	 * @since 1.00
	 */
	public void setShutenYZahyo(int shutenYZahyo) {
		this.shutenYZahyo = shutenYZahyo;
	}
	/**
	 * 様式項目定義-対象行取得
	 * @return 様式項目定義-対象行
	 * @since 1.00
	 */
	public int getTaishogyo() {
		return taishogyo;
	}
	/**
	 * 様式項目定義-対象行設定
	 * @param taishogyo 様式項目定義-対象行
	 * @since 1.00
	 */
	public void setTaishogyo(int taishogyo) {
		this.taishogyo = taishogyo;
	}
	/**
	 * 様式項目定義-対象列取得
	 * @return 様式項目定義-対象列
	 * @since 1.00
	 */
	public int getTaishoretsu() {
		return taishoretsu;
	}
	/**
	 * 様式項目定義-対象列設定
	 * @param taishoretsu 様式項目定義-対象列
	 * @since 1.00
	 */
	public void setTaishoretsu(int taishoretsu) {
		this.taishoretsu = taishoretsu;
	}
	/**
	 * 様式-登録ファイル名取得
	 * @return 様式-登録ファイル名
	 * @since 1.00
	 */
	public String getTorokuFileNm() {
		return torokuFileNm;
	}
	/**
	 * 様式-登録ファイル名設定
	 * @param torokuFileNm 様式-登録ファイル名
	 * @since 1.00
	 */
	public void setTorokuFileNm(String torokuFileNm) {
		this.torokuFileNm = torokuFileNm;
	}
	/**
	 * 様式シート定義-追加ページ用ファイルパス取得
	 * @return 様式シート定義-追加ページ用ファイルパス
	 * @since 1.00
	 */
	public String getTsuikaFilePath() {
		return tsuikaFilePath;
	}
	/**
	 * 様式シート定義-追加ページ用ファイルパス設定
	 * @param tsuikaFilePath 様式シート定義-追加ページ用ファイルパス
	 * @since 1.00
	 */
	public void setTsuikaFilePath(String tsuikaFilePath) {
		this.tsuikaFilePath = tsuikaFilePath;
	}
	/**
	 * 様式シート定義-追加ページ基準行補正値取得
	 * @return 様式シート定義-追加ページ基準行補正値
	 * @since 1.00
	 */
	public int getTsuikaGyoHoseichi() {
		return tsuikaGyoHoseichi;
	}
	/**
	 * 様式シート定義-追加ページ基準行補正値設定
	 * @param tsuikaGyoHoseichi 様式シート定義-追加ページ基準行補正値
	 * @since 1.00
	 */
	public void setTsuikaGyoHoseichi(int tsuikaGyoHoseichi) {
		this.tsuikaGyoHoseichi = tsuikaGyoHoseichi;
	}
	/**
	 * 様式シート定義-追加ページコピー開始行
	 * @return 様式シート定義-追加ページコピー開始行
	 * @since 1.00
	 */
	public int getTsuikaKaishigyo() {
		return tsuikaKaishigyo;
	}
	/**
	 * 様式シート定義-追加ページコピー開始行設定
	 * @param tsuikaKaishigyo 様式シート定義-追加ページコピー開始行
	 * @since 1.00
	 */
	public void setTsuikaKaishigyo(int tsuikaKaishigyo) {
		this.tsuikaKaishigyo = tsuikaKaishigyo;
	}
	/**
	 * 様式シート定義-追加ページコピー開始列取得
	 * @return 様式シート定義-追加ページコピー開始列
	 * @since 1.00
	 */
	public int getTsuikaKaishiretsu() {
		return tsuikaKaishiretsu;
	}
	/**
	 * 様式シート定義-追加ページコピー開始列設定
	 * @param tsuikaKaishiretsu 様式シート定義-追加ページコピー開始列
	 * @since 1.00
	 */
	public void setTsuikaKaishiretsu(int tsuikaKaishiretsu) {
		this.tsuikaKaishiretsu = tsuikaKaishiretsu;
	}
	/**
	 * 様式シート定義-追加ページ基準列補正値取得
	 * @return 様式シート定義-追加ページ基準列補正値
	 * @since 1.00
	 */
	public int getTsuikaRetsuHoseichi() {
		return tsuikaRetsuHoseichi;
	}
	/**
	 * 様式シート定義-追加ページ基準列補正値設定
	 * @param tsuikaRetsuHoseichi 様式シート定義-追加ページ基準列補正値
	 * @since 1.00
	 */
	public void setTsuikaRetsuHoseichi(int tsuikaRetsuHoseichi) {
		this.tsuikaRetsuHoseichi = tsuikaRetsuHoseichi;
	}
	/**
	 * 様式シート定義-追加ページ用シート名取得
	 * @return 様式シート定義-追加ページ用シート名
	 * @since 1.00
	 */
	public String getTsuikaSheetNm() {
		return tsuikaSheetNm;
	}
	/**
	 * 様式シート定義-追加ページ用シート名設定
	 * @param tsuikaSheetNm 様式シート定義-追加ページ用シート名
	 * @since 1.00
	 */
	public void setTsuikaSheetNm(String tsuikaSheetNm) {
		this.tsuikaSheetNm = tsuikaSheetNm;
	}
	/**
	 * 様式シート定義-追加ページコピー終了行取得
	 * @return 様式シート定義-追加ページコピー終了行
	 * @since 1.00
	 */
	public int getTsuikaShuryogyo() {
		return tsuikaShuryogyo;
	}
	/**
	 * 様式シート定義-追加ページコピー終了行設定
	 * @param tsuikaShuryogyo 様式シート定義-追加ページコピー終了行
	 * @since 1.00
	 */
	public void setTsuikaShuryogyo(int tsuikaShuryogyo) {
		this.tsuikaShuryogyo = tsuikaShuryogyo;
	}
	/**
	 * 様式シート定義-追加ページコピー終了列取得
	 * @return 様式シート定義-追加ページコピー終了列
	 * @since 1.00
	 */
	public int getTsuikaShuryoretsu() {
		return tsuikaShuryoretsu;
	}
	/**
	 * 様式シート定義-追加ページコピー終了列設定
	 * @param tsuikaShuryoretsu 様式シート定義-追加ページコピー終了列
	 * @since 1.00
	 */
	public void setTsuikaShuryoretsu(int tsuikaShuryoretsu) {
		this.tsuikaShuryoretsu = tsuikaShuryoretsu;
	}
	/**
	 * 様式リスト定義-リスト用１ユニットあたりの項目数取得
	 * @return 様式リスト定義-リスト用１ユニットあたりの項目数
	 * @since 1.00
	 */
	public int getUnitKomokusu() {
		return unitKomokusu;
	}
	/**
	 * 様式リスト定義-リスト用１ユニットあたりの項目数設定
	 * @param unitKomokusu 様式リスト定義-リスト用１ユニットあたりの項目数
	 * @since 1.00
	 */
	public void setUnitKomokusu(int unitKomokusu) {
		this.unitKomokusu = unitKomokusu;
	}
	/**
	 * 様式-様式ID取得
	 * @return 様式-様式ID
	 * @since 1.00
	 */
	public String getYoshikiId() {
		return yoshikiId;
	}
	/**
	 * 様式-様式ID設定
	 * @param yoshikiId 様式-様式ID
	 * @since 1.00
	 */
	public void setYoshikiId(String yoshikiId) {
		this.yoshikiId = yoshikiId;
	}
	/**
	 * 様式-様式名取得
	 * @return 様式-様式名
	 * @since 1.00
	 */
	public String getYoshikiNm() {
		return yoshikiNm;
	}
	/**
	 * 様式-様式名設定
	 * @param yoshikiNm 様式-様式名
	 * @since 1.00
	 */
	public void setYoshikiNm(String yoshikiNm) {
		this.yoshikiNm = yoshikiNm;
	}
	/**
	 * 様式リスト定義-リスト用増分値(セル)取得
	 * @return 様式リスト定義-リスト用増分値(セル)
	 * @since 1.00
	 */
	public int getZobunchi() {
		return zobunchi;
	}
	/**
	 * 様式リスト定義-リスト用増分値(セル)設定
	 * @param zobunchi 様式リスト定義-リスト用増分値(セル)
	 * @since 1.00
	 */
	public void setZobunchi(int zobunchi) {
		this.zobunchi = zobunchi;
	}

}
