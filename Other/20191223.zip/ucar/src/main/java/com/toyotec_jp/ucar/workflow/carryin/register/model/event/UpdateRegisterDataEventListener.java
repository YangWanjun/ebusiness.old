package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckMenuId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinUtils;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinMenuId;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetDdSiireEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetDdSiireEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.UpdateZoneDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;

/**
 * <strong>更新登録イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class UpdateRegisterDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		TecLogger.trace("update registerData start");

		UpdateRegisterDataEvent targetEvent = (UpdateRegisterDataEvent) event;

		if (CarryinConst.CarryinMenuId.DocumentCheck.toString().equals(targetEvent.getMenuId())) {
			// 書類チェックの場合
			readyUpdateDocumentCheck(targetEvent);
		}

		// DAOIF取得
		RegisterDAOIF dao = getDAO(CarryinDAOKey.REGISTER_DAO, targetEvent, RegisterDAOIF.class);

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarryinConst.APPID_CARRYIN_REGISTER;

		RegisterInputBean registerInputBean = targetEvent.getRegisterInputBean();
		registerInputBean.setCdKsnsya(updateUserId);
		registerInputBean.setCdKsnapp(updateAppId);

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		// 店舗の場合、データ区分を取得
		String kbData = "";
		if (!targetEvent.getUserInfoBean().getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)){
			kbData = dao.selectKbData(registerInputBean.getCdKaisya(),
/*2019.3.20					
										registerInputBean.getCdHanbaitn(),
										
*/
										registerInputBean.getCdTenpoHanbaitnSel(),
//2019.3.20
										registerInputBean.getDdHannyu(),
										registerInputBean.getNoKanri(),
										targetEvent.getUserInfoBean().getCdTenpo());
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		SimpleExecuteResultBean updateResult = null;
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 書類チェック時 搬入チェック情報のみ更新
		if(targetEvent.getMenuId().equals(CarryinConst.CarryinMenuId.DocumentCheck.toString())){

			// 更新対象:チェック内容　書類完備日　個人情報　受注№　受付担当者　備　考　印鑑証明有効期限
			updateResult = dao.updateT220001GOnlyHannyuCheck(registerInputBean,
															 targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															 targetEvent.getUserInfoBean().getKbScenter(),
															 kbData,										// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															 targetEvent.getT220001gDtKosin(),
															 executeDate);

		// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため start
//		} else if(CarCheckMenuId.ENTER_CHECK.toString().equals(targetEvent.getMenuId())
//					|| CarCheckMenuId.WORK_SORT.toString().equals(targetEvent.getMenuId())){
		} else if(CarCheckMenuId.ENTER_CHECK.toString().equals(targetEvent.getMenuId())){
			// 入庫検査の場合
			// 更新対象:走行距離
			updateResult = dao.updateT220001GAlsoNuSoukukm(registerInputBean,
															targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															targetEvent.getUserInfoBean().getKbScenter(),
															kbData,										// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															targetEvent.getT220001gDtKosin(),
															executeDate);

		} else if(CarCheckMenuId.WORK_SORT.toString().equals(targetEvent.getMenuId())){
		// 2012.03.16 C.Ohta 追加 走行距離 入庫検査時、入力可能のため end
			// 作業仕分の場合
			// 2012.01.30 T.Hayato 修正 備考 更新のため start
			// 更新対象:備　考
			updateResult = dao.updateT220001GOnlyMjBikou(registerInputBean,
															targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															targetEvent.getUserInfoBean().getKbScenter(),
															kbData,										// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
															targetEvent.getT220001gDtKosin(),
															executeDate);
			// 2012.01.30 T.Hayato 修正 備考 更新のため end
		}else{
			// 書類チェック時 以外

			// 2013.05.20 T.Hayato 追加 ai21仕入日取得のため start
			// ai21仕入日取得
			GetDdSiireEvent executeEvent = createEvent(UcarEventKey.GET_DD_SIIRE,
														targetEvent.getUserInfo(),
														GetDdSiireEvent.class);

			executeEvent.setCdKaisya(registerInputBean.getCdKaisya());
			executeEvent.setCdHanbaitn(registerInputBean.getCdHanbaitn());
			executeEvent.setNoSyaryou(registerInputBean.getNoSyaryou());

			GetDdSiireEventResult executeResult = (GetDdSiireEventResult)dispatchEvent(executeEvent);
			registerInputBean.setDdSiire(executeResult.getDdSiire());
			// 2013.05.20 T.Hayato 追加 ai21仕入日取得のため end

			updateResult = dao.updateT220001G(registerInputBean,
												targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
												targetEvent.getUserInfoBean().getKbScenter(),
												kbData,										// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
												targetEvent.getT220001gDtKosin(),
												executeDate);
		}
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		if (updateResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
		}

		// 以降の処理にはInsertが含まれるため作成ユーザIDと作成アプリIDにも値をセット
		registerInputBean.setCdSksisya(updateUserId);
		registerInputBean.setCdSksiapp(updateAppId);

		Ucaa001gPKBean t220001gPkBean = new Ucaa001gPKBean(registerInputBean.getCdKaisya(),
/*--2019.3.20				
															registerInputBean.getCdHanbaitn(),
*/
															registerInputBean.getCdTenpoHanbaitnSel(),
//--2019.3.20				
															registerInputBean.getCdHantenpo(),	//2016.9.5 ADD
															registerInputBean.getDdHannyu(),
															registerInputBean.getNoKanri());

		if (CarryinConst.CarryinMenuId.Register.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.Barcode.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.List.toString().equals(targetEvent.getMenuId())) {
			// 仕入種別情報
			updateT220002G(targetEvent, dao, t220001gPkBean, executeDate);
		}

		if (CarryinConst.CarryinMenuId.Register.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.Barcode.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.List.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.DocumentCheck.toString().equals(targetEvent.getMenuId())) {
			// チェック内容情報
			updateT220003G(targetEvent, dao, t220001gPkBean, executeDate);
		}

		// 詳細修正・書類チェックモードで書類完備情報を登録
		if(CarryinConst.CarryinMenuId.DocumentCheck.toString().equals(targetEvent.getMenuId())){
			// 書類完備情報 2011.10.14 H.Yamashita add
			updateT220007G(targetEvent, dao, t220001gPkBean, executeDate);
		}

		if (CarryinConst.CarryinMenuId.Register.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.Barcode.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.List.toString().equals(targetEvent.getMenuId())
			|| CarryinConst.CarryinMenuId.DocumentCheck.toString().equals(targetEvent.getMenuId())) {
			// ステータスＤＢ更新 2011.10.29 H.Yamashita add

			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
			Uccb007gPKBean t220107gPKBean = new Uccb007gPKBean(t220001gPkBean.getCdKaisya(),
																t220001gPkBean.getCdHanbaitn(),
																t220001gPkBean.getDdHannyu(),
																t220001gPkBean.getNoKanri(),
																targetEvent.getUserInfoBean().getCdTenpo(),
																targetEvent.getUserInfoBean().getKbScenter());

//			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
//			updateT220012G(targetEvent, dao, t220001gPkBean, executeDate);
//			// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
			updateT220012G(targetEvent, dao, t220107gPKBean, executeDate);
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		}

		TecLogger.trace("update registerData end");
		return null;
	}

	/**
	 * 更新前の事前チェック処理
	 * <pre>
	 * DocumentCheckのみ
	 * </pre>
	 * @param targetEvent
	 * @throws TecSystemException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void readyUpdateDocumentCheck(UpdateRegisterDataEvent targetEvent)
			throws TecSystemException, SystemException, ApplicationException {

		String message = "";

		// 更新時の下取書類のチェック状態
		boolean nowKbCheckSitadori = CarryinUtils.getNowKbCheckSitadori(targetEvent.getRegisterInputBean());
		boolean checkOffKbCheckSitadori = false;
		if (targetEvent.getRegisterInputBean().isInitKbCheckSitadori() == true
				&& nowKbCheckSitadori == false) {
			// 下取書類の画面初期表示時チェックボックスのチェックあり→更新時チェックボックスのチェックなしの場合

			message = "次工程に入力がありますので、チェック内容・下取書類のチェックを外すことはできません。";
			checkOffKbCheckSitadori = true;
		}

		// 更新時の保留のチェック状態
		boolean nowcheckSrk = CarryinUtils.getNowCheckSrk(targetEvent.getRegisterInputBean());
		boolean checkOffCheckSrk = false;
		if (targetEvent.getRegisterInputBean().isInitCheckSrk() == true
				&& nowcheckSrk == false) {
			// 保留の画面初期表示時チェックボックスのチェックあり→更新時チェックボックスのチェックなしの場合

			message = "次工程に入力がありますので、チェック内容・保留のチェックを外すことはできません。";
			checkOffCheckSrk = true;
		}

		if ((checkOffKbCheckSitadori == true && nowcheckSrk == false)
				|| nowKbCheckSitadori == false && checkOffCheckSrk == true) {
			// 下取書類のチェックボックスのチェックあり→なし、かつ保留のチェックボックスのチェックなし、
			// または下取書類のチェックボックスのチェックなし、かつ保留のチェックボックスのチェックあり→なし、

			// ステータスDBチェック
			checkStatusDB(targetEvent, message);
		}
	}

	/**
	 * ステータスDBチェック
	 * @param targetEvent
	 * @throws TecSystemException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void checkStatusDB(UpdateRegisterDataEvent targetEvent, String message)
			throws TecSystemException, SystemException, ApplicationException {

		CheckStatusEvent checkStatusEvent
			= createEvent(UcarEventKey.CHECK_STATUS, targetEvent.getUserInfo(), CheckStatusEvent.class);
//		Ucaa001gPKBean t220001gPkBean = new Ucaa001gPKBean(targetEvent.getRegisterInputBean().getCdKaisya(),
		Uccb007gPKBean t220001gPkBean = new Uccb007gPKBean(targetEvent.getRegisterInputBean().getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
/*2019.3.20			
															targetEvent.getRegisterInputBean().getCdHanbaitn(),
*/
															targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
//--2019.3.20				
															targetEvent.getRegisterInputBean().getDdHannyu(),
															targetEvent.getRegisterInputBean().getNoKanri(),
															// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
															targetEvent.getUserInfoBean().getCdTenpo(),
															targetEvent.getUserInfoBean().getKbScenter());
//		checkStatusEvent.setT220001gPkBean(t220001gPkBean);
		checkStatusEvent.setT220107gPkBean(t220001gPkBean);
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// ステータス05から
		checkStatusEvent.setStartDtStatus(5);
		// ステータス08まで
		checkStatusEvent.setEndDtStatus(8);
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		// イベント実行
		CheckStatusEventResult checkStatusResult
			= (CheckStatusEventResult)dispatchEvent(checkStatusEvent);

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		if (checkStatusResult.isExistDtStatus()) {
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
			throw new TecApplicationException(message);
		}
	}

	/**
	 * 仕入種別情報に対する更新処理
	 * @param targetEvent
	 * @param dao
	 * @param t220001gPkBean
	 * @param executeDate 実行日時
	 * @throws TecDAOException
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 */
	private void updateT220002G(UpdateRegisterDataEvent targetEvent,
									RegisterDAOIF dao,
									Ucaa001gPKBean t220001gPkBean,
									Timestamp executeDate) throws TecDAOException, TecExclusionException, TecMessageException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
//		// 仕入種別情報取得
//		ResultArrayList<Ucaa002gBean> t220002gList = dao.selectT220002G(t220001gPkBean,
//																		targetEvent.getUserInfoBean().getKbScenter());
//		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
		String kbScenter = "1";
		ResultArrayList<Ucaa002gBean> t220002gList = null;
		t220002gList = dao.selectT220002G(t220001gPkBean,
										UcarConst.KB_SCENTER_SCENTER);
		if (t220002gList.size() == 0) {
			kbScenter = "";
			t220002gList = dao.selectT220002G(t220001gPkBean,
											kbScenter);
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		if (t220002gList.size() > 0) {

			String t220002gDtKosin = DateUtils.dateToString(t220002gList.get(0).getDtKosin(), DateUtils.DB_FORMAT_LONG_M);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			SimpleExecuteResultBean deleteResult002G = dao.deleteT220002G(targetEvent.getRegisterInputBean().getCdKaisya(),
																			targetEvent.getRegisterInputBean().getCdHanbaitn(),
																			targetEvent.getRegisterInputBean().getDdHannyu(),
																			targetEvent.getRegisterInputBean().getNoKanri(),
//																			targetEvent.getUserInfoBean().getKbScenter(),
																			kbScenter,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																			t220002gDtKosin);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

			if (deleteResult002G.getExecuteCount() != t220002gList.size()) {
				// 削除対象件数と実行削除件数が異なる場合は排他エラー
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
			}
		}


		if (targetEvent.getRegisterInputBean().getArrayKbSiire() != null) {
			// 仕入種別のチェック数だけ処理を実行
			for (String kbSiire : targetEvent.getRegisterInputBean().getArrayKbSiire()) {
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
				dao.insertT220002G(targetEvent.getRegisterInputBean(),
//									targetEvent.getUserInfoBean().getKbScenter(),
									kbScenter,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
									kbSiire,
									executeDate);
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
			}
		}
	}

	/**
	 * チェック内容情報に対する更新処理
	 * @param targetEvent
	 * @param dao
	 * @param t220001gPkBean
	 * @param executeDate 実行日時
	 * @throws TecDAOException
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 */
	private void updateT220003G(UpdateRegisterDataEvent targetEvent,
									RegisterDAOIF dao,
									Ucaa001gPKBean t220001gPkBean,
									Timestamp executeDate) throws TecDAOException, TecExclusionException, TecMessageException {

		ResultArrayList<Ucaa003gBean> t220003gList = new ResultArrayList<Ucaa003gBean>();

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// チェック内容情報取得
		if (CarryinMenuId.List.getMenuId().equals(targetEvent.getMenuId())) {
			// 車両搬入一覧の場合⇒下取書類を除外する
			t220003gList = dao.selectT220003G(t220001gPkBean,
					targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
					targetEvent.getUserInfoBean().getKbScenter(),
					CarryinConst.KBCHECK_SITADORI);
		} else if(CarryinMenuId.DocumentCheck.getMenuId().equals(targetEvent.getMenuId())) {
			// 書類チェックの場合⇒全件確認
			t220003gList = dao.selectT220003G(t220001gPkBean,
					targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
					targetEvent.getUserInfoBean().getKbScenter(),
					null);
		}
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		if (t220003gList.size() > 0) {

			for (Ucaa003gBean t220003gBean : t220003gList) {
				String t220003gDtKosin = DateUtils.dateToString(t220003gBean.getDtKosin(), DateUtils.DB_FORMAT_LONG_M);
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
				// 対象データを1件ずつDELETEする
				SimpleExecuteResultBean deleteResult003G = dao.deleteT220003G(targetEvent.getRegisterInputBean().getCdKaisya(),
																			targetEvent.getRegisterInputBean().getCdHanbaitn(),
																			targetEvent.getRegisterInputBean().getDdHannyu(),
																			targetEvent.getRegisterInputBean().getNoKanri(),
																			targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																			t220003gBean.getKbCheck(),
																			targetEvent.getUserInfoBean().getKbScenter(),
																			t220003gDtKosin);
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

				if (deleteResult003G.getExecuteCount() != 1) {
					// 実行削除件数が1以外の場合は排他エラー
					throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
				}
			}

		}

		if (targetEvent.getRegisterInputBean().getArrayKbCheck() != null) {
			String ddCheck = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
			// チェック内容のチェック数だけ処理を実行
			for (String kbCheck : targetEvent.getRegisterInputBean().getArrayKbCheck()) {
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
				dao.insertT220003G(targetEvent.getRegisterInputBean(),
									targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
						 			targetEvent.getUserInfoBean().getKbScenter(),
									kbCheck,
									ddCheck,
									executeDate);
				// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

			}
		}
	}

	/**
	 * 書類チェック情報に対する更新処理
	 * @param targetEvent
	 * @param dao
	 * @param t220001gPkBean
	 * @param executeDate 実行日時
	 * @throws TecDAOException
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 */
	private void updateT220007G(UpdateRegisterDataEvent targetEvent,
									RegisterDAOIF dao,
									Ucaa001gPKBean t220001gPkBean,
									Timestamp executeDate) throws TecDAOException, TecExclusionException, TecMessageException {

		// 書類チェック情報取得
		ResultArrayList<Ucab002gBean> t220007gList = dao.selectT220007G(t220001gPkBean,
																		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
																		targetEvent.getUserInfoBean().getCdTenpo(),
																		targetEvent.getUserInfoBean().getKbScenter());
																		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		if (t220007gList.size() > 0) {

			String t220007gDtKosin = DateUtils.dateToString(t220007gList.get(0).getDtKosin(), DateUtils.DB_FORMAT_LONG_M);

			// レコード削除
			SimpleExecuteResultBean deleteResultT220007G = dao.deleteT220007G(targetEvent.getRegisterInputBean().getCdKaisya(),
																			targetEvent.getRegisterInputBean().getCdHanbaitn(),
																			targetEvent.getRegisterInputBean().getDdHannyu(),
																			targetEvent.getRegisterInputBean().getNoKanri(),
																			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
																			targetEvent.getUserInfoBean().getCdTenpo(),
																			targetEvent.getUserInfoBean().getKbScenter(),
																			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
																			t220007gDtKosin);

			if (deleteResultT220007G.getExecuteCount() != t220007gList.size()) {
				// 削除対象件数と実行削除件数が異なる場合は排他エラー
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
			}
		}

		boolean nowKbCheckSitadori = CarryinUtils.getNowKbCheckSitadori(targetEvent.getRegisterInputBean());
		boolean nowcheckSrk = CarryinUtils.getNowCheckSrk(targetEvent.getRegisterInputBean());
		if (!(CarryinConst.CarryinMenuId.DocumentCheck.toString().equals(targetEvent.getMenuId())
				&& nowKbCheckSitadori == false
				&& nowcheckSrk == false)) {
			// DocumentCheckで「下取書類」と「保留」のチェックボックスのチェックが外れている"以外"はレコード追加を行う

			// 書類チェックDB：会社コード・販売店コード・搬入日・管理番号
			//			   	   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
			Ucab002gBean t220007gBean = new Ucab002gBean(targetEvent.getRegisterInputBean().getCdKaisya(),
/*--2019.3.20 from					
														  targetEvent.getRegisterInputBean().getCdHanbaitn(),
*/
					  									  targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
//--2019.3.20 to
														  targetEvent.getRegisterInputBean().getDdHannyu(),
														  targetEvent.getRegisterInputBean().getNoKanri(),
														  targetEvent.getRegisterInputBean().getCdSksisya(),
														  targetEvent.getRegisterInputBean().getCdKsnsya(),
														  targetEvent.getRegisterInputBean().getCdSksiapp(),
														  targetEvent.getRegisterInputBean().getCdKsnapp());

			// 書類完備日チェック:有りの場合 → 書類完備保留日に移送
			if(targetEvent.getRegisterInputBean().getArrayCheckSrk() != null){
				// 書類完備日
				t220007gBean.setDdSrknb("");
				// 書類完備保留日
				t220007gBean.setDdSrkhr(targetEvent.getRegisterInputBean().getDdSrk());
			// 無しの場合 → 書類完備日に移送
			}else{
				// 書類完備日
				t220007gBean.setDdSrknb(targetEvent.getRegisterInputBean().getDdSrk());
				// 書類完備保留日
				t220007gBean.setDdSrkhr("");
			}
			dao.insertT220007G(t220007gBean,
								// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
								targetEvent.getUserInfoBean().getCdTenpo(),
								targetEvent.getUserInfoBean().getKbScenter(),
								// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
								executeDate);
		}
	}

	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
	/**
	 * ステータス情報に対する更新処理
	 * @param targetEvent
	 * @param dao
	 * @param t220001gPKBean
	 * @param executeDate 実行日時
	 * @throws ApplicationException
	 * @throws SystemException
	 */
	private void updateT220012G(UpdateRegisterDataEvent targetEvent,
									RegisterDAOIF dao,
//									Ucaa001gPKBean t220001gPKBean,
									Uccb007gPKBean t220001gPKBean,		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
									Timestamp executeDate) throws SystemException, ApplicationException {

//		T220012gInputDataBean t220012gInputDataBean = new T220012gInputDataBean(targetEvent.getRegisterInputBean().getCdKaisya(),
		Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(targetEvent.getRegisterInputBean().getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
/*--2019.3.20				
																				  targetEvent.getRegisterInputBean().getCdHanbaitn(),
*/
																				  targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
//--2019.3.20
																				  targetEvent.getRegisterInputBean().getDdHannyu(),
																				  targetEvent.getRegisterInputBean().getNoKanri(),
																				  // 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																				  targetEvent.getUserInfoBean().getCdTenpo(),
																				  targetEvent.getUserInfoBean().getKbScenter(),
																				  // 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																				  targetEvent.getRegisterInputBean().getCdSksisya(),
																				  targetEvent.getRegisterInputBean().getCdKsnsya(),
																				  targetEvent.getRegisterInputBean().getCdSksiapp(),
																				  targetEvent.getRegisterInputBean().getCdKsnapp());


		if(targetEvent.getMenuId().equals(CarryinConst.CarryinMenuId.List.toString())){
			// 車両搬入一覧

			CheckStatusDateEventResult csdeResult = checkStatusDate(targetEvent, t220001gPKBean, 1, targetEvent.getRegisterInputBean().getDdHannyu());
			t220012gInputDataBean.setStrDtStatus01(csdeResult.getDtStatus());

		}else if(targetEvent.getMenuId().equals(CarryinConst.CarryinMenuId.DocumentCheck.toString())){
			// 書類完備

			// ステータス01(Insert時のみ使用)
			t220012gInputDataBean.setStrDtStatus01(UcarUtils.getCurrentDateFormatLongSpace(targetEvent.getRegisterInputBean().getDdHannyu()));

			// 更新時の下取書類の状態を取得
			boolean nowKbCheckSitadori = CarryinUtils.getNowKbCheckSitadori(targetEvent.getRegisterInputBean());
			if (nowKbCheckSitadori == false && targetEvent.getRegisterInputBean().getArrayCheckSrk() == null) {
				// 下取書類チェックOFF、かつ保留チェックOFF
				t220012gInputDataBean.setStrDtStatus03(null);
				t220012gInputDataBean.setStrDtStatus04(null);

			} else if(targetEvent.getRegisterInputBean().getArrayCheckSrk() != null){
				// 保留チェックON
				CheckStatusDateEventResult csdeResult
					= checkStatusDate(targetEvent, t220001gPKBean, 4, targetEvent.getRegisterInputBean().getDdSrk());
				t220012gInputDataBean.setStrDtStatus03(null);
				t220012gInputDataBean.setStrDtStatus04(csdeResult.getDtStatus());
			}else{
				// 下取書類チェックON
				CheckStatusDateEventResult csdeResult
					= checkStatusDate(targetEvent, t220001gPKBean, 3, targetEvent.getRegisterInputBean().getDdSrk());
				t220012gInputDataBean.setStrDtStatus03(csdeResult.getDtStatus());
				t220012gInputDataBean.setStrDtStatus04(null);
			}
		}

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// ステータス情報取得
		ResultArrayList<Ucab007gBean> t220012gList = dao.selectT220012G(t220001gPKBean,
		// 2019.04.04 T.Osada Start			
																		targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
		// 2019.04.04 T.Osada End
																		targetEvent.getUserInfoBean().getKbScenter());

		// レコード有り
		if (t220012gList.size() > 0) {
			// レコード更新
			dao.updateT220012G(t220012gInputDataBean, 
									// 2019.04.04 T.Osada Start			
									targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
									// 2019.04.04 T.Osada End
									targetEvent.getUserInfoBean().getKbScenter(), 
									targetEvent.getMenuId(), 
									executeDate);
		}else{
			// レコード追加
			dao.insertT220012G(t220012gInputDataBean, 
									// 2019.04.04 T.Osada Start			
									targetEvent.getRegisterInputBean().getCdTenpoHanbaitnSel(),
									// 2019.04.04 T.Osada End
									targetEvent.getUserInfoBean().getKbScenter(), 
									targetEvent.getMenuId(), 
									executeDate);
		}
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため start
		UpdateZoneDateEvent updateZoneDateEvent
			= createEvent(UcarEventKey.UPDATE_ZONE_DATE, targetEvent.getUserInfo(), UpdateZoneDateEvent.class);

//		updateZoneDateEvent.setT220001gPkBean(t220001gPKBean);
		updateZoneDateEvent.setT220107gPkBean(t220001gPKBean);					// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
//		updateZoneDateEvent.setT220012gInputDataBean(t220012gInputDataBean);
		updateZoneDateEvent.setUccb007gInputDataBean(t220012gInputDataBean);	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		updateZoneDateEvent.setExecuteDtStatus03(true);
		updateZoneDateEvent.setExecuteDtStatus05(true);
		updateZoneDateEvent.setExecuteDtStatus07(true);

		updateZoneDateEvent.setExecuteDate(executeDate);

		// イベント実行
		dispatchEvent(updateZoneDateEvent);
		// 2012.02.13 T.Hayato 追加 Aゾーン日数・ABゾーン日数 更新のため end

	}
	// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため start
	/**
	 * ステータスDB日付比較チェック
	 * @param targetEvent
	 * @param t220001gPkBean
	 * @param checkStatusNo
	 * @param dtStatus
	 * @return
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	public CheckStatusDateEventResult checkStatusDate(UpdateRegisterDataEvent targetEvent,
//														Ucaa001gPKBean t220001gPkBean,
														Uccb007gPKBean t220107gPKBean,	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
														int checkStatusNo,
														String dtStatus) throws SystemException, ApplicationException {

		CheckStatusDateEvent checkStatusDateEvent
			= createEvent(UcarEventKey.CHECK_STATUS_DATE, targetEvent.getUserInfo(), CheckStatusDateEvent.class);

//		checkStatusDateEvent.setT220001gPkBean(t220001gPkBean);
		checkStatusDateEvent.setT220107gPkBean(t220107gPKBean);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
		checkStatusDateEvent.setCheckStatusNo(checkStatusNo);
		checkStatusDateEvent.setDtStatus(dtStatus);

		return (CheckStatusDateEventResult)dispatchEvent(checkStatusDateEvent);
	}
	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため end
}
