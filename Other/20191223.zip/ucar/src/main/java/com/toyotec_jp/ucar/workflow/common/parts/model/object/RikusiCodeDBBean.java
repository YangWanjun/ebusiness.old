package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>陸支コードDBBean</strong>
 * <p>テーブル英名：TBV0213M</p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class RikusiCodeDBBean extends TecBean {

	/**
	 *
	 */
	private static final long	serialVersionUID	= -4469233974701059808L;

	/** 陸支コード */
	private String	cdRikusi;
	/** 陸支名称 */
	private String	kjRikusim;

	/**
	 *
	 */
	public RikusiCodeDBBean() {
		super();
	}

	/**
	 * cdRikusiを取得する。
	 * @return cdRikusi 陸支コード
	 */
	public String getCdRikusi() {
		return cdRikusi;
	}

	/**
	 * cdRikusiを設定する。
	 * @param cdRikusi 陸支コード
	 */
	public void setCdRikusi(String cdRikusi) {
		this.cdRikusi = cdRikusi;
	}

	/**
	 * kjRikusimを取得する。
	 * @return kjRikusim 陸支名称
	 */
	public String getKjRikusim() {
		return kjRikusim;
	}

	/**
	 * kjRikusimを設定する。
	 * @param kjRikusim 陸支名称
	 */
	public void setKjRikusim(String kjRikusim) {
		this.kjRikusim = kjRikusim;
	}

}
