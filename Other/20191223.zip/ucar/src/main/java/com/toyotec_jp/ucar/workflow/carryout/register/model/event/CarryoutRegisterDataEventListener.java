package com.toyotec_jp.ucar.workflow.carryout.register.model.event;

import java.sql.Timestamp;
import java.util.Date;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.exception.TecMessageException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst;
import com.toyotec_jp.ucar.workflow.carryout.common.CarryoutConst.CarryoutDAOKey;
import com.toyotec_jp.ucar.workflow.carryout.register.model.data.CarryoutRegisterDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CarryoutHaisoKouhoRenkeiEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusDateEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac002mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb009gBean;

/**
 * <strong>車両搬出情報登録イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/05 新規作成<br>
 * @since 1.00
 * @category [[車両搬出登録]]
 */
public class CarryoutRegisterDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		TecLogger.trace("insert registerData start");

		CarryoutRegisterDataEvent targetEvent = (CarryoutRegisterDataEvent) event;

		// DAOIF取得
		CarryoutRegisterDAOIF dao = getDAO(CarryoutDAOKey.REGISTER_DAO, targetEvent, CarryoutRegisterDAOIF.class);

		// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　start
		// 入力チェック
		if (targetEvent.getT220013gBean().getCdHstenpo().equals(targetEvent.getUserInfoBean().getCdTenpo())) {
			// 画面の行先店舗コードが自店舗の場合、エラー
			throw new TecExclusionException("行先が自店舗での登録はできません。");			
		}
		
		if (!targetEvent.getUserInfoBean().getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			ResultArrayList<Uccb009gBean> t220109gList = null;
			t220109gList = dao.selectCdZaitenpo(targetEvent.getT220013gBean().getCdKaisya(),
												targetEvent.getT220013gBean().getCdHanbaitn(),
												targetEvent.getT220013gBean().getDdHannyu(),
												targetEvent.getT220013gBean().getNoKanri(),
												targetEvent.getUserInfoBean().getCdTenpo());
			if (t220109gList.size() != 0) {				
				// 画面の行先店舗コードが車両搬出情報(店舗用)の在庫店舗コードと異なる場合、エラー
				if (!targetEvent.getT220013gBean().getCdHstenpo().equals(t220109gList.get(0).getCdZaitenpo())) {	
					String kjTentanms = dao.selectKjTentanms(targetEvent.getT220013gBean().getCdKaisya(),
															targetEvent.getT220013gBean().getCdHanbaitn(),
															t220109gList.get(0).getCdZaitenpo());
					throw new TecExclusionException("借用車のため（" + kjTentanms + "）以外搬出できません。");	
				}

				// 画面の他店貸出がチェックされている場合、エラー
				if (!targetEvent.getT220013gBean().getKbKasidasi().equals("")) {
					throw new TecExclusionException("借用車のため貸出はできません。");			
				}
			}			
		}
		// 2013.05.29 C.Ohta 追加　搬入拠点分散対応２　end

		// 加修フラグ取得
		ResultArrayList<Ucac002mBean> t220014mList
			= dao.selectKbKasyu(targetEvent.getT220013gBean().getCdKaisya(),
								targetEvent.getT220013gBean().getCdHanbaitn(),
								targetEvent.getT220013gBean().getKbSgyokt());

		if (t220014mList.size() > 0) {
			targetEvent.getT220013gBean().setKbKasyu(t220014mList.get(0).getKbKasyu());
		}

		Ucaa001gPKBean t220001gPKBean = new Ucaa001gPKBean(targetEvent.getT220013gBean().getCdKaisya(),
															targetEvent.getT220013gBean().getCdHanbaitn(),
															targetEvent.getT220013gBean().getDdHannyu(),
															targetEvent.getT220013gBean().getNoKanri());

		// 車両搬出情報テーブル内に既に該当データが存在するか？(Insert/Update分岐条件)
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//		ResultArrayList<T220013gBean> t220013gList = dao.selectT220013G(t220001gPKBean);
		ResultArrayList<Uccb009gBean> t220013gList = dao.selectT220013G(t220001gPKBean,
																		targetEvent.getUserInfoBean().getCdTenpo(),
																		targetEvent.getUserInfoBean().getKbScenter());
																		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		// 実行日時の生成
		Timestamp executeDate = new Timestamp(System.currentTimeMillis());

		String updateUserId = targetEvent.getUserInfo().getUserID();
		String updateAppId = CarryoutConst.APPID_CARRYOUT_REGISTER;

		if (t220013gList.size() > 0) {
			// 更新処理

			// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため start
			if (t220013gList.get(0).getDdTenukt() == null) {
				updateT220013gData(targetEvent, dao, executeDate, updateUserId, updateAppId);
			} else {
				throw new TecExclusionException("他店受取済のため登録できません。");
			}
			// 2013.05.27 T.Hayato 修正 搬入拠点分散対応2のため end

		} else {
			// 新規登録処理
			insertT220013gData(targetEvent, dao, executeDate, updateUserId, updateAppId);
		}

		// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため start
		// ステータスDB：会社コード・販売店コード・搬入日・管理番号
		//			   作成ユーザID・更新ユーザID・作成アプリID・更新アプリID
//		T220012gInputDataBean t220012gInputDataBean = new T220012gInputDataBean(t220001gPKBean.getCdKaisya(),
		Uccb007gInputDataBean t220012gInputDataBean = new Uccb007gInputDataBean(t220001gPKBean.getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																				t220001gPKBean.getCdHanbaitn(),
																				t220001gPKBean.getDdHannyu(),
																				t220001gPKBean.getNoKanri(),
																				// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																				targetEvent.getUserInfoBean().getCdTenpo(),
																				targetEvent.getUserInfoBean().getKbScenter(),
																				// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																				updateUserId,
																				updateUserId,
																				updateAppId,
																				updateAppId);

		// ステータスDB:ステータス21
		CheckStatusDateEventResult csdeResult
			= checkStatusDate(targetEvent, t220001gPKBean, 21, targetEvent.getT220013gBean().getDdHansyt());
		t220012gInputDataBean.setStrDtStatus21(csdeResult.getDtStatus());

		// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため start
		// ステータス09の取得
		Date dtStatus09 = dao.selectDtStatus09(t220001gPKBean,
												// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
												targetEvent.getUserInfoBean().getCdTenpo(),
												targetEvent.getUserInfoBean().getKbScenter());
												// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		if (dtStatus09 != null) {
			// ステータス09に日付がある場合：ステータス19に対してステータス21を同じ日付をセット
			t220012gInputDataBean.setStrDtStatus19(csdeResult.getDtStatus());
		}
		// 2012.03.26 T.Hayato 追加 ステータス19(TML全完了日) 更新のため end

		// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため start
		// ステータスDB:作業工程区分
		t220012gInputDataBean.setKbSgyokt(targetEvent.getT220013gBean().getKbSgyokt());

		// ステータスDB：商品化日数
		Date ddHansyt = DateUtils.getDate(targetEvent.getT220013gBean().getDdHansyt(), DateUtils.FORMAT_SHORT_SIMPLE);
		Date ddHannyu = DateUtils.getDate(targetEvent.getT220013gBean().getDdHannyu(), DateUtils.FORMAT_SHORT_SIMPLE);
		int differentDay = UcarUtils.getDifferentDay(ddHansyt, ddHannyu) + 1;

		t220012gInputDataBean.setNuSyohn(differentDay);
		// 2012.02.13 T.Hayato 追加 作業工程区分・商品化日数 設定のため end
		// 2016.2.8 H.Hara 商品化日数　オーバフロー抑止処理　start
		if(t220012gInputDataBean.getNuSyohn()>999){
			t220012gInputDataBean.setNuSyohn(999);
		}else if(t220012gInputDataBean.getNuSyohn()<0){
			t220012gInputDataBean.setNuSyohn(0);
		}
		// 2016.2.8 H.Hara 商品化日数　オーバフロー抑止処理　end		
		// ステータス更新処理
		SimpleExecuteResultBean updateStatusResult = dao.updateT220012G(t220012gInputDataBean, executeDate);
		if (updateStatusResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合はInsert処理

			// Insertの場合はステータス01をセット
			String strDtStatus01 = UcarUtils.getStringDateFormatShort(t220001gPKBean.getDdHannyu());
			t220012gInputDataBean.setStrDtStatus01(strDtStatus01);

			dao.insertT220012G(t220012gInputDataBean, executeDate);
		}
		// 2012.01.30 T.Hayato 追加 ステータスDB 変更のため end

		// 2013.02.12 T.Hayato 修正 配送候補連携処理 実行販売店限定のため start
//		if (UcarConst.CD_KAISYA.equals(t220001gPKBean.getCdKaisya())
		if (UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.CdTenpo.Scenter").equals(targetEvent.getUserInfoBean().getCdTenpo())	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			&& UcarConst.TOYOPET.equals(t220001gPKBean.getCdHanbaitn())) {

			// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため start
			// 配送候補連携処理
			CarryoutHaisoKouhoRenkeiEvent renkeiEvent
				= createEvent(UcarApplicationManager.UcarEventKey.CARRYOUT_HAISO_KOUHO_RENKEI,
								targetEvent.getUserInfo(),
								CarryoutHaisoKouhoRenkeiEvent.class);

			renkeiEvent.setUcaa001gPKBean(t220001gPKBean);
			renkeiEvent.setExecuteAppId(CarryoutConst.APPID_CARRYOUT_REGISTER);

			dispatchEvent(renkeiEvent);
			// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため end
		}
		// 2013.02.12 T.Hayato 修正 配送候補連携処理 実行販売店限定のため end

		// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため start
		CarryoutRegisterDataEventResult eventResult = new CarryoutRegisterDataEventResult();
		eventResult.setDtKosin(executeDate);
		// 2013.05.28 T.Hayato 追加 搬入拠点分散対応2のため end

		TecLogger.trace("insert registerData end");
		return eventResult;
	}

	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため start
	/**
	 * ステータスDB日付比較チェック
	 * @param targetEvent
	 * @param t220001gPkBean
	 * @param checkStatusNo
	 * @param dtStatus
	 * @return
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	public CheckStatusDateEventResult checkStatusDate(CarryoutRegisterDataEvent targetEvent,
														Ucaa001gPKBean t220001gPkBean,
														int checkStatusNo,
														String dtStatus) throws SystemException, ApplicationException {
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
		Uccb007gPKBean t220107gPKBean = new Uccb007gPKBean(t220001gPkBean.getCdKaisya(),
															t220001gPkBean.getCdHanbaitn(),
															t220001gPkBean.getDdHannyu(),
															t220001gPkBean.getNoKanri(),
															targetEvent.getUserInfoBean().getCdTenpo(),
															targetEvent.getUserInfoBean().getKbScenter());
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		CheckStatusDateEvent checkStatusDateEvent
			= createEvent(UcarEventKey.CHECK_STATUS_DATE, targetEvent.getUserInfo(), CheckStatusDateEvent.class);

//		checkStatusDateEvent.setT220001gPkBean(t220001gPkBean);
		checkStatusDateEvent.setT220107gPkBean(t220107gPKBean);	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
		checkStatusDateEvent.setCheckStatusNo(checkStatusNo);
		checkStatusDateEvent.setDtStatus(dtStatus);

		return (CheckStatusDateEventResult)dispatchEvent(checkStatusDateEvent);
	}
	// 2012.01.30 T.Hayato 追加 ステータスDB日付比較チェックのため end

	/**
	 * 車両搬出情報 更新処理
	 * @param targetEvent
	 * @param dao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void updateT220013gData(CarryoutRegisterDataEvent targetEvent,
									CarryoutRegisterDAOIF dao,
									Timestamp executeDate,
									String updateUserId,
									String updateAppId) throws TecExclusionException, TecMessageException, TecDAOException {

		targetEvent.getT220013gBean().setCdSksisya(updateUserId);
		targetEvent.getT220013gBean().setCdKsnsya(updateUserId);
		targetEvent.getT220013gBean().setCdSksiapp(updateAppId);
		targetEvent.getT220013gBean().setCdKsnapp(updateAppId);

		SimpleExecuteResultBean updateResult = dao.updateT220013G(targetEvent.getT220013gBean(),
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
																	targetEvent.getUserInfoBean().getCdTenpo(),
																	targetEvent.getUserInfoBean().getKbScenter(),
																	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
																	targetEvent.getT220013gDtKosin(),
																	executeDate);

		if (updateResult.getExecuteCount() == 0) {
			// 更新件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
		}
	}

	/**
	 * 車両搬出情報 新規登録処理
	 * @param targetEvent
	 * @param dao
	 * @param executeDate
	 * @param updateUserId
	 * @param updateAppId
	 * @throws TecExclusionException
	 * @throws TecMessageException
	 * @throws TecDAOException
	 */
	private void insertT220013gData(CarryoutRegisterDataEvent targetEvent,
			CarryoutRegisterDAOIF dao, Timestamp executeDate,
			String updateUserId, String updateAppId)
			throws TecExclusionException, TecMessageException, TecDAOException {

		targetEvent.getT220013gBean().setCdSksisya(updateUserId);
		targetEvent.getT220013gBean().setCdKsnsya(updateUserId);
		targetEvent.getT220013gBean().setCdSksiapp(updateAppId);
		targetEvent.getT220013gBean().setCdKsnapp(updateAppId);

		try {
			dao.insertT220013G(targetEvent.getT220013gBean(),
								// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
								targetEvent.getUserInfoBean().getCdTenpo(),
								targetEvent.getUserInfoBean().getKbScenter(),
								// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
					executeDate);
		} catch (TecDAOException e) {
			if (e.getMessage().indexOf("ORA-00001") != -1) {
				// 一意キー制約の場合は排他制御としてエラーをthrow
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_UPDATE));
			} else {
				throw e;
			}
		}
	}

}
