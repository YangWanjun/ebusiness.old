package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.sql.Timestamp;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.HaisoKouhoRenkeiDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean;

/**
 * <strong>配送候補連携DB操作用イベントリスナ(車両搬出用)</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/19 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class CarryoutHaisoKouhoRenkeiEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		CarryoutHaisoKouhoRenkeiEvent targetEvent = (CarryoutHaisoKouhoRenkeiEvent) event;

		// 実行日時の生成
		Timestamp executeDate 	= new Timestamp(System.currentTimeMillis());
		String executeUserId 	= targetEvent.getUserInfo().getUserID();

		HaisoKouhoRenkeiDAOIF dao
			= getDAO(UcarDAOKey.HAISO_KOUHO_RENKEI_DAO, event, HaisoKouhoRenkeiDAOIF.class);

		try {
			// 接続確認(アドイン)
			dao.selectTbjla24mCount(targetEvent.getUcaa001gPKBean().getCdKaisya(),
									targetEvent.getUcaa001gPKBean().getCdHanbaitn());


			// U-Car商品化システム側更新処理
			updateUcarData(dao,
							targetEvent.getUcaa001gPKBean(),
							executeDate,
							executeUserId,
							targetEvent.getExecuteAppId());

			// 削除処理
			deleteData(dao, targetEvent.getUcaa001gPKBean());

		} catch (TecDAOException e) {
			// 配送候補連携(アドイン)に接続できなかった場合
//			if (e.getMessage().indexOf(UcarConst.ERROR_NO_CONNECT) != -1) {

				// 配送候補連携BUFFERに登録処理
				executeT220015w(targetEvent, dao, executeDate, executeUserId);

//			} else {
//				// それ以外はエラー
//				throw e;
//			}
		}

		return null;
	}

	/**
	 * 配送候補連携BUFFER登録処理
	 * @param targetEvent
	 * @param dao
	 * @param executeDate
	 * @param executeUserId
	 * @throws TecDAOException
	 */
	private void executeT220015w(CarryoutHaisoKouhoRenkeiEvent targetEvent,
									HaisoKouhoRenkeiDAOIF dao,
									Timestamp executeDate,
									String executeUserId) throws TecDAOException {

		Ucac003wBean t220015wBean = new Ucac003wBean(targetEvent.getUcaa001gPKBean().getCdKaisya(),
														targetEvent.getUcaa001gPKBean().getCdHanbaitn(),
														targetEvent.getUcaa001gPKBean().getDdHannyu(),
														targetEvent.getUcaa001gPKBean().getNoKanri(),
														executeUserId,
														executeUserId,
														targetEvent.getExecuteAppId(),
														targetEvent.getExecuteAppId());

		t220015wBean.setCdNorikusi(UcarConst.CD_NORIKUSI_DEL);

		ResultArrayList<Ucac003wBean> t220015wList
			= dao.selectT220015w(targetEvent.getUcaa001gPKBean().getCdKaisya(),
								targetEvent.getUcaa001gPKBean().getCdHanbaitn(),
								targetEvent.getUcaa001gPKBean().getDdHannyu(),
								targetEvent.getUcaa001gPKBean().getNoKanri());

		if (t220015wList.size() > 0) {
			dao.updateT220015wDel(t220015wBean, executeDate);
		} else {
			dao.insertT220015w(t220015wBean, executeDate);
		}
	}

	/**
	 * U-Car商品化システム側更新処理
	 * @param dao
	 * @param t220001gPKBean
	 * @param executeDate
	 * @param executeUserId
	 * @param executeAppId
	 * @throws TecDAOException
	 */
	private void updateUcarData(HaisoKouhoRenkeiDAOIF dao,
								Ucaa001gPKBean t220001gPKBean,
								Timestamp executeDate,
								String executeUserId,
								String executeAppId) throws TecDAOException {

		// データ取得
		ResultArrayList<Tbjla24mBean> tbjla24mList
			= dao.selectTbjla24m(t220001gPKBean.getCdKaisya(),
								t220001gPKBean.getCdHanbaitn(),
								t220001gPKBean.getDdHannyu(),
								t220001gPKBean.getNoKanri(),
								true);

		for (Tbjla24mBean tbjla24mBean : tbjla24mList) {
			// 配送候補連携DB(アドイン)の内容を車両搬出情報・ステータスDBに更新する

			Ucac001gBean t220013gBean = new Ucac001gBean(tbjla24mBean.getCdKaisya(),
														tbjla24mBean.getCdHanbaitn(),
														tbjla24mBean.getDdHannyu(),
														tbjla24mBean.getNoKanri(),
														executeUserId,
														executeUserId,
														executeAppId,
														executeAppId);

			// 配送希望日をセット
			t220013gBean.setDdHiskib(tbjla24mBean.getDdHiskib());
			// 配送依頼№をセット
			t220013gBean.setNoHisiri(tbjla24mBean.getNoHisiri());
			// 配送備考をセット
			t220013gBean.setMjHansytbk(tbjla24mBean.getMjBikou());

			// 車両搬出情報更新
			dao.updateT220013g(t220013gBean, executeDate);

			Ucab007gBean t220012gBean = new Ucab007gBean(tbjla24mBean.getCdKaisya(),
														tbjla24mBean.getCdHanbaitn(),
														tbjla24mBean.getDdHannyu(),
														tbjla24mBean.getNoKanri(),
														executeUserId,
														executeUserId,
														executeAppId,
														executeAppId);

			// ステータス20をセット
			t220012gBean.setDtStatus20(tbjla24mBean.getDdHiskib());

			// ステータスDB更新
			dao.updateT220012g(t220012gBean, executeDate);

		}
	}

	/**
	 * 削除処理
	 * @param dao
	 * @throws TecDAOException
	 */
	private void deleteData(HaisoKouhoRenkeiDAOIF dao,
							Ucaa001gPKBean t220001gPKBean) throws TecDAOException {

		// 配送候補連携BUFFER削除
		dao.deleteT220015w(t220001gPKBean.getCdKaisya(),
							t220001gPKBean.getCdHanbaitn(),
							t220001gPKBean.getDdHannyu(),
							t220001gPKBean.getNoKanri());

		// 配送候補連携削除
		dao.deleteTbjla24m(t220001gPKBean.getCdKaisya(),
							t220001gPKBean.getCdHanbaitn(),
							t220001gPKBean.getDdHannyu(),
							t220001gPKBean.getNoKanri());
	}

}
