package com.toyotec_jp.ucar.workflow.carryin.register.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventException;
import jp.co.intra_mart.framework.base.event.EventManagerException;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecExclusionException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.register.model.data.RegisterDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.CheckStatusEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa002gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gPKBean;

/**
 * <strong>登録内容削除イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/14 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class DeleteRegisterDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		TecLogger.trace("delete registerData start");

		DeleteRegisterDataEvent targetEvent = (DeleteRegisterDataEvent) event;

		// DAOIF取得
		RegisterDAOIF dao = getDAO(CarryinDAOKey.REGISTER_DAO, targetEvent, RegisterDAOIF.class);

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		// 店舗の場合、データ区分を取得
		String kbData = "";
		if (!targetEvent.getUserInfoBean().getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)){
			kbData = dao.selectKbData(targetEvent.getT220001gPkBean().getCdKaisya(),
										targetEvent.getT220001gPkBean().getCdHanbaitn(),
										targetEvent.getT220001gPkBean().getDdHannyu(),
										targetEvent.getT220001gPkBean().getNoKanri(),
										targetEvent.getUserInfoBean().getCdTenpo());	
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end		

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		SimpleExecuteResultBean deleteResult001G = dao.deleteT220001G(targetEvent.getT220001gPkBean(),
																		targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																		targetEvent.getUserInfoBean().getKbScenter(),
																		kbData,										// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
																		targetEvent.getT220001gDtKosin());
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		if (deleteResult001G.getExecuteCount() == 0) {
			// 削除件数が0件の場合は排他エラー
			throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
		}

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
//		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
//		// 仕入種別情報取得
//		ResultArrayList<Ucaa002gBean> t220002gList = dao.selectT220002G(targetEvent.getT220001gPkBean(),
//																		targetEvent.getUserInfoBean().getKbScenter());
//		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
		// 仕入種別情報取得
		String kbScenter = "1";
		ResultArrayList<Ucaa002gBean> t220002gList = null;
		t220002gList = dao.selectT220002G(targetEvent.getT220001gPkBean(),
										UcarConst.KB_SCENTER_SCENTER);
		if (t220002gList.size() == 0) {
			kbScenter = "";
			t220002gList = dao.selectT220002G(targetEvent.getT220001gPkBean(),
											kbScenter);			
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		if (t220002gList.size() > 0) {

			String t220002gDtKosin = DateUtils.dateToString(t220002gList.get(0).getDtKosin(), DateUtils.DB_FORMAT_LONG_M);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			SimpleExecuteResultBean deleteResult002G = dao.deleteT220002G(targetEvent.getT220001gPkBean().getCdKaisya(),
																			targetEvent.getT220001gPkBean().getCdHanbaitn(),
																			targetEvent.getT220001gPkBean().getDdHannyu(),
																			targetEvent.getT220001gPkBean().getNoKanri(),
//																			targetEvent.getUserInfoBean().getKbScenter(),
																			kbScenter,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
																			t220002gDtKosin);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

			if (deleteResult002G.getExecuteCount() != t220002gList.size()) {
				// 削除対象件数と実行削除件数が異なる場合は排他エラー
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
			}
		}

		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// チェック内容情報取得
		ResultArrayList<Ucaa003gBean> t220003gList = dao.selectT220003G(targetEvent.getT220001gPkBean(),
																		targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
																		targetEvent.getUserInfoBean().getKbScenter(),
																		null);
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		if (t220003gList.size() > 0) {

			String t220003gDtKosin = DateUtils.dateToString(t220003gList.get(0).getDtKosin(), DateUtils.DB_FORMAT_LONG_M);

			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			SimpleExecuteResultBean deleteResult003G = dao.deleteT220003G(targetEvent.getT220001gPkBean().getCdKaisya(),
																			targetEvent.getT220001gPkBean().getCdHanbaitn(),
																			targetEvent.getT220001gPkBean().getDdHannyu(),
																			targetEvent.getT220001gPkBean().getNoKanri(),
																			targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
																			null,
																			targetEvent.getUserInfoBean().getKbScenter(),
																			t220003gDtKosin);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

			if (deleteResult003G.getExecuteCount() != t220003gList.size()) {
				// 削除対象件数と実行削除件数が異なる場合は排他エラー
				throw new TecExclusionException(TecMessageManager.getMessage(UcarMessage.EXCLUSION_DELETE));
			}
		}

		checkStatusDB(targetEvent);
//--2019.3.20 from
		dao.deleteT220007G(targetEvent.getT220001gPkBean().getCdKaisya(),
							targetEvent.getT220001gPkBean().getCdHanbaitn(),
							targetEvent.getT220001gPkBean().getDdHannyu(),
							targetEvent.getT220001gPkBean().getNoKanri(),
							targetEvent.getUserInfoBean().getCdTenpo(),
							targetEvent.getUserInfoBean().getKbScenter(),
							null
							);

//--2019.3.20 end
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// ステータスDB削除
		dao.deleteT220012G(targetEvent.getT220001gPkBean().getCdKaisya(),
							targetEvent.getT220001gPkBean().getCdHanbaitn(),
							targetEvent.getT220001gPkBean().getDdHannyu(),
							targetEvent.getT220001gPkBean().getNoKanri(),
							targetEvent.getUserInfoBean().getCdTenpo(),	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
							targetEvent.getUserInfoBean().getKbScenter());
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end

		TecLogger.trace("delete registerData end");
		return null;
	}

	/**
	 * ステータスDBチェック
	 * @param targetEvent
	 * @throws TecSystemException
	 * @throws EventManagerException
	 * @throws EventException
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void checkStatusDB(DeleteRegisterDataEvent targetEvent)
			throws TecSystemException, EventManagerException, EventException,
			SystemException, ApplicationException {

		CheckStatusEvent checkStatusEvent
			= createEvent(UcarEventKey.CHECK_STATUS, targetEvent.getUserInfo(), CheckStatusEvent.class);

//		T220001gPKBean t220001gPkBean = new T220001gPKBean(targetEvent.getT220001gPkBean().getCdKaisya(),
		Uccb007gPKBean t220001gPkBean = new Uccb007gPKBean(targetEvent.getT220001gPkBean().getCdKaisya(),	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
															targetEvent.getT220001gPkBean().getCdHanbaitn(),
															targetEvent.getT220001gPkBean().getDdHannyu(),
															targetEvent.getT220001gPkBean().getNoKanri(),
															// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
															targetEvent.getUserInfoBean().getCdTenpo(),	
															targetEvent.getUserInfoBean().getKbScenter());
//		checkStatusEvent.setT220001gPkBean(t220001gPkBean);
		checkStatusEvent.setT220107gPkBean(t220001gPkBean);
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		// ステータス03から
		checkStatusEvent.setStartDtStatus(3);
		// ステータス08まで
		checkStatusEvent.setEndDtStatus(8);
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end

		// イベント実行
		CheckStatusEventResult checkStatusResult
			= (CheckStatusEventResult)dispatchEvent(checkStatusEvent);

		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため start
		if (checkStatusResult.isExistDtStatus()) {
		// 2012.01.30 T.Hayato 修正 ステータスDB 変更のため end
			throw new TecApplicationException("次工程に入力があるため、削除できません。");
		}
	}

}
