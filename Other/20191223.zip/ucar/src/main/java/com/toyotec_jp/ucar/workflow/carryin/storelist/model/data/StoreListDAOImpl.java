package com.toyotec_jp.ucar.workflow.carryin.storelist.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListDataBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListPagingBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListParamBean;
import com.toyotec_jp.ucar.workflow.common.parts.AddonTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;

/**
 * <strong>展示店舗受取処理DAOの実装。</strong>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/02/24 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class StoreListDAOImpl extends UcarSharedDBDAO implements StoreListDAOIF {

	// SQL:全件数データ抽出
	private static final String SQL_ALLDATA = " AND (STATUS.DT_STATUS20 IS NOT NULL OR STATUS.DT_STATUS21 IS NOT NULL)";

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.storelist.model.data.StoreListDAOIF#selectStoreListPaging(java.lang.String, java.lang.String, com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListParamBean, java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	public StoreListPagingBean selectStoreListPaging(
			String cdKaisya,
			String cdHanbaitn,
			StoreListParamBean storeListParamBean,
			String sortParam,
            String sortOrder,
            String pageNo,
            String pageSize,
            boolean isInit) throws TecDAOException {

		// 2013.03.13 T.Hayato 修正 複数販売店化 修正のため start
		/** 展示店舗受取情報取得処理（展示店舗受取処理）SQL */
		final String SELECT_STORELISTDATA_SQL
			= "SELECT "
			+ "   SYARYOU_HANNYU.CD_KAISYA "
			+ " , SYARYOU_HANNYU.CD_HANBAITN "
			+ " , SYARYOU_HANNYU.DD_HANNYU "
			+ " , SYARYOU_HANNYU.NO_KANRI "
			+ " , STATUS.DT_STATUS20"
			+ " , SYARYOU_HANSYUTU.DD_HANSYT "
			+ " , SYARYOU_HANNYU.MJ_SYAMEI "
			+ " , SYARYOU_HANNYU.NO_SYADAI "
			+ " , TBV0231M.MJ_KUBUNNAI "
			+ " , SYARYOU_HANNYU.DD_SYODOTOR "
			+ " , STATUS.DT_STATUS11 "
			+ " , STATUS.DT_STATUS17 "
			+ " , STATUS.DT_STATUS14 "
			+ " , STATUS.DT_STATUS23 "
			+ " , STATUS.DT_STATUS25 "
			+ " , T220014M.MJ_SGYOKT "
			+ " , TBV0201M.KJ_TENTANMS "
			+ " , SYARYOU_HANNYU.MJ_BIKOU "
			+ " , to_char(SYARYOU_HANSYUTU.DT_KOSIN, 'yyyy-mm-dd hh24:mi:ss.ff3') DT_KOSIN "
			+ " , STATUS.DT_STATUS26 "
			+ " , STATUS.DT_STATUS21 "
			+ " , SYARYOU_HANNYU.CD_HANTENPO ";

		/** 商品化センター側テーブル SQL */
		final String FROM_STORELISTDATA_CENTER_SQL
			= "FROM "
			+ " T220001G SYARYOU_HANNYU "
			+ " INNER JOIN T220013G SYARYOU_HANSYUTU "
			+ "   ON SYARYOU_HANNYU.CD_KAISYA = SYARYOU_HANSYUTU.CD_KAISYA "
			+ "   AND SYARYOU_HANNYU.CD_HANBAITN = SYARYOU_HANSYUTU.CD_HANBAITN "
			+ "   AND SYARYOU_HANNYU.DD_HANNYU = SYARYOU_HANSYUTU.DD_HANNYU "
			+ "   AND SYARYOU_HANNYU.NO_KANRI = SYARYOU_HANSYUTU.NO_KANRI "
			+ " INNER JOIN T220012G STATUS "
			+ "   ON SYARYOU_HANNYU.CD_KAISYA = STATUS.CD_KAISYA "
			+ "   AND SYARYOU_HANNYU.CD_HANBAITN = STATUS.CD_HANBAITN "
			+ "   AND SYARYOU_HANNYU.DD_HANNYU = STATUS.DD_HANNYU "
			+ "   AND SYARYOU_HANNYU.NO_KANRI = STATUS.NO_KANRI ";

		/** 業販・U-Car店舗側テーブル SQL */
		final String FROM_STORELISTDATA_TENPO_SQL
			= "FROM "
			+ "  T220902V SYARYOU_HANNYU "
			+ "  INNER JOIN T220109G SYARYOU_HANSYUTU "
			+ "    ON SYARYOU_HANNYU.CD_KAISYA = SYARYOU_HANSYUTU.CD_KAISYA "
			+ "    AND SYARYOU_HANNYU.CD_HANBAITN = SYARYOU_HANSYUTU.CD_HANBAITN "
			+ "    AND SYARYOU_HANNYU.DD_HANNYU = SYARYOU_HANSYUTU.DD_HANNYU "
			+ "    AND SYARYOU_HANNYU.NO_KANRI = SYARYOU_HANSYUTU.NO_KANRI "
			+ "    AND SYARYOU_HANNYU.CD_HANTENPO = SYARYOU_HANSYUTU.CD_ZAITENPO "
			+ "  INNER JOIN T220107G STATUS "
			+ "    ON SYARYOU_HANNYU.CD_KAISYA = STATUS.CD_KAISYA "
			+ "    AND SYARYOU_HANNYU.CD_HANBAITN = STATUS.CD_HANBAITN "
			+ "    AND SYARYOU_HANNYU.DD_HANNYU = STATUS.DD_HANNYU "
			+ "    AND SYARYOU_HANNYU.NO_KANRI = STATUS.NO_KANRI "
			+ "    AND SYARYOU_HANNYU.CD_HANTENPO = STATUS.CD_ZAITENPO ";

		String JOIN_STORELISTDATA_SQL
			= " LEFT JOIN (SELECT CD_KAISYA, MJ_BLOCKID, MJ_KUBUNID, CD_KUBUN, MJ_KUBUNNAI FROM " + AddonTableManager.getCodeKubun(cdHanbaitn) + ") TBV0231M "
			+ "   ON SYARYOU_HANNYU.CD_KAISYA = TBV0231M.CD_KAISYA "
			+ "   AND SYARYOU_HANNYU.CD_TOSYOKU = TBV0231M.CD_KUBUN "
			+ "   AND TBV0231M.MJ_BLOCKID = '03' "
			+ "   AND TBV0231M.MJ_KUBUNID = '0108' "
			+ " LEFT JOIN (SELECT CD_KAISYA, CD_HANBAITN, KB_SGYOKT, MJ_SGYOKT FROM T220014M) T220014M "
			+ "   ON STATUS.CD_KAISYA = T220014M.CD_KAISYA "
			+ "   AND STATUS.CD_HANBAITN = T220014M.CD_HANBAITN "
			+ "   AND STATUS.KB_SGYOKT = T220014M.KB_SGYOKT "
			+ " LEFT JOIN (SELECT CD_KAISYA, CD_TENPO, KJ_TENTANMS FROM " + AddonTableManager.getKyoutuTenpo(cdHanbaitn) + ") TBV0201M "
			/*2019.04.29 T.Osada Start
			+ "   ON SYARYOU_HANSYUTU.CD_KAISYA = TBV0201M.CD_KAISYA "
			+ "   AND SYARYOU_HANSYUTU.CD_HSTENPO = TBV0201M.CD_TENPO "
			*/
			+ "   ON SYARYOU_HANSYUTU.CD_HSTENPO = TBV0201M.CD_TENPO "
			// 2019.04.29 T.Osada end
			+ "WHERE "
/*2019.3.20 from			
			+ "      SYARYOU_HANNYU.CD_KAISYA   = ? "
			+ "  AND SYARYOU_HANNYU.CD_HANBAITN = ? ";
*/
			+ "      SYARYOU_HANNYU.CD_KAISYA   = ? ";
		if(cdHanbaitn.equals(UcarConst.WCOROLLA)){
			JOIN_STORELISTDATA_SQL += "  AND SYARYOU_HANNYU.CD_HANBAITN = ? ";
		}else{
			JOIN_STORELISTDATA_SQL += "  AND SYARYOU_HANNYU.CD_HANBAITN != ? ";
		}
//2019.3.20 to
		// 2013.03.13 T.Hayato 修正 複数販売店化 修正のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);


		String strCenterSql = "";
		// パラメータセット<条件>
		paramBean.setString(cdKaisya);      // 会社コード
// 2019.04.05 T.Osada Start
		//paramBean.setString(cdHanbaitn);    // 販売店コード
		paramBean.setString(UcarConst.WCOROLLA);	// 販売店コード
// 2019.04.05 T.Osada End

		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		// 検索条件
		StringBuilder sqlCenterCondition = createSqlCondition(storeListParamBean, paramBean);

		strCenterSql = SELECT_STORELISTDATA_SQL
					+ " , '" + UcarConst.KB_DATA_HANNYU + "' KB_DATA "
					+ FROM_STORELISTDATA_CENTER_SQL
					+ JOIN_STORELISTDATA_SQL
					+ sqlCenterCondition.toString();

		String strTenpoSql = "";
		paramBean.setString(cdKaisya);      // 会社コード
/*2019.3.20		
		paramBean.setString(cdHanbaitn);    // 販売店コード
*/
		paramBean.setString(UcarConst.WCOROLLA);	// 販売店コード
//2019.3.20
		StringBuilder sqlTenpoCondition = createSqlCondition(storeListParamBean, paramBean);
		strTenpoSql = SELECT_STORELISTDATA_SQL
					+ " , SYARYOU_HANNYU.KB_DATA "
					+ FROM_STORELISTDATA_TENPO_SQL
					+ JOIN_STORELISTDATA_SQL
					+ sqlTenpoCondition.toString();

		paramBean.setSql(strCenterSql + " UNION " + strTenpoSql);
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end

		StringBuilder orderSql = new StringBuilder();
		// 並び順がない場合は昇順とする
		if ("".equals(sortOrder) || sortOrder == null) {
			sortOrder = "ASC";
		}
		// ソート条件
		if (!"".equals(sortParam) ) {
			if ("dd_hansyt".equals(sortParam)) {
				// 搬出日
				orderSql.append(" ORDER BY CD_KAISYA "   +
						        "         ,CD_HANBAITN " +
						        "         ,DD_HANSYT "   + sortOrder +
						        "         ,DD_HANNYU "   +
						        "         ,NO_KANRI ");
			}
		} else {
			orderSql.append(" ORDER BY CD_KAISYA "   +
			                "         ,CD_HANBAITN " +
			                "         ,DD_HANSYT "   + sortOrder +
			                "         ,DD_HANNYU "   +
			                "         ,NO_KANRI ");
		}
		// ソート条件
		paramBean.setOrderSql(orderSql.toString());

		// ページ設定
		paramBean.setPageNo(Integer.parseInt(pageNo));

		paramBean.setPageSize(Integer.parseInt(pageSize));

		StoreListPagingBean resultPagingBean = executeSimplePagingQuery(paramBean, StoreListPagingBean.class, StoreListDataBean.class);

		return resultPagingBean;
	}

	/**
	 * @param storeListParamBean
	 * @param paramBean
	 * @return
	 */
	private StringBuilder createSqlCondition(
			StoreListParamBean storeListParamBean,
			SimpleQueryParamBean paramBean) {
		StringBuilder sqlCondition = new StringBuilder();

		if (!storeListParamBean.getCdTenpo().equals("")) {
			// 店舗コード
			// 2014.5.1 H.Yamashita 店舗CD2桁対応 start
			//sqlCondition.append(" AND SYARYOU_HANSYUTU.CD_HSTENPO = ? ");
			//paramBean.setString(storeListParamBean.getCdTenpo());
			sqlCondition.append(" AND SYARYOU_HANSYUTU.CD_HSTENPO = '" + storeListParamBean.getCdTenpo() + "'");
			// 2014.5.1 H.Yamashita 店舗CD2桁対応 end
		}
		if (!storeListParamBean.getDdHansytFrom().equals("")) {
			// 搬出日
			sqlCondition.append(" AND SYARYOU_HANSYUTU.DD_HANSYT BETWEEN ? AND ? ");
			paramBean.setString(storeListParamBean.getDdHansytFrom().replace("/", ""));  // 搬出日(From)
			paramBean.setString(storeListParamBean.getDdHansytTo().replace("/", ""));    // 搬出日(To)
		}
		if (!storeListParamBean.getNoSyadai().equals("")) {
			// フレームNo.
			sqlCondition.append(" AND SYARYOU_HANNYU.NO_SYADAI LIKE '%" + storeListParamBean.getNoSyadai() + "%'");
		}
		// 2012.04.05 A.Yoshinami 追加 受取チェック start
		if (storeListParamBean.getArrayChkUketori() != null) {

			String sqlUketori = "";

			// 画面のchk_uketoriの存在チェック
			for (int i = 0; i < storeListParamBean.getArrayChkUketori().length; i++) {
				String chkUketori = storeListParamBean.getArrayChkUketori()[i];

				// 未完了にチェック
				if (chkUketori.equals(CarryinConst.UKETORI_MIKANRYOU)) {
					sqlUketori = " AND (STATUS.DT_STATUS20 IS NOT NULL OR STATUS.DT_STATUS21 IS NOT NULL) AND STATUS.DT_STATUS26 IS NULL ";
				}
				// 完了にチェック
				if (chkUketori.equals(CarryinConst.UKETORI_KANRYOU)) {
					if ("".equals(sqlUketori)) {
						sqlUketori = " AND STATUS.DT_STATUS26 IS NOT NULL ";
					} else {
						sqlUketori = SQL_ALLDATA;
					}
				}
			}
			sqlCondition.append(sqlUketori);
		} else {
			sqlCondition.append(SQL_ALLDATA);
		}
		// 2012.04.05 A.Yoshinami 追加 受取チェック end

//		if (!storeListParamBean.getChkUketori().equals("")) {
//			// 受取済
//			sqlCondition.append(" AND STATUS.DT_STATUS26 IS NOT NULL ");
//		} else if (isInit) {
//			// 初期表示
//			sqlCondition.append(" AND (STATUS.DT_STATUS20 IS NOT NULL OR STATUS.DT_STATUS21 IS NOT NULL) AND STATUS.DT_STATUS26 IS NULL ");
//		} else {
//			// 検索処理
//			sqlCondition.append(" AND (STATUS.DT_STATUS20 IS NOT NULL OR STATUS.DT_STATUS21 IS NOT NULL)");
//		}
		return sqlCondition;
	}

	public SimpleExecuteResultBean updateDdTenukt(
			Ucaa001gPKBean t220001gPKBean,
			String cdZaitenpo,
			String dtKosin,
			String updateUserId,
			String updateAppId,
			Timestamp executeDate,
            String kbData) throws TecDAOException {

		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		String executeSql
			= "UPDATE ";

		if (UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			// 搬出元が商品化センターの場合
			executeSql += " T220013G ";
		} else {
			// 搬出元が業販・U-Car店舗の場合
			executeSql += " T220109G ";
		}

		executeSql
			+= "SET "
			+ "     DD_TENUKT = SYSDATE "
			+ "  ,  DT_KOSIN  = ? "
			+ "  ,  CD_KSNSYA = ? "
			+ "  ,  CD_KSNAPP = ? "
			+ "WHERE "
			+ "      CD_KAISYA 	 = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		// パラメータセット<値>
		paramBean.setTimestamp(executeDate);                // データ更新日時
		paramBean.setString(updateUserId);                  // 更新ユーザID
		paramBean.setString(updateAppId);                   // 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220001gPKBean.getCdKaisya());    // 会社コード
		paramBean.setString(t220001gPKBean.getCdHanbaitn());  // 販売店コード
		paramBean.setString(t220001gPKBean.getDdHannyu());    // 搬入日
		paramBean.setString(t220001gPKBean.getNoKanri());     // 管理番号
		paramBean.setString(dtKosin);                         // データ更新日時

		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (!UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			// 搬出元が業販・U-Car店舗の場合
			executeSql += "  AND CD_ZAITENPO = ? ";
			paramBean.setString(cdZaitenpo);					// データ更新日時
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end

		paramBean.setSql(executeSql);
		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	public SimpleExecuteResultBean updateStatus26(
			Ucaa001gPKBean t220001gPKBean,
			String cdZaitenpo,
            String updateUserId,
            String updateAppId,
            Timestamp executeDate,
            String kbData) throws TecDAOException {

		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		String executeSql
			= "UPDATE ";

		if (UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			// 搬出元が商品化センターの場合
			executeSql += " T220012G ";
		} else {
			// 搬出元が業販・U-Car店舗の場合
			executeSql += " T220107G ";
		}

		executeSql
			+= "SET "
			+ "     DT_STATUS26 = SYSDATE "
			+ "  ,  DT_KOSIN  = ? "
			+ "  ,  CD_KSNSYA = ? "
			+ "  ,  CD_KSNAPP = ? "
			+ "WHERE "
			+ "      CD_KAISYA 	 = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? ";
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		// パラメータセット<値>
		paramBean.setTimestamp(executeDate);                // データ更新日時
		paramBean.setString(updateUserId);                  // 更新ユーザID
		paramBean.setString(updateAppId);                   // 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220001gPKBean.getCdKaisya());    // 会社コード
		paramBean.setString(t220001gPKBean.getCdHanbaitn());  // 販売店コード
		paramBean.setString(t220001gPKBean.getDdHannyu());    // 搬入日
		paramBean.setString(t220001gPKBean.getNoKanri());     // 管理番号

		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため start
		if (!UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			// 搬出元が業販・U-Car店舗の場合
			executeSql += "  AND CD_ZAITENPO = ? ";
			paramBean.setString(cdZaitenpo);				// データ更新日時
		}
		// 2013.04.29 T.Hayato 修正 搬入拠点分散対応2のため end

		paramBean.setSql(executeSql);
		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため start
	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.storelist.model.data.StoreListDAOIF#insertT220108g(java.lang.String, java.lang.String, java.lang.String, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean insertT220108g(Ucaa001gPKBean t220001gPKBean,
													String cdUketenpo,
													String cdHantenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate,
													String kbData) throws TecDAOException {

		String executeSql
			= "INSERT "
			+ "INTO T220108G( "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , CD_UKETENPO "
			+ "  , DD_UKETORI "
			+ "  , CD_OKYAKU "
			+ "  , KJ_OKYAKUM "
			+ "  , CD_NORIKUSI "
			+ "  , KB_NOSYASYU "
			+ "  , CD_NOGYOTAI "
			+ "  , NO_NOSEIRI "
			+ "  , MJ_SITKATA "
			+ "  , NO_SYADAI "
			+ "  , MJ_SYAMEI "
			+ "  , DD_SYODOTOR "
			+ "  , DD_SYKNMANR "
			+ "  , NO_KATARUIB "
			+ "  , CD_TOSYOKU "
			+ "  , NU_SOUKUKM "
			+ "  , CD_SIRTENPO "
			+ "  , CD_SDTAN "
			+ "  , KI_NYUKOK "
			+ "  , CD_KOZINZYHO "
			+ "  , NO_ZYUTYU "
			+ "  , MJ_UKETAN "
			+ "  , NO_SYARYOU "
			+ "  , DD_SIIRE "
			+ "  , DD_INKANKGN "
			+ "  , MJ_BIKOU "
			+ "  , DT_ZAIKO "
			+ "  , DT_KOUTEI "
			+ "  , DT_SOUBI "
			+ "  , DT_SHAKO "
			+ "  , DT_ZEI "
			+ "  , DT_TYUMON "
			+ "  , DD_1JTOROKU "	//2015.5.9
			+ "  , NO_UKETAN "		//2015.5.9
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , ? "
			+ "  , ? "
			+ "  , CD_OKYAKU "
			+ "  , KJ_OKYAKUM "
			+ "  , CD_NORIKUSI "
			+ "  , KB_NOSYASYU "
			+ "  , CD_NOGYOTAI "
			+ "  , NO_NOSEIRI "
			+ "  , MJ_SITKATA "
			+ "  , NO_SYADAI "
			+ "  , MJ_SYAMEI "
			+ "  , DD_SYODOTOR "
			+ "  , DD_SYKNMANR "
			+ "  , NO_KATARUIB "
			+ "  , CD_TOSYOKU "
			+ "  , NU_SOUKUKM "
			+ "  , CD_SIRTENPO "
			+ "  , CD_SDTAN "
			+ "  , KI_NYUKOK "
			+ "  , CD_KOZINZYHO "
			+ "  , NO_ZYUTYU "
			+ "  , MJ_UKETAN "
			+ "  , NO_SYARYOU "
			+ "  , DD_SIIRE "
			+ "  , DD_INKANKGN "
			+ "  , MJ_BIKOU "
			+ "  , null " // 在庫カード印刷日時
			+ "  , null " // 工程表印刷日時
			+ "  , null " // 装備チェックシート印刷日時
			+ "  , null " // 車庫証明印刷日
			+ "  , null " // 税申告書印刷日
			+ "  , null " // 注文書印刷日時
			+ "  , DD_1JTOROKU "	//2015.5.9
			+ "  , NO_UKETAN "		//2015.5.9
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "FROM ";

		if (UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			// 搬出元が商品化センターの場合
			executeSql += "  T220001G ";
		} else {
			// 搬出元が業販・U-Car店舗の場合
			executeSql += "  T220902V ";
		}

		executeSql
			+= "WHERE "
			+ "  CD_KAISYA = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU = ? "
			+ "  AND NO_KANRI = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(null);

		// パラメータセット<値>
		paramBean.setString(cdUketenpo);		// 受取店舗コード(受取側)
		paramBean.setString(DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE));	// 受取日
		paramBean.setTimestamp(executeDate);	// データ作成日時
		paramBean.setTimestamp(executeDate);	// データ更新日時
		paramBean.setString(updateUserId);		// 作成ユーザID
		paramBean.setString(updateUserId);		// 更新ユーザID
		paramBean.setString(updateAppId);		// 作成アプリID
		paramBean.setString(updateAppId);		// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220001gPKBean.getCdKaisya());		// 会社コード
		paramBean.setString(t220001gPKBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220001gPKBean.getDdHannyu());		// 搬入日
		paramBean.setString(t220001gPKBean.getNoKanri());		// 管理番号

		if (!UcarConst.KB_DATA_HANNYU.equals(kbData)) {
			// 搬出元が業販・U-Car店舗の場合
			executeSql += "  AND CD_HANTENPO = ? ";
			paramBean.setString(cdHantenpo);	// 搬入店舗コード・受取店舗コード(搬出側)
		}

		paramBean.setSql(executeSql);
		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.storelist.model.data.StoreListDAOIF#insertT220107g(com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean, java.lang.String, java.lang.String, java.lang.String, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean insertT220107g(Ucaa001gPKBean t220001gPKBean,
													String cdTenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate) throws TecDAOException {

		String executeSql
			= "INSERT "
			+ "INTO T220107G( "
			+ "  CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "  , CD_ZAITENPO "
			+ "  , DT_STATUS09 "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "  ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<値>
		paramBean.setString(t220001gPKBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220001gPKBean.getCdHanbaitn());// 販売店コード
		paramBean.setString(t220001gPKBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220001gPKBean.getNoKanri());	// 管理番号
		paramBean.setString(cdTenpo);			// 在庫店舗コード
		paramBean.setTimestamp(executeDate);	// ステータス09

		paramBean.setTimestamp(executeDate);	// データ作成日時
		paramBean.setTimestamp(executeDate);	// データ更新日時
		paramBean.setString(updateUserId);		// 作成ユーザID
		paramBean.setString(updateUserId);		// 更新ユーザID
		paramBean.setString(updateAppId);		// 作成アプリID
		paramBean.setString(updateAppId);		// 更新アプリID

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.storelist.model.data.StoreListDAOIF#updateT220107g(java.lang.String, java.lang.String, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220107g(Ucaa001gPKBean t220001gPKBean,
													String cdTenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate) throws TecDAOException {

		String executeSql
			= "UPDATE T220107G "
			+ "SET "
			+ "  DT_STATUS21 = ? "
			+ "  , DT_STATUS26 = ? "
			+ "  , DT_KOSIN = ? "
			+ "  , CD_KSNSYA = ? "
			+ "  , CD_KSNAPP = ? "
			+ "WHERE "
			+ "  CD_KAISYA = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU = ? "
			+ "  AND NO_KANRI = ? "
			+ "  AND CD_ZAITENPO = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<値>
		paramBean.setDate(null);				// ステータス21
		paramBean.setDate(null);				// ステータス26
		paramBean.setTimestamp(executeDate);	// データ更新日時
		paramBean.setString(updateUserId);		// 更新ユーザID
		paramBean.setString(updateAppId);		// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220001gPKBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220001gPKBean.getCdHanbaitn());// 販売店コード
		paramBean.setString(t220001gPKBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220001gPKBean.getNoKanri());	// 管理番号
		paramBean.setString(cdTenpo);			// 在庫店舗コード

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.storelist.model.data.StoreListDAOIF#updateT220109g(java.lang.String, java.lang.String, java.sql.Timestamp)
	 */
	@Override
	public SimpleExecuteResultBean updateT220109g(Ucaa001gPKBean t220001gPKBean,
													String cdTenpo,
													String updateUserId,
													String updateAppId,
													Timestamp executeDate) throws TecDAOException {

		String executeSql
			= "UPDATE T220109G "
			+ "SET "
			+ "  DD_HANSYT = ? "
			+ "  , DD_TENUKT = ? "
			+ "  , KB_KASIDASI = ? "	// 2013.05.30 C.Ohta 追加 搬入拠点分散対応2のため
			+ "  , DT_KOSIN = ? "
			+ "  , CD_KSNSYA = ? "
			+ "  , CD_KSNAPP = ? "
			+ "WHERE "
			+ "  CD_KAISYA = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU = ? "
			+ "  AND NO_KANRI = ? "
			+ "  AND CD_ZAITENPO = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(executeSql);

		// パラメータセット<値>
		paramBean.setString(null);				// 搬出日
		paramBean.setDate(null);				// 店舗受取日
		paramBean.setString(null);				// 他店貸出区分	// 2013.05.30 C.Ohta 追加 搬入拠点分散対応2のため
		paramBean.setTimestamp(executeDate);	// データ更新日時
		paramBean.setString(updateUserId);		// 更新ユーザID
		paramBean.setString(updateAppId);		// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220001gPKBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220001gPKBean.getCdHanbaitn());// 販売店コード
		paramBean.setString(t220001gPKBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220001gPKBean.getNoKanri());	// 管理番号
		paramBean.setString(cdTenpo);			// 在庫店舗コード

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}
	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため end
}