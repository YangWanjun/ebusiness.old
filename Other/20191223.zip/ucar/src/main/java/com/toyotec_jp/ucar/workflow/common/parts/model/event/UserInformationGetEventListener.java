package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UserInformationDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>ユーザ情報取得イベントリスナ。</strong>
 * <p>
 * イベントで指定したユーザIDに対応するユーザ情報ビーンを返却する。
 * </p>
 * @author Y.M(TEC)
 * @version 1.00 2011/11/18 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UserInformationGetEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {
		UserInformationGetEvent targetEvent = (UserInformationGetEvent)event;
		String targetUserID = targetEvent.getEmployeeCd();
		UserInformationDAOIF daoIF = getDAO(UcarDAOKey.USER_INFO_DAO, event, UserInformationDAOIF.class);

		UserInformationBean userInfoBean = null;
		// ユーザ情報取得
		userInfoBean = daoIF.getUserInformation(targetUserID);

		// 処理結果がNullの場合は空のユーザ情報を返却
		if(userInfoBean == null){
			userInfoBean = new UserInformationBean();
		}

		// 結果を返却
		return userInfoBean;
	}

}
