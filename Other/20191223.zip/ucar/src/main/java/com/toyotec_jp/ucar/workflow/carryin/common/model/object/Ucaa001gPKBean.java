package com.toyotec_jp.ucar.workflow.carryin.common.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>車両搬入情報 プライマリーキーBean</strong>
 * <p>
 * 車両搬入情報(T220001G)の主キー情報
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/10 新規作成<br>
 * @since 1.00
 * @category [[車両搬入(共通)]]
 */
public class Ucaa001gPKBean extends TecBean implements Cloneable {

	private static final long serialVersionUID = -588485238257856717L;

	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	/** 搬入日 */
	private String	ddHannyu;
	/** 管理番号 */
	private String	noKanri;
//2016.9.5 FROM
	/** 販売店舗コード
	  	(pkではないが販売店コードと同じタイミングでログインIDから取得)
	 **/
	private String cdHantenpo;
//2016.9.5 TO

	/**
	 * コンストラクタ
	 */
	public Ucaa001gPKBean() {
		super();
	}

	/**
	 * コンストラクタ
	 * @param cdKaisya 		会社コード
	 * @param cdHanbaitn	販売店コード
	 * @param cdHantenpo   販売店舗コード
	 * @param ddHannyu		搬入日
	 * @param noKanri		管理番号
	 */
	public Ucaa001gPKBean(String cdKaisya, String cdHanbaitn, String ddHannyu, String noKanri) {
		super();
		this.cdKaisya = cdKaisya;
		this.cdHanbaitn = cdHanbaitn;
		this.ddHannyu = ddHannyu;
		this.noKanri = noKanri;
	}
//2016.9.5 from
	/**
	 * 販売店コード,販売店舗コードの設定場所が同一の為、同じ場所に保持する
	 */
	public Ucaa001gPKBean(String cdKaisya, String cdHanbaitn, String cdHantenpo, String ddHannyu, String noKanri) {
		super();
		this.cdKaisya = cdKaisya;
		this.cdHanbaitn = cdHanbaitn;
		this.cdHantenpo = cdHantenpo;
		this.ddHannyu = ddHannyu;
		this.noKanri = noKanri;
	}
//2016.9.5 to	
	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn 販売店コード
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn 販売店コード
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}
//2016.9.5 FROM
	public String getCdHantenpo() {
		return cdHantenpo;
	}
	public void setCdHantenpo(String cdHantenpo) {
		this.cdHantenpo = cdHantenpo;
	}
//2016.9.5 TO
	/**
	 * ddHannyuを取得する。
	 * @return ddHannyu 搬入日
	 */
	public String getDdHannyu() {
		return ddHannyu;
	}

	/**
	 * ddHannyuを設定する。
	 * @param ddHannyu 搬入日
	 */
	public void setDdHannyu(String ddHannyu) {
		this.ddHannyu = ddHannyu;
	}

	/**
	 * noKanriを取得する。
	 * @return noKanri 管理番号
	 */
	public String getNoKanri() {
		return noKanri;
	}

	/**
	 * noKanriを設定する。
	 * @param noKanri 管理番号
	 */
	public void setNoKanri(String noKanri) {
		this.noKanri = noKanri;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Ucaa001gPKBean clone() {
		try {
			return (Ucaa001gPKBean)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new InternalError(e.toString());
		}
	}

}
