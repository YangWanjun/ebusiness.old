package com.toyotec_jp.ucar.workflow.carcheck.common;

import com.toyotec_jp.im_common.TecApplicationManager.TecApplicationIdIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecServiceIdIF;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;

/**
 * <strong>車両チェック関連共通定数管理クラス。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/04 新規作成<br>
 * @since 1.00
 * @category [[車両チェック(共通)]]
 */
public class CarCheckConst {

	/** パッケージカテゴリ:車両チェック */
	public static final String PKG_CAT_CARCHECK = ".carcheck";

	/** 車両チェック関連パッケージルート */
	public static final String CARCHECK_ROOT
		= UcarApplicationManager.WF_ROOT + PKG_CAT_CARCHECK;

	/** 車両チェックパッケージルート */
	public static final String CARCHECK_SUB_ROOT
		= CARCHECK_ROOT + ".carcheck";

	/** アプリID:車両チェック-入庫検査 */
	public static final String APPID_CARCHECK_ENTERCHECK
		= UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.carcheck.EnterCheck");
	/** アプリID:車両チェック-作業仕分 */
	public static final String APPID_CARCHECK_WORKSORT
		= UcarApplicationManager.getConfigValue(UcarApplicationManager.WF_ROOT + ".appid.carcheck.WorkSort");

	// 2012.01.30 T.Hayato 修正 システム全体 共通化 start
	/** 入庫検査：入庫検査未完了 */
	public static final String ENTERCHECK_INCOMPLETE 	= UcarConst.RDO_KUBUN_INCOMPLETE;
	/** 入庫検査：入庫検査完了 */
	public static final String ENTERCHECK_COMPLETE 	= UcarConst.RDO_KUBUN_COMPLETE;
	/** 入庫検査：保留 */
	public static final String ENTERCHECK_RESERVE 	= UcarConst.RDO_KUBUN_RESERVE;

	/** 作業仕分：仕分未完了 */
	public static final String WORKSORT_INCOMPLETE 	= UcarConst.RDO_KUBUN_INCOMPLETE;
	/** 作業仕分：仕分完了 */
	public static final String WORKSORT_COMPLETE 		= UcarConst.RDO_KUBUN_COMPLETE;
	/** 作業仕分：保留 */
	public static final String WORKSORT_RESERVE 		= UcarConst.RDO_KUBUN_RESERVE;
	// 2012.01.30 T.Hayato 修正 システム全体 共通化 end

	/** インスタンスを生成しない。 */
	private CarCheckConst(){
	}

	/** 車両チェック関連タイトル */
	public enum CarCheckTitle {
		/** 入庫検査 */
		ENTER_CHECK(".EnterCheck"),
		/** 作業仕分 */
		WORK_SORT(".WorkSort"),
		;
		private String titleLabel;
		private CarCheckTitle(String key){
			this.titleLabel = UcarApplicationManager.getConstantValue(
					UcarApplicationManager.WF_ROOT + ".title" + PKG_CAT_CARCHECK + key);
		}
		public String toString(){
			return titleLabel;
		}
		/**
		 * 画面タイトルを取得する。
		 * @return titleLabel 画面タイトル
		 */
		public String getTitleLabel() {
			return titleLabel;
		}
	}

	/** 車両チェック関連メニューID */
	public enum CarCheckMenuId {
		/** 入庫検査 */
		ENTER_CHECK(".CarCheck.ENTERCHECK"),
		/** 作業仕分 */
		WORK_SORT(".CarCheck.WORKSORT"),
		;
		private String menuId;
		private CarCheckMenuId(String key){
			this.menuId = UcarApplicationManager.getConfigValue(
					UcarApplicationManager.WF_ROOT + ".menuid" + PKG_CAT_CARCHECK + key);
		}
		public String toString(){
			return menuId;
		}
		/**
		 * メニューIDを取得する。
		 * @return menuId メニューID
		 */
		public String getMenuId() {
			return menuId;
		}
	}

	/** 車両チェック関連アプリケーションID */
	public enum CarCheckApplicationId implements TecApplicationIdIF {
		/** 車両チェック */
		CAR_CHECK(CARCHECK_SUB_ROOT + ".CarCheck"),
		;
		private String applicationId;
		private CarCheckApplicationId(String applicationId){
			this.applicationId = applicationId;
		}
		public String toString(){
			return applicationId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
	}

	/** 車両チェック関連サービスID */
	public enum CarCheckServiceId implements TecServiceIdIF {
		/** 初期処理 */
		CAR_CHECK_INIT(CarCheckApplicationId.CAR_CHECK, "CarCheckInit"),
		/** 検索処理 */
		CAR_CHECK_SEARCH(CarCheckApplicationId.CAR_CHECK, "CarCheckSearch"),
		/** クリア処理 */
		CAR_CHECK_CLEAR(CarCheckApplicationId.CAR_CHECK, "CarCheckClear"),
		/** ソート処理 */
		CAR_CHECK_SORTING(CarCheckApplicationId.CAR_CHECK, "CarCheckSorting"),
		/** 登録処理 */
		CAR_CHECK_REGISTER(CarCheckApplicationId.CAR_CHECK, "CarCheckRegister"),
		/** 取消処理 */
		CAR_CHECK_CANCEL(CarCheckApplicationId.CAR_CHECK, "CarCheckCancel"),
		// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
		/** 選択処理 */
		CAR_CHECK_SELECT(CarCheckApplicationId.CAR_CHECK, "CarCheckSelect"),
		// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end

		/** 登録＆車両搬出表印刷処理 */
		CAR_CHECK_REGISTER_AND_DOWNLOAD(CarCheckApplicationId.CAR_CHECK, "CarCheckRegisterAndDownload"),
		/** 車両搬出表印刷処理 */
		CAR_CHECK_DOWNLOAD(CarCheckApplicationId.CAR_CHECK, "CarCheckDownload"),
		/** 搬入登録画面への遷移 */
		CAR_CHECK_TRANS_REGISTER(CarCheckApplicationId.CAR_CHECK, "CarCheckTransRegister"),
		/** 搬入登録画面からの遷移 */
		CAR_CHECK_RETURN_REGISTER(CarCheckApplicationId.CAR_CHECK, "CarCheckReturnRegister"),
		;
		private String applicationId;
		private String serviceId;
		private CarCheckServiceId(TecApplicationIdIF appId, String serviceId){
			this.applicationId = appId.getApplicationId();
			this.serviceId = serviceId;
		}
		@Override
		public String getApplicationId() {
			return applicationId;
		}
		@Override
		public String getServiceId() {
			return serviceId;
		}
		/**
		 * 車両チェック関連サービスID取得。
		 * <pre>
		 * 車両チェック関連サービスIDを返却する。<br>
		 * 値として認められない場合はnullを返却する。
		 * </pre>
		 * @param serviceId サービスID
		 * @return 車両チェック関連サービスID
		 */
		public static CarCheckServiceId getTargetCarCheckServiceId(String serviceId){
			CarCheckServiceId target = null;
			for(CarCheckServiceId enumElement : CarCheckServiceId.values()){
				if(enumElement.getServiceId().equals(serviceId)){
					target = enumElement;
					break;
				}
			}
			return target;
		}
	}

	/** 車両チェック関連イベントキー */
	public enum CarCheckEventKey implements TecEventKeyIF {
		/** 入庫検査情報取得イベント */
		GET_ENTER_CHECK_DATA(CarCheckApplicationId.CAR_CHECK, "GetEnterCheckDataEvent"),
		// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
		/** 入庫検査情報選択イベント */
		GET_ENTER_CHECK_SELECT_DATA(CarCheckApplicationId.CAR_CHECK, "GetEnterCheckSelectDataEvent"),
		/** 入庫検査情報再取得イベント */
		GET_ENTER_CHECK_RELOAD_DATA(CarCheckApplicationId.CAR_CHECK, "GetEnterCheckReloadDataEvent"),
		// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end
		/** 入庫検査情報登録イベント */
		REGISTER_ENTER_CHECK_DATA(CarCheckApplicationId.CAR_CHECK, "RegisterEnterCheckDataEvent"),
		/** 入庫検査情報取消イベント */
		CANCEL_ENTER_CHECK_DATA(CarCheckApplicationId.CAR_CHECK, "CancelEnterCheckDataEvent"),

		/** 作業仕分情報取得イベント */
		GET_WORK_SORT_DATA(CarCheckApplicationId.CAR_CHECK, "GetWorkSortDataEvent"),
		/** 作業仕分情報登録イベント */
		REGISTER_WORK_SORT_DATA(CarCheckApplicationId.CAR_CHECK, "RegisterWorkSortDataEvent"),
		/** 作業仕分情報取消イベント */
		CANCEL_WORK_SORT_DATA(CarCheckApplicationId.CAR_CHECK, "CancelWorkSortDataEvent"),
		;
		private String applicationId;
		private String eventKey;
		private CarCheckEventKey(TecApplicationIdIF appId, String eventKey){
			this.applicationId = appId.getApplicationId();
			this.eventKey = eventKey;
		}
		public String toString(){
			return eventKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getEventKey(){
			return eventKey;
		}
	}

	/** 車両チェック関連DAOキー */
	public enum CarCheckDAOKey implements TecDAOKeyIF {
		/** 入庫検査DAO */
		CAR_CHECK_DAO(CarCheckApplicationId.CAR_CHECK, "CarCheckDAO"),
		;
		private String applicationId;
		private String daoKey;
		private CarCheckDAOKey(TecApplicationIdIF appId, String daoKey){
			this.applicationId = appId.getApplicationId();
			this.daoKey = daoKey;
		}
		public String toString(){
			return daoKey;
		}
		@Override
		public String getApplicationId(){
			return applicationId;
		}
		@Override
		public String getDAOKey(){
			return daoKey;
		}
	}

}
