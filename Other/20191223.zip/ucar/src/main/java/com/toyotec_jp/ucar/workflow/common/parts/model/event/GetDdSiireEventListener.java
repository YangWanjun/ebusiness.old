package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListSystemDBDaoIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcarCommonDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucca002mBean;

/**
 * <strong>ai21仕入日取得イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/05/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetDdSiireEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetDdSiireEvent executeEvent = (GetDdSiireEvent)event;

		ListSystemDBDaoIF sysDao = getDAO(CarryinDAOKey.LIST_SYSTEMDB_DAO, executeEvent, ListSystemDBDaoIF.class);
		UcarCommonDAOIF commonDao = getDAO(UcarDAOKey.UCARCOMMON_DAO, executeEvent, UcarCommonDAOIF.class);

		// DB連携名取得
		Ucca002mBean t220018mBean = commonDao.selectT220018m(executeEvent.getCdKaisya(),
															executeEvent.getCdHanbaitn(),
															UcarConst.KB_ID_DBRENKEI,
															UcarConst.CD_KUBUN_DBRENKEI);

		if (t220018mBean == null || t220018mBean.getMjInfo1() == null) {
			throw new ApplicationException("仕分用コード区分マスタにDB連携名が登録されていません。");
		}

		String ddSiire = sysDao.selectDdSiire("@" + t220018mBean.getMjInfo1(),
												executeEvent.getCdKaisya(),
												executeEvent.getNoSyaryou());

		if (ddSiire != null) {
			ddSiire = ddSiire.substring(0, 10).replaceAll("-", "");
		}

		GetDdSiireEventResult executeResult = new GetDdSiireEventResult();
		executeResult.setDdSiire(ddSiire);

		return executeResult;
	}
}
