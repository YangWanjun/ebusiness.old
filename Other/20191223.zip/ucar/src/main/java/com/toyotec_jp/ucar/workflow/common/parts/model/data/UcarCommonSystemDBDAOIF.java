package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import jp.co.intra_mart.framework.base.data.DataAccessException;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.workflow.report.model.object.UcarZaikoBean;


/**
 * <strong>在庫カード(店舗用) System Daoインターフェース</strong>
 * <pre>
 *  system-data-sourceで直接addonDBにアクセスするために使用する
 * </pre>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/04/11 新規作成<br>
 * @since 1.00
 * @category [[在庫カード(店舗用)]]
 */
public interface UcarCommonSystemDBDAOIF {

	/**
	 * 中古車在庫情報取得処理
	 * @param dbLink 		DB連携名
	 * @param cdKaisya		会社コード
	 * @param noSyaryou		車両NO
	 * @return
	 * @throws DataAccessException
	 */
	public UcarZaikoBean selectUcarZaiko(String dbLink, String cdKaisya, String noSyaryou) throws TecDAOException;

	/**
	 * 車両装備チェックシート取得処理
	 * @param dbLink 		DB連携名
	 * @param cdKaisya		会社コード
	 * @param noSyaryou		車両NO
	 * @return
	 * @throws DataAccessException
	 */
	public UcarZaikoBean selectSyaryoSoubiCheckSheet(String dbLink, String cdKaisya, String noSyaryou) throws TecDAOException;

}
