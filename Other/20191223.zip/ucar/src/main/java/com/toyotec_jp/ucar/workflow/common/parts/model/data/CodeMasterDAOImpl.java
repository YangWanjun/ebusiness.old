package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.CodeMasterBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>コード区分マスタ操作DAOの実装。</strong>
 * @author Y.M(TEC)
 * @version 1.00 2010/06/02 新規作成<br>
 * @since 1.00
 */
public class CodeMasterDAOImpl extends UcarSharedDBDAO implements CodeMasterDAOIF {

	private static final String SELECT_CODE_MASTER_SQL =
		"SELECT "					+
		"    CD_KAISYA "			+
		"  , CD_JIGYOSYO "			+
		"  , KB_ID "				+
		"  , CD_KUBUN "				+
		"  , MJ_KUBUN "				+
		"  , MJ_KBNRK "				+
		"  , NO_SORT "				+
		"  , MJ_INFO1 "				+
		"  , MJ_INFO2 "				+
		"  , MJ_INFO3 "				+
		"  , MJ_INFO4 "				+
		"  , MJ_INFO5 "				+
		"FROM "						+
		"    T220204M "				+
		"WHERE " 					+
		"     CD_KAISYA = ? "		+
		" AND CD_JIGYOSYO = ? "		+
		" AND KB_ID = ? ";

	private static final String SELECT_CODE_MASTER_ORDER_SQL =
		"ORDER BY NO_SORT ASC ";

	/* (非 Javadoc)
	 * @see jp.co.core.lcm.common.model.dao.CodeMasterDAOIF#getCodeMasterList(java.lang.String)
	 */
	@Override
	public ResultArrayList<CodeMasterBean> getCodeMasterList(String key, UserInformationBean userInfoBean) throws TecDAOException {

		ResultArrayList<CodeMasterBean> resList = null;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_CODE_MASTER_SQL, SELECT_CODE_MASTER_ORDER_SQL);
//			paramBean.setString(userInfoBean.getCdKaisya());
//			paramBean.setString(userInfoBean.getCdJigyosyo());
			paramBean.setString(userInfoBean.getCdKasyukai()); 			// 会社 	2013.2.13(TEC) N.O
			paramBean.setString(userInfoBean.getCdKasyujigyo());		// 事業所　	2013.2.13(TEC) N.O
			paramBean.setString(key);
			resList = executeSimpleSelectQuery(paramBean, CodeMasterBean.class);

		} finally {
		}

		return resList;
	}

	// 2013.03.01 C.Ohta 追加　搬入拠点分散　start
	/* (非 Javadoc)
	 * @see jp.co.core.lcm.common.model.dao.CodeMasterDAOIF#getCodeMasterList(java.lang.String)
	 */
	@Override
	public ResultArrayList<CodeMasterBean> getCodeMasterListD(String key, String kaisya, String jigyosyo) throws TecDAOException {

		ResultArrayList<CodeMasterBean> resList = null;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_CODE_MASTER_SQL, SELECT_CODE_MASTER_ORDER_SQL);
			paramBean.setString(kaisya); 	// 会社
			paramBean.setString(jigyosyo);	// 事業所
			paramBean.setString(key);
			resList = executeSimpleSelectQuery(paramBean, CodeMasterBean.class);

		} finally {
		}

		return resList;
	}
	// 2013.03.01 C.Ohta 追加　搬入拠点分散　end

}
