package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.math.BigDecimal;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;

/**
 * <strong>消費税率取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/16 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetSyouhizeirituEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 消費税率(パーセント)
	 * <p>
	 * 例：消費税が5%の場合、5という形式で変数に格納する
	 * </p>
	 *  */
	private BigDecimal bdSyouhizeiPercent;

	/**
	 * 消費税率(消費税÷100)
	 * <p>
	 * 例：消費税が5%の場合、0.05という形式で変数に格納する
	 * </p>
	 *  */
	private BigDecimal bdSyouhizeiritu;

	/**
	 * 1＋消費税率
	 * <p>
	 * 例：消費税が5%の場合、1.05という形式で変数に格納する
	 * </p>
	 *  */
	private BigDecimal bdSyouhizeikomi;

	/** 端数処理名称(コード区分マスタ：端数処理区分'30') */
	private String mjHasuu;


	/**
	 * bdSyouhizeiPercentを取得する。
	 * @return bdSyouhizeiPercent 消費税率(パーセント)
	 * <p>
	 * 例：消費税が5%の場合、5という形式で変数に取得する
	 * </p>
	 */
	public BigDecimal getBdSyouhizeiPercent() {
		return bdSyouhizeiPercent;
	}

	/**
	 * bdSyouhizeiPercentを設定する。
	 * @param bdSyouhizeiPercent 消費税率(パーセント)
	 * <p>
	 * 例：消費税が5%の場合、5という形式で変数に格納する
	 * </p>
	 */
	public void setBdSyouhizeiPercent(BigDecimal bdSyouhizeiPercent) {
		this.bdSyouhizeiPercent = bdSyouhizeiPercent;
	}

	/**
	 * bdSyouhizeirituを取得する。
	 * @return bdSyouhizeiritu 消費税率(消費税÷100)
	 * <p>
	 * 例：消費税が5%の場合、0.05という形式で変数に取得する
	 * </p>
	 */
	public BigDecimal getBdSyouhizeiritu() {
		return bdSyouhizeiritu;
	}

	/**
	 * bdSyouhizeirituを設定する。
	 * @param bdSyouhizeiritu 消費税率(消費税÷100)
	 * <p>
	 * 例：消費税が5%の場合、0.05という形式で変数に格納する
	 * </p>
	 */
	public void setBdSyouhizeiritu(BigDecimal bdSyouhizeiritu) {
		this.bdSyouhizeiritu = bdSyouhizeiritu;
	}

	/**
	 * mjHasuuを取得する。
	 * @return mjHasuu 端数処理名称(コード区分マスタ：端数処理区分'30')
	 */
	public String getMjHasuu() {
		return mjHasuu;
	}

	/**
	 * mjHasuuを設定する。
	 * @param mjHasuu
	 */
	public void setMjHasuu(String mjHasuu) {
		this.mjHasuu = mjHasuu;
	}

	/**
	 * bdSyouhizeikomiを取得する。
	 * @return bdSyouhizeikomi 1＋消費税率
	 * <p>
	 * 例：消費税が5%の場合、1.05という形式で変数に取得する
	 * </p>
	 */
	public BigDecimal getBdSyouhizeikomi() {
		bdSyouhizeikomi = new BigDecimal(1).add(this.bdSyouhizeiritu);
		return bdSyouhizeikomi;
	}

	/**
	 * 内消費税を取得する。
	 * @return kiGoukei
	 * <p>
	 * kiGoukei×消費税率÷(1＋消費税率)
	 * </p>
	 */
	public int getUchiSyouhizei(int kiGoukei) {

		// 補足：割り切れない答えの場合エラーになるので、小数点5桁目で切り捨てをする
		BigDecimal bdGoukei = new BigDecimal(kiGoukei)
									.multiply(this.getBdSyouhizeiritu())
									.divide(this.getBdSyouhizeikomi(), 5, BigDecimal.ROUND_DOWN);
		// 端数処理
		int kiTax = UcarUtils.adjustFraction(bdGoukei, this.getMjHasuu());

		return kiTax;
	}

}