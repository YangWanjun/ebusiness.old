package com.toyotec_jp.ucar.workflow.common.parts.model.object;

import com.toyotec_jp.im_common.system.model.object.TecBean;

/**
 * <strong>共通店舗DBBean</strong>
 * <p>テーブル英名：TBV0201M</p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/03 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class KyoutuTenpoDBBean extends TecBean {

	/**
	 *
	 */
	private static final long serialVersionUID	= -1486984813640618905L;

	/** 店舗コード */
	private String	cdTenpo;
	/** 店舗名称 */
	private String	kjTenpomei;
	/** 店舗短縮名称 */
	private String kjTentanms;
	/** 店舗種別 */
	private String	kbTenpo;	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
//--2019.3.20 from	
	/** DUO店舗区分**/
	private String kbDuotenpo;
	/** 販売店コード**/
	private String cdHanbaitn;
//--2019.3.20 to	

	/**
	 *
	 */
	public KyoutuTenpoDBBean() {
		super();
	}

	/**
	 * cdTenpoを取得する。
	 * @return cdTenpo 店舗コード
	 */
	public String getCdTenpo() {
		return cdTenpo;
	}

	/**
	 * cdTenpoを設定する。
	 * @param cdTenpo 店舗コード
	 */
	public void setCdTenpo(String cdTenpo) {
		this.cdTenpo = cdTenpo;
	}

	/**
	 * kjTenpomeiを取得する。
	 * @return kjTenpomei 店舗名称
	 */
	public String getKjTenpomei() {
		return kjTenpomei;
	}

	/**
	 * kjTenpomeiを設定する。
	 * @param kjTenpomei 店舗名称
	 */
	public void setKjTenpomei(String kjTenpomei) {
		this.kjTenpomei = kjTenpomei;
	}

	/**
	 * kjTentanmsを取得する。
	 * @return kjTentanms 店舗短縮名称
	 */
	public String getKjTentanms() {
		return kjTentanms;
	}

	/**
	 * kjTentanmsを設定する。
	 * @param kjTentanms 店舗短縮名称
	 */
	public void setKjTentanms(String kjTentanms) {
		this.kjTentanms = kjTentanms;
	}

	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
	/**
	 * kbTenpoを取得する。
	 * @return kbTenpo 店舗種別
	 */
	public String getKbTenpo() {
		return kbTenpo;
	}

	/**
	 * kbTenpoを設定する。
	 * @param kbTenpo 店舗種別
	 */
	public void setKbTenpo(String kbTenpo) {
		this.kbTenpo = kbTenpo;
	}
	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

//2019.3.20 from
	public String getKbDuotenpo() {
		return kbDuotenpo;
	}

	public void setKbDuotenpo(String kbDuotenpo) {
		this.kbDuotenpo = kbDuotenpo;
	}

	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}
//2019.3.20 to
	
}
