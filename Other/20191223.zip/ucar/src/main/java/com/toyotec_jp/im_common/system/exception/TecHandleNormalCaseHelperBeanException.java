/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecHandleNormalCaseHelperBeanException.java
 * 【  説  明  】
 * 【  作  成  】2010/07/28 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;

/**
 * <strong>正常系ヘルパービーン例外クラス。</strong>
 * <p>
 * 共通メッセージ画面において正常系として扱うヘルパービーン例外。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/28 新規作成<br>
 * @since 1.00
 */
public class TecHandleNormalCaseHelperBeanException extends HelperBeanException {

	private static final long serialVersionUID = 7067472998357205379L;

	/**
	 * コンストラクタ。
	 */
	public TecHandleNormalCaseHelperBeanException() {
		super();
	}

}
