package com.toyotec_jp.ucar.workflow.carryin.register.service.controller;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.toyotec_jp.ucar.base.service.controller.UcarAjaxServiceController;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinAjaxServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetNoKataruibCountEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.GetNoKataruibCountEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.SyainDBEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.SyainDBEventResult;

/**
 * <strong>車両搬入登録Ajaxサービスコントローラ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/19 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterAjaxServiceController extends UcarAjaxServiceController {

	/** 車検満了日(日)セレクトボックス取得 */
	private final static String GET_DD_SYKNMANR_DD = CarryinAjaxServiceId.GET_DD_SYKNMANR_DD.toString();
	/** 下取担当者名取得 */
	private final static String GET_KJ_SYAINMEI = CarryinAjaxServiceId.GET_KJ_SYAINMEI.toString();
	/** 型式指定類別NO取得 */
	private final static String GET_NO_KATARUIB = CarryinAjaxServiceId.GET_NO_KATARUIB.toString();

	/**
	 *  Ajaxサービス呼出しに対する処理を実行します。
	 * @return 処理結果
	 * @throws SystemException 処理実行時にシステム例外が発生
	 * @throws ApplicationException 処理実行時にアプリケーション例外が発生
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {

		// Ajax サービスコントローラ初期化
		super.initService();

		// 入力オブジェクト取得
		JSONObject reqObj 		= getRequestJSONObject();
		String ajaxServiceId 	= (String) reqObj.get("ajax_service_id");

		// 結果オブジェクト作成
		JSONObject resultObj = new JSONObject();

		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
		UcarSessionManager sessionMng = UcarSessionManager.getInstance();
		LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());
		String cdKaisya 	= loginSessionBean.getUserInfoBean().getCdKaisya();
		String cdHanbaitn 	= loginSessionBean.getUserInfoBean().getCdHanbaitn();
//2016.9.5 FROM
		String cdHantenpo 	= loginSessionBean.getUserInfoBean().getCdTenpo();
//2016.9.5 TO		
		// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

		if (GET_DD_SYKNMANR_DD.equals(ajaxServiceId)) {
			// 車検満了日(日)セレクトボックス取得

			Long ddSyknmanrDd = (Long) reqObj.get("dd_syknmanr_dd");

			// JSON データ
			JSONObject listObj 		= new JSONObject();
			JSONArray resultList 	= new JSONArray();

			// コンボボックスの先頭に空欄を付加
			listObj.put(UcarUtils.getSelectValueKey(), "");
			listObj.put(UcarUtils.getSelectTextKey(), "");
			resultList.add(listObj);

			for(Integer i = 1; i <= ddSyknmanrDd; i++){
				listObj = new JSONObject();
				listObj.put(UcarUtils.getSelectValueKey(), String.format("%1$02d", i));
				listObj.put(UcarUtils.getSelectTextKey(), String.format("%1$02d", i));
				resultList.add(listObj);
			}
			resultObj.put("ddSyknmanrDdList", resultList);

		} else if (GET_KJ_SYAINMEI.equals(ajaxServiceId)) {
			// 下取担当者名取得

			SyainDBEvent getEvent
				= (SyainDBEvent)createEvent("com.toyotec_jp.ucar.workflow.common.parts.UcarCommonParts",
											"SyainDBEvent");

			// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更のため start
			getEvent.setCdKaisya(cdKaisya);
			getEvent.setCdHanbaitn(cdHanbaitn);
			// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更のため end

			String cdSdtan = (String) reqObj.get("cd_sdtan");
			getEvent.setCdSdtan(cdSdtan);

			// イベントリスナー実行
			SyainDBEventResult getEventResult = (SyainDBEventResult) dispatchEvent(getEvent);

			resultObj.put("kjSyainmei", getEventResult.getKjSyainmei());

		} else if (GET_NO_KATARUIB.equals(ajaxServiceId)) {
			// 型式指定類別NO件数取得

			String ddHannyu 	= (String) reqObj.get("dd_hannyu");
			String noKanri 		= (String) reqObj.get("no_kanri");

			String noKataruib = (String) reqObj.get("no_kataruib");
			boolean editMode = (Boolean) reqObj.get("edit_mode");

			GetNoKataruibCountEvent getEvent
				= (GetNoKataruibCountEvent)createEvent("com.toyotec_jp.ucar.workflow.common.parts.UcarCommonParts",
														"GetNoKataruibCountEvent");
/*2016.9.5 from
			getEvent.setT220001gPkBean(new Ucaa001gPKBean(cdKaisya, cdHanbaitn, ddHannyu, noKanri));
*/
			getEvent.setT220001gPkBean(new Ucaa001gPKBean(cdKaisya, cdHanbaitn, cdHantenpo, ddHannyu, noKanri));
//2016.9.5 to			
			getEvent.setNoKataruib(noKataruib);
			getEvent.setEditMode(editMode);

			// イベントリスナー実行
			GetNoKataruibCountEventResult getEventResult = (GetNoKataruibCountEventResult) dispatchEvent(getEvent);

			resultObj.put("countNoKataruib", getEventResult.getCountNoKataruib());
		}

		// 結果をレスポンスへセット
		setResponseData(resultObj);

		return null;
	}
}
