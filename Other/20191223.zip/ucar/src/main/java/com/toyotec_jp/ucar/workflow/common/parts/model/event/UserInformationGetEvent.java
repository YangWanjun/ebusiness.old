package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>ユーザ情報取得イベント。</strong>
 * <p>
 * ユーザ情報を取得する
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/07/07 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UserInformationGetEvent extends UcarEvent {

	private static final long serialVersionUID = 1L;
	private String employeeCd;		// ユーザID

	/**
	 * コンストラクタ
	 */
	public UserInformationGetEvent() {
		super();
		this.employeeCd	= "";
	}

	/**
	 * ユーザIDを取得する。
	 * @return ユーザID
	 */
	public String getEmployeeCd() {
		return employeeCd;
	}

	/**
	 * ユーザIDを設定する。
	 * @param ユーザID
	 */
	public void setEmployeeCd(String employeeCd) {
		this.employeeCd = employeeCd;
	}

}
