/**
 * システム共通メッセージ関連パッケージ
 * @version 1.00 2010/06/17 新規作成<br>
 * @since 1.00
 */
package com.toyotec_jp.im_common.system.message;
