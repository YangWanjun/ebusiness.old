package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Tbjla24mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucab007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac001gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucac003wBean;

/**
 * <strong>配送候補連携操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/03/19 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface HaisoKouhoRenkeiDAOIF {

	/**
	 * 件数取得処理(配送候補連携)
	 * <pre>
	 * 接続確認に使用する
	 * </pre>
	 * @param 	cdKaisya 会社コード
	 * @param 	cdHanbaitn 販売店コード
	 * @return 件数
	 * @throws LcmDAOException DAO例外クラス
	 */
	public int selectTbjla24mCount(String cdKaisya,
									String cdHanbaitn) throws TecDAOException;

	/**
	 * 配送候補連携リスト取得
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @return 配送候補連携リスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<Tbjla24mBean> selectTbjla24m(String cdKaisya,
														String cdHanbaitn) throws TecDAOException;

	/**
	 * 配送候補連携リスト取得
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @param	isNotNullDdHiskib 配送希望日(where条件にis not nullを付ける場合はtrueを設定)
	 * @return 配送候補連携リスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<Tbjla24mBean> selectTbjla24m(String cdKaisya,
														String cdHanbaitn,
														String ddHannyu,
														String noKanri,
														boolean isNotNullDdHiskib) throws TecDAOException;

	/**
	 * 更新処理（ステータスDB）
	 * @param	t220011gBean    ステータスDBBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220012g(Ucab007gBean t220012gBean,
													Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（車両搬出情報）
	 * @param	t220013gBean    車両搬出情報Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220013g(Ucac001gBean t220013gBean,
													Timestamp executeDate) throws TecDAOException;

	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
	/**
	 * 配送候補連携BUFFER取得処理
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @return
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucac003wBean> selectT220015w(String cdKaisya,
			String cdHanbaitn) throws TecDAOException;

	/**
	 * 配送候補連携BUFFER取得処理
	 * <pre>
	 * 登録NO陸支コードでの検索が必要な場合に使用する。
	 * </pre>
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param	cdNorikusi	登録NO陸支コード
	 * @return
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucac003wBean> selectT220015w(String cdKaisya,
			String cdHanbaitn,
			String cdNorikusi) throws TecDAOException;
	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

	/**
	 * 配送候補連携BUFFER取得処理
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @return
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucac003wBean> selectT220015w(String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri) throws TecDAOException;

	/**
	 * 削除処理（配送候補連携BUFFER）
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteT220015w(String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri) throws TecDAOException;

	/**
	 * 削除処理（配送候補連携）
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean deleteTbjla24m(String cdKaisya,
			String cdHanbaitn,
			String ddHannyu,
			String noKanri) throws TecDAOException;

	/**
	 * 新規登録処理（配送候補連携）
	 * @param 	tbjla24mBean 	配送候補連携Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertTbjla24m(Tbjla24mBean tbjla24mBean,
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（配送候補連携）
	 * @param 	tbjla24mBean 	配送候補連携Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateTbjla24m(Tbjla24mBean tbjla24mBean,
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（配送候補連携）
	 * <pre>
	 * 作業仕分用
	 * </pre>
	 * @param 	tbjla24mBean 	配送候補連携Bean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateTbjla24mWorkSort(Tbjla24mBean tbjla24mBean,
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 新規登録処理（配送候補連携BUFFER）
	 * @param 	Ucac003wBean 	配送候補連携BUFFERBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean insertT220015w(Ucac003wBean t220015wBean,
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（配送候補連携BUFFER）
	 * <pre>
	 * DEL更新用
	 * </pre>
	 * @param 	Ucac003wBean 	配送候補連携BUFFERBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220015wDel(Ucac003wBean t220015wBean,
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 更新処理（配送候補連携BUFFER）
	 * <pre>
	 * 作業仕分用
	 * </pre>
	 * @param 	Ucac003wBean 	配送候補連携BUFFERBean
	 * @param	executeDate     実行日時
	 * @throws TecDAOException DAO例外クラス
	 */
	public SimpleExecuteResultBean updateT220015wWorkSort(Ucac003wBean t220015wBean,
			Timestamp executeDate) throws TecDAOException;

	/**
	 * 配送候補連携 登録データ取得
	 * @param 	cdKaisya 	会社コード
	 * @param 	cdHanbaitn 	販売店コード
	 * @param 	ddHannyu 	搬入日
	 * @param 	noKanri 	管理番号
	 * @return 配送候補連携Bean
	 * @throws TecDAOException
	 */
	public Tbjla24mBean selectHaisorenkei(String cdKaisya,
											String cdHanbaitn,
											String ddHannyu,
											String noKanri) throws TecDAOException;

}
