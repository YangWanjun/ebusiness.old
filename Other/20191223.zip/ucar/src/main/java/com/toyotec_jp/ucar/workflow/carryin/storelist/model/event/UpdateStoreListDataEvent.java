package com.toyotec_jp.ucar.workflow.carryin.storelist.model.event;

import java.util.List;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.storelist.model.object.StoreListDataBean;

/**
 * <strong>更新イベント</strong>
 * <p>
 * </p>
 * @author A.Y(TOYOTEC)
 * @version 1.00 2012/03/09 新規作成<br>
 * @since 1.00
 * @category [[展示店舗受取処理]]
 */
public class UpdateStoreListDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/** 車両搬出情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPKBean;
	/** データ更新日時 */
	private String dtKosin;
	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため start
	/** 展示店舗受取処理 画面出力値リスト */
	private List<StoreListDataBean> storeListDataList;
	// 2013.04.29 T.Hayato 追加 搬入拠点分散対応2のため end

	/**
	 * t220001gPKBeanを取得する。
	 * @return t220001gPKBean 車両搬入情報 プライマリーキーBean
	 */
	public Ucaa001gPKBean getUcaa001gPKBean() {
		return t220001gPKBean;
	}

	/**
	 * t220001gPKBeanを設定する。
	 * @param t220001gPKBean データ更新日時
	 */
	public void setUcaa001gPKBean(Ucaa001gPKBean t220001gPKBean) {
		this.t220001gPKBean = t220001gPKBean;
	}

	/**
	 * @return the dtKosin
	 */
	public String getDtKosin() {
		return dtKosin;
	}

	/**
	 * @param dtKosin the dtKosin to set
	 */
	public void setDtKosin(String dtKosin) {
		this.dtKosin = dtKosin;
	}

	/**
	 * storeListDataListを取得する。
	 * @return storeListDataList
	 */
	public List<StoreListDataBean> getStoreListDataList() {
		return storeListDataList;
	}

	/**
	 * storeListDataListを設定する。
	 * @param storeListDataList
	 */
	public void setStoreListDataList(List<StoreListDataBean> storeListDataList) {
		this.storeListDataList = storeListDataList;
	}

}