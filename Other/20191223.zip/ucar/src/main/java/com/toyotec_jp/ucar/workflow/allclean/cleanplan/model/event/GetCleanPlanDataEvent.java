package com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>まるクリ作業計画入力取得イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/24 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public class GetCleanPlanDataEvent extends UcarEvent {

	/**  */
	private static final long	serialVersionUID	= -4027313481306671402L;

	public GetCleanPlanDataEvent() {
		super();
	}

}
