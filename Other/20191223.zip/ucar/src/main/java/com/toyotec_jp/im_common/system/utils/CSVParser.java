/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】CSVParser.java
 * 【  説  明  】
 * 【  作  成  】2010/09/03 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import jp.co.intra_mart.foundation.service.client.information.Identifier;

import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.TecApplicationManager.TecConfigKey;
import com.toyotec_jp.im_common.system.exception.TecFileMngException;
import com.toyotec_jp.im_common.system.utils.StringUtils.CharSet;

/**
 * <strong>CSVファイルパーサ。</strong>
 * <p>
 * CSVファイル操作用。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/09/03 新規作成<br>
 * @since 1.00
 */
public class CSVParser {

	/** 自動生成一時保存先(APサーバ)ROOT */
	private static final String TEMP_SAVE_ROOT = TecApplicationManager.getConfigValue(TecConfigKey.TEMP_CSV_PARSER_PATH);

	private static final String DEFAULT_SEPARATOR = ",";

	private static final String DEFAULT_NL = "\r\n";

	private static final String DBLQ_SET = "\"\"";

	private static final String DBLQ = "\"";

	private CSVParser(){
	}

	/**
	 * ストレージサービス上のCSVファイルをパース。
	 * <pre>
	 * ストレージサービス上のCSVファイルをパースした結果を返却する。<br>
	 * APサーバに一時ファイルを作成し、処理を実行する(実行後一時ファイルは削除)。<br>
	 * ファイルの文字エンコーディングはデフォルト。<br>
	 * セパレータ文字列「,」、改行文字列「\r\n」
	 * </pre>
	 * @param ssPath ストレージサービス上のファイルパス
	 * @return パース結果リスト
	 * @throws TecFileMngException
	 */
	public static ArrayList<ArrayList<String>> parseCSV(String ssPath) throws TecFileMngException {
		return parseCSV(ssPath, null, DEFAULT_SEPARATOR, DEFAULT_NL);
	}

	/**
	 * ストレージサービス上のCSVファイルをパース。
	 * <pre>
	 * ストレージサービス上のCSVファイルをパースした結果を返却する。<br>
	 * APサーバに一時ファイルを作成し、処理を実行する(実行後一時ファイルは削除)。<br>
	 * </pre>
	 * @param ssPath ストレージサービス上のファイルパス
	 * @param encChar ファイルの文字エンコーディング名
	 * @param separator セパレータ文字列(デフォルト:「,」)
	 * @param newline 改行文字列(要素の値に改行がある場合設定)(デフォルト:「\r\n」)
	 * @return パース結果リスト
	 * @throws TecFileMngException
	 */
	public static ArrayList<ArrayList<String>> parseCSV(
			String ssPath, CharSet encChar, String separator, String newline) throws TecFileMngException {
		IMStorageServiceManager ssMng = IMStorageServiceManager.getInstance();
		IMAppFileManager apFileMng = IMAppFileManager.getInstance();
		String tempAppSavePath = getTempSavePath(ssPath);
		apFileMng.saveFile(tempAppSavePath, ssMng.loadFile(ssPath), true);
		ArrayList<ArrayList<String>> result = parseCSVFromApp(tempAppSavePath, encChar, separator, newline);
		try{
			apFileMng.deleteFile(tempAppSavePath);
		} catch(TecFileMngException e){
			// 削除失敗は無視
		}
		return result;
	}

	/**
	 * APサーバ上のCSVファイルをパース。
	 * <pre>
	 * APサーバ上のCSVファイルをパースした結果を返却する。<br>
	 * APサーバ上のファイルは削除しない。<br>
	 * ファイルの文字エンコーディングはデフォルト。<br>
	 * セパレータ文字列「,」、改行文字列「\r\n」
	 * </pre>
	 * @param apPath APサーバworkからの相対ファイルパス
	 * @return パース結果リスト
	 * @throws TecFileMngException
	 */
	public static ArrayList<ArrayList<String>> parseCSVFromApp(String apPath) throws TecFileMngException {
		return parseCSVFromApp(apPath, null, DEFAULT_SEPARATOR, DEFAULT_NL);
	}

	/**
	 * APサーバ上のCSVファイルをパース。
	 * <pre>
	 * APサーバ上のCSVファイルをパースした結果を返却する。<br>
	 * APサーバ上のファイルは削除しない。
	 * </pre>
	 * @param apPath APサーバworkからの相対ファイルパス
	 * @param encChar ファイルの文字エンコーディング名
	 * @param separator セパレータ文字列(デフォルト:「,」)
	 * @param newline 改行文字列(要素の値に改行がある場合設定)(デフォルト:「\r\n」)
	 * @return パース結果リスト
	 * @throws TecFileMngException
	 */
	public static ArrayList<ArrayList<String>> parseCSVFromApp(
			String apPath, CharSet encChar, String separator, String newline) throws TecFileMngException {
		IMAppFileManager apFileMng = IMAppFileManager.getInstance();
		Iterator<String> textLines = apFileMng.readLines(apPath, encChar);
		ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
		separator = StringUtils.defaultValue(separator, DEFAULT_SEPARATOR);
		newline = StringUtils.defaultValue(newline, DEFAULT_NL);
		while(textLines.hasNext()){
			result.add(getParseCSVRecord(textLines, separator, newline));
		}
		result.trimToSize();
		return result;
	}

	// CSVの1行(CSVファイルの1行ではなく、CSVファイルフォーマットとしての1行)を返却
	private static ArrayList<String> getParseCSVRecord(
			Iterator<String> textLines,
			final String separator, final String newline){
		ArrayList<String> rec = null;
		if(textLines.hasNext()){
			rec = new ArrayList<String>();
			String baseStr = textLines.next();
			for(;;){
				baseStr = setNextAttr(baseStr, rec, textLines, separator, newline);
				if(baseStr == null){
					break;
				}
			}
			rec.trimToSize();
		}
		return rec;
	}

	// CSVの1要素を設定
	// 設定後の残りの要素候補となる文字列を返却
	// 1行(CSVファイルの1行ではなく、CSVファイルフォーマットとしての1行)の設定が完了した時点でnullを返却
	// パース方式はExcelでCSVを開いた場合に似せて作成
	private static String setNextAttr(
			String baseStr, ArrayList<String> rec, Iterator<String> textLines,
			final String separator, final String newline){
		String remainStr = null;
		if(baseStr.length() > 0){
			// ダブルクォーテーションで開始の場合
			if(baseStr.startsWith(DBLQ)){
				int dqEndIdx = baseStr.replaceAll(DBLQ_SET, "xx").indexOf(DBLQ, 1);
				// 終了ダブルクォーテーションがない場合
				// 「"a,bc""def,」→「a,bc"def,・・・」
				if(dqEndIdx <= 0){
					// 次行ありの場合は取得結果を連結し、再帰
					if(textLines.hasNext()){
						remainStr = setNextAttr(baseStr + newline + textLines.next(), rec, textLines, separator, newline);
					} else {
						// 開始を除く全てを要素とする(「""」→「"」変換もする)
						rec.add(baseStr.substring(1).replaceAll(DBLQ_SET, DBLQ));
						// 1行完成(次行なし)
						remainStr = null;
					}
				// 現在の基本文字列内に終了ダブルクォーテーションがある場合
				// 「"a,bc""def",」→「a,bc"def」
				// 「"a,bc"def,」→「a,bcdef」
				} else {
					StringBuilder attrBld = new StringBuilder();
					attrBld.append(baseStr.substring(1, dqEndIdx).replaceAll(DBLQ_SET, DBLQ));
					if(dqEndIdx + 1 < baseStr.length()){
						int attrEndIdx = baseStr.indexOf(separator, dqEndIdx + 1);
						// カンマが後ろにある場合
						if(attrEndIdx >= dqEndIdx + 1){
							attrBld.append(baseStr.substring(dqEndIdx + 1, attrEndIdx));
							rec.add(new String(attrBld));
							if(attrEndIdx + 1 < baseStr.length()){
								remainStr = baseStr.substring(attrEndIdx + 1);
							} else {
								// 次の要素ありだが、値なしのため
								remainStr = "";
							}
						// カンマなし
						} else {
							attrBld.append(baseStr.substring(dqEndIdx + 1));
							rec.add(new String(attrBld));
							// 1行完成
							remainStr = null;
						}
					} else {
						rec.add(new String(attrBld));
						// 1行完成
						remainStr = null;
					}
				}
			// ダブルクォーテーション以外で開始の場合
			// 「a,bc""def",」→「a」、「bc""def"」
			} else {
				int attrEndIdx = baseStr.indexOf(separator);
				if(attrEndIdx < 0){
					rec.add(baseStr);
					// 1行完成
					remainStr = null;
				} else {
					rec.add(baseStr.substring(0, attrEndIdx));
					if(attrEndIdx + 1 < baseStr.length()){
						remainStr = baseStr.substring(attrEndIdx + 1);
					} else {
						// 次の要素ありだが、値なしのため
						remainStr = "";
					}
				}
			}
		} else {
			rec.add("");
			// 1行完成
			remainStr = null;
		}
		return remainStr;
	}

	// 一時保存先パス取得
	private static String getTempSavePath(String baseFilePath){
		String fileExtension = StringUtils.getFileExtension(baseFilePath);
		Identifier idt = new Identifier();
		String id = "";
		try {
			id = idt.get();
		} catch (IOException e) {
			// ID取得失敗は無視
		}
		StringBuilder sb = new StringBuilder();
		sb.append(StringUtils.getFolderPath(TEMP_SAVE_ROOT));
		sb.append(DateUtils.getCurrentDateStr(DateUtils.FORMAT_LONG_M_SIMPLE));
		sb.append("#" + id);
		if(fileExtension != null){
			sb.append("." + fileExtension);
		}
		return new String(sb);
	}

}
