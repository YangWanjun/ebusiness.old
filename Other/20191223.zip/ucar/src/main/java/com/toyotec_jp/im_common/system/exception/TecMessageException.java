/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecMessageException.java
 * 【  説  明  】
 * 【  作  成  】2010/05/24 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.exception;

import com.toyotec_jp.im_common.system.message.TecMessageKeyIF;

/**
 * <strong>メッセージ取得例外クラス。</strong>
 * <p>
 * メッセージ取得失敗時の例外。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/24 新規作成<br>
 * @since 1.00
 */
public class TecMessageException extends TecSystemException {

	private static final long serialVersionUID = 5359411151903321582L;

	private static final String DEFAULT_ERR_MSG = "メッセージの取得に失敗しました。";

	private String messageKey;

	/**
	 * コンストラクタ。
	 * @param key キー
	 */
	public TecMessageException(String key) {
		super(DEFAULT_ERR_MSG);
		setMessageKey(key);
	}

	/**
	 * コンストラクタ。
	 * @param key キー
	 * @param cause
	 */
	public TecMessageException(String key, Throwable cause) {
		super(DEFAULT_ERR_MSG, cause);
		setMessageKey(key);
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 */
	public TecMessageException(TecMessageKeyIF messageKey) {
		super(DEFAULT_ERR_MSG);
		setMessageKey(messageKey.toString());
	}

	/**
	 * コンストラクタ。
	 * @param messageKey メッセージキー
	 * @param cause
	 */
	public TecMessageException(TecMessageKeyIF messageKey, Throwable cause) {
		super(DEFAULT_ERR_MSG, cause);
		setMessageKey(messageKey.toString());
	}

	/**
	 * messageKeyを取得する。
	 * @return messageKey メッセージキー
	 * @since 1.00
	 */
	public String getMessageKey() {
		return messageKey;
	}

	/**
	 * messageKeyを設定する。
	 * @param messageKey メッセージキー
	 * @since 1.00
	 */
	private void setMessageKey(String messageKey) {
		this.messageKey = messageKey;
	}

}
