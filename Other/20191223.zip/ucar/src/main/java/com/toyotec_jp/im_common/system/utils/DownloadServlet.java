/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】DownloadServlet.java
 * 【  説  明  】
 * 【  作  成  】2010/06/30 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.SocketException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.system.exception.TecFileMngException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.utils.StringUtils.CharSet;


/**
 * <strong>ダウンロードサーブレット。</strong>
 * <p>
 * ダウンロード用のサーブレット。<br>
 * 使用する場合はweb.xmlにマッピングする。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/30 新規作成<br>
 * @since 1.00
 */
public class DownloadServlet extends HttpServlet {

	private static final long serialVersionUID = -7453053576359704970L;

	/* (非 Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doDownload(req, res);
	}

	/* (非 Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doDownload(req, res);
	}

	// ダウンロード処理
	private void doDownload(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// 情報の取得
		String fileName = (String)req.getAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_FILE_NAME);
		fileName = StringUtils.encode(fileName, CharSet.WINDOWS_31J, CharSet.ISO_8859_1);
		//fileName = URLEncoder.encode(fileName, "UTF-8");
		// レスポンスヘッダ設定
		setDownloadResponseHeaders(res, fileName);
		BufferedInputStream bufIn = null;
		BufferedOutputStream bufOut = null;
		try {
			bufIn = getDownloadFileData(req, res);
			bufOut = new BufferedOutputStream(res.getOutputStream());
			// 4kでバッファリングしながら出力
			byte buf[] = new byte[4096];
			int len;
			while((len = bufIn.read(buf)) > -1){
				bufOut.write(buf, 0, len);
			}
		} catch (SocketException e) {
			// ユーザのキャンセルは無視
		} catch (Exception e) {
			// HTTPヘッダリセット
			TecLogger.error("ダウンロード処理中にエラーが発生しました", e);
			res.reset();
			res.sendError(HttpURLConnection.HTTP_INTERNAL_ERROR, e.toString());
		} finally {
			if(bufIn != null){
				try{
					bufIn.close();
				} catch (IOException e){
				}
			}
			if(bufOut != null){
				try{
					bufOut.flush();
				} catch (IOException e){
				}
				try{
					bufOut.close();
				} catch (IOException e){
				}
			}
		}
	}

	// レスポンスヘッダ設定
	private void setDownloadResponseHeaders(HttpServletResponse res, String fileName){
		// ヘッダの出力
		res.setContentType("application/octet-stream");
		res.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		res.setHeader("Expires", "0");
		res.setHeader("Cache-Control", "must-revalidate, post-check=0,pre-check=0");
		res.setHeader("Pragma", "private");
	}

	// ファイルをBufferedInputStreamで取得
	private BufferedInputStream getDownloadFileData(HttpServletRequest req, HttpServletResponse res) throws IOException, TecSystemException {
		BufferedInputStream bufIn = null;
		String ssFilePath = (String)req.getAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_SS_FILE_PATH);
		String apFilePath = (String)req.getAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_AP_FILE_PATH);
		// ストレージサービス、APサーバのファイルパスが未設定の場合
		if(ssFilePath == null && apFilePath == null){
			// リクエストから取得
			Object reqData = req.getAttribute(TecApplicationManager.REQ_ATTR_KEY_DOWNLOAD_FILE_DATA);
			if(reqData != null){
				int byteLen = ((byte[])reqData).length;
				if(byteLen > 0){
					// ContentLength
					res.setContentLength(byteLen);
					// BufferedInputStream
					bufIn = new BufferedInputStream(new ByteArrayInputStream((byte[])reqData));
				} else {
					// 0バイト
					throw new TecFileMngException("0byteのファイルは操作できません");
				}
			} else {
				// 未指定
				throw new TecSystemException("パラメータが不正です", new IllegalArgumentException());
			}
		} else {
			IMFileManagerIF imfm = null;
			String filePath = null;
			if(ssFilePath != null){
				// ストレージサービス
				imfm = IMStorageServiceManager.getInstance();
				filePath = ssFilePath;
			} else {
				// APサーバ
				imfm = IMAppFileManager.getInstance();
				filePath = apFilePath;
			}
			long byteLenLong = imfm.getFileByteLength(filePath);
			if(byteLenLong > 0){
				if(byteLenLong <= Integer.MAX_VALUE){
					// ContentLength
					res.setContentLength(Integer.parseInt(Long.toString(byteLenLong, 10), 10));
				} else {
					// TODO 限界値について
					// int限界超えのファイル(2Gくらい)・・・でもその前に、
					// ストレージサービスがbyte配列でAP上に展開するのでAPのメモリが限界を迎える・・・
					// 最大値として適正な値はせいぜいAPの20分の1くらいか・・・
					throw new TecFileMngException("2147483647byteを超えるファイルは操作できません");
				}
				bufIn = new BufferedInputStream(new ByteArrayInputStream(imfm.loadFile(filePath)));
			} else {
				// 0バイト
				throw new TecFileMngException("0byteのファイルは操作できません");
			}
		}
		return bufIn;
	}

}
