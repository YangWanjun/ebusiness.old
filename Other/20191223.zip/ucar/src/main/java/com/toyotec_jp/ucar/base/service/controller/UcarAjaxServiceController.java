/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarAjaxServiceController.java
 * 【  説  明  】
 * 【  作  成  】2010/07/12 S.K(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.service.controller;

import java.io.BufferedReader;
import java.io.IOException;

import jp.co.intra_mart.framework.base.service.ServiceControllerAdapter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * <strong>AJaxサービスコントローラー。</strong>
 * <p>
 * Ajaxサービスコントローラー作成時は本クラスを継承すること。
 * </p>
 * @author S.K(SCC)
 * @version 1.00 2010/07/12 新規作成<br>
 * @since 1.00
 */
public abstract class UcarAjaxServiceController extends ServiceControllerAdapter {

	Object requestObj = null;

	/**
	 * サービス初期化
	 */
	protected void initService() {
		try {
			this.requestObj = JSONValue.parse(getBody(getRequest().getReader()));
		}catch(IOException ioe){
			//throw new TSystemException(ioe.getMessage());
		}
	}

	/**
	 * HTTP要求本文を取得する。
	 * @param reader BufferedReaderクラス
	 * @return
	 * @throws IOException
	 */
	protected String getBody(BufferedReader reader) throws IOException {
		try {
			StringBuffer sb = new StringBuffer();
			String str;
			while ((str = reader.readLine()) != null) {
				sb.append(str);
			}
			return sb.toString();
		} finally {
			reader.close();
		}
	}
	/**
	 * JSONObjectを返却する
	 * @return JSONObject
	 */
	protected JSONObject getRequestJSONObject(){
		return (JSONObject) requestObj;
	}

	/**
	 * JSONArray を返却する
	 * @return JSONArray
	 */
	protected JSONArray getRequestJSONArray(){
		return (JSONArray) requestObj;
	}

	/**
	 * JSSONデータ(JSSonObject)をレスポンスにセットする
	 * @param jsonObj JSSONObject
	 */
	protected void setResponseData(JSONObject jsonObj){
		getRequest().setAttribute("jsondata",jsonObj.toString());
	}

	/**
	 * JSSONデータ(JSSonObject)をレスポンスにセットする
	 * @param jsonArray
	 */
	protected void setResponseData(JSONArray jsonArray){
		getRequest().setAttribute("jsondata",jsonArray.toString());
	}
}
