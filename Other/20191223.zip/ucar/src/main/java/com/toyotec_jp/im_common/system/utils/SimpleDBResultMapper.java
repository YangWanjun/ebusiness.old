/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】SimpleDBResultMapper.java
 * 【  説  明  】
 * 【  作  成  】2010/05/07 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import com.toyotec_jp.im_common.system.db.TecResultSet;
import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.exception.TecUnsupportedDataTypeException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageKey;
import com.toyotec_jp.im_common.system.model.object.MethodInfoBean;
import com.toyotec_jp.im_common.system.model.object.TecBean;


/**
 * <strong>データベース情報取得結果簡易マッピング用クラス。</strong>
 * <p>
 * データベースから取得した結果をビーンにマッピングする。<br>
 * ビーンのフィールド名が「abcDef」の場合、データベースから取得した結果の項目名「abc_def」の値を設定する。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/17 新規作成<br>
 * @since 1.00
 */
public class SimpleDBResultMapper {

	private SimpleDBResultMapper(){
	}

	/**
	 * 結果セット現在行の内容をビーンにマッピングする。
	 * @param result
	 * @param bean
	 * @throws TecDAOException
	 */
	public static void setResult(TecResultSet result, TecBean bean) throws TecDAOException {
		Class<?> clsTarget = bean.getClass();
		setResultToSubBean(result, bean, clsTarget);
//		while (clsTarget != null) {
//			setResult(result, bean, clsTarget);
//			clsTarget = clsTarget.getSuperclass();
//		}
	}

	public static void setResult(
			TecResultSet result, TecBean bean, HashMap<String, MethodInfoBean> setterMap) throws TecDAOException {
		// セッターメソッドごとの処理
		for(Entry<String, MethodInfoBean> setterEntry : setterMap.entrySet()){
			String columnName = setterEntry.getValue().getColumnName();
			Method method = setterEntry.getValue().getMethod();
			Class<?> returnType = method.getParameterTypes()[0];
			// セッターメソッドによりビーンへ値を設定
			setResultBySetterMethod(result, bean, columnName, method, returnType);
		}
	}

	// マッピング(子ビーン用)
	private static void setResultToSubBean(
			TecResultSet result, TecBean bean, Class<?> cls) throws TecDAOException {
		HashMap<String, MethodInfoBean> setterMap = ReflectionUtils.getBeanSetterMap(cls);
		// セッターメソッドごとの処理
		setResult(result, bean, setterMap);
//		Field[] fields = cls.getDeclaredFields();
//		for (int i = 0; i < fields.length; i++) {
//			Class<?> returnType = fields[i].getType();
//			String fieldName = fields[i].getName();
//			String methodName = StringUtils.getSetterName(fields[i]);
//			String columnName = StringUtils.convFieldToColumnName(fieldName);
//			Method method = null;
//			try {
//				method = bean.getClass().getMethod(methodName, returnType);
//			// メソッドが存在しない場合は無視
//			} catch (NoSuchMethodException e) {
//			}
//			// セッターメソッドによりビーンへ値を設定
//			if(method != null){
//				setResultBySetterMethod(result, bean, columnName, method, returnType);
//			}
//		}
	}

	private static void setResultBySetterMethod(
			TecResultSet result, TecBean bean,
			String columnName, Method method, Class<?> returnType) throws TecDAOException {

		try {
			Object obj = null;

			// プリミティブの場合
			if (returnType.isPrimitive()) {

				// resultsetに対象項目が存在しない場合は無視
				if(result.isExistCol(columnName)){
					obj = convResultSetValueToPrimitiveType(result, columnName, returnType);
					// 結果が取得できた場合
					if (obj != null) {
						method.invoke(bean, obj);
					}
				}

			// 配列の場合
			} else if (returnType.isArray()) {

				// resultsetに対象項目が存在しない場合は無視
				if(result.isExistCol(columnName)){
					// 配列を含んでいる場合はエラー処理
					throw new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
				}

			// プリミティブ、配列以外のオブジェクト
			} else {
				Constructor<?> constructor = null;

				// 基本データビーンを継承している場合
				if(TecBean.class.isAssignableFrom(returnType)){
					// 基本データビーンの場合のみresultsetに対象項目が存在しない場合も処理
					constructor = returnType.getConstructor();
					obj = constructor.newInstance();
					// 再帰処理
					setResultToSubBean(result, (TecBean) obj, obj.getClass());
					method.invoke(bean, obj);

				// 基本データビーンを継承していない場合
				} else {
					// resultsetに対象項目が存在しない場合は無視
					if(result.isExistCol(columnName)){
						//String data = null;
						//if(result.isNationalTypeString(columnName)){
						//	data = result.getNString(columnName);
						//} else {
						//	data = result.getString(columnName);
						//}
						String data = result.getString(columnName);
						if (data != null) {
							if (data.length() > 0 || returnType == String.class || returnType == Boolean.class) {
								if (returnType == Character.class) {
									constructor = returnType.getConstructor(Character.TYPE);
									obj = constructor.newInstance(data.charAt(0));
								} else if(returnType == Date.class){
									obj = DateUtils.getDateFromOdbcFormat(data);
								} else if(returnType == String.class){
									obj = data;
								} else {
									constructor = returnType.getConstructor(String.class);
									obj = constructor.newInstance(data);
								}
							}
							method.invoke(bean, obj);
						}
					}
				}
			}

		// メソッドが存在しない場合は無視
		} catch (NoSuchMethodException e) {

		// その他例外はエラー処理
		} catch (InstantiationException e) {
			TecLogger.error(e.getMessage(), columnName);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_DB_RESULT_MAPPING, e);
		} catch (IllegalAccessException e) {
			TecLogger.error(e.getMessage(), columnName);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_DB_RESULT_MAPPING, e);
		} catch (InvocationTargetException e) {
			TecLogger.error(e.getMessage(), columnName);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_DB_RESULT_MAPPING, e);
		} catch (SQLException e) {
			TecLogger.error(e);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_DB_RESULT_MAPPING, e);
		} catch (TecUnsupportedDataTypeException e) {
			TecLogger.error(e.getMessage(), columnName);
			throw new TecDAOException(TecMessageKey.SYS_E_FAILED_DB_RESULT_MAPPING, e);
		}
	}

	// ResultSetの値を指定のプリミティブ型に変換
	private static Object convResultSetValueToPrimitiveType(
			TecResultSet result, String columnName, Class<?> convType) throws TecUnsupportedDataTypeException, SQLException {
		Object obj = null;
		// 変換対象外の型の場合は例外生成
		if(
				!(convType == Byte.TYPE || convType == Character.TYPE ||
				convType == Double.TYPE || convType == Float.TYPE ||
				convType == Integer.TYPE || convType == Long.TYPE || convType == Short.TYPE ||
				convType == Boolean.TYPE)){
			throw new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
		}

		// 結果を取得
		if (convType == Byte.TYPE) {
			obj = result.getByte(columnName);
		} else if (convType == Character.TYPE) {
			String charData = result.getString(columnName);
			if(charData != null && charData.length() > 0){
				obj = charData.charAt(0);
			}
		} else if (convType == Double.TYPE) {
			obj = result.getDouble(columnName);
		} else if (convType == Float.TYPE) {
			obj = result.getFloat(columnName);
		} else if (convType == Integer.TYPE) {
			obj = result.getInt(columnName);
		} else if (convType == Long.TYPE) {
			obj = result.getLong(columnName);
		} else if (convType == Short.TYPE) {
			obj = result.getShort(columnName);
		} else if (convType == Boolean.TYPE) {
			obj = result.getBoolean(columnName);
		}

		return obj;
	}

}
