package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SagyoKubunBean;

/**
 * <strong>作業区分取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2014/02/27 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetSagyoKubunEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 作業区分Bean */
	private SagyoKubunBean sagyoKubunBean;

	/**
	 * sagyoKubunBeanを取得する。
	 * @return sagyoKubunBean 作業区分Bean
	 */
	public SagyoKubunBean getSagyoKubunBean() {
		return sagyoKubunBean;
	}

	/**
	 * sagyoKubunBeanを設定する。
	 * @param sagyoKubunBean 作業区分Bean
	 */
	public void setSagyoKubunBean(SagyoKubunBean sagyoKubunBean) {
		this.sagyoKubunBean = sagyoKubunBean;
	}

}
