package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.SiwakeCodeMasterDAOIF;

/**
 * <strong>仕分用コード区分マスタ操作用イベントリスナ。</strong>
 *
 * @author C.O(TEC)
 * @version 1.00 2013/02/05 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SiwakeCodeMasterEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {
		SiwakeCodeMasterEvent cmEvent = (SiwakeCodeMasterEvent)event;
		SiwakeCodeMasterDAOIF cmDaoIF = getDAO(UcarDAOKey.SIWAKECODE_MASTER_DAO, event, SiwakeCodeMasterDAOIF.class);
		
		return cmDaoIF.getSiwakeCodeMasterList(cmEvent.getKbID()

										,cmEvent.getUserInfoBean());
	}
}