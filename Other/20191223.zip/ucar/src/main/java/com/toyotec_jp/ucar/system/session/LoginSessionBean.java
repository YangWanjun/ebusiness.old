package com.toyotec_jp.ucar.system.session;

import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;

/**
 * <strong>ログインユーザの情報を格納するセッションビーンクラス。</strong>
 * @author H.O(SCC)
 * @version 1.00 2010/06/23 新規作成<br>
 * @since 1.00
 */
public class LoginSessionBean extends TecBean implements SessionBeanIF {

	private static final long serialVersionUID = 9046447436258623288L;

	private UserInformationBean userInfoBean;

	/**
	 * userInfoBeanを取得する。
	 * @return userInfoBean
	 */
	public UserInformationBean getUserInfoBean() {
		return userInfoBean;
	}

	/**
	 * userInfoBeanを設定する。
	 * @param userInfoBean
	 */
	public void setUserInfoBean(UserInformationBean userInfoBean) {
		this.userInfoBean = userInfoBean;
	}

}
