package com.toyotec_jp.ucar.workflow.carryin.register.view;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;

import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.ListDummySessionBean;

/**
 * <strong>搬入情報一覧(ダミー)ヘルパービーン。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 * @category [[ダミー]]
 */
public class ListDummyHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 8584928315609391060L;

	private ListDummySessionBean sessionBean;

	private String	serviceUrlPrintTest;

	/** デフォルトコンストラクタ。 */
	public ListDummyHelperBean() throws HelperBeanException {
		super();
	}

	/* (非 Javadoc)
	 * @see com.toyotec_jp.t_lease.base.view.TlsHelperBean#init()
	 */
	@Override
	public void init() throws HelperBeanException {

//		HomeDirectory APP_HOME_DIR = HomeDirectory.instance();
//		String OUTPUT_DIR = "/doc/imart/toyotec/ucar/temp/pdf/";
//		String OUTPUT_WORK_DIR = "/work/";
//		String nowDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_LONG_SIMPLE);
//
//		File folderPath = new File(APP_HOME_DIR + OUTPUT_DIR);
//		if(!folderPath.exists()){
//			// 出力先ディレクトリが無い場合
//			folderPath.mkdirs();
//		}
//
//		File sf = new File(APP_HOME_DIR + OUTPUT_WORK_DIR + "toyotec/ucar/temp/excel_format/20110705142858281#ucar#newcar.pdf");
//		File df = new File(APP_HOME_DIR + OUTPUT_DIR + "工程管理表_"+ nowDate + ".pdf");
//
//		FileChannel sourceChannel = null, destinationChannel = null;
//		try {
//			sourceChannel = new FileInputStream(sf).getChannel();
//			destinationChannel = new FileOutputStream(df).getChannel();
//			destinationChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//			if (destinationChannel != null) try { destinationChannel.close(); } catch (IOException e) {}
//			if (sourceChannel != null) try { sourceChannel.close(); } catch (IOException e) {}
//		}

//		NetworkFile nf = new NetworkFile("toyotec/ucar/temp/excel_format/newcar.pdf");
//
//		File folderPath = new File(APP_HOME_DIR + "/doc/imart/toyotec/ucar/temp/pdf/");
//		if(!folderPath.exists()){
//			// 出力先ディレクトリが無い場合
//			folderPath.mkdirs();
//		}
//
//		File newFile = new File(APP_HOME_DIR + "/doc/imart/toyotec/ucar/temp/pdf/javaCopyNewcar"+ time + ".pdf");
//
//		OutputStream os = null;
//		try {
//			byte[] data = nf.load();
//
//			os = new FileOutputStream(newFile);
//			os.write(data);
//
//		} catch (Exception e) {
//			throw new RuntimeException(e);
//		} finally {
//			if (os != null) try { os.close(); } catch (IOException e) {}
//		}

		sessionBean = getApplicationSessionBean(ListDummySessionBean.class);
		serviceUrlPrintTest = getServiceUrl(CarryinServiceId.DUMMY_PRINT_TEST);
	}

	/**
	 * sessionBeanを取得する。
	 * @return sessionBean
	 */
	public ListDummySessionBean getSessionBean() {
		return sessionBean;
	}

	/**
	 * serviceUrlPrintTestを取得する。
	 * @return serviceUrlPrintTest
	 */
	public String getServiceUrlPrintTest() {
		return serviceUrlPrintTest;
	}
}
