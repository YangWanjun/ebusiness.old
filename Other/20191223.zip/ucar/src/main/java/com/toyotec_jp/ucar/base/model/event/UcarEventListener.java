/*
 * 【システム名】リース管理システム
 * 【ファイル名】UcarEventListener.java
 * 【  説  明  】
 * 【  作  成  】2010/06/02 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventManager;
import jp.co.intra_mart.framework.base.event.StandardEventListener;
import jp.co.intra_mart.framework.base.util.UserInfo;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.TecApplicationManager.TecConfigKey;
import com.toyotec_jp.im_common.TecApplicationManager.TecDAOKeyIF;
import com.toyotec_jp.im_common.TecApplicationManager.TecEventKeyIF;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarEventKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.ExcelFormatReadEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.ExcelFormatWriteEvent;

/**
 * <strong>基本イベントリスナ。</strong>
 * <p>
 * イベントリスナ作成時は本クラスを継承すること。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/02 新規作成<br>
 * @since 1.00
 */
public abstract class UcarEventListener extends StandardEventListener {

	/**
	 * イベントを生成。
	 * <pre>
	 * アプリケーションID、イベントキーに対応するイベントを返却する。
	 * </pre>
	 * @param applicationID アプリケーションID
	 * @param eventKey イベントキー
	 * @param userInfo ユーザ情報
	 * @return イベントキーに対応するイベント
	 * @throws TecSystemException
	 */
	protected Event createEvent(String applicationID, String eventKey, UserInfo userInfo) throws TecSystemException {
		Event event = null;
		try {
			event = EventManager.getEventManager().createEvent(applicationID, eventKey, userInfo);
		} catch (Exception e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		return event;
	}

	/**
	 * イベントを生成。
	 * <pre>
	 * イベントキーに対応するイベントを返却する。
	 * </pre>
	 * @param eventKey イベントキー
	 * @param userInfo ユーザ情報
	 * @return イベントキーに対応するイベント
	 * @throws TecSystemException
	 */
	protected Event createEvent(TecEventKeyIF eventKey, UserInfo userInfo) throws TecSystemException {
		return createEvent(eventKey.getApplicationId(), eventKey.getEventKey(), userInfo);
	}

	/**
	 * イベントを生成。
	 * <pre>
	 * イベントキーに対応するイベントを返却する。
	 * </pre>
	 * @param <E>
	 * @param eventKey イベントキー
	 * @param userInfo ユーザ情報
	 * @param cls 返却するイベントのクラス
	 * @return イベントキーに対応するイベント
	 * @throws TecSystemException
	 */
	protected <E extends Event> E createEvent(TecEventKeyIF eventKey, UserInfo userInfo, Class<E> cls) throws TecSystemException {
		E targetEvent = null;
		Event event = createEvent(eventKey, userInfo);
		if(cls.isAssignableFrom(event.getClass())){
			targetEvent = cls.cast(event);
		} else {
			TecSystemException e = new TecSystemException(new ClassCastException());
			TecLogger.error(e);
			throw e;
		}
		return targetEvent;
	}

	/**
	 * DAOIFを返却する。
	 * <pre>
	 * DAOキーに対応するDAOIFを返却する。
	 * </pre>
	 * @param <E>
	 * @param daoKey DAOキー
	 * @param event イベント
	 * @param cls 返却するDAOIFのクラス
	 * @return DAOIF
	 * @throws TecSystemException
	 */
	protected <E> E getDAO(TecDAOKeyIF daoKey, Event event, Class<E> cls) throws TecSystemException {
		String loginGroupID = event.getUserInfo().getLoginGroupID();
		return getDAO(daoKey, TecApplicationManager.getConfigValue(TecConfigKey.SHAREE_DB_SCHEMA), cls);
	}

	/**
	 * DAOIFを返却する。
	 * <pre>
	 * DAOキーに対応するDAOIFを返却する。
	 * </pre>
	 * @param <E>
	 * @param daoKey DAOキー
	 * @param loginGroupID ログイングループID
	 * @param cls 返却するDAOIFのクラス
	 * @return DAOIF
	 * @throws TecSystemException
	 */
	protected <E> E getDAO(TecDAOKeyIF daoKey, String loginGroupID, Class<E> cls) throws TecSystemException {
		E daoIF = null;
		Object dao = null;
		try {
			dao = getDAO(daoKey.getApplicationId(), daoKey.getDAOKey(), TecApplicationManager.getConfigValue(TecConfigKey.SHAREE_DB_SCHEMA));
		} catch (SystemException e) {
			TecLogger.error(e);
			throw new TecSystemException(e);
		}
		for(Class<?> ifcls : dao.getClass().getInterfaces()){
			if(cls.isAssignableFrom(ifcls)){
				daoIF = cls.cast(dao);
				break;
			}
		}
		if(daoIF == null){
			TecSystemException e = new TecSystemException(new ClassCastException());
			TecLogger.error(e);
			throw e;
		}
		return daoIF;
	}

	/**
	 * Excel読み込みイベントを生成。
	 * @param userInfo ユーザ情報
	 * @return Excel読み込みイベント
	 * @throws TecSystemException
	 */
	protected ExcelFormatReadEvent createExcelFormatReadEvent(UserInfo userInfo) throws TecSystemException {
		return createEvent(UcarEventKey.EXCEL_FORMAT_READ, userInfo, ExcelFormatReadEvent.class);
	}

	/**
	 * Excel書き込みイベントを生成。
	 * @param userInfo ユーザ情報
	 * @return Excel書き込みイベント
	 * @throws TecSystemException
	 */
	protected ExcelFormatWriteEvent createExcelFormatWriteEvent(UserInfo userInfo) throws TecSystemException {
		return createEvent(UcarEventKey.EXCEL_FORMAT_WRITE, userInfo, ExcelFormatWriteEvent.class);
	}

}
