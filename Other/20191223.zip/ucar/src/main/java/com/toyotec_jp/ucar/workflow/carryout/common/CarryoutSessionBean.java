package com.toyotec_jp.ucar.workflow.carryout.common;

import com.toyotec_jp.ucar.system.session.ApplicationSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;

/**
 * <strong>車両搬出セッションBean。</strong>
 * <p>
 * セッションに格納する車両搬出パッケージ共通セッションBean。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/08/02 新規作成<br>
 * @since 1.00
 * @category [[車両搬出(共通)]]
 */
public class CarryoutSessionBean extends ApplicationSessionBean {

	private static final long serialVersionUID = -8839503802278602566L;

	/** サービスID */
	private String serviceId;
	/** メニューID */
	private String menuId;

	private String backFlg;
	
	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;

	/**
	 * デフォルトコンストラクタ。
	 */
	public CarryoutSessionBean() {
		setDefaultParams();
	}

	/**
	 * デフォルトパラメータ設定。
	 * <pre>
	 * メニューID以外のパラメータ初期化。
	 * </pre>
	 */
	public void setDefaultParams(){
		t220001gPkBean 		= new Ucaa001gPKBean();
		backFlg = "false";
	}





	public String getBackFlg() {
		return backFlg;
	}

	public void setBackFlg(String backFlg) {
		this.backFlg = backFlg;
	}

	/**
	 * serviceIdを取得する。
	 * @return serviceId サービスID
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * serviceIdを設定する。
	 * @param serviceId サービスID
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * menuIdを取得する。
	 * @return menuId メニューID
	 */
	public String getMenuId() {
		return menuId;
	}

	/**
	 * menuIdを設定する。
	 * @param menuId メニューID
	 */
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}



}
