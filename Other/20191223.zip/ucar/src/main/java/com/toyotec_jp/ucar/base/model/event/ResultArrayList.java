/*
 * 【システム名】リース管理システム
 * 【ファイル名】ResultArrayList.java
 * 【  説  明  】
 * 【  作  成  】2010/06/10 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.ucar.base.model.event;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.exception.TecUnsupportedDataTypeException;
import com.toyotec_jp.im_common.system.message.TecMessageKey;
import com.toyotec_jp.im_common.system.model.object.MethodInfoBean;
import com.toyotec_jp.im_common.system.model.object.TecBean;
import com.toyotec_jp.im_common.system.utils.ReflectionUtils;


/**
 * <strong>ResultArrayListクラス。</strong>
 * <p>
 * イベント処理結果として使用可能なArrayList。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/06/10 新規作成<br>
 * @since 1.00
 */
public class ResultArrayList<E> extends ArrayList<E> implements UcarEventResult {

	private static final long serialVersionUID = -3849096241278359187L;

	/**
	 * コンストラクタ。
	 */
	public ResultArrayList() {
		super();
	}

	/**
	 * コンストラクタ。
	 * @param c
	 */
	public ResultArrayList(Collection<? extends E> c) {
		super(c);
	}

	/**
	 * コンストラクタ。
	 * @param initialCapacity
	 */
	public ResultArrayList(int initialCapacity) {
		super(initialCapacity);
	}

	/**
	 * リスト要素をフィルタして新規リストを返却。
	 * <pre>
	 * filterにマッチしたリスト要素を返却する。<br>
	 * 値がNullのフィールド(filter側)はフィルタ条件としない。
	 * </pre>
	 * @param filter 条件となるビーン
	 * @param isIgnoreCase true:文字列比較時に大文字小文字を区別しない
	 * @param isStringFilterOnly true:文字列フィールドの値のみをフィルタ対象とする
	 * @return フィルタした新規リスト
	 * @throws TecSystemException
	 */
	public ResultArrayList<E> getFilterdNewList(
			E filter, boolean isIgnoreCase, boolean isStringFilterOnly) throws TecSystemException {
		ResultArrayList<E> newList = new ResultArrayList<E>();
		try {
			if(TecBean.class.isAssignableFrom(filter.getClass())){
				ArrayList<Method> methodList = null;
				methodList = getFilterTargetMethodList(filter, isStringFilterOnly);
				for(E item : this){
					boolean isMatch = true;
					for(Method method : methodList){
						Object filterVal = method.invoke(filter);
						Object itemVal = method.invoke(item);
						// 無視フラグtrue、String型の場合
						if(isIgnoreCase && String.class.isAssignableFrom(filterVal.getClass())){
							if(!String.class.cast(filterVal).equalsIgnoreCase(String.class.cast(itemVal))){
								isMatch = false;
								break;
							}
						} else {
							if(!filterVal.equals(itemVal)){
								isMatch = false;
								break;
							}
						}
					}
					if(isMatch){
						newList.add(item);
					}
				}
			} else if(String.class.isAssignableFrom(filter.getClass())){
				for(E item : this){
					boolean isMatch = true;
					// 無視フラグtrue、String型の場合
					if(isIgnoreCase){
						if(!String.class.cast(filter).equalsIgnoreCase(String.class.cast(item))){
							isMatch = false;
						}
					} else {
						if(!filter.equals(item)){
							isMatch = false;
						}
					}
					if(isMatch){
						newList.add(item);
					}
				}
			} else {
				// 要素がTBean、String以外は対象外
				throw new TecUnsupportedDataTypeException(TecMessageKey.SYS_E_UNSUPPORTED_DATA_TYPE);
			}
		} catch (IllegalArgumentException e) {
			throw new TecSystemException(e);
		} catch (IllegalAccessException e) {
			throw new TecSystemException(e);
		} catch (InvocationTargetException e) {
			throw new TecSystemException(e);
		}
		newList.trimToSize();
		return newList;
	}

	// フィルタ対象メソッドのリスト取得
	private ArrayList<Method> getFilterTargetMethodList(
			E filter, boolean isStringFilterOnly) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		ArrayList<Method> methodList = new ArrayList<Method>();
		// ゲッターのハッシュマップ取得
		HashMap<String, MethodInfoBean> filterTarget = ReflectionUtils.getBeanGetterMap(filter.getClass());
		for(Entry<String, MethodInfoBean> filterTargetEntry : filterTarget.entrySet()){
			// 条件として対象とするデータ型である場合
			Method method = filterTargetEntry.getValue().getMethod();
			if(isTargetType(method.getReturnType(), isStringFilterOnly)){
				Object val = method.invoke(filter);
				if(val != null){
					methodList.add(method);
				}
			}
		}
		return methodList;
	}

	// フィールドの型がフィルタ対象かどうか
	private static boolean isTargetType(Class<?> fieldType, boolean isStringFilterOnly){
		boolean isTarget = false;
		if(fieldType.isPrimitive() && !isStringFilterOnly){
			if(
					fieldType == Byte.TYPE || fieldType == Character.TYPE ||
					fieldType == Double.TYPE || fieldType == Float.TYPE ||
					fieldType == Integer.TYPE || fieldType == Long.TYPE || fieldType == Short.TYPE ||
					fieldType == Boolean.TYPE){
				isTarget = true;
			}
		} else {
			if(String.class.equals(fieldType)){
				isTarget = true;
			}
		}
		return isTarget;
	}

}
