package com.toyotec_jp.ucar.workflow.adjustment.salesadjustment.model.object;

import java.util.Date;

import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb004gBean;

/**
 * <strong>売上精算 画面出力値Bean</strong>
 * <p>
 * 売上精算情報Bean(Ucbb004gBean)を継承している。
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/09/22 新規作成<br>
 * @since 1.00
 * @category [[売上精算]]
 */
public class SalesAdjustmentDataBean extends Ucbb004gBean {

	/**  */
	private static final long serialVersionUID	= -2393603105655318730L;

	/** 受注NO */
	private String noJucyu;
	/** 車名 */
	private String mjSyamei;
	/** 車台番号 */
	private String noSyadai;
	/** 得意先値引適用区分 */
	private String kbNebiki;
	/** 依頼伝票NO */
	private String noIrdenpyo;
	/** ご用命事項区分 */
	private String kbGoyomei;
	/** 精算日 */
	private Date ddSeisan;
	/** 消費税率 */
	private double suTaxritu;  // 2013/08/28 要望対応
	/** 消費税率同一判定 */
	private boolean sameTax = true;   // 2013/09/10 要望対応

	/**
	 *
	 */
	public SalesAdjustmentDataBean() {
		super();
	}

	/**
	 * noJucyuを取得する。
	 * @return noJucyu 受注NO
	 */
	public String getNoJucyu() {
		return noJucyu;
	}

	/**
	 * noJucyuを設定する。
	 * @param noJucyu 受注NO
	 */
	public void setNoJucyu(String noJucyu) {
		this.noJucyu = noJucyu;
	}

	/**
	 * mjSyameiを取得する。
	 * @return mjSyamei 車名
	 */
	public String getMjSyamei() {
		return mjSyamei;
	}

	/**
	 * mjSyameiを設定する。
	 * @param mjSyamei 車名
	 */
	public void setMjSyamei(String mjSyamei) {
		this.mjSyamei = mjSyamei;
	}

	/**
	 * noSyadaiを取得する。
	 * @return noSyadai 車台番号
	 */
	public String getNoSyadai() {
		return noSyadai;
	}

	/**
	 * noSyadaiを設定する。
	 * @param noSyadai 車台番号
	 */
	public void setNoSyadai(String noSyadai) {
		this.noSyadai = noSyadai;
	}

	/**
	 * kbNebikiを取得する。
	 * @return kbNebiki 得意先値引適用区分
	 */
	public String getKbNebiki() {
		return kbNebiki;
	}

	/**
	 * kbNebikiを設定する。
	 * @param kbNebiki 得意先値引適用区分
	 */
	public void setKbNebiki(String kbNebiki) {
		this.kbNebiki = kbNebiki;
	}

	/**
	 * noIrdenpyoを取得する。
	 * @return noIrdenpyo 依頼伝票NO
	 */
	public String getNoIrdenpyo() {
		return noIrdenpyo;
	}

	/**
	 * noIrdenpyoを設定する。
	 * @param noIrdenpyo 依頼伝票NO
	 */
	public void setNoIrdenpyo(String noIrdenpyo) {
		this.noIrdenpyo = noIrdenpyo;
	}

	/**
	 * kbGoyomeiを取得する。
	 * @return kbGoyomei ご用命事項区分
	 */
	public String getKbGoyomei() {
		return kbGoyomei;
	}

	/**
	 * kbGoyomeiを設定する。
	 * @param kbGoyomei ご用命事項区分
	 */
	public void setKbGoyomei(String kbGoyomei) {
		this.kbGoyomei = kbGoyomei;
	}

	/**
	 * ddSeisanを取得する。
	 * @return ddSeisan 精算日
	 */
	public Date getDdSeisan() {
		return ddSeisan;
	}

	/**
	 * ddSeisanを設定する。
	 * @param ddSeisan 精算日
	 */
	public void setDdSeisan(Date ddSeisan) {
		this.ddSeisan = ddSeisan;
	}

	// 2013/08/28 要望対応 start
	/**
	 * suTaxrituを取得する。
	 * @return suTaxritu 消費税率
	 */
	public double getSuTaxritu() {
		return suTaxritu;
	}

	/**
	 * suTaxrituを設定する。
	 * @param suTaxritu 消費税率
	 */
	public void setSuTaxritu(double suTaxritu) {
		this.suTaxritu = suTaxritu;
	}

	/**
	 * sameTaxを取得する。
	 * @return sameTax 消費税同一判定
	 */
	public boolean getSameTax() {
		return sameTax;
	}

	/**
	 * sameTaxを設定する。
	 * @param sameTax 消費税同一判定
	 */
	public void setSameTax(boolean sameTax) {
		this.sameTax = sameTax;
	}

	// 2013/08/28 要望対応 end

	/**
	 * stateListTextlabelを取得する。
	 * @return stateListTextlabel
	 */
	public String getStateListTextlabel() {
		String stateListTextlabel = "false";
		if (this.getDdSeisan() != null) {
			// 精算日がある場合には入力不可にする
			stateListTextlabel = "true";
		}
		return stateListTextlabel;
	}

	/**
	 * stateListSelectを取得する。
	 * @return stateListSelect
	 */
	public String getStateListSelect() {
		String stateListSelect = "";
		if (this.getDdSeisan() != null) {
			// 精算日がある場合には入力不可にする
			stateListSelect = "disabled";
		}
		return stateListSelect;
	}

	/**
	 * stateButtonを取得する。
	 * @return stateButton
	 */
	public String getStateButton() {
		String stateButton = "false";
		if (this.getDdSeisan() != null) {
			// 精算日がある場合には入力不可にする
			stateButton = "true";
		}
		return stateButton;
	}

	private String replace(int money) {
		String ret = "";
		if (money != 0) {
			ret = String.valueOf(money);
		}
		return ret;
	}

	public String getStrKiGenbuhin() {
		return replace(super.getKiGenbuhin());
	}

	public String getStrKiGengai() {
		return replace(super.getKiGengai());
	}

	public String getStrKiGenka() {
		return replace(super.getKiGenka());
	}

	public String getStrKiGenkou() {
		return replace(super.getKiGenkou());
	}

	public String getStrKiGenyusi() {
		return replace(super.getKiGenyusi());
	}

	public String getStrKiNebiki() {
		return replace(super.getKiNebiki());
	}

	public String getStrKiSeikyu() {
		return replace(super.getKiSeikyu());
	}

	public String getStrKiSyafbuhin() {
		return replace(super.getKiSyafbuhin());
	}

	public String getStrKiSyafgai() {
		return replace(super.getKiSyafgai());
	}

	public String getStrKiSyafkou() {
		return replace(super.getKiSyafkou());
	}

	public String getStrKiSyafyusi() {
		return replace(super.getKiSyafyusi());
	}

	public String getStrKiSyanai() {
		return replace(super.getKiSyanai());
	}

	public String getStrKiTax() {
		return replace(super.getKiTax());
	}

	public String getStrKiTnebiki() {
		return replace(super.getKiTnebiki());
	}

	public String getStrKiUriage() {
		return replace(super.getKiUriage());
	}

	public String getStrKiUribuhin() {
		return replace(super.getKiUribuhin());
	}

	public String getStrKiUrigai() {
		return replace(super.getKiUrigai());
	}

	public String getStrKiUrikou() {
		return replace(super.getKiUrikou());
	}

	public String getStrKiUriyusi() {
		return replace(super.getKiUriyusi());
	}

}
