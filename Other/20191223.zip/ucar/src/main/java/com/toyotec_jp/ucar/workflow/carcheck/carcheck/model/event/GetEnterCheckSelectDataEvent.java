package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>入庫検査選択イベント。</strong>
 * <p>
 * </p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/21 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class GetEnterCheckSelectDataEvent extends UcarEvent {

	private static final long serialVersionUID = -1170024913671409592L;

	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;
	/** 搬入日(画面からの入力値、またはバーコードの値) */
	private String selectDdHannyu;
	/** 管理番号(画面からの入力値、またはバーコードの値) */
	private String selectNoKanri;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * selectDdHannyuを取得する。
	 * @return selectDdHannyu
	 */
	public String getSelectDdHannyu() {
		return selectDdHannyu;
	}

	/**
	 * selectDdHannyuを設定する。
	 * @param selectDdHannyu
	 */
	public void setSelectDdHannyu(String selectDdHannyu) {
		this.selectDdHannyu = selectDdHannyu;
	}

	/**
	 * selectNoKanriを取得する。
	 * @return selectNoKanri
	 */
	public String getSelectNoKanri() {
		return selectNoKanri;
	}

	/**
	 * selectNoKanriを設定する。
	 * @param selectNoKanri
	 */
	public void setSelectNoKanri(String selectNoKanri) {
		this.selectNoKanri = selectNoKanri;
	}

}
