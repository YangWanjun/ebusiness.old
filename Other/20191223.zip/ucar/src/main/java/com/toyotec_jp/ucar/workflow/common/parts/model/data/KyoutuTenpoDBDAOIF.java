package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.KyoutuTenpoDBBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa006mBean;

/**
 * <strong>共通店舗DB操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface KyoutuTenpoDBDAOIF {

	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
	/**
	 * 共通店舗DBリスト取得
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @return 共通店舗DBリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<KyoutuTenpoDBBean> getKyoutuTenpoDBList(String cdKaisya, String cdHanbaitn) throws TecDAOException;
	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
	/**
	 * 店舗付加マスタ取得処理
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @return 店舗付加マスタリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<Ucaa006mBean> selectT220006m(String cdKaisya, String cdHanbaitn) throws TecDAOException;
	// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため start
	/**
	 * 共通店舗DBリスト取得
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @param cdTenpo 店舗コード
	 * @return 共通店舗DBBean
	 * @throws TecDAOException
	 */
	public KyoutuTenpoDBBean getKyoutuTenpoDB(String cdKaisya,
												String cdHanbaitn,
												String cdTenpo) throws TecDAOException;
	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため end

}
