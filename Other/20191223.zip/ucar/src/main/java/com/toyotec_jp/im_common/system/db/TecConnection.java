/*
 * 【システム名】IM用共通ライブラリ
 * 【ファイル名】TecConnection.java
 * 【  説  明  】
 * 【  作  成  】2010/05/19 H.O(SCC)
 * 【  変  更  】
 */
package com.toyotec_jp.im_common.system.db;

import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.Map;
import java.util.Properties;

import com.toyotec_jp.im_common.system.log.TecLogger;


/**
 * <strong>共通コネクションクラス。</strong>
 * <p>
 * 共通ステートメントを取得可能なコネクションクラス。
 * </p>
 * @author H.O(SCC)
 * @version 1.00 2010/05/19 新規作成<br>
 * @since 1.00
 */
public class TecConnection {

	private Connection con = null;

	/**
	 * コンストラクタ。
	 * @param con
	 */
	public TecConnection(Connection con){
		this.con = con;
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Connection#clearWarnings()
	 */
	public void clearWarnings() throws SQLException {
		con.clearWarnings();
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Connection#close()
	 */
	public void close() throws SQLException {
		con.close();
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Connection#commit()
	 */
	public void commit() throws SQLException {
		con.commit();
	}

	/**
	 * @param typeName
	 * @param elements
	 * @return Array
	 * @throws SQLException
	 * @see java.sql.Connection#createArrayOf(java.lang.String, java.lang.Object[])
	 */
	public Array createArrayOf(String typeName, Object[] elements)
			throws SQLException {
		return con.createArrayOf(typeName, elements);
	}

	/**
	 * @return Blob
	 * @throws SQLException
	 * @see java.sql.Connection#createBlob()
	 */
	public Blob createBlob() throws SQLException {
		return con.createBlob();
	}

	/**
	 * @return Clob
	 * @throws SQLException
	 * @see java.sql.Connection#createClob()
	 */
	public Clob createClob() throws SQLException {
		return con.createClob();
	}

	/**
	 * @return NClob
	 * @throws SQLException
	 * @see java.sql.Connection#createNClob()
	 */
	public NClob createNClob() throws SQLException {
		return con.createNClob();
	}

	/**
	 * @return SQLXML
	 * @throws SQLException
	 * @see java.sql.Connection#createSQLXML()
	 */
	public SQLXML createSQLXML() throws SQLException {
		return con.createSQLXML();
	}

	/**
	 * @return Statement
	 * @throws SQLException
	 * @see java.sql.Connection#createStatement()
	 */
	public Statement createStatement() throws SQLException {
		return con.createStatement();
	}

	/**
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @param resultSetHoldability
	 * @return Statement
	 * @throws SQLException
	 * @see java.sql.Connection#createStatement(int, int, int)
	 */
	public Statement createStatement(int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return con.createStatement(resultSetType, resultSetConcurrency,
				resultSetHoldability);
	}

	/**
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @return Statement
	 * @throws SQLException
	 * @see java.sql.Connection#createStatement(int, int)
	 */
	public Statement createStatement(int resultSetType, int resultSetConcurrency)
			throws SQLException {
		return con.createStatement(resultSetType, resultSetConcurrency);
	}

	/**
	 * @param typeName
	 * @param attributes
	 * @return Struct
	 * @throws SQLException
	 * @see java.sql.Connection#createStruct(java.lang.String, java.lang.Object[])
	 */
	public Struct createStruct(String typeName, Object[] attributes)
			throws SQLException {
		return con.createStruct(typeName, attributes);
	}

	/**
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Connection#getAutoCommit()
	 */
	public boolean getAutoCommit() throws SQLException {
		return con.getAutoCommit();
	}

	/**
	 * @return String
	 * @throws SQLException
	 * @see java.sql.Connection#getCatalog()
	 */
	public String getCatalog() throws SQLException {
		return con.getCatalog();
	}

	/**
	 * @return Properties
	 * @throws SQLException
	 * @see java.sql.Connection#getClientInfo()
	 */
	public Properties getClientInfo() throws SQLException {
		return con.getClientInfo();
	}

	/**
	 * @param name
	 * @return String
	 * @throws SQLException
	 * @see java.sql.Connection#getClientInfo(java.lang.String)
	 */
	public String getClientInfo(String name) throws SQLException {
		return con.getClientInfo(name);
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Connection#getHoldability()
	 */
	public int getHoldability() throws SQLException {
		return con.getHoldability();
	}

	/**
	 * @return DatabaseMetaData
	 * @throws SQLException
	 * @see java.sql.Connection#getMetaData()
	 */
	public DatabaseMetaData getMetaData() throws SQLException {
		return con.getMetaData();
	}

	/**
	 * @return int
	 * @throws SQLException
	 * @see java.sql.Connection#getTransactionIsolation()
	 */
	public int getTransactionIsolation() throws SQLException {
		return con.getTransactionIsolation();
	}

	/**
	 * @return Map
	 * @throws SQLException
	 * @see java.sql.Connection#getTypeMap()
	 */
	public Map<String, Class<?>> getTypeMap() throws SQLException {
		return con.getTypeMap();
	}

	/**
	 * @return SQLWarning
	 * @throws SQLException
	 * @see java.sql.Connection#getWarnings()
	 */
	public SQLWarning getWarnings() throws SQLException {
		return con.getWarnings();
	}

	/**
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Connection#isClosed()
	 */
	public boolean isClosed() throws SQLException {
		return con.isClosed();
	}

	/**
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Connection#isReadOnly()
	 */
	public boolean isReadOnly() throws SQLException {
		return con.isReadOnly();
	}

	/**
	 * @param timeout
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Connection#isValid(int)
	 */
	public boolean isValid(int timeout) throws SQLException {
		return con.isValid(timeout);
	}

	/**
	 * @param arg0
	 * @return boolean
	 * @throws SQLException
	 * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
	 */
	public boolean isWrapperFor(Class<?> arg0) throws SQLException {
		return con.isWrapperFor(arg0);
	}

	/**
	 * @param sql
	 * @return String
	 * @throws SQLException
	 * @see java.sql.Connection#nativeSQL(java.lang.String)
	 */
	public String nativeSQL(String sql) throws SQLException {
		return con.nativeSQL(sql);
	}

	/**
	 * @param sql
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @param resultSetHoldability
	 * @return CallableStatement
	 * @throws SQLException
	 * @see java.sql.Connection#prepareCall(java.lang.String, int, int, int)
	 */
	public CallableStatement prepareCall(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return con.prepareCall(sql, resultSetType, resultSetConcurrency,
				resultSetHoldability);
	}

	/**
	 * @param sql
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @return CallableStatement
	 * @throws SQLException
	 * @see java.sql.Connection#prepareCall(java.lang.String, int, int)
	 */
	public CallableStatement prepareCall(String sql, int resultSetType,
			int resultSetConcurrency) throws SQLException {
		return con.prepareCall(sql, resultSetType, resultSetConcurrency);
	}

	/**
	 * @param sql
	 * @return CallableStatement
	 * @throws SQLException
	 * @see java.sql.Connection#prepareCall(java.lang.String)
	 */
	public CallableStatement prepareCall(String sql) throws SQLException {
		return con.prepareCall(sql);
	}

	/**
	 * 共通プリペアドステートメント取得。
	 * @param sql
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @param resultSetHoldability
	 * @return 共通プリペアドステートメント
	 * @throws SQLException
	 * @see java.sql.Connection#prepareStatement(String, int, int, int)
	 */
	public TecPreparedStatement prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		TecLogger.debug("sql[" + sql + "]");
		return new TecPreparedStatement(con.prepareStatement(sql, resultSetType, resultSetConcurrency,
				resultSetHoldability));
	}

	/**
	 * 共通プリペアドステートメント取得。
	 * @param sql
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @return 共通プリペアドステートメント
	 * @throws SQLException
	 * @see java.sql.Connection#prepareStatement(String, int, int)
	 */
	public TecPreparedStatement prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency) throws SQLException {
		TecLogger.debug("sql[" + sql + "]");
		return new TecPreparedStatement(con.prepareStatement(sql, resultSetType, resultSetConcurrency));
	}

	/**
	 * 共通プリペアドステートメント取得。
	 * @param sql
	 * @param autoGeneratedKeys
	 * @return 共通プリペアドステートメント
	 * @throws SQLException
	 * @see java.sql.Connection#prepareStatement(String, int)
	 */
	public TecPreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
			throws SQLException {
		TecLogger.debug("sql[" + sql + "]");
		return new TecPreparedStatement(con.prepareStatement(sql, autoGeneratedKeys));
	}

	/**
	 * 共通プリペアドステートメント取得。
	 * @param sql
	 * @param columnIndexes
	 * @return 共通プリペアドステートメント
	 * @throws SQLException
	 * @see java.sql.Connection#prepareStatement(String, int[])
	 */
	public TecPreparedStatement prepareStatement(String sql, int[] columnIndexes)
			throws SQLException {
		TecLogger.debug("sql[" + sql + "]");
		return new TecPreparedStatement(con.prepareStatement(sql, columnIndexes));
	}

	/**
	 * 共通プリペアドステートメント取得。
	 * @param sql
	 * @param columnNames
	 * @return 共通プリペアドステートメント
	 * @throws SQLException
	 * @see java.sql.Connection#prepareStatement(String, String[])
	 */
	public TecPreparedStatement prepareStatement(String sql, String[] columnNames)
			throws SQLException {
		TecLogger.debug("sql[" + sql + "]");
		return new TecPreparedStatement(con.prepareStatement(sql, columnNames));
	}

	/**
	 * 共通プリペアドステートメント取得。
	 * @param sql
	 * @return 共通プリペアドステートメント
	 * @throws SQLException
	 * @see java.sql.Connection#prepareStatement(String)
	 */
	public TecPreparedStatement prepareStatement(String sql) throws SQLException {
		TecLogger.debug("sql[" + sql + "]");
		return new TecPreparedStatement(con.prepareStatement(sql));
	}

	/**
	 * @param savepoint
	 * @throws SQLException
	 * @see java.sql.Connection#releaseSavepoint(java.sql.Savepoint)
	 */
	public void releaseSavepoint(Savepoint savepoint) throws SQLException {
		con.releaseSavepoint(savepoint);
	}

	/**
	 * @throws SQLException
	 * @see java.sql.Connection#rollback()
	 */
	public void rollback() throws SQLException {
		con.rollback();
	}

	/**
	 * @param savepoint
	 * @throws SQLException
	 * @see java.sql.Connection#rollback(java.sql.Savepoint)
	 */
	public void rollback(Savepoint savepoint) throws SQLException {
		con.rollback(savepoint);
	}

	/**
	 * @param autoCommit
	 * @throws SQLException
	 * @see java.sql.Connection#setAutoCommit(boolean)
	 */
	public void setAutoCommit(boolean autoCommit) throws SQLException {
		con.setAutoCommit(autoCommit);
	}

	/**
	 * @param catalog
	 * @throws SQLException
	 * @see java.sql.Connection#setCatalog(java.lang.String)
	 */
	public void setCatalog(String catalog) throws SQLException {
		con.setCatalog(catalog);
	}

	/**
	 * @param properties
	 * @throws SQLClientInfoException
	 * @see java.sql.Connection#setClientInfo(java.util.Properties)
	 */
	public void setClientInfo(Properties properties)
			throws SQLClientInfoException {
		con.setClientInfo(properties);
	}

	/**
	 * @param name
	 * @param value
	 * @throws SQLClientInfoException
	 * @see java.sql.Connection#setClientInfo(java.lang.String, java.lang.String)
	 */
	public void setClientInfo(String name, String value)
			throws SQLClientInfoException {
		con.setClientInfo(name, value);
	}

	/**
	 * @param holdability
	 * @throws SQLException
	 * @see java.sql.Connection#setHoldability(int)
	 */
	public void setHoldability(int holdability) throws SQLException {
		con.setHoldability(holdability);
	}

	/**
	 * @param readOnly
	 * @throws SQLException
	 * @see java.sql.Connection#setReadOnly(boolean)
	 */
	public void setReadOnly(boolean readOnly) throws SQLException {
		con.setReadOnly(readOnly);
	}

	/**
	 * @return Savepoint
	 * @throws SQLException
	 * @see java.sql.Connection#setSavepoint()
	 */
	public Savepoint setSavepoint() throws SQLException {
		return con.setSavepoint();
	}

	/**
	 * @param name
	 * @return Savepoint
	 * @throws SQLException
	 * @see java.sql.Connection#setSavepoint(java.lang.String)
	 */
	public Savepoint setSavepoint(String name) throws SQLException {
		return con.setSavepoint(name);
	}

	/**
	 * @param level
	 * @throws SQLException
	 * @see java.sql.Connection#setTransactionIsolation(int)
	 */
	public void setTransactionIsolation(int level) throws SQLException {
		con.setTransactionIsolation(level);
	}

	/**
	 * @param map
	 * @throws SQLException
	 * @see java.sql.Connection#setTypeMap(java.util.Map)
	 */
	public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
		con.setTypeMap(map);
	}

	/**
	 * @param <T>
	 * @param arg0
	 * @return Class
	 * @throws SQLException
	 * @see java.sql.Wrapper#unwrap(java.lang.Class)
	 */
	public <T> T unwrap(Class<T> arg0) throws SQLException {
		return con.unwrap(arg0);
	}

}
