package com.toyotec_jp.ucar.workflow.carryin.list.model.event;
import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinDAOKey;
import com.toyotec_jp.ucar.workflow.carryin.list.model.data.ListDaoIF;
import com.toyotec_jp.ucar.workflow.carryin.list.model.object.ListPageingBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa004mBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucaa005mBean;

/**
 * @category [[車両搬入一覧]]
 */
public class ListSelectEventListener extends UcarEventListener {

	public ListSelectEventListener() {

	}

	/**
	 * イベントに対する処理です。
	 *
	 * @param arg0 イベント
	 * @return イベント処理結果
	 * @throws SystemException システム例外が発生
	 * @throws ApplicationException アプリケーション例外が発生
	 */
	protected EventResult fire(Event arg0) throws SystemException, ApplicationException {

		// イベントのキャスト
		ListSelectEvent listSelect = (ListSelectEvent) arg0;

		// DAOの取得
		ListDaoIF listDaoIF =
			(ListDaoIF) getDAO (CarryinDAOKey.LIST_DAO, listSelect, ListDaoIF.class);


		// チェック内容マスタ取得
		ResultArrayList<Ucaa005mBean> t220005mList = listDaoIF.selectT220005M(listSelect.getListParamBean());

		// 仕入種別マスタ取得 2011.10.18 H.Yamashita add
		ResultArrayList<Ucaa004mBean> t220004mList = listDaoIF.selectT220004M(listSelect.getListParamBean());

		// 検索対象が0件の場合
		if (t220005mList.size() == 0) {
			throw new TecApplicationException(TecMessageManager.getMessage(UcarMessage.NOT_FOUND));
		}

		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため start
		//抽出を実施
		ListPageingBean	listPagingBean =
				listDaoIF.selectMain(listSelect.getUserInfoBean().getKbScenter(),
									 listSelect.getListParamBean(),
									 t220005mList,
									 t220004mList,
									 listSelect.getSortParam(),
									 listSelect.getSortOrder(),
									 listSelect.getPageNo(),
									 listSelect.getPageSize());
		// 2013.05.21 T.Hayato 修正 搬入拠点分散対応2のため end

		ListSelectEventResult eventResult = new ListSelectEventResult();
		//結果の格納
		eventResult.setRtnData(listPagingBean.getResultRecordList());
		eventResult.setT220005mList(t220005mList);
		eventResult.setPageNo(Integer.parseInt(listSelect.getPageNo()));		//	ページ番号
		eventResult.setPageSize(Integer.parseInt(listSelect.getPageSize()));	//	ページサイズ
		eventResult.setTotalRecordCount(listPagingBean.getTotalRecordCount());	//	レコード数

		// イベント処理結果を返す。
		return eventResult;
	}

}
