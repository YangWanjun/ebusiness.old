package com.toyotec_jp.ucar.workflow.carryin.register.service.controller;

import java.util.ArrayList;

import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.ListDummySessionBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucbb001gBean;
import com.toyotec_jp.ucar.workflow.receipt.common.ReceiptConst.ReceiptServiceId;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportUtils;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst.ReportEventKey;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportKouteiKanriEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportKouteiKanriEventResult;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportUriageDenpyoEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportUriageDenpyoEventResult;

public class ListDummyServiceController extends UcarServiceController {

	private ListDummySessionBean sessionBean;

	private String serviceId = "";
	private CarryinServiceId targetServiceId = null;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {
		TecLogger.trace("service start");
		// セッション設定
		setupSession();
		// サービス個別処理
		executeServiceProcess();
		TecLogger.trace("service end");
		return null;
	}

	/** セッション設定 */
	private void setupSession() throws TecSystemException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = CarryinServiceId.getTargetCarryinServiceId(serviceId);

		sessionBean = getApplicationSessionBean(ListDummySessionBean.class);

		String backUrl = StringUtils.defaultValue(getRequest().getParameter("backUrl"));
		if (StringCheckUtils.isEmpty(backUrl)) {
			backUrl = StringUtils.defaultValue(getRequest().getParameter("back_url"));
		}
		sessionBean.setBackUrl(backUrl);

		TecLogger.trace("setupSession end");
	}

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException, ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if(targetServiceId != null){
			switch (targetServiceId) {
				case DUMMY_PRINT_TEST:

					// 印刷処理
					// 車両搬入登録帳票(在庫カード/工程管理表)
					executeReportKouteiKanri();

					break;
				case DUMMY_PRINT_TEST_URIAGE:
					
					// 印刷処理
					// 売上精算
					executeReportUriageDenpyo();
					
					break;
				default:
					break;
			}
		}

		TecLogger.trace("executeServiceProcess end");
	}

	/** 帳票処理：工程管理表 */
	private void executeReportKouteiKanri() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportKouteiKanriEvent event = createEvent(ReportEventKey.REPORT_KOUTEI_KANRI, ReportKouteiKanriEvent.class);

			Ucaa001gPKBean t220001gPKBean = new Ucaa001gPKBean();
			t220001gPKBean.setCdKaisya("01");
			t220001gPKBean.setCdHanbaitn("13601");
			t220001gPKBean.setDdHannyu("20120307");
			t220001gPKBean.setNoKanri("002");

			ArrayList<Ucaa001gPKBean> t220001gPKList = new ArrayList<Ucaa001gPKBean>();
			t220001gPKList.add(t220001gPKBean);

			event.setT220001gPKList(t220001gPKList);

			String printCount = getRequest().getParameter("print_count");

			for (int i = 0; i < Integer.parseInt(printCount); i++) {
				ReportKouteiKanriEventResult eventResult = (ReportKouteiKanriEventResult)dispatchEvent(event);

				TecLogger.info(String.valueOf(i + 1));

				// ダウンロード用処理
				String tempFilePath = eventResult.getFilePath();
				String downloadfileName
				= ReportUtils.getDownloadFileName(ReportConst.FILE_NAME_KOUTEI_KANRI,
						StringUtils.getFileExtension(tempFilePath));

				String currentDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
				String downloadFilePath = ReportUtils.copyPdf(tempFilePath, downloadfileName, currentDate);
			

			sessionBean.setDownloadFilePath(downloadFilePath);
			}

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}
	
	/** 帳票処理：売上伝票 */
	private void executeReportUriageDenpyo() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			String downloadfileName = "";
			ArrayList<String> arrayDownloadFilePath = new ArrayList<String>();

			ReportUriageDenpyoEvent event = createEvent(ReportEventKey.REPORT_URIAGE_DENPYO,
														  ReportUriageDenpyoEvent.class);

			Ucbb001gBean t220211gBean = new Ucbb001gBean();
			t220211gBean.setCdKaisya("01");
			t220211gBean.setCdJigyosyo("001");
			t220211gBean.setNoJucyu("1200001");

			ArrayList<Ucbb001gBean> t220211gList = new ArrayList<Ucbb001gBean>();
			t220211gList.add(t220211gBean);
			event.setT220211gList(t220211gList);

			// 再発行識別フラグ(0:精算、精算取消／1:再発行)
			event.setResikibetuFg("0");

			ReportUriageDenpyoEventResult eventResult = (ReportUriageDenpyoEventResult)dispatchEvent(event);

			// 同名のファイルが作成されないように出力カウンターをファイル名に入れる
			int outputFileCount = 1;
			// ファイルパスの配列
			for (String tempFilePath : eventResult.getArrayFilePath()) {

				// 売上伝票、請求明細書
				// ファイル名変更をする
				downloadfileName = getDownloadFileName(ReportConst.FILE_NAME_IRAI
													   + "_"
													   + outputFileCount++,
													   StringUtils.getFileExtension(tempFilePath));

				// ダウンロード用処理
				String currentDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
				String downloadFilePath = ReportUtils.copyPdf(tempFilePath, downloadfileName, currentDate);

				arrayDownloadFilePath.add(downloadFilePath);
			}

			sessionBean.setArrayDownloadFilePath(arrayDownloadFilePath);

		}catch(SystemException e){
			throw e;
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), ReceiptServiceId.REQUESTISSUE_RELOAD_EXCLUSION);
			throw e;	
		}
	}

	/** 帳票ダウンロードファイル名取得
	 * @param fileName */
	private String getDownloadFileName(String fileName, String fileExtension){
		StringBuilder sb = new StringBuilder();
		sb.append(fileName + "_");
		sb.append(DateUtils.getCurrentDateStr(DateUtils.FORMAT_LONG_SIMPLE));
		sb.append("." + fileExtension);
		return new String(sb);
	}
	
	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, CarryinServiceId carryinServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carryinServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryinServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}
	
	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, ReceiptServiceId receiptServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(receiptServiceId.getApplicationId());
		messageBean.setReturnServiceId(receiptServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

}
