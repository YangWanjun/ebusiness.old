package com.toyotec_jp.ucar.batch.monthly.datacleaning.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.TecApplicationManager;
import com.toyotec_jp.im_common.TecApplicationManager.TecConfigKey;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.batch.common.BatchUtils;
import com.toyotec_jp.ucar.batch.common.BatchConst.BatchDAOKey;
import com.toyotec_jp.ucar.batch.monthly.datacleaning.model.data.DataCleaningDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;

/**
 * <strong>データ削除イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/03 新規作成<br>
 * @since 1.00
 * @category [[バッチ：データ削除]]
 */
public class DataCleaningEventListener extends UcarEventListener {

	/** クラス名 */
	private static final String CLASS_NAME = "DataCleaningEventListener";

	/**
	 * イベントに対する処理です。
	 *
	 * @param event イベント
	 * @return イベント処理結果
	 * @throws SystemException システム例外が発生
	 * @throws ApplicationException アプリケーション例外が発生
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		// DAOの取得
		DataCleaningDAOIF dataCleaningDao
			= (DataCleaningDAOIF) getDAO(BatchDAOKey.DATA_CLEANING_DAO.getApplicationId(),
											BatchDAOKey.DATA_CLEANING_DAO.getDAOKey(),
											TecApplicationManager.getConfigValue(TecConfigKey.SHAREE_DB_SCHEMA));

		String cdKaisya = UcarConst.CD_KAISYA;
		String cdHanbaitn = UcarConst.CD_HANBAITN;

		// 削除対象日付(搬出日)の取得(yyyyMMdd)
		String ddHansyt = getDdHansyt();

		// 削除対象メッセージ出力
		BatchUtils.outputInfoLog(CLASS_NAME, "削除対象は搬出日が『" + UcarUtils.getStringDateFormatShort(ddHansyt) + "』以前のデータです。");

		SimpleExecuteResultBean resultBean = null;

		// 削除処理(車両搬入情報)
		resultBean = dataCleaningDao.deleteT220001G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "車両搬入情報(T220001G)", "削除", resultBean.getExecuteCount());

		// 削除処理(仕入種別情報)
		resultBean = dataCleaningDao.deleteT220002G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "仕入種別情報(T220002G)", "削除", resultBean.getExecuteCount());

		// 削除処理(チェック内容情報)
		resultBean = dataCleaningDao.deleteT220003G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "チェック内容情報(T220003G)", "削除", resultBean.getExecuteCount());

		// 削除処理(書類チェックDB)
		resultBean = dataCleaningDao.deleteT220007G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "書類チェックDB(T220007G)", "削除", resultBean.getExecuteCount());

		// 削除処理(入庫検査チェックDB)
		resultBean = dataCleaningDao.deleteT220008G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "入庫検査チェックDB(T220008G)", "削除", resultBean.getExecuteCount());

		// 削除処理(仕分作業DB)
		resultBean = dataCleaningDao.deleteT220009G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "仕分作業DB(T220009G)", "削除", resultBean.getExecuteCount());

		// 削除処理(完成検査DB)
		resultBean = dataCleaningDao.deleteT220010G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "完成検査DB(T220010G)", "削除", resultBean.getExecuteCount());

		// 削除処理(ステータスDB)
		resultBean = dataCleaningDao.deleteT220012G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "ステータスDB(T220012G)", "削除", resultBean.getExecuteCount());

		// 削除処理(車両搬出情報)
		resultBean = dataCleaningDao.deleteT220013G(cdKaisya, cdHanbaitn, ddHansyt);
		BatchUtils.outputInfoLog(CLASS_NAME, "車両搬出情報(T220013G)", "削除", resultBean.getExecuteCount());

		return null;
	}

	/**
	 * 2年1ヵ月前の月末日付を取得
	 * @return 日付文字列(yyyyMMdd)
	 */
	public String getDdHansyt() {
		// 現在日付を取得(yyyy/MM/dd)
		String strCurrentDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT);
		// 2年前の日付を取得
		String twoYearsAgo = DateUtils.addYear(strCurrentDate, -2);
		// 1ヶ月前の日付を取得(2年1ヵ月前の日付)
		String twoYearsAndOneMonthAgo = DateUtils.addMonth(twoYearsAgo, -1);
		// 2年1ヵ月前の月末日付を取得
		String ddHansyt = UcarUtils.getLastDay(twoYearsAndOneMonthAgo);
		// yyyy/MM/dd⇒yyyyMMddに変換
		return UcarUtils.getStringDateFormatShortSimple(ddHansyt);
	}
}