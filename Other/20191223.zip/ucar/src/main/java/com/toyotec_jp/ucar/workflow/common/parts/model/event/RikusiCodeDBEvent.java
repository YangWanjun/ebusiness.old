package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;

/**
 * <strong>陸支コードDB操作用イベント。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class RikusiCodeDBEvent extends UcarEvent {

	private static final long serialVersionUID = -8975344836334571960L;

	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
	/** 会社コード */
	private String cdKaisya;
	/** 販売店コード */
	private String cdHanbaitn;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn 販売店コード
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn 販売店コード
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}
	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

}
