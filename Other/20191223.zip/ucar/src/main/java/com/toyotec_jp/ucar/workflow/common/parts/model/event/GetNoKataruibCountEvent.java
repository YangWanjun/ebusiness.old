package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;


/**
 * <strong>型式指定類別NO件数取得イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/07/05 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetNoKataruibCountEvent extends UcarEvent {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** 車両搬入情報 プライマリーキーBean */
	private Ucaa001gPKBean t220001gPkBean;
	/** 型式指定類別NO */
	private String	noKataruib;
	/** 詳細確認・修正モード */
	private boolean editMode;

	/**
	 * t220001gPkBeanを取得する。
	 * @return t220001gPkBean
	 */
	public Ucaa001gPKBean getT220001gPkBean() {
		return t220001gPkBean;
	}

	/**
	 * t220001gPkBeanを設定する。
	 * @param t220001gPkBean
	 */
	public void setT220001gPkBean(Ucaa001gPKBean t220001gPkBean) {
		this.t220001gPkBean = t220001gPkBean;
	}

	/**
	 * noKataruibを取得する。
	 * @return noKataruib
	 */
	public String getNoKataruib() {
		return noKataruib;
	}

	/**
	 * noKataruibを設定する。
	 * @param noKataruib
	 */
	public void setNoKataruib(String noKataruib) {
		this.noKataruib = noKataruib;
	}

	/**
	 * editModeを取得する。
	 * @return editMode
	 */
	public boolean isEditMode() {
		return editMode;
	}

	/**
	 * editModeを設定する。
	 * @param editMode
	 */
	public void setEditMode(boolean editMode) {
		this.editMode = editMode;
	}

}
