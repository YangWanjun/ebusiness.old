package com.toyotec_jp.ucar.workflow.common.parts.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.RikusiCodeDBBean;

/**
 * <strong>陸支コードDB操作DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/31 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public interface RikusiCodeDBDAOIF {

	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
	/**
	 * 陸支コードDBリスト取得
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @return 陸支コードDBリスト
	 * @throws TecDAOException
	 */
	public ResultArrayList<RikusiCodeDBBean> getRikusiCodeDBList(String cdKaisya, String cdHanbaitn) throws TecDAOException;
	// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため start
	/**
	 * 陸支コードDB取得
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @param cdRikusi 陸支コード
	 * @return 陸支コードDBBean
	 * @throws TecDAOException
	 */
	public RikusiCodeDBBean getRikusiCodeDB(String cdKaisya,
											String cdHanbaitn,
											String cdRikusi) throws TecDAOException;
	// 2013.04.17 T.Hayato 追加 搬入拠点分散対応2のため end

}
