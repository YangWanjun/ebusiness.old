package com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event;

import java.util.ArrayList;
import java.util.List;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.CarCheckDAOIF;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckDataBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckDAOKey;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.CodeKubunDBDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.CodeKubunDBBean;

/**
 * <strong>入庫検査選択イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/21 新規作成<br>
 * @since 1.00
 * @category [[入庫検査]]
 */
public class GetEnterCheckSelectDataEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		GetEnterCheckSelectDataEvent targetEvent = (GetEnterCheckSelectDataEvent)event;

		// DAOIF取得
		CarCheckDAOIF getDao = getDAO(CarCheckDAOKey.CAR_CHECK_DAO, targetEvent, CarCheckDAOIF.class);

		// 入庫検査 画面出力値取得
		ResultArrayList<CarCheckDataBean> resultList = getDao.selectEnterCheckList(targetEvent.getCdKaisya(),
													targetEvent.getCdHanbaitn(),
													// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
													targetEvent.getUserInfoBean().getCdTenpo(),	
													targetEvent.getUserInfoBean().getKbScenter(),
													// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
													targetEvent.getSelectDdHannyu(),
													targetEvent.getSelectNoKanri(),
													true);

		CodeKubunDBDAOIF codeKubunDao
			= getDAO(UcarDAOKey.CODE_KUBUN_DB_DAO, event, CodeKubunDBDAOIF.class);
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<CodeKubunDBBean> codeKubunList = codeKubunDao.getCodeKubunDBList(targetEvent.getCdKaisya(),
																						targetEvent.getCdHanbaitn());
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		GetEnterCheckSelectDataEventResult getEventResult = new GetEnterCheckSelectDataEventResult();

		if (resultList.size() > 0) {
			// 検索対象が1件以上の場合
			List<CarCheckDataBean> carCheckDataList = new ArrayList<CarCheckDataBean>();

			for (CarCheckDataBean carCheckDataBean : resultList) {

				if (StringCheckUtils.isEmpty(carCheckDataBean.getCdTosyoku())) {
					// 塗色コードがnull/空文字の場合はそのままリストに追加
					carCheckDataList.add(carCheckDataBean);
					continue;
				}
				boolean isAdd = false;
				for (CodeKubunDBBean codeKubunDBBean : codeKubunList) {
					if (carCheckDataBean.getCdTosyoku().equals(codeKubunDBBean.getCdKubun())) {
						// コード区分DBリストに該当するコードが存在した場合
						carCheckDataBean.setMjKubunnai(codeKubunDBBean.getMjKubunnai());
						carCheckDataList.add(carCheckDataBean);
						isAdd = true;
						break;
					}
				}
				if (!isAdd) {
					// 存在しなかった場合はそのままリストに追加
					carCheckDataList.add(carCheckDataBean);
				}
			}
			getEventResult.setCarCheckDataList(carCheckDataList);
		} else {
			// 検索結果が0件の場合

			// 対象データが入庫検査完了しているかを検索
			ResultArrayList<CarCheckDataBean> ddNkknsList = getDao.selectEnterCheckList(targetEvent.getCdKaisya(),
															targetEvent.getCdHanbaitn(),		
															// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　start
															targetEvent.getUserInfoBean().getCdTenpo(),	
															targetEvent.getUserInfoBean().getKbScenter(),
															// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end
															targetEvent.getSelectDdHannyu(),
															targetEvent.getSelectNoKanri(),
															false);

			if (ddNkknsList.size() > 0) {
				// 検索結果が1件以上の場合：既に入庫検査が完了している
				getEventResult.setExistDdNkkns(true);
			}
		}

		return getEventResult;
	}

}
