/*
 * 【システム名】
 * 【ファイル名】DMSheet.java
 * 【  説  明  】ワークシートクラス
 * 【  作  成  】2009/04/01 H.O(SCC)
 * 【  変  更  】2010/09/01 H.O(SCC) version 1.02
 *                 POI 3.5.0対応
 */
package com.toyotec_jp.im_common.system.docmng.mng.excel;

import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapData;
import com.toyotec_jp.im_common.system.docmng.data.DMFilesMapKey;
import com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo;
import com.toyotec_jp.im_common.system.docmng.data.DMSheetMap;


/**
 * <strong>DMSheet</strong>
 * <p>
 * ワークシートクラス<br>
 * POI 3.5.0 版
 * </p>
 * @author H.O(SCC)
 * @version 1.02 2010/09/01 <br>
 */
public class DMSheet {

	// TODO
	// POI 3.0.2 版だったが
	// 3.0.2では入力規則が消えるという問題が発生したため
	// 急遽3.2.0に変更になった
	// そのため対応し切れていない可能性あり
	// 次期バージョン開発時にはその対応も検討すること

	protected Sheet sheet;

	protected DMSheetInfo sheetInfo;

	/**
	 * コンストラクタ
	 * @param hssfSheet
	 * @param mapSheet シート情報格納用マップ
	 */
	protected DMSheet(Sheet hssfSheet, DMSheetMap<DMFilesMapKey, ArrayList<DMFilesMapData>> mapSheet) {
		sheet = hssfSheet;
		setup(mapSheet);
	}

	private int pageIdx;
	private Drawing patriarch;

	/**
	 * シート情報設定
	 * @param mapSheet シート情報格納用マップ
	 * @since 1.00
	 */
	private void setup(DMSheetMap<?, ?> mapSheet){
		pageIdx = 0;
		patriarch = null;
		sheetInfo = new DMSheetInfo(mapSheet);
	}

	/**
	 * 現在のページインデックス取得
	 * @return 現在のページインデックス
	 * @since 1.00
	 */
	public int getPageIdx() {
		return pageIdx;
	}
	/**
	 * 現在のページインデックス加算
	 * @since 1.00
	 */
	public void addPageIdx() {
		pageIdx++;
	}

	/**
	 * オートシェイプ生成用クラス取得
	 * @return オートシェイプ生成用クラス
	 * @since 1.00
	 */
	public Drawing getPatriarch(){
		if(patriarch == null){
			patriarch = sheet.createDrawingPatriarch();
		}
		return patriarch;
	}

	/**
	 * 追加ページ用挿入行数取得
	 * @return 追加ページ用挿入行数
	 * @since 1.00
	 */
	public int getAddPageInsCnt(){
		return sheetInfo.getTsuikaShuryogyo() - sheetInfo.getTsuikaKaishigyo() + 1;
	}

	/**
	 * 現在の最終行インデックス取得
	 * @return 現在の最終行インデックス
	 * @since 1.00
	 */
	public int getLastRowIdx(){
		return sheetInfo.getShokiSaishugyo() + (getAddPageInsCnt() * pageIdx);
	}

	/**
	 * 対象ページの最終行インデックス取得
	 * @param pageIdx 対象ページインデックス
	 * @return 対象ページの最終行インデックス
	 * @since 1.00
	 */
	public int getLastRowIdx(int pageIdx){
		return sheetInfo.getShokiSaishugyo() + (getAddPageInsCnt() * pageIdx);
	}

	/**
	 * 指定した行インデックスの行を取得(値設定用)<br>
	 * 存在しない場合は作成
	 * @param rowIdx 行インデックス
	 * @return 行
	 * @since 1.00
	 */
	private Row getRowForSetData(int rowIdx){
		Row row = sheet.getRow(rowIdx);
		if(row == null) {
			row = sheet.createRow(rowIdx);
		}
		return row;
	}

	/**
	 * 指定した行、列インデックスのセルを取得(値設定用)<br>
	 * 存在しない場合は作成
	 * @param rowIdx 行インデックス
	 * @param colIdx 列インデックス
	 * @return セル
	 * @since 1.00
	 */
	public Cell getCellForSetData(int rowIdx, int colIdx) {
		Row row = getRowForSetData(rowIdx);
		Cell cell = row.getCell(colIdx);
		if(cell == null) {
			cell = row.createCell(colIdx);
		}
		return cell;
	}


	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getKaiPageKbn()
	 */
	public int getKaiPageKbn() {
		return sheetInfo.getKaiPageKbn();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getSheetIdx()
	 */
	public int getSheetIdx() {
		return sheetInfo.getSheetIdx();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getSheetKbn()
	 */
	public int getSheetKbn() {
		return sheetInfo.getSheetKbn();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getSheetNm()
	 */
	public String getSheetNm() {
		return sheetInfo.getSheetNm();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiFilePath()
	 */
	public String getShokiFilePath() {
		return sheetInfo.getShokiFilePath();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiSaishugyo()
	 */
	public int getShokiSaishugyo() {
		return sheetInfo.getShokiSaishugyo();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiSaishuretsu()
	 */
	public int getShokiSaishuretsu() {
		return sheetInfo.getShokiSaishuretsu();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getShokiSheetNm()
	 */
	public String getShokiSheetNm() {
		return sheetInfo.getShokiSheetNm();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaFilePath()
	 */
	public String getTsuikaFilePath() {
		return sheetInfo.getTsuikaFilePath();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaGyoHoseichi()
	 */
	public int getTsuikaGyoHoseichi() {
		return sheetInfo.getTsuikaGyoHoseichi();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaKaishigyo()
	 */
	public int getTsuikaKaishigyo() {
		return sheetInfo.getTsuikaKaishigyo();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaRetsuHoseichi()
	 */
	public int getTsuikaRetsuHoseichi() {
		return sheetInfo.getTsuikaRetsuHoseichi();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaSheetNm()
	 */
	public String getTsuikaSheetNm() {
		return sheetInfo.getTsuikaSheetNm();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getTsuikaShuryogyo()
	 */
	public int getTsuikaShuryogyo() {
		return sheetInfo.getTsuikaShuryogyo();
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.im_common.system.docmng.data.DMSheetInfo#getYoshikiId()
	 */
	public String getYoshikiId() {
		return sheetInfo.getYoshikiId();
	}

}
