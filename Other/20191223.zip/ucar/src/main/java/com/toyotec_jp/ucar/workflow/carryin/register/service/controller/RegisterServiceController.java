package com.toyotec_jp.ucar.workflow.carryin.register.service.controller;

import java.util.ArrayList;

import jp.co.intra_mart.framework.base.service.ServiceControllerException;
import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecApplicationException;
import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.message.TecMessageManager;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.SimpleRequestMapper;
import com.toyotec_jp.im_common.system.utils.StringCheckUtils;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinEventKey;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinConst.CarryinServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.carryin.register.model.event.DeleteRegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.register.model.event.RegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.register.model.event.RegisterDataEventResult;
import com.toyotec_jp.ucar.workflow.carryin.register.model.event.UpdateRegisterDataEvent;
import com.toyotec_jp.ucar.workflow.carryin.register.model.object.RegisterInputBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst.UcarMessage;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportUtils;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst.ReportEventKey;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportKouteiKanriEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportKouteiKanriEventResult;

/**
 * <strong>車両搬入登録サービスコントローラ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/05/30 新規作成<br>
 * @since 1.00
 * @category [[車両搬入登録]]
 */
public class RegisterServiceController extends UcarServiceController {

	/** 車両搬入登録 画面入力値Bean */
	private RegisterInputBean registerInputBean = new RegisterInputBean();
	private CarryinSessionBean sessionBean = null;

	private String serviceId = "";
	private CarryinServiceId targetServiceId = null;
	/** 管理番号 */
	private String	noKanri;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {
		TecLogger.trace("service start");
		// セッション設定
		setupSession();
		// サービス個別処理
		executeServiceProcess();
		TecLogger.trace("service end");
		return null;
	}

	/** セッション設定
	 * @throws ServiceControllerException */
	private void setupSession() throws TecSystemException, ServiceControllerException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = CarryinServiceId.getTargetCarryinServiceId(serviceId);
		String menuId = getMenuId();

		TecLogger.debug("serviceId[" + serviceId + "]menuId[" + menuId + "]");

		// メニューID有りの場合はメニューからの呼び出し
		if(menuId != null){
			// セッションのクリア
			clearAllApplicationSession();
			// セッションの取得(新規)
			sessionBean = getNewApplicationSessionBean(CarryinSessionBean.class);
			// メニューID
			sessionBean.setMenuId(menuId);

			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
			UcarSessionManager sessionMng = UcarSessionManager.getInstance();
			LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());
			String cdKaisya 	= loginSessionBean.getUserInfoBean().getCdKaisya();
			String cdHanbaitn 	= loginSessionBean.getUserInfoBean().getCdHanbaitn();
//2016.9.5 from
			String cdHantenpo	= loginSessionBean.getUserInfoBean().getCdTenpo();
//2016.9.5 to			
			// 会社コード
			sessionBean.getT220001gPkBean().setCdKaisya(cdKaisya);
			// 販売店コード
			sessionBean.getT220001gPkBean().setCdHanbaitn(cdHanbaitn);
//2016.9.5 from
			// 販売店舗コード
			sessionBean.getT220001gPkBean().setCdHantenpo(cdHantenpo);
//2016.9.5 to	
			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

/*2016.9.5 DEL
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
			String cdTenpo 		= loginSessionBean.getUserInfoBean().getCdTenpo();
			sessionBean.setLoginCdTenpo(cdTenpo);
			// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
--*/
		} else {
			// セッションの取得
			sessionBean = getApplicationSessionBean(CarryinSessionBean.class);
		}
		sessionBean.setServiceId(serviceId);

		// サービスごとの処理
		if(targetServiceId != null){
			switch (targetServiceId) {
				case INIT:
					// 初期処理

					break;
				case REGISTER_AND_DOWNLOAD:
				case REGISTER:
					// 登録(帳票印刷)・登録処理
					SimpleRequestMapper.setRequest(getRequest(), registerInputBean);

					// 2014.04.15 T.Hayato 修正 カーチェックシートの場合でもセッションの会社コード、販売店コードを使用する start
//					String cdKaisya = getRequest().getParameter("cd_kaisya");
//					String cdHanbaitn = getRequest().getParameter("cd_hanbaitn");

//					if (!StringCheckUtils.isEmpty(cdKaisya) && !StringCheckUtils.isEmpty(cdHanbaitn)) {
//						// カーチェックシートの場合
//						registerInputBean.setCdKaisya(cdKaisya);		// 会社コード
//						registerInputBean.setCdHanbaitn(cdHanbaitn);	// 販売店コード
//					} else {
						// 車検証、または手入力の場合
						registerInputBean.setCdKaisya(sessionBean.getT220001gPkBean().getCdKaisya());		// 会社コード
						registerInputBean.setCdHanbaitn(sessionBean.getT220001gPkBean().getCdHanbaitn());	// 販売店コード
//					}
					// 2014.04.15 T.Hayato 修正 カーチェックシートの場合でもセッションの会社コード、販売店コードを使用する end
//2016.9.5 from
					registerInputBean.setCdHantenpo(sessionBean.getT220001gPkBean().getCdHantenpo());	// 販売店舗コード
//2016.9.5 to
					registerInputBean.setDdHannyu(registerInputBean.getDdHannyu().replace("/", ""));	// 搬入日
					registerInputBean.setArrayKbSiire(getRequest().getParameterValues("kb_siire"));		// 仕入種別
					registerInputBean.setArrayKbCheck(getRequest().getParameterValues("kb_check"));		// チェック内容
					registerInputBean.setArrayCheckSrk(getRequest().getParameterValues("check_srk"));	// 書類完備チェック 2011.10.14 H.Yamashita add
					break;
				case UPDATE_REGISTER_AND_DOWNLOAD:
				case UPDATE_REGISTER:
					// 更新登録(帳票印刷)・更新登録処理
					SimpleRequestMapper.setRequest(getRequest(), registerInputBean);
					registerInputBean.setCdKaisya(sessionBean.getT220001gPkBean().getCdKaisya());		// 会社コード
					registerInputBean.setCdHanbaitn(sessionBean.getT220001gPkBean().getCdHanbaitn());	// 販売店コード
//2016.9.5 from
					registerInputBean.setCdHantenpo(sessionBean.getT220001gPkBean().getCdHantenpo());	// 販売店舗コード
//2016.9.5 to
					registerInputBean.setDdHannyu(sessionBean.getT220001gPkBean().getDdHannyu());		// 搬入日
					registerInputBean.setNoKanri(sessionBean.getT220001gPkBean().getNoKanri());			// 管理番号
					registerInputBean.setArrayKbSiire(getRequest().getParameterValues("kb_siire"));		// 仕入種別
					registerInputBean.setArrayKbCheck(getRequest().getParameterValues("kb_check"));		// チェック内容
					registerInputBean.setArrayCheckSrk(getRequest().getParameterValues("check_srk"));	// 書類完備チェック 2011.10.14 H.Yamashita add

					// 下取書類(チェックボックス)の初期表示状態
					registerInputBean.setInitKbCheckSitadori(Boolean.valueOf(getRequest().getParameter("init_kb_check_sitadori")));
					// 保留(チェックボックス)の初期表示状態
					registerInputBean.setInitCheckSrk(Boolean.valueOf(getRequest().getParameter("init_check_srk")));

					// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため start
					// 印鑑証明有効期限
					if (CarryinConst.DDINKANKGN_OK.equals(getRequest().getParameter("check_ok_inkankgn"))) {
						registerInputBean.setDdInkankgn(CarryinConst.DDINKANKGN_OK);
					} else {
						registerInputBean.setDdInkankgn(getRequest().getParameter("hidden_dd_inkankgn"));
					}
					// 2012.01.30 T.Hayato 追加 印鑑証明期限 表示のため end

					break;
				case EDIT:
					// 修正処理(搬入情報一覧からの遷移)

					// メニューIDをクリア
					//sessionBean.setMenuId(null);
					break;
				case TRANS_LIST:
					// 車両搬入一覧への遷移
/**	2013.04.30 delete
					// 主キー情報のクリア
					sessionBean.setT220001gPkBean(null);
**/
/** 2013.04.30 add start
 *  下記2点がListHelperBeanで使用されているので、上の処理にあるnullをセットするとListHelperBeanでヌルポで落ちる。
 *  そもそも下記2点の値は初期設定時にセットされて、他の処理で使いまわしている。
 *  sessionBean.getT220001gPkBean().getCdKaisya()
 *  sessionBean.getT220001gPkBean().getCdHanbaitn()
 * */
					sessionBean.getT220001gPkBean().setDdHannyu(null);
					sessionBean.getT220001gPkBean().setNoKanri(null);
//--2019.3.22 from
					sessionBean.getT220001gPkBean().setCdHantenpo(null);
//--2019.3.22 to					
/** 2013.04.30 add end */
					break;
				default:
					break;
			}
		}
		TecLogger.trace("setupSession end");
	}

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException, ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if(targetServiceId != null){
			switch (targetServiceId) {
				case REGISTER_AND_DOWNLOAD:
					// 登録(帳票印刷)処理
					executeRegister();

					// 印刷処理
					// 車両搬入登録帳票(在庫カード/工程管理表)
					executeReportKouteiKanri();

					break;
				case REGISTER:
					// 登録処理
					executeRegister();
					break;
				case UPDATE_REGISTER_AND_DOWNLOAD:
					// 更新登録(帳票印刷)処理
					executeUpdateRegister();

					// 印刷処理
					// 車両搬入登録帳票(在庫カード/工程管理表)
					executeReportKouteiKanri();

					break;
				case UPDATE_REGISTER:
					// 更新登録処理
					executeUpdateRegister();

					String updateMessage = "車両搬入情報を更新";
					if (CarryinConst.CarryinMenuId.List.toString().equals(sessionBean.getMenuId())) {

						// 車両搬入一覧の場合
						setExecuteEndCarryinMessageBean(
								TecMessageManager.getMessage(UcarMessage.EXEC_ANY, updateMessage),
								CarryinServiceId.RETURN_REGISTER);

					} else if (CarryinConst.CarryinMenuId.DocumentCheck.toString().equals(sessionBean.getMenuId())) {
						// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため start
						// 書類チェックの場合
						setExecuteEndCarryinMessageBean(
								TecMessageManager.getMessage(UcarMessage.EXEC_ANY, updateMessage),
								CarryinServiceId.DOCUMENT_CHECK_RETURN_REGISTER);
						// 2012.01.30 T.Hayato 追加 搬入書類チェック画面新規作成のため end

					} else if (CarCheckConst.CarCheckMenuId.ENTER_CHECK.toString().equals(sessionBean.getMenuId())
								|| CarCheckConst.CarCheckMenuId.WORK_SORT.toString().equals(sessionBean.getMenuId())) {

						// 入庫検査、作業仕分の場合
						setExecuteEndCarcheckMessageBean(
								TecMessageManager.getMessage(UcarMessage.EXEC_ANY, updateMessage),
								CarCheckServiceId.CAR_CHECK_RETURN_REGISTER);

					}
					break;
				case DELETE:
					// 削除処理
					executeDelete();
					// 主キー情報のクリア
					sessionBean.setT220001gPkBean(null);
					// 完了メッセージ表示後、検索条件を保持した状態で車両搬入一覧へ遷移
					setExecuteEndCarryinMessageBean(
							TecMessageManager.getMessage(UcarMessage.EXEC_ANY, "車両搬入情報を削除"),
														CarryinServiceId.RETURN_REGISTER);
					break;
				default:
					break;
			}
		}
		TecLogger.trace("executeServiceProcess end");
	}

	/** 登録処理 */
	private void executeRegister() throws SystemException, ApplicationException {

		RegisterDataEvent event = createEvent(CarryinEventKey.REGISTER_DATA, RegisterDataEvent.class);
/*2016.9.5
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため start
		// 搬入店舗コードをセット
		registerInputBean.setCdHantenpo(sessionBean.getLoginCdTenpo());
		// 2013.03.13 T.Hayato 修正 搬入拠点分散 修正のため end
--*/
		event.setRegisterInputBean(registerInputBean);
		event.setMenuId(sessionBean.getMenuId());

		// 2014.04.15 T.Hayato 修正 ログインユーザと異なる販売店コードでデータができてしまう現象への対応 start
		boolean returnFlg = true;

		try {
			UcarSessionManager sessionMng = UcarSessionManager.getInstance();
			LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());
			String cdHanbaitn = loginSessionBean.getUserInfoBean().getCdHanbaitn();

			if (!cdHanbaitn.equals(registerInputBean.getCdHanbaitn())) {
				// 同じ画面に戻らないようにする
				returnFlg = false;
				throw new TecApplicationException("販売店コードに不一致が発生しています。\nメニューから画面を表示し、再度登録をして下さい。");
			}

			RegisterDataEventResult eventResult = (RegisterDataEventResult)dispatchEvent(event);
			// 登録時に生成した管理番号を取得
			noKanri = eventResult.getNoKanri();
		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.INIT, returnFlg);
//			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.INIT);
			throw e;
		}
		// 2014.04.15 T.Hayato 修正 ログインユーザと異なる販売店コードでデータができてしまう現象への対応 end
	}

	/** 帳票処理：工程管理表 */
	private void executeReportKouteiKanri() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportKouteiKanriEvent event = createEvent(ReportEventKey.REPORT_KOUTEI_KANRI, ReportKouteiKanriEvent.class);

			Ucaa001gPKBean t220001gPKBean = new Ucaa001gPKBean();
			t220001gPKBean.setCdKaisya(registerInputBean.getCdKaisya());
			//2019.05.10 T.Osada レクサス対応 start
			//t220001gPKBean.setCdHanbaitn(registerInputBean.getCdHanbaitn());
			t220001gPKBean.setCdHanbaitn(registerInputBean.getCdTenpoHanbaitnSel());
			//2019.05.10 T.Osada レクサス対応 start
			t220001gPKBean.setDdHannyu(registerInputBean.getDdHannyu());

			if (StringCheckUtils.isEmpty(noKanri)) {
				t220001gPKBean.setNoKanri(registerInputBean.getNoKanri());
			} else {
				t220001gPKBean.setNoKanri(noKanri);
			}

			ArrayList<Ucaa001gPKBean> t220001gPKList = new ArrayList<Ucaa001gPKBean>();
			t220001gPKList.add(t220001gPKBean);

			event.setT220001gPKList(t220001gPKList);

			ReportKouteiKanriEventResult eventResult = (ReportKouteiKanriEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName
				= ReportUtils.getDownloadFileName(ReportConst.FILE_NAME_KOUTEI_KANRI,
										StringUtils.getFileExtension(tempFilePath));

			String currentDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
			String downloadFilePath = ReportUtils.copyPdf(tempFilePath, downloadfileName, currentDate);
			// 2012.02.08 T.Hayato 修正 ファイル削除バッチ 作成のため start
//			ReportUtils.deleteDocTempFile(currentDate);
			// 2012.02.08 T.Hayato 修正 ファイル削除バッチ 作成のため end

			sessionBean.setDownloadFilePath(downloadFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}

	/** 更新登録処理 */
	private void executeUpdateRegister() throws SystemException, ApplicationException {

		UpdateRegisterDataEvent updateEvent
			= createEvent(CarryinEventKey.UPDATE_REGISTER_DATA, UpdateRegisterDataEvent.class);

		updateEvent.setRegisterInputBean(registerInputBean);
		updateEvent.setT220001gDtKosin(sessionBean.getT220001gDtKosin());
		updateEvent.setMenuId(sessionBean.getMenuId());

		try {
			dispatchEvent(updateEvent);
		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
			throw e;
		}
	}

	/**	削除処理 */
	private void executeDelete() throws SystemException, ApplicationException {

		DeleteRegisterDataEvent deleteEvent
			= createEvent(CarryinEventKey.DELETE_REGISTER_DATA, DeleteRegisterDataEvent.class);

		deleteEvent.setT220001gPkBean(sessionBean.getT220001gPkBean());
		deleteEvent.setT220001gDtKosin(sessionBean.getT220001gDtKosin());

		try {
			dispatchEvent(deleteEvent);
		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarryinServiceId.LIST_INIT);
			throw e;
		}
	}

	/** 正常系メッセージ設定 */
	private void setExecuteEndCarryinMessageBean(String message, CarryinServiceId carryinServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carryinServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryinServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_INFORMATION);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

	/** 正常系メッセージ設定 */
	private void setExecuteEndCarcheckMessageBean(String message, CarCheckServiceId carCheckServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carCheckServiceId.getApplicationId());
		messageBean.setReturnServiceId(carCheckServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_INFORMATION);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, CarryinServiceId carryinServiceId, boolean returnFlg){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(returnFlg));
		messageBean.setReturnApplicationId(carryinServiceId.getApplicationId());
		messageBean.setReturnServiceId(carryinServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, CarryinServiceId carryinServiceId){
		setApplicationExceptionMessageBean(message, carryinServiceId, true);
	}

}
