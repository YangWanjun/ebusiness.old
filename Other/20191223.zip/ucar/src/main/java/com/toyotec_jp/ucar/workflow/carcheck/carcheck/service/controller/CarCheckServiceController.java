package com.toyotec_jp.ucar.workflow.carcheck.carcheck.service.controller;

import java.util.ArrayList;

import jp.co.intra_mart.framework.base.service.ServiceControllerException;
import jp.co.intra_mart.framework.base.service.ServiceResult;
import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.exception.TecSystemException;
import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.im_common.system.model.object.MessageBean;
import com.toyotec_jp.im_common.system.utils.DateUtils;
import com.toyotec_jp.im_common.system.utils.SimpleRequestMapper;
import com.toyotec_jp.im_common.system.utils.StringUtils;
import com.toyotec_jp.ucar.UcarApplicationManager;
import com.toyotec_jp.ucar.UcarApplicationManager.UcarEventKey;
import com.toyotec_jp.ucar.base.service.controller.UcarServiceController;
import com.toyotec_jp.ucar.system.session.LoginSessionBean;
import com.toyotec_jp.ucar.system.session.UcarSessionManager;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.CancelEnterCheckDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.CancelEnterCheckDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.CancelWorkSortDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.CancelWorkSortDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.RegisterEnterCheckDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.RegisterEnterCheckDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.RegisterWorkSortDataEvent;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.event.RegisterWorkSortDataEventResult;
import com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.object.CarCheckParamBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckSessionBean;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckEventKey;
import com.toyotec_jp.ucar.workflow.carcheck.common.CarCheckConst.CarCheckServiceId;
import com.toyotec_jp.ucar.workflow.carryin.common.CarryinSessionBean;
import com.toyotec_jp.ucar.workflow.carryin.common.model.object.Ucaa001gPKBean;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.model.event.InitHaisoKouhoRenkeiEvent;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst;
import com.toyotec_jp.ucar.workflow.report.common.ReportUtils;
import com.toyotec_jp.ucar.workflow.report.common.ReportConst.ReportEventKey;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportSyaryouHansyutuEvent;
import com.toyotec_jp.ucar.workflow.report.model.event.ReportSyaryouHansyutuEventResult;
import com.toyotec_jp.ucar.workflow.report.model.object.SyaryouHansyutuPKBean;

/**
 * <strong>車両チェックサービスコントローラ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/10/05 新規作成<br>
 * @since 1.00
 * @category [[車両チェック]]
 */
public class CarCheckServiceController extends UcarServiceController {

	private String serviceId = "";
	private CarCheckServiceId targetServiceId = null;

	/** 車両チェックセッションBean */
	private CarCheckSessionBean sessionBean = null;
	/** 車両搬入セッションBean */
	private CarryinSessionBean carryinSessionBean = null;

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.service.ServiceControllerAdapter#service()
	 */
	@Override
	public ServiceResult service() throws SystemException, ApplicationException {
		TecLogger.trace("service start");
		// セッション設定
		setupSession();
		// サービス個別処理
		executeServiceProcess();
		TecLogger.trace("service end");
		return null;
	}

	/** セッション設定
	 * @throws ServiceControllerException */
	private void setupSession() throws TecSystemException, ServiceControllerException {
		TecLogger.trace("setupSession start");

		serviceId = getServiceID();
		targetServiceId = CarCheckServiceId.getTargetCarCheckServiceId(serviceId);
		String menuId = getMenuId();

		TecLogger.debug("serviceId[" + serviceId + "]menuId[" + menuId + "]");

		// メニューID有りの場合はメニューからの呼び出し
		if(menuId != null){
			// セッションのクリア
			clearAllApplicationSession();
			// セッションの取得(新規)
			sessionBean = getNewApplicationSessionBean(CarCheckSessionBean.class);

			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため start
			UcarSessionManager sessionMng = UcarSessionManager.getInstance();
			LoginSessionBean loginSessionBean = sessionMng.getLoginSessionBean(getRequest(), getUserInfo());
			String cdKaisya 	= loginSessionBean.getUserInfoBean().getCdKaisya();
			String cdHanbaitn 	= loginSessionBean.getUserInfoBean().getCdHanbaitn();
			String cdTenpo		= loginSessionBean.getUserInfoBean().getCdTenpo();		// 2013.02.05 C.Ohta 追加　複数販売店化
			String kbScenter	= loginSessionBean.getUserInfoBean().getKbScenter();	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

			// 会社コード
			sessionBean.setCdKaisya(cdKaisya);
			// 販売店コード
			sessionBean.setCdHanbaitn(cdHanbaitn);
			// 店舗コード
			sessionBean.setCdTenpo(cdTenpo);		// 2013.02.05 C.Ohta 追加　複数販売店化
			// 商品化センター区分
			sessionBean.setKbScenter(kbScenter);	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
			// 2013.02.12 T.Hayato 修正 ログインユーザから会社コード、販売店コードを取得するため end

			// メニューID
			sessionBean.setMenuId(menuId);
		} else {
			// セッションの取得
			sessionBean = getApplicationSessionBean(CarCheckSessionBean.class);
		}
		sessionBean.setServiceId(serviceId);
		CarCheckParamBean carCheckParamBean = new CarCheckParamBean();

		// サービスごとの処理
		if(targetServiceId != null){
			switch (targetServiceId) {
				case CAR_CHECK_INIT:
					// 初期処理
					resetSession();
					sessionBean.setPageNo("1");
					sessionBean.setCarCheckExecute("");
					sessionBean.setNarrowSearch(false);	 // 絞り込み検索
					break;
				case CAR_CHECK_CLEAR:
					resetSession();
					// 2012.01.30 T.Hayato 修正 条件初期化動作 変更のため start
					sessionBean.setPageNo("1");
					sessionBean.setCarCheckExecute("");
					// 2012.01.30 T.Hayato 修正 条件初期化動作 変更のため end
					sessionBean.setNarrowSearch(Boolean.valueOf(getRequest().getParameter("is_narrow_search")));	// 絞り込み検索
					break;
				case CAR_CHECK_SEARCH:
					sessionBean.setSortParam(getRequest().getParameter("sort_param"));	// ソートキー
					sessionBean.setSortOrder(getRequest().getParameter("sort_order"));	// ソート順
					sessionBean.setPageNo("1");

					SimpleRequestMapper.setRequest(getRequest(), carCheckParamBean);
					sessionBean.setCarCheckParamBean(carCheckParamBean);
					sessionBean.setNarrowSearch(Boolean.valueOf(getRequest().getParameter("is_narrow_search")));	// 絞り込み検索
					sessionBean.setCarCheckExecute("");
					break;
				case CAR_CHECK_SELECT:
					// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため start
					// 選択処理(入庫検査画面のみ使用)
					sessionBean.setSelectDdHannyu(getRequest().getParameter("select_dd_hannyu"));
					sessionBean.setSelectNoKanri(getRequest().getParameter("select_no_kanri"));

					sessionBean.setCarCheckExecute(UcarConst.EXECUTE_SELECT);
					break;
					// 2012.02.23 T.Hayato 追加 入庫検査画面表示速度 改善のため end
				case CAR_CHECK_SORTING:
					sessionBean.setSortParam(getRequest().getParameter("sort_param"));	// ソートキー
					sessionBean.setSortOrder(getRequest().getParameter("sort_order"));	// ソート順

					String currentPage = getRequest().getParameter("current_page");
					if (currentPage == null) {
						sessionBean.setPageNo("1");
					} else {
						sessionBean.setPageNo(currentPage);
					}

					// 2012.03.27 T.Hayato 修正 ソート機能 修正のため start
					sessionBean.setNarrowSearch(Boolean.valueOf(getRequest().getParameter("is_narrow_search_sorting")));// 絞り込み検索(ソート用)
					if (Boolean.valueOf(getRequest().getParameter("is_narrow_search_sorting"))) {
					// 2012.03.27 T.Hayato 修正 ソート機能 修正のため end
						carCheckParamBean.setNoSyadai(getRequest().getParameter("search_no_syadai"));
						carCheckParamBean.setDdConditionFrom(getRequest().getParameter("search_dd_condition_from"));
						carCheckParamBean.setDdConditionTo(getRequest().getParameter("search_dd_condition_to"));
						carCheckParamBean.setRdoKoutei(getRequest().getParameter("search_rdo_koutei"));
					}

					sessionBean.setCarCheckParamBean(carCheckParamBean);
					sessionBean.setCarCheckExecute("");
					break;
				case CAR_CHECK_REGISTER:
				case CAR_CHECK_REGISTER_AND_DOWNLOAD:
					sessionBean.setNarrowSearch(false); // 絞り込み検索

					// 2012.01.30 T.Hayato 修正 システム全体 共通定数化 start
					if (UcarConst.RDO_KUBUN_COMPLETE.equals(getRequest().getParameter("rdo_kubun"))) {
						// 検査完了／仕分完了
						resetSession();
						sessionBean.setCarCheckExecute(UcarConst.EXECUTE_REGISTER);
					} else {
						// 保留
						sessionBean.setCarCheckParamBean(new CarCheckParamBean());
						sessionBean.setCarCheckExecute(UcarConst.EXECUTE_RESERVE);
					}
					// 2012.01.30 T.Hayato 修正 システム全体 共通定数化 end
					// 入庫検査／作業仕分画面での保留時に先頭で選択されたPKキー
					sessionBean.setSelectHeadReservePk(getRequest().getParameter("select_head_reserve_pk"));
					break;
				case CAR_CHECK_DOWNLOAD:
					resetSession();
					sessionBean.setNarrowSearch(false); // 絞り込み検索
					sessionBean.setCarCheckExecute("");
					break;
				case CAR_CHECK_CANCEL:
					resetSession();
					sessionBean.setNarrowSearch(false); // 絞り込み検索
					// 2012.01.30 T.Hayato 修正 システム全体 共通定数化 start
					sessionBean.setCarCheckExecute(UcarConst.EXECUTE_CANCEL);
					// 2012.01.30 T.Hayato 修正 システム全体 共通定数化 end
					break;
				case CAR_CHECK_TRANS_REGISTER:
					// 搬入登録画面遷移
					//ページングの設定
					sessionBean.setSortParam(getRequest().getParameter("sort_param"));	// ソートキー
					sessionBean.setSortOrder(getRequest().getParameter("sort_order"));	// ソート順
					sessionBean.setPageNo(getRequest().getParameter("current_page"));	// ページ

					sessionBean.setNarrowSearch(Boolean.valueOf(getRequest().getParameter("is_narrow_search")));	// 絞り込み検索
					if (Boolean.valueOf(getRequest().getParameter("is_narrow_search"))) {
						// 手入力モードの場合は検索条件を格納
						carCheckParamBean.setNoSyadai(getRequest().getParameter("search_no_syadai"));
						carCheckParamBean.setDdConditionFrom(getRequest().getParameter("search_dd_condition_from"));
						carCheckParamBean.setDdConditionTo(getRequest().getParameter("search_dd_condition_to"));
						carCheckParamBean.setRdoKoutei(getRequest().getParameter("search_rdo_koutei"));
					}

					sessionBean.setCarCheckParamBean(carCheckParamBean);
					sessionBean.setCarCheckExecute("");

					// 入庫検査／作業仕分画面での選択行番号
					sessionBean.setSelectRowNumber(getRequest().getParameter("select_row_number"));

					Ucaa001gPKBean t220001gPKBean = new Ucaa001gPKBean();

					t220001gPKBean.setCdKaisya(getRequest().getParameter("trans_cd_kaisya"));
					t220001gPKBean.setCdHanbaitn(getRequest().getParameter("trans_cd_hanbaitn"));
					t220001gPKBean.setDdHannyu(getRequest().getParameter("trans_dd_hannyu"));
					t220001gPKBean.setNoKanri(getRequest().getParameter("trans_no_kanri"));

					carryinSessionBean = getNewApplicationSessionBean(CarryinSessionBean.class);
					// 会社コード
					carryinSessionBean.setT220001gPkBean(t220001gPKBean);
					carryinSessionBean.setTransCarCheck(true);
					carryinSessionBean.setMenuId(sessionBean.getMenuId());
					break;
				case CAR_CHECK_RETURN_REGISTER:
					// 搬入登録画面からの遷移
					break;
				default:
					break;
			}
		}
		TecLogger.trace("setupSession end");
	}

	/**
	 * 車両チェックセッションBean パラメータクリア処理
	 */
	private void resetSession() {
		sessionBean.setSortOrder("");
		sessionBean.setSortParam("");
		sessionBean.setCarCheckParamBean(new CarCheckParamBean());
	}

	/** サービス個別処理 */
	private void executeServiceProcess() throws SystemException, ApplicationException {
		TecLogger.trace("executeServiceProcess start");

		if(targetServiceId != null){
			switch (targetServiceId) {
				case CAR_CHECK_INIT:
					// 初期処理

					// 2013.02.12 T.Hayato 修正 配送候補連携処理 実行販売店限定のため start
					// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため start
					String cdKaisya = sessionBean.getCdKaisya();
					String cdHanbaitn = sessionBean.getCdHanbaitn();
					// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
					String cdTenpo = sessionBean.getCdTenpo();

//					if (UcarConst.CD_KAISYA.equals(cdKaisya)
					if (UcarApplicationManager.getConfigValue("com.toyotec_jp.ucar.workflow.CdTenpo.Scenter").equals(cdTenpo)
						// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
						&& UcarConst.TOYOPET.equals(cdHanbaitn)
						&& CarCheckConst.CarCheckMenuId.WORK_SORT.getMenuId().equals(sessionBean.getMenuId())) {
						// P東京の場合

						// 作業仕分の場合
						executeHaisoRenkei(cdKaisya, cdHanbaitn);
					}
					// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため end
					// 2013.02.12 T.Hayato 修正 配送候補連携処理 実行販売店限定のため end
					break;
				case CAR_CHECK_REGISTER:
					// 登録処理
					executeRegister();
					break;
				case CAR_CHECK_REGISTER_AND_DOWNLOAD:
					// 登録処理
					executeRegister();
					// 印刷処理（車両搬出表）
					executeReportHansyutu();
					break;
				case CAR_CHECK_DOWNLOAD:
					// 印刷処理（車両搬出表）
					executeReportHansyutu();
					break;
				case CAR_CHECK_CANCEL:
					// 取消処理
					executeCancel();
					break;
				default:
					break;
			}
		}
		TecLogger.trace("executeServiceProcess end");
	}

	// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため start
	/**
	 * 配送候補連携処理
	 * @param cdKaisya 会社コード
	 * @param cdHanbaitn 販売店コード
	 * @throws SystemException
	 * @throws ApplicationException
	 */
	private void executeHaisoRenkei(String cdKaisya,
			String cdHanbaitn) throws SystemException, ApplicationException {

		InitHaisoKouhoRenkeiEvent event
			= createEvent(UcarEventKey.INIT_HAISO_KOUHO_RENKEI, InitHaisoKouhoRenkeiEvent.class);

		event.setCdKaisya(cdKaisya);
		event.setCdHanbaitn(cdHanbaitn);
		event.setExecuteAppId(CarCheckConst.APPID_CARCHECK_WORKSORT);

		try {
			dispatchEvent(event);
		} catch(SystemException e){
			TecLogger.error(e);
			throw e;
		} catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarCheckServiceId.CAR_CHECK_INIT);
			throw e;
		}
	}
	// 2012.03.26 T.Hayato 追加 配送候補連携処理 追加のため end

	/** 登録処理 */
	private void executeRegister() throws SystemException, ApplicationException {

		if (CarCheckConst.CarCheckMenuId.ENTER_CHECK.getMenuId().equals(sessionBean.getMenuId())) {
			// 入庫検査
			RegisterEnterCheckDataEvent event
				= createEvent(CarCheckEventKey.REGISTER_ENTER_CHECK_DATA, RegisterEnterCheckDataEvent.class);

			event.setCdKaisya(sessionBean.getCdKaisya());
			event.setCdHanbaitn(sessionBean.getCdHanbaitn());
			event.setSelectData(getRequest().getParameterValues("select_data"));

			event.setRdoKubun(getRequest().getParameter("rdo_kubun"));
			event.setDdSetDate(getRequest().getParameter("dd_set_date"));

			// 2012.03.26 T.Hayato 追加 チェック者 追加のため start
			event.setCdNkktan(getRequest().getParameter("cd_nkktan"));
			// 2012.03.26 T.Hayato 追加 チェック者 追加のため end

			event.setCarCheckDataList(sessionBean.getCarCheckDataList());

			try {
				RegisterEnterCheckDataEventResult eventResult
					= (RegisterEnterCheckDataEventResult)dispatchEvent(event);

				sessionBean.setCountExecute(eventResult.getCountExecute());

			} catch(SystemException e){
				TecLogger.error(e);
				throw e;
			} catch(ApplicationException e){
				// アプリケーション例外時はメッセージ設定
				setApplicationExceptionMessageBean(e.getMessage(), CarCheckServiceId.CAR_CHECK_INIT);
				throw e;
			}
		} else if (CarCheckConst.CarCheckMenuId.WORK_SORT.getMenuId().equals(sessionBean.getMenuId())) {
			// 作業仕分
			RegisterWorkSortDataEvent event
				= createEvent(CarCheckEventKey.REGISTER_WORK_SORT_DATA, RegisterWorkSortDataEvent.class);

			event.setCdKaisya(sessionBean.getCdKaisya());
			event.setCdHanbaitn(sessionBean.getCdHanbaitn());
			event.setSelectData(getRequest().getParameterValues("select_data"));

			event.setRdoKubun(getRequest().getParameter("rdo_kubun"));
			event.setDdSetDate(getRequest().getParameter("dd_set_date"));

			event.setCarCheckDataList(sessionBean.getCarCheckDataList());

			event.setCdKoutei(getRequest().getParameterValues("cd_koutei"));
			event.setCdTenpo(getRequest().getParameterValues("cd_tenpo"));
			event.setSelectDataChecked(getRequest().getParameter("hid_array_select_data_checked").split(",", -1));

			try {
				RegisterWorkSortDataEventResult eventResult
					= (RegisterWorkSortDataEventResult)dispatchEvent(event);

				sessionBean.setCountExecute(eventResult.getCountExecute());

			} catch(SystemException e){
				TecLogger.error(e);
				throw e;
			} catch(ApplicationException e){
				// アプリケーション例外時はメッセージ設定
				setApplicationExceptionMessageBean(e.getMessage(), CarCheckServiceId.CAR_CHECK_INIT);
				throw e;
			}

		}

	}

	/** 取消処理 */
	private void executeCancel() throws SystemException, ApplicationException {

		if (CarCheckConst.CarCheckMenuId.ENTER_CHECK.getMenuId().equals(sessionBean.getMenuId())) {
			// 入庫検査
			CancelEnterCheckDataEvent event
				= createEvent(CarCheckEventKey.CANCEL_ENTER_CHECK_DATA, CancelEnterCheckDataEvent.class);

			event.setCdKaisya(sessionBean.getCdKaisya());
			event.setCdHanbaitn(sessionBean.getCdHanbaitn());
			event.setSelectData(getRequest().getParameterValues("select_data"));

			event.setCarCheckDataList(sessionBean.getCarCheckDataList());

			try {
				CancelEnterCheckDataEventResult eventResult
				= (CancelEnterCheckDataEventResult)dispatchEvent(event);

				sessionBean.setCountExecute(eventResult.getCountExecute());

			} catch(SystemException e){
				TecLogger.error(e);
				throw e;
			} catch(ApplicationException e){
				// アプリケーション例外時はメッセージ設定
				setApplicationExceptionMessageBean(e.getMessage(), CarCheckServiceId.CAR_CHECK_INIT);
				throw e;
			}

		}  else if (CarCheckConst.CarCheckMenuId.WORK_SORT.getMenuId().equals(sessionBean.getMenuId())) {
			// 作業仕分
			CancelWorkSortDataEvent event
				= createEvent(CarCheckEventKey.CANCEL_WORK_SORT_DATA, CancelWorkSortDataEvent.class);

			event.setCdKaisya(sessionBean.getCdKaisya());
			event.setCdHanbaitn(sessionBean.getCdHanbaitn());
			event.setSelectData(getRequest().getParameterValues("select_data"));

			event.setCarCheckDataList(sessionBean.getCarCheckDataList());

			try {
				CancelWorkSortDataEventResult eventResult
					= (CancelWorkSortDataEventResult)dispatchEvent(event);

				sessionBean.setCountExecute(eventResult.getCountExecute());

			} catch(SystemException e){
				TecLogger.error(e);
				throw e;
			} catch(ApplicationException e){
				// アプリケーション例外時はメッセージ設定
				setApplicationExceptionMessageBean(e.getMessage(), CarCheckServiceId.CAR_CHECK_INIT);
				throw e;
			}
		}

	}

	/** 帳票処理：車両搬出表 */
	private void executeReportHansyutu() throws SystemException, ApplicationException {

		try{
			// 帳票作成
			ReportSyaryouHansyutuEvent event = createEvent(ReportEventKey.REPORT_SYARYOU_HANSYUTU, ReportSyaryouHansyutuEvent.class);

			String selectDataList[] = getRequest().getParameterValues("select_data");
			// 2013.02.05 C.Ohta 変更　複数販売店化　start
//			ArrayList<Ucaa001gPKBean> t220001gPKList = new ArrayList<Ucaa001gPKBean>();
			ArrayList<SyaryouHansyutuPKBean> syaryouHansyutuPKList = new ArrayList<SyaryouHansyutuPKBean>();
			// 2013.02.05 C.Ohta 変更　複数販売店化　end

			for (String selectData : selectDataList) {
				String[] arraySelectData = selectData.split(",");
				// 2013.02.05 C.Ohta 変更　複数販売店化　start
//				Ucaa001gPKBean t220001gPKBean = new Ucaa001gPKBean(sessionBean.getCdKaisya(),
//																	sessionBean.getCdHanbaitn(),
//																	arraySelectData[0],
//																	arraySelectData[1]);
//              2019.04.01 T.Osada start				
//				SyaryouHansyutuPKBean syaryouHansyutuPKBean = new SyaryouHansyutuPKBean(sessionBean.getCdKaisya(),
//						sessionBean.getCdHanbaitn(),
				SyaryouHansyutuPKBean syaryouHansyutuPKBean = new SyaryouHansyutuPKBean(arraySelectData[0],
																				arraySelectData[1],
																				arraySelectData[2],
																				arraySelectData[3],
																				// 2019.04.01 T.Osada end
																				sessionBean.getCdTenpo(),
																				sessionBean.getKbScenter());	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２
//				t220001gPKList.add(t220001gPKBean);
				syaryouHansyutuPKList.add(syaryouHansyutuPKBean);
				// 2013.02.05 C.Ohta 変更　複数販売店化　end
			}

			// 2013.02.05 C.Ohta 変更　複数販売店化　start
//			event.setT220001gPKList(t220001gPKList);
			event.setSyaryouHansyutuPKList(syaryouHansyutuPKList);
			// 2013.02.05 C.Ohta 変更　複数販売店化　end
			// 2013.05.29 T.Hayato 追加 搬入拠点分散対応2のため start
			event.setExecuteDtKosin(true);
			// 2013.05.29 T.Hayato 追加 搬入拠点分散対応2のため end

			ReportSyaryouHansyutuEventResult eventResult = (ReportSyaryouHansyutuEventResult)dispatchEvent(event);

			// ダウンロード用処理
			String tempFilePath = eventResult.getFilePath();
			String downloadfileName
				= ReportUtils.getDownloadFileName(ReportConst.FILE_NAME_SYARYOU_HANSYUTU,
										StringUtils.getFileExtension(tempFilePath));

			String currentDate = DateUtils.getCurrentDateStr(DateUtils.FORMAT_SHORT_SIMPLE);
			String downloadFilePath = ReportUtils.copyPdf(tempFilePath, downloadfileName, currentDate);
			//deleteDocTempFile();

			sessionBean.setDownloadFilePath(downloadFilePath);

		}catch(SystemException e){
			throw new HelperBeanException(e.getMessage());
		}catch(ApplicationException e){
			// アプリケーション例外時はメッセージ設定
			setApplicationExceptionMessageBean(e.getMessage(), CarCheckServiceId.CAR_CHECK_INIT);
		}catch(Exception e){
			throw new HelperBeanException(e.getMessage());
		}
	}

	/** アプリケーション例外系メッセージ設定 */
	private void setApplicationExceptionMessageBean(String message, CarCheckServiceId carCheckServiceId){
		MessageBean messageBean = new MessageBean();
		messageBean.setReturnFlg(Boolean.toString(true));
		messageBean.setReturnApplicationId(carCheckServiceId.getApplicationId());
		messageBean.setReturnServiceId(carCheckServiceId.getServiceId());
		messageBean.setIcon(MessageBean.ICON_WARNING);
		messageBean.setMessage(message);
		setMessageBean(messageBean);
	}

}
