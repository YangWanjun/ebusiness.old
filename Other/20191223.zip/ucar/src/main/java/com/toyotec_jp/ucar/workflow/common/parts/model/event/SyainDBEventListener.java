package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.SyainDBDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.SyainDBBean;

/**
 * <strong>社員DB操作用イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/06/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SyainDBEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		SyainDBEvent targetEvent = (SyainDBEvent)event;

		SyainDBDAOIF dao
			= getDAO(UcarDAOKey.SYAIN_DB_DAO, event, SyainDBDAOIF.class);

		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 start
		ResultArrayList<SyainDBBean> SyainDBList = dao.getSyainDBList(targetEvent.getCdKaisya(), targetEvent.getCdHanbaitn(), targetEvent.getCdSdtan());
		// 2013.02.12 T.Hayato 修正 アドオンテーブル名 動的変更の為 end

		SyainDBEventResult getEventResult = new SyainDBEventResult();

		if (SyainDBList.size() > 0) {
			getEventResult.setKjSyainmei(SyainDBList.get(0).getKjSyainmei());
		} else {
			getEventResult.setKjSyainmei("");
		}

		return getEventResult;
	}

}
