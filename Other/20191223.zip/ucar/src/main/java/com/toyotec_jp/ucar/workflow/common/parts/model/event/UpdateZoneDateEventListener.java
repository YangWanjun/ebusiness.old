package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import java.util.Date;

import jp.co.intra_mart.framework.base.event.Event;
import jp.co.intra_mart.framework.base.event.EventResult;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.ucar.UcarApplicationManager.UcarDAOKey;
import com.toyotec_jp.ucar.base.model.event.UcarEventListener;
import com.toyotec_jp.ucar.workflow.common.parts.UcarUtils;
import com.toyotec_jp.ucar.workflow.common.parts.model.data.UcaaTransactionDAOIF;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;

/**
 * <strong>ゾーン日数更新イベントリスナ。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/02/13 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class UpdateZoneDateEventListener extends UcarEventListener {

	/* (非 Javadoc)
	 * @see jp.co.intra_mart.framework.base.event.StandardEventListener#fire(jp.co.intra_mart.framework.base.event.Event)
	 */
	@Override
	protected EventResult fire(Event event) throws SystemException, ApplicationException {

		UpdateZoneDateEvent targetEvent = (UpdateZoneDateEvent)event;

		UcaaTransactionDAOIF dao
			= getDAO(UcarDAOKey.UCAA_TRANSACTION_DAO, targetEvent, UcaaTransactionDAOIF.class);

		// ステータスDB取得
//		T220012gBean t220012gBean = dao.selectT220012g(targetEvent.getT220001gPkBean().getCdKaisya(),
//														targetEvent.getT220001gPkBean().getCdHanbaitn(),
//														targetEvent.getT220001gPkBean().getDdHannyu(),
//														targetEvent.getT220001gPkBean().getNoKanri());
		Uccb007gBean t220012gBean = dao.selectT220012g(targetEvent.getT220107gPkBean().getCdKaisya(),
														targetEvent.getT220107gPkBean().getCdHanbaitn(),
														targetEvent.getT220107gPkBean().getDdHannyu(),
														targetEvent.getT220107gPkBean().getNoKanri(),
														targetEvent.getT220107gPkBean().getCdZaitenpo(),
														targetEvent.getT220107gPkBean().getKbScenter());
		// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２　end

		Date maxDtStatus = null;
		if (targetEvent.isExecuteDtStatus03()) {
			maxDtStatus = UcarUtils.setMaxDtStatus(maxDtStatus, t220012gBean.getDtStatus03());
		}
		if (targetEvent.isExecuteDtStatus05()) {
			maxDtStatus = UcarUtils.setMaxDtStatus(maxDtStatus, t220012gBean.getDtStatus05());
		}
		if (targetEvent.isExecuteDtStatus07()) {
			maxDtStatus = UcarUtils.setMaxDtStatus(maxDtStatus, t220012gBean.getDtStatus07());
		}

		// Aゾーン日数
		int nuAzone = 0;
		if (maxDtStatus != null) {
			// +1して変数に格納
			nuAzone = UcarUtils.getDifferentDay(maxDtStatus, t220012gBean.getDtStatus01()) + 1;
		}

//		T220012gInputDataBean t220012gInputDataBean = targetEvent.getT220012gInputDataBean();
		Uccb007gInputDataBean t220012gInputDataBean = targetEvent.getUccb007gInputDataBean();	// 2013.04.03 C.Ohta 追加　搬入拠点分散対応２

		t220012gInputDataBean.setNuAzone(nuAzone);
		// ABゾーン日数：Aゾーン日数 + Bゾーン日数
		t220012gInputDataBean.setNuAbzone(nuAzone + t220012gBean.getNuBzone());

		// 更新処理：Aゾーン日数, ABゾーン日数
		dao.updateT220012GZoneDate(t220012gInputDataBean, targetEvent.getExecuteDate());

		return null;
	}
}
