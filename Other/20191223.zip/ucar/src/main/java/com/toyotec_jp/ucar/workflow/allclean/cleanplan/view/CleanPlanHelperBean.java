package com.toyotec_jp.ucar.workflow.allclean.cleanplan.view;

import java.util.ArrayList;
import java.util.List;

import jp.co.intra_mart.framework.base.web.bean.HelperBeanException;
import jp.co.intra_mart.framework.system.exception.ApplicationException;
import jp.co.intra_mart.framework.system.exception.SystemException;

import com.toyotec_jp.im_common.system.log.TecLogger;
import com.toyotec_jp.ucar.base.view.UcarHelperBean;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.event.GetCleanPlanDataEvent;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.event.GetCleanPlanDataEventResult;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.object.CleanPlanUnPlanDataBean;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanSessionBean;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanConst.AllCleanEventKey;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanConst.AllCleanServiceId;
import com.toyotec_jp.ucar.workflow.allclean.common.AllCleanConst.AllCleanTitle;

/**
 * <strong>まるクリ作業計画入力ヘルパービーン。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/17 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public class CleanPlanHelperBean extends UcarHelperBean {

	private static final long serialVersionUID = 8584928315609391060L;

	/** まるクリセッションBean */
	private AllCleanSessionBean allCleanSession;
	/** まるクリ関連サービスID */
	private AllCleanServiceId targetServiceId;

	/** 受付車両情報 表示リスト */
	private List<List<CleanPlanUnPlanDataBean>> multiplUnplanList 	= new ArrayList<List<CleanPlanUnPlanDataBean>>();

	private int dataRow = 0;
	/** 未計画情報 表示列 */
	private int dataColumn = 10;

	/** デフォルトコンストラクタ。 */
	public CleanPlanHelperBean() throws HelperBeanException {
		super();
	}

	public void init() throws HelperBeanException {

		// セッションの取得
		allCleanSession = getApplicationSessionBean(AllCleanSessionBean.class);

		String serviceId = allCleanSession.getServiceId();
		targetServiceId = AllCleanServiceId.getTargetAllCleanServiceId(serviceId);

		// サービス呼び出し用URL設定
		setServiceURLs();

		try {

			// サービスごとの処理
			if(targetServiceId != null){
				switch (targetServiceId) {
					case CLEANPLAN_INIT:

						GetCleanPlanDataEvent getEvent = createEvent(
								AllCleanEventKey.GET_CLEANPLAN_DATA, GetCleanPlanDataEvent.class);

						GetCleanPlanDataEventResult getResult
							= (GetCleanPlanDataEventResult)dispatchEvent(getEvent);

						/** 受付車両情報 表示リスト */
						List<CleanPlanUnPlanDataBean> unplanList = new ArrayList<CleanPlanUnPlanDataBean>();

						// 商
						int quotient 	= getResult.getUnPlanList().size() / dataColumn;
						// 余り
						int remainder 	= getResult.getUnPlanList().size() % dataColumn;

						if (remainder > 0) {
							quotient++;
						}
						dataRow = quotient;

						int recordIndex = 1;
						for (CleanPlanUnPlanDataBean unPlanDataBean : getResult.getUnPlanList()) {

							if (recordIndex > 10) {
								recordIndex = 1;
								multiplUnplanList.add(unplanList);
								unplanList = new ArrayList<CleanPlanUnPlanDataBean>();
							}
							unplanList.add(unPlanDataBean);
							recordIndex++;
						}

						if (unplanList.size() > 0) {
							// 空白データ充填数
							int countFill = dataColumn - unplanList.size();

							for (int i = 1; i <= countFill; i++) {
								unplanList.add(new CleanPlanUnPlanDataBean());
							}
							multiplUnplanList.add(unplanList);
						}

						break;
					default:
						break;
				}
			}

		} catch (SystemException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		} catch (ApplicationException e) {
			TecLogger.error(e);
			throw new HelperBeanException(e.getMessage(), e);
		} finally {
		}
	}

	/**
	 * unplanListを取得する。
	 * @return unplanList
	 */
	public List<CleanPlanUnPlanDataBean> getUnplanList(int index) {
		return multiplUnplanList.get(index);
	}

	/** サービス呼び出し用URL設定 */
	private void setServiceURLs() throws HelperBeanException {

//		serviceUrlInit		= getServiceUrl(CarryoutServiceId.REGISTER_INIT);

	}

	/** 画面タイトル取得 */
	public String getTitleLabel(){
		return AllCleanTitle.CLEANPLAN.getTitleLabel();
	}

	/**
	 * dataRowを取得する。
	 * @return dataRow
	 */
	public int getDataRow() {
		return dataRow;
	}

}
