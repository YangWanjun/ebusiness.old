package com.toyotec_jp.ucar.workflow.carryin.list.model.data;

import java.sql.Timestamp;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.im_common.system.model.object.SimpleExecuteResultBean;
import com.toyotec_jp.im_common.system.model.object.SimpleQueryParamBean;
import com.toyotec_jp.ucar.base.model.data.UcarSharedDBDAO;
import com.toyotec_jp.ucar.workflow.common.parts.UcarConst;
import com.toyotec_jp.ucar.workflow.common.parts.UcarTableManager;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb003gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb004gBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb007gInputDataBean;

/**
 * <strong>搬入書類チェックDAOの実装。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2012/01/18 新規作成<br>
 * @since 1.00
 * @category [[搬入書類チェック]]
 */
public class DocumentCheckDAOImpl extends UcarSharedDBDAO implements DocumentCheckDAOIF {

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carcheck.carcheck.model.data.EnterCheckDAOIF#selectT220008GCount(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
//	public int selectT220007GCount(T220007gBean t220007gBean) throws TecDAOException {
	public int selectT220007GCount(Uccb004gBean t220007gBean) throws TecDAOException {	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220007gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		
		/** 書類チェックDB取得処理 SQL */
		final String SELECT_T220007G_SQL
			= "SELECT "
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ "FROM "
//			+ "  T220007G "
			+ "  " + UcarTableManager.getSyoruiCheck(t220007gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		int recordCount = 0;

		try{
			SimpleQueryParamBean paramBean = new SimpleQueryParamBean(SELECT_T220007G_SQL);

			// パラメータセット<条件>
			paramBean.setString(t220007gBean.getCdKaisya());	// 会社コード
			paramBean.setString(t220007gBean.getCdHanbaitn());	// 販売店コード
			paramBean.setString(t220007gBean.getDdHannyu());	// 搬入日
			paramBean.setString(t220007gBean.getNoKanri());		// 管理番号
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
			if (!t220007gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
				paramBean.setString(t220007gBean.getCdZaitenpo());	// 在庫店舗コード
			}
			// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

			// 取得
			recordCount = getRecordCount(paramBean);

		} finally {
		}
		// 返却
		return recordCount;
	}

	@Override
	//public SimpleExecuteResultBean insertT220007G(T220007gBean t220007gBean,
	public SimpleExecuteResultBean insertT220007G(Uccb004gBean t220007gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220007gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 新規登録処理（書類チェックDB）SQL */
		final String INSERT_T220007G_SQL
			= "INSERT "
//			+ "INTO T220007G( "
			+ "INTO " + UcarTableManager.getSyoruiCheck(t220007gBean.getKbScenter()) + "( "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , DD_SRKNB "
			+ "  , DD_SRKHR "
			+ "  , DD_SRKFK "
			+ "  , MJ_SRKBK "
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220007G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220007gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220007gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220007gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220007gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220007gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220007gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(t220007gBean.getDdSrknb());		// 書類完備日
		paramBean.setString(t220007gBean.getDdSrkhr());		// 書類完備保留日
		paramBean.setString(t220007gBean.getDdSrkfk());		// 書類完備保留復帰予定日
		paramBean.setString(t220007gBean.getMjSrkbk());		// 書類完備備考
		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220007gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220007gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220007gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220007gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	@Override
//	public SimpleExecuteResultBean updateT220007G(T220007gBean t220007gBean,
	public SimpleExecuteResultBean updateT220007G(Uccb004gBean t220007gBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			String nyukoDtKosin, Timestamp executeDate)
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220007gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 更新処理（書類チェックDB）SQL */
		final String UPDATE_T220007G_SQL
//			= "UPDATE T220007G "
			= "UPDATE " + UcarTableManager.getSyoruiCheck(t220007gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    DD_SRKNB  = :DD_SRKNB "
			+ "  , DD_SRKHR  = :DD_SRKHR "
			+ "  , DD_SRKFK  = :DD_SRKFK "
			+ "  , MJ_SRKBK  = :MJ_SRKBK "
			+ "  , DT_KOSIN  = :DT_KOSIN "
			+ "  , CD_KSNSYA = :CD_KSNSYA "
			+ "  , CD_KSNAPP = :CD_KSNAPP "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  AND DT_KOSIN    = TO_TIMESTAMP(?, 'yyyy-mm-dd hh24:mi:ss.ff3') ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220007G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220007gBean.getDdSrknb());		// 書類完備日
		paramBean.setString(t220007gBean.getDdSrkhr());		// 書類完備保留日
		paramBean.setString(t220007gBean.getDdSrkfk());		// 書類完備保留復帰予定日
		paramBean.setString(t220007gBean.getMjSrkbk());		// 書類完備備考

		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220007gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220007gBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220007gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220007gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220007gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220007gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220007gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220007gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(nyukoDtKosin);					// 更新日時(排他制御)：SQL側で加工処理実行

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	@Override
//	public SimpleExecuteResultBean insertT220012G(T220012gInputDataBean t220012gInputDataBean,
	public SimpleExecuteResultBean insertT220012G(Uccb007gInputDataBean t220012gInputDataBean,	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
													Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 新規登録処理（ステータスDB） SQL */
		final String INSERT_T220012G_SQL
			= "INSERT "
//			+ "INTO T220012G( "
			+ "INTO " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + "( "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "    CD_KAISYA "
			+ "  , CD_HANBAITN "
			+ "  , DD_HANNYU "
			+ "  , NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , DT_STATUS01 "
			+ "  , DT_STATUS03 "
			+ "  , DT_STATUS04 "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
			+ "  , NU_AZONE "
			+ "  , NU_BZONE "
			+ "  , NU_ABZONE "
			+ "  , NU_SYOHN "
			+ "  , MJ_KASYU "
			+ "  , MJ_MARUCL "
			+ "  , MJ_SEIBI "
			+ "  , MJ_AMUSU "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
			+ "  , DT_SAKUSEI "
			+ "  , DT_KOSIN "
			+ "  , CD_SKSISYA "
			+ "  , CD_KSNSYA "
			+ "  , CD_SKSIAPP "
			+ "  , CD_KSNAPP "
			+ ") "
			+ "VALUES ( "
			+ "    ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ "  , ? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220012G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		paramBean.setString(t220012gInputDataBean.getStrDtStatus01());	// ステータス01
		paramBean.setString(t220012gInputDataBean.getStrDtStatus03());	// ステータス03
		paramBean.setString(t220012gInputDataBean.getStrDtStatus04());	// ステータス04

		// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため start
		paramBean.setInt(0);		// Aゾーン日数
		paramBean.setInt(0);		// Bゾーン日数
		paramBean.setInt(0);		// ABゾーン日数
		paramBean.setInt(0);		// 商品化日数
		paramBean.setString("0");	// 加修フラグ
		paramBean.setString("0");	// まるクリフラグ
		paramBean.setString("0");	// 整備フラグ
		paramBean.setString("0");	// アムスフラグ
		// 2012.02.13 T.Hayato 追加 Aゾーン日数～アムスフラグ 初期値設定のため end
		paramBean.setTimestamp(executeDate);						// データ作成日時
		paramBean.setTimestamp(executeDate);						// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	@Override
	public SimpleExecuteResultBean updateT220012G(
//			T220012gInputDataBean t220012gInputDataBean, Timestamp executeDate) throws TecDAOException {
			Uccb007gInputDataBean t220012gInputDataBean, Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 更新処理（ステータスDB） SQL */
		final String UPDATE_T220012G_SQL
//			= "UPDATE T220012G "
			= "UPDATE " + UcarTableManager.getStatus(t220012gInputDataBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "SET "
			+ "    DT_STATUS03 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , DT_STATUS04 = TO_DATE(?, 'YYYY/MM/DD HH24:MI:SS') "
			+ "  , DT_KOSIN    = ? "
			+ "  , CD_KSNSYA   = ? "
			+ "  , CD_KSNAPP   = ? "
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo;	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(UPDATE_T220012G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220012gInputDataBean.getStrDtStatus03());	// ステータス03
		paramBean.setString(t220012gInputDataBean.getStrDtStatus04());	// ステータス04

		paramBean.setTimestamp(executeDate);						// データ更新日時
		paramBean.setString(t220012gInputDataBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220012gInputDataBean.getCdKsnapp());	// 更新アプリID

		// パラメータセット<条件>
		paramBean.setString(t220012gInputDataBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220012gInputDataBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220012gInputDataBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220012gInputDataBean.getNoKanri());	// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220012gInputDataBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220012gInputDataBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.list.model.data.DocumentCheckDAOIF#deleteT220003G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb003gBean)
	 */
	@Override
//	public SimpleExecuteResultBean deleteT220003G(T220003gBean t220003gBean)
	public SimpleExecuteResultBean deleteT220003G(Uccb003gBean t220003gBean)
			throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		if (!t220003gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  AND CD_ZAITENPO = ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		
		/** 削除処理（チェック内容情報）SQL */
		final String DELETE_T220003G_SQL
			= "DELETE "
			+ "FROM "
//			+ "  T220003G "
			+ "  " + UcarTableManager.getCheckNaiyo(t220003gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "WHERE "
			+ "      CD_KAISYA   = ? "
			+ "  AND CD_HANBAITN = ? "
			+ "  AND DD_HANNYU   = ? "
			+ "  AND NO_KANRI    = ? "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "  AND KB_CHECK    = ? ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(DELETE_T220003G_SQL);

		// パラメータセット<条件>
		paramBean.setString(t220003gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220003gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220003gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220003gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220003gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220003gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(t220003gBean.getKbCheck());		// チェック内容区分

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

	/* (non-Javadoc)
	 * @see com.toyotec_jp.ucar.workflow.carryin.list.model.data.DocumentCheckDAOIF#insertT220003G(com.toyotec_jp.ucar.workflow.common.parts.model.object.Uccb003gBean, java.sql.Timestamp)
	 */
	@Override
//	public SimpleExecuteResultBean insertT220003G(T220003gBean t220003gBean,
	public SimpleExecuteResultBean insertT220003G(Uccb003gBean t220003gBean,
			Timestamp executeDate) throws TecDAOException {

		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		String sqlTenpo = "";
		String sqlTenpo2 = "";
		if (!t220003gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			sqlTenpo = "  , CD_ZAITENPO ";
			sqlTenpo2 = "  , ? ";
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end

		/** 新規登録処理（チェック内容情報）SQL */
		final String INSERT_T220003G_SQL
			= "INSERT INTO "
//			+ " T220003G "
			+ " " + UcarTableManager.getCheckNaiyo(t220003gBean.getKbScenter()) + " "	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ "(CD_KAISYA "
			+ ",CD_HANBAITN "
			+ ",DD_HANNYU "
			+ ",NO_KANRI "
			+ sqlTenpo	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ ",KB_CHECK "
			+ ",DD_CHECK "
			+ ",DT_SAKUSEI "
			+ ",DT_KOSIN "
			+ ",CD_SKSISYA "
			+ ",CD_KSNSYA "
			+ ",CD_SKSIAPP "
			+ ",CD_KSNAPP "
			+ ") VALUES "
			+ "(? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ sqlTenpo2	// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ",? "
			+ ") ";

		SimpleQueryParamBean paramBean = new SimpleQueryParamBean(INSERT_T220003G_SQL);

		// パラメータセット<値>
		paramBean.setString(t220003gBean.getCdKaisya());	// 会社コード
		paramBean.setString(t220003gBean.getCdHanbaitn());	// 販売店コード
		paramBean.setString(t220003gBean.getDdHannyu());	// 搬入日
		paramBean.setString(t220003gBean.getNoKanri());		// 管理番号
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　start
		if (!t220003gBean.getKbScenter().equals(UcarConst.KB_SCENTER_SCENTER)) {
			paramBean.setString(t220003gBean.getCdZaitenpo());	// 在庫店舗コード
		}
		// 2013.04.03 C.Ohta 修正　搬入拠点分散対応２　end
		paramBean.setString(t220003gBean.getKbCheck());		// チェック内容区分
		paramBean.setString(t220003gBean.getDdCheck());		// チェック日
		paramBean.setTimestamp(executeDate);				// データ作成日時
		paramBean.setTimestamp(executeDate);				// データ更新日時
		paramBean.setString(t220003gBean.getCdSksisya());	// 作成ユーザID
		paramBean.setString(t220003gBean.getCdKsnsya());	// 更新ユーザID
		paramBean.setString(t220003gBean.getCdSksiapp());	// 作成アプリID
		paramBean.setString(t220003gBean.getCdKsnapp());	// 更新アプリID

		SimpleExecuteResultBean resultBean = executeSimpleUpdateQuery(paramBean);

		return resultBean;
	}

}
