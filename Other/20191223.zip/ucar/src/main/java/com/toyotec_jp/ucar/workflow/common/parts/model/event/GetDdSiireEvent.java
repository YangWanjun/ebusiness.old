package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;


/**
 * <strong>ai21仕入日取得イベント</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2013/05/20 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetDdSiireEvent extends UcarEvent {

	/**	 */
	private static final long serialVersionUID = 1L;

	/** 会社コード */
	private String	cdKaisya;
	/** 販売店コード */
	private String	cdHanbaitn;
	/** ai21車両NO */
	private String noSyaryou;

	/**
	 * cdKaisyaを取得する。
	 * @return cdKaisya 会社コード
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}

	/**
	 * cdKaisyaを設定する。
	 * @param cdKaisya 会社コード
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}

	/**
	 * cdHanbaitnを取得する。
	 * @return cdHanbaitn 販売店コード
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}

	/**
	 * cdHanbaitnを設定する。
	 * @param cdHanbaitn 販売店コード
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

	/**
	 * noSyaryouを取得する。
	 * @return noSyaryou ai21車両NO
	 */
	public String getNoSyaryou() {
		return noSyaryou;
	}

	/**
	 * noSyaryouを設定する。
	 * @param noSyaryou ai21車両NO
	 */
	public void setNoSyaryou(String noSyaryou) {
		this.noSyaryou = noSyaryou;
	}

}
