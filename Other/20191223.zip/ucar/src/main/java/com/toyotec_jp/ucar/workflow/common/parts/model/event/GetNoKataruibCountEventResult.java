package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEventResult;

/**
 * <strong>型式指定類別NO件数取得イベントリザルト</strong>
 * <p></p>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/07/05 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class GetNoKataruibCountEventResult implements UcarEventResult {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 型式指定類別NO件数 */
	private int countNoKataruib;

	/**
	 * countNoKataruibを取得する。
	 * @return countNoKataruib
	 */
	public int getCountNoKataruib() {
		return countNoKataruib;
	}

	/**
	 * countNoKataruibを設定する。
	 * @param countNoKataruib
	 */
	public void setCountNoKataruib(int countNoKataruib) {
		this.countNoKataruib = countNoKataruib;
	}

}
