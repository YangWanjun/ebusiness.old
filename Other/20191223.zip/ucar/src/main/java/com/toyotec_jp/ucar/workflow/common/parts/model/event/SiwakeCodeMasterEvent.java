package com.toyotec_jp.ucar.workflow.common.parts.model.event;

import com.toyotec_jp.ucar.base.model.event.UcarEvent;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.UserInformationBean;


/**
 * <strong>仕分用コード区分マスタ操作用イベント。</strong>
 *
 * @author C.O(TEC)
 * @version 1.00 2013/02/05 新規作成<br>
 * @since 1.00
 * @category [[U-Car商品化システム(共通)]]
 */
public class SiwakeCodeMasterEvent extends UcarEvent {

	private static final long serialVersionUID = 131183458984028469L;

	/** 区分ID */
	private String kbID;
	/** ユーザーインフォビーン */
	private UserInformationBean userInfoBean;
	/**	会社コード */
	private String cdKaisya;
	/**	販売店コード */
	private String cdHanbaitn;
	

	/**
	 * 区分IDを取得します。
	 * @return 区分ID
	 */
	public String getKbID() {
	    return kbID;
	}

	/**
	 * 区分IDを設定します。
	 * @param kbID 区分ID
	 */
	public void setKbID(String kbID) {
	    this.kbID = kbID;
	}

	/**
	 * ユーザーインフォビーンを取得します。
	 * @return ユーザーインフォビーン
	 */
	public UserInformationBean getUserInfoBean() {
	    return userInfoBean;
	}

	/**
	 * ユーザーインフォビーンを設定します。
	 * @param userInfoBean ユーザーインフォビーン
	 */
	public void setUserInfoBean(UserInformationBean userInfoBean) {
	    this.userInfoBean = userInfoBean;
	}
	/**
	 * 会社コードを返却
	 * @return
	 */
	public String getCdKaisya() {
		return cdKaisya;
	}
	/**
	 * 会社コードを設定
	 * @param cdKaisya
	 */
	public void setCdKaisya(String cdKaisya) {
		this.cdKaisya = cdKaisya;
	}
	/**
	 * 販売店を返却
	 * @return
	 */
	public String getCdHanbaitn() {
		return cdHanbaitn;
	}
	/**
	 * 販売店を設定
	 * @param cdHanbaitn
	 */
	public void setCdHanbaitn(String cdHanbaitn) {
		this.cdHanbaitn = cdHanbaitn;
	}

}
