package com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.data;

import com.toyotec_jp.im_common.system.exception.TecDAOException;
import com.toyotec_jp.ucar.base.model.event.ResultArrayList;
import com.toyotec_jp.ucar.workflow.allclean.cleanplan.model.object.CleanPlanUnPlanDataBean;
import com.toyotec_jp.ucar.workflow.common.parts.model.object.Ucba004mBean;

/**
 * <strong>まるクリ作業計画入力DAOインターフェース。</strong>
 * @author H.T(TOYOTEC)
 * @version 1.00 2011/11/17 新規作成<br>
 * @since 1.00
 * @category [[まるクリ作業計画入力]]
 */
public interface CleanPlanDAOIF {

	/**
	 * 未計画情報 画面出力値取得処理
	 * @param cdKaisya		会社コード
	 * @param cdJigyosyo	事業所コード
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<CleanPlanUnPlanDataBean> selectUnPlanList(String cdKaisya,
																	  String cdJigyosyo) throws TecDAOException;

	/**
	 * コード区分マスタ まるクリ色コード 画面出力値取得処理
	 * @param cdKaisya		会社コード
	 * @param cdJigyosyo	事業所コード
	 * @throws LcmDAOException DAO例外クラス
	 */
	public ResultArrayList<Ucba004mBean> selectColorCodeList(String cdKaisya,
			String cdJigyosyo) throws TecDAOException;

}
